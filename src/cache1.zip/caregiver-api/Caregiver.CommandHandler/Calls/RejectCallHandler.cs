﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Calls;
using Caregiver.Domain.DomainTransferObjects.Calls;
using MediatR;
namespace Caregiver.CommandHandler.Calls
{
    public class RejectCallHandler : IRequestHandler<RejectCallRequest, RejectCallResponse>
    {
        private readonly IRejectCallRepository _rejectCallRepository;

        public RejectCallHandler(IRejectCallRepository rejectCallRepository)
        {
            _rejectCallRepository = Guard.Against.Null(rejectCallRepository);
        }

        public async Task<RejectCallResponse> Handle(RejectCallRequest request, CancellationToken cancellationToken)
        {
            return await _rejectCallRepository.RejectCall(request);
        }
    }
}
