﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.RTM;
using Caregiver.Domain.DomainTransferObjects.RTM;
using MediatR;

namespace Caregiver.CommandHandler.RTM
{
    public class EditVisitReasonHandler : IRequestHandler<EditVisitReasonRequest, List<EditVisitReasonResponse>>
    {
        private readonly IEditVisitReasonRepository _reasonRepository;

        public EditVisitReasonHandler(IEditVisitReasonRepository reasonRepository)
        {
            _reasonRepository = Guard.Against.Null(reasonRepository);
        }

        public async Task<List<EditVisitReasonResponse>> Handle(EditVisitReasonRequest request, CancellationToken cancellationToken)
        {
            return await _reasonRepository.GetEditVisitReasons(request);
        }
    }
}
