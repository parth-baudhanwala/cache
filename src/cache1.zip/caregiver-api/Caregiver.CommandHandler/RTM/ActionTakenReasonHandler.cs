﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.RTM;
using Caregiver.Domain.DomainTransferObjects.RTM;
using MediatR;

namespace Caregiver.CommandHandler.Reason
{
    public class ActionTakenReasonHandler : IRequestHandler<ActionTakenReasonRequest, List<ActionTakenReasonResponse>>
    {
        private readonly IActionTakenReasonRepository _actionTakenReasonRepository;

        public ActionTakenReasonHandler(IActionTakenReasonRepository actionTakenReasonRepository)
        {
            _actionTakenReasonRepository = Guard.Against.Null(actionTakenReasonRepository);
        }

        public async Task<List<ActionTakenReasonResponse>> Handle(ActionTakenReasonRequest request, CancellationToken cancellationToken)
        {
            return await _actionTakenReasonRepository.GetActionTakenReasonsByReasonID(request);
        }
    }
}
