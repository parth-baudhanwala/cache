﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.GlobalVisit
{
    public class LinkCallHandler : IRequestHandler<GlobalLinkCallRequest, LinkCallResponse>
    {
        private readonly IGlobalLinkCallRepository _globalLinkCallRepository;

        public LinkCallHandler(IGlobalLinkCallRepository globalLinkCallRepository)
        {
            _globalLinkCallRepository = Guard.Against.Null(globalLinkCallRepository);
        }

        public async Task<LinkCallResponse> Handle(GlobalLinkCallRequest request, CancellationToken cancellationToken)
        {
            return await _globalLinkCallRepository.LinkCall(request);
        }
    }
}
