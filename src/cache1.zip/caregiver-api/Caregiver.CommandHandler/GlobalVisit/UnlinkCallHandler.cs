﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.GlobalVisit
{
    public class UnlinkCallHandler : IRequestHandler<GlobalUnlinkCallRequest, UnlinkCallResponse>
    {
        private readonly IGlobalUnlinkCallRepository _globalunlinkCallRepository;

        public UnlinkCallHandler(IGlobalUnlinkCallRepository globalLinkCallRepository)
        {
            _globalunlinkCallRepository = Guard.Against.Null(globalLinkCallRepository);
        }

        public async Task<UnlinkCallResponse> Handle(GlobalUnlinkCallRequest request, CancellationToken cancellationToken)
        {
            return await _globalunlinkCallRepository.UnLinkCall(request);
        }
    }
}
