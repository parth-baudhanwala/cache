﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.GlobalVisit
{
    public class ACSHandler : IRequestHandler<ACSDetailRequest, List<ACSDetailResponse>>
    {
        private readonly IACSRepository _acsRepository;
        public ACSHandler(IACSRepository acsRepository)
        {
            _acsRepository = Guard.Against.Null(acsRepository);
        }

        public async Task<List<ACSDetailResponse>> Handle(ACSDetailRequest request, CancellationToken cancellationToken)
        {
            return await _acsRepository.GetACSData(request);
        }
    }
}
