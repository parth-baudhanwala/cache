﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.GlobalVisit
{
    public class ShowMatchingCallsDetailHandler : IRequestHandler<GlobalMatchingCallsDetailRequest, List<MatchingCallsDetailResponse>>
    {
        private readonly IGlobalShowMatchingCallsDetailRepository _globalShowMatchingCallsDetailRepository;

        public ShowMatchingCallsDetailHandler(IGlobalShowMatchingCallsDetailRepository globalShowMatchingCallsDetailRepository)
        {
            _globalShowMatchingCallsDetailRepository = Guard.Against.Null(globalShowMatchingCallsDetailRepository);
        }

        public async Task<List<MatchingCallsDetailResponse>> Handle(GlobalMatchingCallsDetailRequest request, CancellationToken cancellationToken)
        {
            return await _globalShowMatchingCallsDetailRepository.ShowMatchingCalls(request);
        }
    }
}
