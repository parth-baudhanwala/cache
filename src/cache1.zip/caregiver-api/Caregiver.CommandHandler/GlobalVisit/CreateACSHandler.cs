﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using MediatR;

namespace Caregiver.CommandHandler.GlobalVisit
{
    public class CreateACSHandler : IRequestHandler<CreateACSScheduleRequest, List<CreateACSScheduleResponse>>
    {
        private readonly ICreateACSScheduleRepository _createACSScheduleRepository;

        public CreateACSHandler(ICreateACSScheduleRepository createACSScheduleRepository)
        {
            _createACSScheduleRepository = Guard.Against.Null(createACSScheduleRepository);
        }

        public async Task<List<CreateACSScheduleResponse>> Handle(CreateACSScheduleRequest request, CancellationToken cancellationToken)
        {
            return await _createACSScheduleRepository.CreateACSSchedule(request);
        }
    }
}
