﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using MediatR;

namespace Caregiver.CommandHandler.GlobalVisit
{
    public class LinkableVisitHandler : IRequestHandler<LinkableVisitRequest, List<LinkableVisitResponse>>
    {
        private readonly ILinkableVisitRepository _linkableVisitRepository;

        public LinkableVisitHandler(ILinkableVisitRepository linkableVisitRepository)
        {
            _linkableVisitRepository = Guard.Against.Null(linkableVisitRepository);
        }

        public async Task<List<LinkableVisitResponse>> Handle(LinkableVisitRequest request, CancellationToken cancellationToken)
        {
            return await _linkableVisitRepository.LinkableVisits(request);
        }
    }
}
