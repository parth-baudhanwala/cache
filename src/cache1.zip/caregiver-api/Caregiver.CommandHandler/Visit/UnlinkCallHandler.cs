﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.Visit
{
    public class UnlinkCallHandler : IRequestHandler<UnlinkCallRequest, UnlinkCallResponse>
    {
        private readonly IUnlinkCallRepository _unlinkCallRepository;

        public UnlinkCallHandler(IUnlinkCallRepository unlinkCallRepository)
        {
            _unlinkCallRepository = Guard.Against.Null(unlinkCallRepository);
        }

        public async Task<UnlinkCallResponse> Handle(UnlinkCallRequest request, CancellationToken cancellationToken)
        {
            return await _unlinkCallRepository.UnlinkCall(request);
        }
    }
}
