﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.Visit
{
    public class MoveCallsToCallMaintenanceHandler : IRequestHandler<MoveCallsToCallMaintenanceRequest, MoveCallsToCallMaintenanceResponse>
    {
        private readonly IMoveCallsToCallMaintenanceRepository _moveCallsToCallMaintenanceRepository;

        public MoveCallsToCallMaintenanceHandler(IMoveCallsToCallMaintenanceRepository moveCallsToCallMaintenanceRepository)
        {
            _moveCallsToCallMaintenanceRepository = Guard.Against.Null(moveCallsToCallMaintenanceRepository);
        }

        public async Task<MoveCallsToCallMaintenanceResponse> Handle(MoveCallsToCallMaintenanceRequest request, CancellationToken cancellationToken)
        {
            return await _moveCallsToCallMaintenanceRepository.MoveCallsToCallMaintenance(request);
        }
    }
}
