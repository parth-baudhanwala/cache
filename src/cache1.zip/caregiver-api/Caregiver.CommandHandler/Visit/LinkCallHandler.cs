﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.Visit
{
    public class LinkCallHandler : IRequestHandler<LinkCallRequest, LinkCallResponse>
    {
        private readonly ILinkCallRepository _linkCallRepository;

        public LinkCallHandler(ILinkCallRepository linkCallRepository)
        {
            _linkCallRepository = Guard.Against.Null(linkCallRepository);
        }

        public async Task<LinkCallResponse> Handle(LinkCallRequest request, CancellationToken cancellationToken)
        {
            return await _linkCallRepository.LinkCall(request);
        }
    }
}
