﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.Visit
{
    public class VisitDetailsHandler : IRequestHandler<VisitDetailsRequest, VisitDetailsResponse>
    {
        private readonly IVisitDetailsRepository _visitDetailsRepository;

        public VisitDetailsHandler(IVisitDetailsRepository visitDetailsRepository)
        {
            _visitDetailsRepository = Guard.Against.Null(visitDetailsRepository);
        }

        public async Task<VisitDetailsResponse> Handle(VisitDetailsRequest request, CancellationToken cancellationToken)
        {
            return await _visitDetailsRepository.VisitDetails(request);
        }
    }

}
