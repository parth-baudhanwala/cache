﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;

namespace Caregiver.CommandHandler.Visit
{
    public class ShowMatchingCallsDetailHandler : IRequestHandler<MatchingCallsDetailRequest, List<MatchingCallsDetailResponse>>
    {
        private readonly IShowMatchingCallsDetailRepository _showMatchingCallsDetailRepository;

        public ShowMatchingCallsDetailHandler(IShowMatchingCallsDetailRepository showMatchingCallsDetailRepository)
        {
            _showMatchingCallsDetailRepository = Guard.Against.Null(showMatchingCallsDetailRepository);
        }

        public async Task<List<MatchingCallsDetailResponse>> Handle(MatchingCallsDetailRequest request, CancellationToken cancellationToken)
        {
            return await _showMatchingCallsDetailRepository.ShowMatchingCalls(request);
        }
    }
}
