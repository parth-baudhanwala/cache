﻿using Caregiver.Core.Interfaces.BroadcastHistory;
using Caregiver.Domain.DomainTransferObjects.BroadcastHistory;
using MediatR;

namespace Caregiver.CommandHandler.BroadcastHistory
{
    public class BroadcastHistoryCancelHandler : IRequestHandler<BroadcastHistoryCancelRequest, long>
    {
        readonly IBroadcastHistoryRepository _broadcastHistoryRepository;
        public BroadcastHistoryCancelHandler(IBroadcastHistoryRepository broadcastHistoryRepository)
        {
            _broadcastHistoryRepository = broadcastHistoryRepository;
        }

        public async Task<long> Handle(BroadcastHistoryCancelRequest request, CancellationToken cancellationToken)
        {
            return await _broadcastHistoryRepository.BroadcastHistoryCancelByID(request);
        }
    }
}
