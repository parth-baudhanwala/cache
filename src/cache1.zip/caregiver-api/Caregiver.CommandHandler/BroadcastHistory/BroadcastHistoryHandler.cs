﻿using Caregiver.Core.Interfaces.BroadcastHistory;
using Caregiver.Domain.DomainTransferObjects.BroadcastHistory;
using Caregiver.Domain.DomainTransferObjects.TimeZone;
using Caregiver.Infrastructure;
using MediatR;

namespace Caregiver.CommandHandler.BroadcastHistory
{
    public class BroadcastHistoryHandler : IRequestHandler<BroadcastHistoryRequest, List<BroadcastHistoryResponse>>
    {
        readonly ITimeZoneService _timeZoneService;
        readonly IBroadcastHistoryRepository _broadcastHistoryRepository;
        public BroadcastHistoryHandler(IBroadcastHistoryRepository broadcastHistoryRepository, ITimeZoneService timeZoneService)
        {
            _broadcastHistoryRepository = broadcastHistoryRepository;
            _timeZoneService = timeZoneService;
        }
        public async Task<List<BroadcastHistoryResponse>> Handle(BroadcastHistoryRequest request, CancellationToken cancellationToken)
        {
            List<TimeZoneResponse> timeZoneResponses = new();
            string EntpApiUrl = string.Empty;
            if (request.UserPrimaryOfficeID > 0)
            {
                List<int> distinctOfficeIds = new List<int>
                {
                    request.UserPrimaryOfficeID
                };
                if (!string.IsNullOrEmpty(request.EntpApiUrl)) EntpApiUrl = request.EntpApiUrl;
                timeZoneResponses = _timeZoneService.GetOfficeTimeZone(distinctOfficeIds, EntpApiUrl);
            }
            return await _broadcastHistoryRepository.BroadcastHistory(request, timeZoneResponses);
        }
    }
}
