﻿using Caregiver.Core.Interfaces.Common;
using Caregiver.Domain.DomainTransferObjects.Common;
using MediatR;

namespace Caregiver.CommandHandler.Common
{
    public class OfficesHandler : IRequestHandler<OfficesRequest, List<OfficesResponse>>
    {
        readonly ICommonRepository _commonRepository;
        public OfficesHandler(ICommonRepository commonRepository)
        {
            _commonRepository = commonRepository;
        }

        public async Task<List<OfficesResponse>> Handle(OfficesRequest request, CancellationToken cancellationToken)
        {
            return await _commonRepository.Offices(request);
        }
    }
}
