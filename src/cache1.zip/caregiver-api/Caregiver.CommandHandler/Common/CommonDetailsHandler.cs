﻿using Caregiver.Core.Interfaces.Common;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Infrastructure.Cache;
using MediatR;

namespace Caregiver.CommandHandler.Common
{
    public class CommonDetailsHandler : IRequestHandler<CommonDetailsRequest, List<CommonDetailsResponse>>
    {
        readonly ICommonRepository _commonRepository;
        readonly IRedisConnectionService _redisConnectionService;
        public CommonDetailsHandler(ICommonRepository commonRepository, IRedisConnectionService redisConnectionService)
        {
            _commonRepository = commonRepository;
            _redisConnectionService = redisConnectionService;
        }

        public async Task<List<CommonDetailsResponse>> Handle(CommonDetailsRequest request, CancellationToken cancellationToken)
        {
            return await _commonRepository.CommonDetails(request);
        }
    }
}
