﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Caregiver;
using Caregiver.Domain.DomainTransferObjects.Caregiver;
using MediatR;

namespace Caregiver.CommandHandler.Caregiver
{
    public class ValidateActivationCodeHandler : IRequestHandler<ValidateActivationCodeRequest, ValidateActivationCodeResponse>
    {
        private readonly IValidateActivationCodeRepository _validateActivationCodeRepository;

        public ValidateActivationCodeHandler(IValidateActivationCodeRepository validateActivationCodeRepository)
        {
            _validateActivationCodeRepository = Guard.Against.Null(validateActivationCodeRepository);
        }

        public async Task<ValidateActivationCodeResponse> Handle(ValidateActivationCodeRequest request, CancellationToken cancellationToken)
        {
            return await _validateActivationCodeRepository.ValidateActivationCode(request);
        }
    }
}
