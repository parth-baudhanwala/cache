﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Caregiver;
using Caregiver.Domain.DomainTransferObjects.Caregiver;
using MediatR;

namespace Caregiver.CommandHandler.Caregiver
{
    public class GetCaregiverAgencyDetailsHandler : IRequestHandler<GetCaregiverAgencyDetailsRequest, GetCaregiverAgencyDetailsResponse>
    {
        private readonly IMobileUserRepository _mobileUserRepository;

        public GetCaregiverAgencyDetailsHandler(IMobileUserRepository MobileUserRepository)
        {
            _mobileUserRepository = Guard.Against.Null(MobileUserRepository);
        }

        public async Task<GetCaregiverAgencyDetailsResponse> Handle(GetCaregiverAgencyDetailsRequest request, CancellationToken cancellationToken)
        {
            return await _mobileUserRepository.GetCaregiverAgencyDetails(request);
        }
    }
}
