﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces.Caregiver;
using Caregiver.Domain.DomainTransferObjects.Caregiver;
using MediatR;

namespace Caregiver.CommandHandler.Caregiver
{
    public class RegisterMobileUserlHandler : IRequestHandler<RegisterMobileUserRequest, RegisterMobileUserResponse>,
        IRequestHandler<ActivationCodeGenerationRequest, ActivationCodeGenerationResponse>,
        IRequestHandler<UserAgencyLinkRequest, UserAgencyLinkResponse>
    {
        private readonly IMobileUserRepository _mobileUserRepository;

        public RegisterMobileUserlHandler(IMobileUserRepository MobileUserRepository)
        {
            _mobileUserRepository = Guard.Against.Null(MobileUserRepository);
        }

        public async Task<RegisterMobileUserResponse> Handle(RegisterMobileUserRequest request, CancellationToken cancellationToken)
        {
            return await _mobileUserRepository.RegisterMobileUser(request);
        }
        public async Task<ActivationCodeGenerationResponse> Handle(ActivationCodeGenerationRequest request, CancellationToken cancellationToken)
        {
            return await _mobileUserRepository.ActivationCodeGeneration(request);

        }
        public async Task<UserAgencyLinkResponse> Handle(UserAgencyLinkRequest request, CancellationToken cancellationToken)
        {
            return await _mobileUserRepository.LinkUnlinkMobileUser(request);

        }
    }
}
