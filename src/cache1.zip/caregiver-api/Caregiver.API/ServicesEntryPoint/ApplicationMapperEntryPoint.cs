﻿namespace Caregiver.API.ServicesEntryPoint
{
    /// <summary>
    /// Used to get application entry point
    /// </summary>
    public class ApplicationMapperEntryPoint
    {
    }
}
