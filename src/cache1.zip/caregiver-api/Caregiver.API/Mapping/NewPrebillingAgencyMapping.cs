﻿using Caregiver.Domain.DomainTransferObjects.DapperResponses;
using Caregiver.Domain.DomainTransferObjects.Dtos;
using Mapster;

namespace Caregiver.API.Mapping
{
    internal class NewPrebillingAgencyMapping : IRegister
    {
        public void Register(TypeAdapterConfig config)
        {
            config.NewConfig<NewPrebillingAgency, NewPrebillingAgencyDTO>()
                .Map(destination => destination.Name, source => source.VendorName)
                .Map(destination => destination.VendorId, source => source.VendorID)
                .Map(destination => destination, source => source);
        }
    }
}
