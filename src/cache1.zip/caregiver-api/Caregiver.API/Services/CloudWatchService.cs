﻿using Serilog;
using Serilog.Formatting.Compact;

namespace Caregiver.API.Services
{
    /// <summary>
    /// Servie class for cloud watch
    /// </summary>
    public static class CloudWatchService
    {
        /// <summary>
        /// Used for add Amazon Cloud Watch Logger
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static IWebHostBuilder AddAmazonCloudWatchLogger(this IWebHostBuilder builder) =>
            builder.UseSerilog((hostingContext, loggerConfiguration) =>
            {
                loggerConfiguration.WriteTo.Console(restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Information, formatter: new RenderedCompactJsonFormatter())
                .MinimumLevel.Information().Enrich.FromLogContext();
            });
    }
}
