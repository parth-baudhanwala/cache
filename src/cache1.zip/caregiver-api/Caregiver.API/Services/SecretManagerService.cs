﻿using HHAExchange.AWSSecretsManager.Common;

namespace Caregiver.API.Services
{
    /// <summary>
    /// Used for Configure Secret Manager Service
    /// </summary>
    public static class SecretManagerService
    {
        private static IConfigurationRoot? _instance;

        /// <summary>
        /// Used for add Amazon secret manager builder
        /// </summary>
        /// <param name="builder"></param>
        /// <returns>Return configuration</returns>
        public static IWebHostBuilder AddAmazonSecretsManagerBuilder(this IWebHostBuilder builder) =>
            builder.ConfigureAppConfiguration((hostingContext, configBuilder) =>
            {
                configBuilder.SetBasePath(Directory.GetCurrentDirectory());
                configBuilder.AddJsonFile(Constants.Configuration.AppSettings, optional: false, reloadOnChange: true);
                configBuilder.AddJsonFile(Constants.Configuration.StoreProcedure, optional: false, reloadOnChange: true);
                configBuilder.AddSecretsManagerConfiguration();
            });

        /// <summary>
        /// Used for add Amazon secret manager configuration
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static IConfigurationRoot AddSecretsManagerConfiguration(this IConfigurationBuilder builder)
        {
            _instance = builder.Build();
            if (_instance.GetSection("AWSSecretsManager:ConnectionStringSecretName").Exists())
            {
                var awsSecretManagerConfig = _instance.GetSection("AWSSecretsManager:ConnectionStringSecretName");
                using IEnumerator<IConfigurationSection> secretConnectionStringConfig = awsSecretManagerConfig.GetChildren().GetEnumerator();
                List<SecretConnectionStringRelationModel> secretConnectionStringRelationModelsList = new();

                while (secretConnectionStringConfig.MoveNext())
                {
                    secretConnectionStringRelationModelsList.Add(new SecretConnectionStringRelationModel()
                    {
                        ConnectionStringName = "ConnectionStrings:" + secretConnectionStringConfig.Current.Key,
                        SecretName = secretConnectionStringConfig.Current.Value
                    });
                }
                if (secretConnectionStringRelationModelsList.Any())
                {
                     string format = "Server={0};Database={1};User Id={2};Password={3};";
                    _instance = builder.AddSecretsManager(configurator: options =>
                            {
                                options.AcceptedSecretArns = new List<string> { _instance["AWSSecretsManager:SecretName"] };
                                options.AcceptedConnectionStringsSecretArns = secretConnectionStringRelationModelsList;
                                options.ConfigureConnectionStringMapping = (connectionStringSecretValues, secretConnectionStringRelationModel) =>
                                {
                                    string connectionString = string.Format(format,
                                    connectionStringSecretValues["host"], connectionStringSecretValues["dbname"], connectionStringSecretValues["username"], connectionStringSecretValues["password"]);
                                    connectionString += $"Application Name={_instance.GetValue<string>("ApplicationName")};";
                                    return connectionString;
                                };
                            }).Build();
                }
            }
            
            SecretManagerConnectionStatus();

            return _instance;
        }

        private static Action SecretManagerConnectionStatus = () =>
        {
            if (SecretsManagerConnectionState.ConnectionState == SecretsManagerConnectionStateEnum.Connected)
            {
                //Do Nothing
            }
            else if (SecretsManagerConnectionState.ConnectionState == SecretsManagerConnectionStateEnum.NoCredentialsLocated)
            {
                throw new ArgumentException("Failed loading of AWS secrets. No credentials located.", SecretsManagerConnectionState.ConnectionException);
            }
            else if (SecretsManagerConnectionState.ConnectionState == SecretsManagerConnectionStateEnum.ConnectionError)
            {
                throw new ArgumentException("Failed loading of AWS secrets", SecretsManagerConnectionState.ConnectionException);
            }
        };
    }
}

