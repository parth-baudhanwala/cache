﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.GlobalVisit
{
    /// <summary>
    /// Show Matching ACS Detail Controller for Global IDs.
    /// </summary>
    [Route(RouteContfiguration.GlobalACSProcess)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class ACSController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Constructor for show Matching Calls Detail Controller.
        /// </summary>
        /// <param name="mediator"></param>
        public ACSController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used to get ACS Data by Globel IDs.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        [Route(RouteContfiguration.ShowMatchingACSDetailMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.ShowMatchingACSDetailRouteDescription, Description = RouteContfiguration.ShowMatchingACSDetailRouteDescription, Tags = new[] { RouteContfiguration.GlobalACSEndPoint })]
        [ProducesResponseType(typeof(ACSDetailResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<ACSDetailResponse>>> ShowMatchingACSData([FromBody] ACSDetailRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }

        /// <summary>
        /// Used to API for Create ACS Schedules From CallMaintenance Data.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Created Schedules details.</returns>
        [HttpPost]
        [Route(RouteContfiguration.GlobalACSPostMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.GlobalACSPostMethodRoute, Description = RouteContfiguration.GlobalACSPostMethodRouteDescription, Tags = new[] { RouteContfiguration.GlobalACSEndPoint })]
        [ProducesResponseType(typeof(List<CreateACSScheduleResponse>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<List<CreateACSScheduleResponse>>> CreateSchedulesFromACS([FromBody] CreateACSScheduleRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
