﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.GlobalVisit
{
    /// <summary>
    /// Show Matching Calls Detail Controller for Global VisitID.
    /// </summary>
    [Route(RouteContfiguration.GlobalVisitCallTypeRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class ShowMatchingCallsDetailController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Constructor for show Matching Calls Detail Controller.
        /// </summary>
        /// <param name="mediator"></param>
        public ShowMatchingCallsDetailController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used to show matching Calls from Global VisitIDs.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>List of call details</returns>
        [HttpGet]
        [Route(RouteContfiguration.ShowMatchingCallsDetailMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.ShowMatchingCallsDetailMethodRoute, Description = RouteContfiguration.ShowMatchingCallsDetailRouteDescription, Tags = new[] { RouteContfiguration.GlobalVisitEndPoint })]
        [ProducesResponseType(typeof(MatchingCallsDetailResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<MatchingCallsDetailResponse>>> ShowMatchingCalls([FromRoute] GlobalMatchingCallsDetailRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
