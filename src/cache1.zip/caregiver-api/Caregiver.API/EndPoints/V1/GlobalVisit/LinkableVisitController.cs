﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.GlobalVisit
{
    /// <summary>
    /// Linkable Visit Controller.
    /// </summary>
    [Route(RouteContfiguration.LinkableVisitRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class LinkableVisitController : BaseApiController
    {
        private readonly IMediator _mediator;
        /// <summary>
        /// Constructor for Linkable Visit Controller.
        /// </summary>
        /// <param name="mediator"></param>
        public LinkableVisitController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used to get Linkable Visits Globel VisitIDs.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Linkable Visits Globel VisitIDs</returns>
        [HttpPost]
        [Route(RouteContfiguration.LinkableVisitMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.LinkableVisitMethodRoute, Description = RouteContfiguration.LinkableVisitRouteDescription, Tags = new[] { RouteContfiguration.GlobalVisitEndPoint })]
        [ProducesResponseType(typeof(LinkableVisitResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<LinkableVisitResponse>>> LinkableVisit([FromBody] LinkableVisitRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
