﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.GlobalVisit
{
    /// <summary>
    /// Link Call Controller.
    /// </summary>
    [Route(RouteContfiguration.GlobalVisitRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class LinkCallController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Constructor for Link Call Controller for Global VisitID.
        /// </summary>
        /// <param name="mediator"></param>
        public LinkCallController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used to Link Call from Global VisitIDs.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>ReturnValue, MessageText</returns>
        [HttpPost]
        [Route(RouteContfiguration.LinkCallMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.LinkCallMethodRoute, Description = RouteContfiguration.LinkCallRouteDescription, Tags = new[] { RouteContfiguration.GlobalVisitEndPoint })]
        [ProducesResponseType(typeof(LinkCallResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<LinkCallResponse>> LinkCall([FromBody] GlobalLinkCallRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
