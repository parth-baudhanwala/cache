﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Core.Constants;
using Caregiver.Domain.DomainTransferObjects.Caregiver;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Caregiver
{

    /// <summary>
    /// Validate Activation Code Controller
    /// </summary>
    [Route(RouteContfiguration.ValidateActivationCodeRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class ValidateActivationCodeController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Constructor for Validate Activation Code Controller.
        /// </summary>
        /// <param name="mediator"></param>
        public ValidateActivationCodeController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used for validate the Activation Code is active or not.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="caregiveruserglobalid"></param>
        /// <returns></returns>
        [HttpPost]
        [Route(RouteContfiguration.ValidateActivationCodeMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.ValidateActivationCodeMethodRoute, Description = RouteContfiguration.ValidateActivationCodeDescription, Tags = new[] { RouteContfiguration.CaregiverEndPoint })]
        [ProducesResponseType(typeof(ValidateActivationCodeResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType((int)HttpStatusCode.UnprocessableEntity)]
        public async Task<ActionResult<ValidateActivationCodeResponse>> ValidateActivationCode([FromBody] ValidateActivationCodeRequest request, [FromRoute] Guid caregiveruserglobalid)
        {
            if (Request.Headers.TryGetValue("transaction_id", out var transactionID) && Guid.TryParse(transactionID, out var transactionGuid))
            {
                request.CaregiverUserGlobalID = caregiveruserglobalid;
                request.TransactionID = transactionGuid;

                var response = await this._mediator.Send(request);

                if (response == null)
                {
                    return UnprocessableEntity(ValidationMessageText.CommonNoResultMsg);
                }

                response.TransactionID = transactionGuid;

                if (!string.IsNullOrEmpty(response.MessageText) && response.MessageText.Length > 0)
                {
                    return UnprocessableEntity(response.MessageText);
                }

                return GetResult(response);
            }
            else
            {
                return BadRequest(ValidationMessageText.TransactionIDNotFoundMsg);
            }
        }
    }
}
