﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Caregiver;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Caregiver
{
    /// <summary>
    ///  Mobile User Controller.
    /// </summary>
    [Route(RouteContfiguration.MobileUserRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class MobileUserController : BaseApiController
    {
        private readonly IMediator _mediator;
        /// <summary>
        /// Constructor for Mobile User Controller.
        /// </summary>
        /// <param name="mediator"></param>
        public MobileUserController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used for link/register mobile user
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return response of link/register mobile user</returns>
        [HttpPost]
        [Route(RouteContfiguration.RegisterMobileUserMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.RegisterMobileUserMethodRoute, Description = RouteContfiguration.RegisterMobileUserRouteDescription, Tags = new[] { RouteContfiguration.CaregiverEndPoint })]
        [ProducesResponseType(typeof(RegisterMobileUserResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<RegisterMobileUserResponse>> RegisterMobileUser([FromBody] RegisterMobileUserRequest request, [FromRoute] Guid globalcaregiverid)
        {
            if (Request.Headers.TryGetValue("transaction_id", out var transactionId) && Guid.TryParse(transactionId, out var transactionGuid))
            {
                request.CaregiverGlobalId = globalcaregiverid;

                var response = await this._mediator.Send(request);

                response.TransactionId = transactionGuid;

                if (response.ReturnValue < 0)
                {
                    return UnprocessableEntity(response);
                }
                return GetResult(response);
            }
            else
            {
                return BadRequest("Transaction ID in request header is missing or not in proper format.");
            }
        }

        /// <summary>
        /// Used for Generate Activation Code
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return response of Generate Activation Code</returns>
        [HttpPost]
        [Route(RouteContfiguration.ActivationCodeGenerationMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.ActivationCodeGenerationMethodRoute, Description = RouteContfiguration.ActivationCodeGenerationDescription, Tags = new[] { RouteContfiguration.CaregiverEndPoint })]
        [ProducesResponseType(typeof(ActivationCodeGenerationResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]

        public async Task<ActionResult<ActivationCodeGenerationResponse>> ActivationCodeGenerate([FromBody] ActivationCodeGenerationRequest request, [FromRoute] Guid globalcaregiverid)
        {
            if (Request.Headers.TryGetValue("transaction_id", out var transactionId) && Guid.TryParse(transactionId, out var transactionGuid))
            {
                request.CaregiverGlobalId = globalcaregiverid;

                var response = await this._mediator.Send(request);

                response.TransactionId = transactionGuid;

                if (string.IsNullOrEmpty(response.ActivationCode))
                {
                    return UnprocessableEntity(response);
                }
                return GetResult(response);
            }
            else
            {
                return BadRequest("Transaction ID in request header is missing or not in proper format.");
            }
        }

        [HttpGet]
        [Route(RouteContfiguration.CaregiverAgencyDetailsRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.CaregiverAgencyDetailsRoute, Description = RouteContfiguration.CaregiverAgencyDetailsRouteDescription, Tags = new[] { RouteContfiguration.CaregiverEndPoint })]
        [ProducesResponseType(typeof(GetCaregiverAgencyDetailsResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<GetCaregiverAgencyDetailsResponse>> GetCaregiverAgencyDetails([FromRoute] Guid globalcaregiverid)
        {
            if (Request.Headers.TryGetValue("transaction_id", out var transactionId) && Guid.TryParse(transactionId, out var transactionGuid))
            {
                var response = await this._mediator.Send(new GetCaregiverAgencyDetailsRequest() { GlobalCaregiverID = globalcaregiverid });

                response.TransactionID = transactionGuid;

                return GetResult(response);
            }
            else
            {
                return BadRequest("Transaction ID in request header is missing or not in proper format.");
            }
        }

        /// <summary>
        /// Used for User Agency Link Unlink
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return response of Agency Link Unlink</returns>
        [HttpPost]
        [Route(RouteContfiguration.UserAgencyLinkUnlinkMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.UserAgencyLinkUnlinkMethodRoute,
            Description = RouteContfiguration.UserAgencyLinkUnlinkDescription, Tags = new[] { RouteContfiguration.CaregiverEndPoint })]
        [ProducesResponseType(typeof(RegisterMobileUserResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]

        public async Task<ActionResult<UserAgencyLinkResponse>> UserAgencyLinkUnlink([FromBody] UserAgencyLinkRequest request,
            [FromRoute] Guid globalcaregiverid)
        {
            if (Request.Headers.TryGetValue("transaction_id", out var transactionId) && Guid.TryParse(transactionId, out var transactionGuid))
            {
                request.GlobalCaregiverID = globalcaregiverid;

                var response = await this._mediator.Send(request);

                response.TransactionId = transactionGuid;

                if (string.IsNullOrEmpty(response.MessageText))
                {
                    return UnprocessableEntity(response);
                }
                return GetResult(response);
            }
            else
            {
                return BadRequest("Transaction ID in request header is missing or not in proper format.");
            }
        }



    }
}
