﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.BroadcastHistory;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.BroadcastHistory
{
    /// <summary>
    /// Broadcast History Controller.
    /// </summary>
    [Route(RouteContfiguration.BroadcastHistoryRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class BroadcastHistoryController : BaseApiController
    {
        private readonly IMediator _mediator;
        /// <summary>
        /// Constructor for Broadcast History Controller.
        /// </summary>
        /// <param name="mediator"></param>

        public BroadcastHistoryController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used to Get Broadcast History.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>All Broadcast History</returns>
        [HttpPost]
        [Route(RouteContfiguration.BroadcastHistoryMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.BroadcastHistoryMethodRoute, Description = RouteContfiguration.BroadcastHistoryDescription, Tags = new[] { RouteContfiguration.BroadcastHistoryEndPoint })]
        [ProducesResponseType(typeof(BroadcastHistoryResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<BroadcastHistoryResponse>>> BroadcastHistory(BroadcastHistoryRequest request)
        {
            var broadcastHistoryList = await _mediator.Send(request);
            return GetResult(broadcastHistoryList);
        }

        /// <summary>
        /// Used to Get Broadcast History Details Using BroadCast ID.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>All Broadcast History Details Based On BroadCast ID</returns>
        [HttpPost]
        [Route(RouteContfiguration.BroadcastHistoryDetailsMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.BroadcastHistoryDetailsMethodRoute, Description = RouteContfiguration.BroadcastHistoryDetailsDescription, Tags = new[] { RouteContfiguration.BroadcastHistoryEndPoint })]
        [ProducesResponseType(typeof(BroadcastHistoryDetailsResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<BroadcastHistoryDetailsResponse>>> BroadcastHistoryDetailsByID(BroadcastHistoryDetailsRequest request)
        {
            var broadcastHistoryDetailsList = await _mediator.Send(request);
            return GetResult(broadcastHistoryDetailsList);
        }

        /// <summary>
        /// Used to Cancel Broadcast History Using BroadCast ID.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Broadcast Result ID</returns>
        [HttpPost]
        [Route(RouteContfiguration.BroadcastHistoryCancelByIDMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.BroadcastHistoryCancelByIDMethodRoute, Description = RouteContfiguration.BroadcastHistoryCancelByIDDescription, Tags = new[] { RouteContfiguration.BroadcastHistoryEndPoint })]
        [ProducesResponseType(typeof(long), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<long>>> BroadcastHistoryCancelByID(BroadcastHistoryCancelRequest request)
        {
            var broadcastHistoryCancelID = await _mediator.Send(request);
            return GetResult(broadcastHistoryCancelID);
        }
    }
}
