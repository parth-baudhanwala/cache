﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Visit
{
    /// <summary>
    /// Unlink Call Controller
    /// </summary>
    [Route(RouteContfiguration.VisitRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class UnlinkCallController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Unlink Call Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public UnlinkCallController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used for unlink the call
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return response of unlink call</returns>
        [HttpPost]
        [Route(RouteContfiguration.CallUnLinkMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.CallUnLinkMethodRoute, Description = RouteContfiguration.CallUnLinkRouteDescription, Tags = new[] { RouteContfiguration.VisitEndPoint })]
        [ProducesResponseType(typeof(UnlinkCallResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<UnlinkCallResponse>> UnlinkCall([FromBody] UnlinkCallRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
