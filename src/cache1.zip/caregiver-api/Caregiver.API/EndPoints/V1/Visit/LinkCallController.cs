﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Visit
{
    /// <summary>
    /// Link Call Controller
    /// </summary>
    [Route(RouteContfiguration.VisitRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class LinkCallController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Link Call Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public LinkCallController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used for link the call
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return response of link call</returns>
        [HttpPost]
        [Route(RouteContfiguration.LinkCallMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.LinkCallMethodRoute, Description = RouteContfiguration.LinkCallRouteDescription, Tags = new[] { RouteContfiguration.VisitEndPoint })]
        [ProducesResponseType(typeof(LinkCallResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<LinkCallResponse>> LinkCall([FromBody] LinkCallRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
