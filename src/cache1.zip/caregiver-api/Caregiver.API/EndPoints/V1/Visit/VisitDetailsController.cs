﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Visit
{
    /// <summary>
    /// Visit Details Controller
    /// </summary>
    [Route(RouteContfiguration.VisitDetailsRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class VisitDetailsController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Visit Details Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public VisitDetailsController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used for get visit details based on VisitID
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return the visit details response</returns>
        [HttpGet]
        [Route(RouteContfiguration.VisitDetailsMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.VisitDetailsMethodRoute, Description = RouteContfiguration.VisitDetailsRouteDescription, Tags = new[] { RouteContfiguration.VisitEndPoint })]
        [ProducesResponseType(typeof(VisitDetailsResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<VisitDetailsResponse>> VisitDetails([FromRoute] VisitDetailsRequest request)
        {
            var response = await this._mediator.Send(request);
            return GetResult(response);
        }
    }
}
