﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Visit
{
    /// <summary>
    /// MoveCallsToCallMaintenance Controller
    /// </summary>
    [Route(RouteContfiguration.MoveCallsToCallDashboardRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class MoveCallsToCallMaintenanceController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// MoveCallsToCallMaintenance Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public MoveCallsToCallMaintenanceController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used for move calls to call maintenance
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return the response of call is moved or not</returns>
        [HttpPost]
        [Route(RouteContfiguration.MoveCallsToCallDashboardMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.MoveCallsToCallDashboardMethodRoute, Description = RouteContfiguration.MoveCallsToCallDashboardRouteDescription, Tags = new[] { RouteContfiguration.VisitEndPoint })]
        [ProducesResponseType(typeof(MoveCallsToCallMaintenanceResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<MoveCallsToCallMaintenanceResponse>> MoveCallsToCallDashboard([FromBody] MoveCallsToCallMaintenanceRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
