﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Visit
{
    /// <summary>
    /// ShowMatchingCallsDetail Controller
    /// </summary>
    [Route(RouteContfiguration.ShowMatchingCallsDetailRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class ShowMatchingCallsDetailController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// ShowMatchingCallsDetail Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public ShowMatchingCallsDetailController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// used for get matching calls details
        /// </summary>
        /// <param name="matchingCallsDetailRequest"></param>
        /// <returns>Return the matching calls</returns>
        [HttpGet]
        [Route(RouteContfiguration.ShowMatchingCallsDetailMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.ShowMatchingCallsDetailMethodRoute, Description = RouteContfiguration.ShowMatchingCallsDetailRouteDescription, Tags = new[] { RouteContfiguration.VisitEndPoint })]
        [ProducesResponseType(typeof(MatchingCallsDetailResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<MatchingCallsDetailResponse>>> ShowMatchingCalls([FromRoute] MatchingCallsDetailRequest matchingCallsDetailRequest)
        {
            var response = await _mediator.Send(matchingCallsDetailRequest);
            return GetResult(response);
        }
    }
}
