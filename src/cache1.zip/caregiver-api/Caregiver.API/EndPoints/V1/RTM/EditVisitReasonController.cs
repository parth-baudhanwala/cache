﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.RTM;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.RTM
{
    /// <summary>
    /// Edit Visit Reason Controller
    /// </summary>
    [Route(RouteContfiguration.EditVisitReasonRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class EditVisitReasonController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Edit Visit Reason Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public EditVisitReasonController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used for get edit visit reason by vendor and contract
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return response of edit visit reasons</returns>
        [HttpPost]
        [Route(RouteContfiguration.EditVisitReasonMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.EditVisitReasonMethodRoute, Description = RouteContfiguration.EditVisitReasonRouteDescription, Tags = new[] { RouteContfiguration.ReasonEndPoint })]
        [ProducesResponseType(typeof(EditVisitReasonResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<EditVisitReasonResponse>>> GetEditVisitReasons([FromBody] EditVisitReasonRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
