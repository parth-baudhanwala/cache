﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.RTM;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.RTM
{
    /// <summary>
    /// Action Taken Reason Controller
    /// </summary>
    [Route(RouteContfiguration.ActionTakenReasonRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class ActionTakenReasonController : BaseApiController
    {
        private readonly IMediator _mediator;

        /// <summary>
        /// Action Taken Reason Controller Constructor
        /// </summary>
        /// <param name="mediator"></param>
        public ActionTakenReasonController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used for get action taken reason by vendor, contract and reason id
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return response of action taken reasons</returns>
        [HttpPost]
        [Route(RouteContfiguration.ActionTakenReasonMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.ActionTakenReasonMethodRoute, Description = RouteContfiguration.ActionTakenReasonRouteDescription, Tags = new[] { RouteContfiguration.ReasonEndPoint })]
        [ProducesResponseType(typeof(ActionTakenReasonResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<ActionTakenReasonResponse>>> GetActionTakenReasonsByReasonID([FromBody] ActionTakenReasonRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
