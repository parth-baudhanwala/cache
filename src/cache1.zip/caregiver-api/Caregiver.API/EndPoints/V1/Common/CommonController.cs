﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Common;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Common
{
    /// <summary>
    /// Common Controller.
    /// </summary>
    [Route(RouteContfiguration.CommonRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class CommonController : BaseApiController
    {
        private readonly IMediator _mediator;
        /// <summary>
        /// Constructor for Common Controller.
        /// </summary>
        /// <param name="mediator"></param>
        public CommonController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }

        /// <summary>
        /// Used to Get All Offices.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>All Offices</returns>
        [HttpGet]
        [Route(RouteContfiguration.CommonOfficesMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.CommonOfficesMethodRoute, Description = RouteContfiguration.CommonRouteOfficesDescription, Tags = new[] { RouteContfiguration.CommonEndPoint })]
        [ProducesResponseType(typeof(OfficesResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<OfficesResponse>>> Offices([FromQuery] OfficesRequest request)
        {
            if (request.UserID == 0 || string.IsNullOrEmpty(request.AppVersion)
                || request.Version == 0 || request.MinorVersion == 0)
            {
                return NoContent();
            }

            var officeList = await _mediator.Send(request);
            return GetResult(officeList);
        }

        /// <summary>
        /// Used to Get Common Details.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>All Common Details</returns>
        [HttpGet]
        [Route(RouteContfiguration.CommonDetailsMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.CommonDetailsMethodRoute, Description = RouteContfiguration.CommonRouteDetailsDescription, Tags = new[] { RouteContfiguration.CommonEndPoint })]
        [ProducesResponseType(typeof(CommonDetailsResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IEnumerable<CommonDetailsResponse>>> CommonDetails([FromQuery] CommonDetailsRequest request)
        {
            if (request.UserID == 0)
            {
                return NoContent();
            }
            var commonDetailsList = await _mediator.Send(request);
            return GetResult(commonDetailsList);
        }
    }
}
