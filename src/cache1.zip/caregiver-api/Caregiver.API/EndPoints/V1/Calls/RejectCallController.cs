﻿using Ardalis.GuardClauses;
using Caregiver.API.Endpoints;
using Caregiver.Domain.DomainTransferObjects.Calls;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using static Caregiver.API.Constants.ApiSetup;

namespace Caregiver.API.EndPoints.V1.Calls
{
    /// <summary>
    /// Reject Call Controller.
    /// </summary>
    [Route(RouteContfiguration.RejectCallRoute)]
    [ApiVersion(WebApi.ApiVersionV1)]
    public class RejectCallController : BaseApiController
    {
        private readonly IMediator _mediator;
        /// <summary>
        /// Constructor for Reject Call Controller.
        /// </summary>
        /// <param name="mediator"></param>
        public RejectCallController(IMediator mediator)
        {
            _mediator = Guard.Against.Null(mediator);
        }
        /// <summary>
        /// Used to reject the call
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return response of reject</returns>
        [HttpPost]
        [Route(RouteContfiguration.RejectCallMethodRoute)]
        [SwaggerOperation(Summary = RouteContfiguration.RejectCallMethodRoute, Description = RouteContfiguration.RejectCallRouteDescription, Tags = new[] { RouteContfiguration.VisitEndPoint })]
        [ProducesResponseType(typeof(RejectCallResponse), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<RejectCallResponse>> RejectCall([FromBody] RejectCallRequest request)
        {
            var response = await _mediator.Send(request);
            return GetResult(response);
        }
    }
}
