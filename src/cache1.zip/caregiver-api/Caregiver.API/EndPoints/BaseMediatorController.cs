using Ardalis.GuardClauses;
using MediatR;

namespace Caregiver.API.Endpoints
{
    /// <summary>
    /// Base Mediator Controller
    /// </summary>
    public class BaseMediatorController : BaseApiController
    {
        /// <summary>
        /// Interface declaration
        /// </summary>
        protected readonly IMediator Mediator;

        /// <summary>
        /// BaseMediator Controller Constuctor
        /// </summary>
        /// <param name="mediator"></param>
        public BaseMediatorController(IMediator mediator)
        {
            Mediator = Guard.Against.Null(mediator, nameof(mediator));
        }
    }
}