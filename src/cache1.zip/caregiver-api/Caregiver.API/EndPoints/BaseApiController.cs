﻿using Microsoft.AspNetCore.Mvc;

namespace Caregiver.API.Endpoints
{
    /// <summary>
    /// Base Api Controller
    /// </summary>
    [ApiController]
    public abstract class BaseApiController : ControllerBase
    {
        /// <summary>
        /// GetResult Method to format the response
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="responseObject"></param>
        /// <returns>Return the response</returns>
        protected ActionResult GetResult<T>(IEnumerable<T> responseObject) where T : class
        {
            var responseState = responseObject?.Any();
            ActionResult actionResult = responseState.HasValue && responseState.Value ? Ok(responseObject) : NoContent();
            return actionResult;
        }

        /// <summary>
        /// GetResult Method to format the response
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="responseObject"></param>
        /// <returns>Return the response</returns>
        protected ActionResult GetResult<T>(T responseObject) where T : class
        {
            ActionResult actionResult = responseObject != null ? Ok(responseObject) : NoContent();
            return actionResult;
        }

        /// <summary>
        /// GetResult Method to format the response
        /// </summary>
        /// <param name="responseObject"></param>
        /// <returns>Return the response</returns>
        protected ActionResult GetResult(long responseObject)
        {
            ActionResult actionResult = responseObject > 0 ? Ok(responseObject) : NoContent();
            return actionResult;
        }
    }
}
