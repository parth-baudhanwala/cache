using Caregiver.API.Constants;
using Caregiver.API.Extensions;
using Caregiver.API.Services;

namespace Caregiver.API
{
    /// <summary>
    /// Program Class
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Main Method of class
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static async Task Main(string[] args)
        {
            await CreateHostBuilder(args).Build().RunAsync();
        }

        /// <summary>
        /// Used for create Host Builder
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((host, configBuilder) =>
                {
                    configBuilder.SetBasePath(Directory.GetCurrentDirectory());
                    configBuilder.AddJsonFile(Configuration.AppSettings, optional: false, reloadOnChange: true);
                    configBuilder.AddJsonFile(Configuration.StoreProcedure, optional: false, reloadOnChange: true);
                    configBuilder.AddJsonFile(Configuration.TimeZoneData, optional: false, reloadOnChange: true);
                    configBuilder.AddEnvironmentVariables();
                    configBuilder.AddSecretsManagerConfiguration();
                })
                .ConfigureSerilog()
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                    webBuilder.AddAmazonCloudWatchLogger();
                });
    }
}