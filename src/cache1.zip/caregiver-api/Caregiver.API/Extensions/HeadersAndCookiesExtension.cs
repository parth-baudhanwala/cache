﻿using Microsoft.AspNetCore.HttpOverrides;

namespace Caregiver.API.Extensions
{
    /// <summary>
    /// Headers And Cookies Extension
    /// </summary>
    public static class HeadersAndCookiesExtension
    {
        /// <summary>
        /// Forwards the Client IP Address and Protocol to the reverse proxy and load balancer for security purpose.
        /// Have a User Consent for the Cookies and Allow cookies to be sent cross-sites.
        /// </summary>
        /// <param name="services"></param>
        /// <returns>Return the Header and Cookie service collections</returns>
        public static IServiceCollection AddHHAHeadersAndCookies(this IServiceCollection services)
        {
            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });

            services.Configure<CookiePolicyOptions>(options =>
            {
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            return services;
        }
    }
}
