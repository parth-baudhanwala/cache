﻿using Caregiver.Core.Interfaces.BroadcastHistory;
using Caregiver.Core.Interfaces.Calls;
using Caregiver.Core.Interfaces.Caregiver;
using Caregiver.Core.Interfaces.Common;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Core.Interfaces.Helper;
using Caregiver.Core.Interfaces.Prebilling;
using Caregiver.Core.Interfaces.RTM;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Infrastructure;
using Caregiver.Infrastructure.Cache;
using Caregiver.Infrastructure.Helper;
using Caregiver.Infrastructure.Repositories.BroadcastHistory;
using Caregiver.Infrastructure.Repositories.Calls;
using Caregiver.Infrastructure.Repositories.Common;
using Caregiver.Infrastructure.Repositories.GlobalVisit;
using Caregiver.Infrastructure.Repositories.Prebilling;
using Caregiver.Infrastructure.Repositories.RTM;
using Caregiver.Infrastructure.Repositories.Visit;

namespace Caregiver.API.Extensions
{
    /// <summary>
    /// Class for add RepositoryExtension
    /// </summary>
    public static class RepositoryExtension
    {
        /// <summary>
        /// Constructor for Register Repositories
        /// </summary>
        /// <param name="services"></param>
        public static void RegisterRepositories(this IServiceCollection services)
        {
            services.AddTransient<ILinkCallRepository, LinkCallRepository>();
            services.AddTransient<ILinkUnlinkCallDetailRepository, LinkUnlinkCallDetailRepository>();
            services.AddTransient<ICommonRepository, CommonRepository>();
            services.AddTransient<IPrebillingRepository, PrebillingRepository>();
            services.AddTransient<IMoveCallsToCallMaintenanceRepository, MoveCallsToCallMaintenanceRepository>();
            services.AddTransient<IUnlinkCallRepository, UnlinkCallRepository>();
            services.AddTransient<IShowMatchingCallsDetailRepository, ShowMatchingCallsDetailRepository>();
            services.AddTransient<IVisitDetailsRepository, VisitDetailsRepository>();
            services.AddTransient<ILinkableVisitRepository, LinkableVisitRepository>();
            services.AddTransient<IGlobalLinkCallRepository, GlobalLinkCallRepository>();
            services.AddTransient<IGlobalUnlinkCallRepository, GlobalUnlinkCallRepository>();
            services.AddTransient<IGlobalShowMatchingCallsDetailRepository, GlobalShowMatchingCallsDetailRepository>();
            services.AddTransient<IRejectCallRepository, RejectCallRepository>();
            services.AddTransient<IEditVisitReasonRepository, EditVisitReasonRepository>();
            services.AddTransient<IActionTakenReasonRepository, ActionTakenReasonRepository>();
            services.AddTransient<IWebApiHelper, WebApiHelper>();
            services.AddTransient<ICallExceptionsRepository, CallExceptionsRepository>();
            services.AddTransient<IBroadcastHistoryRepository, BroadcastHistoryRepository>();
            services.AddTransient<IACSRepository, ACSRepository>();
            services.AddTransient<ICreateACSScheduleRepository, CreateACSScheduleRepository>();
            services.AddSingleton<IRedisConnectionService, RedisConnectionService>();
            services.AddSingleton<ITimeZoneService, TimeZoneService>();
            services.AddTransient<IMobileUserRepository, MobileUserRepository>();
            services.AddTransient<IValidateActivationCodeRepository, ValidateActivationCodeRepository>();
        }
    }
}
