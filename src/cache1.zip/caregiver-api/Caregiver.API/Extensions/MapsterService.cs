﻿using Caregiver.API.ServicesEntryPoint;
using Mapster;
using MapsterMapper;

namespace Caregiver.API.Extensions
{
    internal static class MapsterService
    {
        internal static IServiceCollection AddApplicationMapsterServices(this IServiceCollection services)
        {
            var typeAdapterConfig = TypeAdapterConfig.GlobalSettings;
            typeAdapterConfig.Scan(typeof(ApplicationMapperEntryPoint).Assembly);
            var mapperConfig = new Mapper(typeAdapterConfig);
            services.AddSingleton<IMapper>(mapperConfig);
            return services;
        }
    }
}