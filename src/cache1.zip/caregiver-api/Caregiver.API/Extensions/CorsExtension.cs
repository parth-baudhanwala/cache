﻿using Caregiver.API.Constants;

namespace Caregiver.API.Extensions
{
    /// <summary>
    /// CorsExtension class is used for adding cors policy
    /// </summary>
    public static class CorsExtension
    {
        /// <summary>
        /// Used for allow headers, domain, policy
        /// </summary>
        /// <param name="services"></param>
        /// <param name="hostingEnvironment"></param>
        /// <returns></returns>
        public static IServiceCollection AddHHACors(this IServiceCollection services, IWebHostEnvironment hostingEnvironment) =>
            services.AddCors(options =>
            {
                options.AddPolicy(
                    name: ApiSetup.WebApi.CorsPolicyName,
                    builder =>
                    {
                        builder.SetIsOriginAllowedToAllowWildcardSubdomains()
                        .WithOrigins(hostingEnvironment.IsDevelopment() ? "http://localhost:4200" : "https://*.hhaexchange.com")
                        .AllowAnyHeader()
                        .AllowCredentials()
                        .AllowAnyMethod();
                    });
            });
    }
}