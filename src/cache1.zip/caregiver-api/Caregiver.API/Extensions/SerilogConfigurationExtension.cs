﻿using Caregiver.API.Constants;
using Serilog;

namespace Caregiver.API.Extensions
{
    /// <summary>
    /// Serilog Configuration Extension Class
    /// </summary>
    public static class SerilogConfigurationExtension
    {
        /// <summary>
        /// Used to configuration serilog
        /// </summary>
        /// <param name="hostLogger"></param>
        /// <returns></returns>
        public static IHostBuilder ConfigureSerilog(this IHostBuilder hostLogger)
        {
            string Namespace = typeof(Program).Namespace;
            string AppName = Namespace[(Namespace.LastIndexOf('.', Namespace.LastIndexOf('.') - 1) + 1)..];

            return hostLogger.UseSerilog((hostingContext, loggerConfiguration) =>
            {
                loggerConfiguration
                .Enrich.FromLogContext()
                .Enrich.WithProperty(Configuration.Serilog.ApplicationContext, AppName)
                .ReadFrom.Configuration(hostingContext.Configuration);
#if DEBUG
                loggerConfiguration.WriteTo.File(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Configuration.Serilog.LogFile), rollingInterval: RollingInterval.Day);
                // Used to filter out potentially bad data due debugging.
                // Very useful when doing Seq dashboards and want to remove logs under debugging session.
                loggerConfiguration.Enrich.WithProperty(Configuration.Serilog.DebuggerAttached, System.Diagnostics.Debugger.IsAttached);
#endif
            });
        }
    }
}
