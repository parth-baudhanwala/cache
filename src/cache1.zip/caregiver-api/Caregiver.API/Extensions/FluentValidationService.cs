﻿using Caregiver.API.PipelineBehaviours;
using Caregiver.Core;
using FluentValidation;
using MediatR;

namespace Caregiver.API.Extensions
{
    internal static class FluentValidationService
    {
        internal static IServiceCollection AddFluentValidationService(this IServiceCollection services) =>
            services.AddValidatorsFromAssembly(typeof(CoreFluentValidationEntryPoint).Assembly)
            .AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehaviour<,>));
    }
}
