﻿using Caregiver.API.Constants;
using Caregiver.Infrastructure.Contexts;
using Microsoft.EntityFrameworkCore;

namespace Caregiver.API.Extensions
{
    /// <summary>
    /// DbContextExtension class is used for set up db context
    /// </summary>
    public static class DbContextExtension
    {
        /// <summary>
        /// Used for add connectin in DB Context
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <returns>Returns the connection service</returns>
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<HhaDbContext>(
                        options =>
                        {
                            options.UseSqlServer(
                                configuration.GetValue<string>(Configuration.ConnectionString.HHAConnectionString),
                                sqlServerOptionsAction: sqlOptions =>
                                {
                                    sqlOptions.EnableRetryOnFailure(maxRetryCount: 15, maxRetryDelay: TimeSpan.FromSeconds(configuration.GetValue<int>("DBContextTimeout")), errorNumbersToAdd: null);
                                });
                        },
                        ServiceLifetime.Scoped);

            services.AddDbContext<HhaReadDbContext>(
                        options =>
                        {
                            options.UseSqlServer(
                                configuration.GetValue<string>(Configuration.ConnectionString.HHAMirrorConnectionString),
                                sqlServerOptionsAction: sqlOptions =>
                                {
                                    sqlOptions.EnableRetryOnFailure(maxRetryCount: 15, maxRetryDelay: TimeSpan.FromSeconds(configuration.GetValue<int>("DBContextTimeout")), errorNumbersToAdd: null);
                                });
                        },
                        ServiceLifetime.Scoped);

            services.AddDbContext<ClinicalDbContext>(
                        options =>
                        {
                            options.UseSqlServer(
                                configuration.GetValue<string>(Configuration.ConnectionString.ClinicalConnectionString),
                                sqlServerOptionsAction: sqlOptions =>
                                {
                                    sqlOptions.EnableRetryOnFailure(maxRetryCount: 15, maxRetryDelay: TimeSpan.FromSeconds(configuration.GetValue<int>("DBContextTimeout")), errorNumbersToAdd: null);
                                });
                        },
                        ServiceLifetime.Scoped);

            services.AddDbContext<IVRMainDbContext>(
                       options =>
                       {
                           options.UseSqlServer(
                               configuration.GetValue<string>(Configuration.ConnectionString.IVRMainConnectionString),
                               sqlServerOptionsAction: sqlOptions =>
                               {
                                   sqlOptions.EnableRetryOnFailure(maxRetryCount: 15, maxRetryDelay: TimeSpan.FromSeconds(configuration.GetValue<int>("DBContextTimeout")), errorNumbersToAdd: null);
                               });
                       },
                       ServiceLifetime.Scoped);

            services.AddDbContext<PrebillingDbContext>(
                       options =>
                       {
                           options.UseSqlServer(
                               configuration.GetValue<string>(Configuration.ConnectionString.PrebillingConnectionString),
                               sqlServerOptionsAction: sqlOptions =>
                               {
                                   sqlOptions.EnableRetryOnFailure(maxRetryCount: 15, maxRetryDelay: TimeSpan.FromSeconds(configuration.GetValue<int>("DBContextTimeout")), errorNumbersToAdd: null);
                               });
                       },
                       ServiceLifetime.Scoped);

            services.AddDbContext<HhaCaregiverDbContext>(
                       options =>
                       {
                           options.UseNpgsql(
                               configuration.GetValue<string>(Configuration.ConnectionString.HhaCaregiverConnectionString),
                               npgsqlOptionsAction: sqlOptions =>
                               {
                                   sqlOptions.EnableRetryOnFailure(maxRetryCount: 15, maxRetryDelay: TimeSpan.FromSeconds(configuration.GetValue<int>("DBContextTimeout")), errorCodesToAdd: null);
                               });
                       },
                       ServiceLifetime.Scoped);

            return services;
        }
    }
}
