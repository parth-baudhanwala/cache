﻿using Caregiver.API.Filters;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.OpenApi.Models;
using System.Reflection;

namespace Caregiver.API.Extensions
{
    /// <summary>
    /// Used for Swagger Extension
    /// </summary>
    public static class SwaggerExtension
    {
        /// <summary>
        /// Used for add swagger configuration
        /// </summary>
        /// <param name="services"></param>
        public static void AddSwaggerGenCustom(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.EnableAnnotations();
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Name = "AuthorizationToken",
                    Description = @"JWT Authorization header using the Bearer scheme. </br >
                      Enter 'Bearer' [space] and then your token in the text input below. </br >
                      Example: 'Bearer 12345abcdef'",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = JwtBearerDefaults.AuthenticationScheme
                            },

                        },
                        Array.Empty<string>()
                    }
                });
                c.OperationFilter<AuthorizationHeaderParameterOperationFilter>();
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });
        }
    }
}
