﻿namespace Caregiver.API.Constants
{
    /// <summary>
    /// Configuration class is used for constant variable value
    /// </summary>
    public static class Configuration
    {
        internal const string AppSettings = "appsettings.json";
        internal const string StoreProcedure = "StoredProcedures.json";
        internal const string TimeZoneData = "TimeZoneData.json";
        internal static class ConnectionString
        {
            internal const string HHAMirrorConnectionString = "ConnectionStrings:HHAMirror";
            internal const string HHAConnectionString = "ConnectionStrings:HHA";
            internal const string ClinicalConnectionString = "ConnectionStrings:Clinical";
            internal const string IVRMainConnectionString = "ConnectionStrings:IVRMain";
            internal const string PrebillingConnectionString = "ConnectionStrings:Prebilling";
            internal const string HhaCaregiverConnectionString = "ConnectionStrings:hhacaregiver";
        }

        internal static class Serilog
        {
            internal const string ApplicationContext = "ApplicationContext";
            internal const string LogFile = @"log\log.txt";
            internal const string DebuggerAttached = "DebuggerAttached";
        }
    }
}
