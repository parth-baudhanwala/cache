namespace Caregiver.API.Constants
{
    /// <summary>
    /// ApiSetup class is used for api route's naming convension
    /// </summary>
    public static class ApiSetup
    {
        internal static class WebApi
        {
            internal const string Name = "Caregiver.API";
            internal const string ApiDescription = "Amazon Lambda-Hosted REST API for Caregiver API (Serverless Architecture)";
            internal const string Version = "v1";
            internal const string SwaggerEndpoint = "../swagger/v1/swagger.json";
            internal const string CorsPolicyName = "CaregiverApiCors";
            internal const string CaregiverApi = "CaregiverApi";
            internal const string ApiVersionV1 = "1.0";
        }

        internal static class RouteContfiguration
        {
            internal const string VisitEndPoint = "Visit Endpoints";
            internal const string GlobalVisitEndPoint = "Global Visit Endpoints";
            internal const string ReasonEndPoint = "Reason Endpoints";
            internal const string CommonEndPoint = "Common Endpoints";
            internal const string BroadcastHistoryEndPoint = "Broadcast History End Points";
            internal const string VisitRoute = "api/v{version:apiVersion}/visits/{visitid}/calls/{maintenanceid}";
            internal const string GlobalACSEndPoint = "Global ACS Endpoints";
            internal const string CaregiverEndPoint = "Caregiver Endpoints";

            #region Call Link
            internal const string LinkCallMethodRoute = "link";
            internal const string LinkCallRouteDescription = "API for link calls";
            #endregion

            #region Call UnLink            
            internal const string CallUnLinkMethodRoute = "unlink";
            internal const string CallUnLinkRouteDescription = "API for Unlink calls";
            #endregion

            #region Move Calls To CallDashboard
            internal const string MoveCallsToCallDashboardRoute = "api/v{version:apiVersion}/visits/{visitid}";
            internal const string MoveCallsToCallDashboardMethodRoute = "movecall-to-calldashboard";
            internal const string MoveCallsToCallDashboardRouteDescription = "API for move calls to call dashboard";
            #endregion

            #region Show Matching Calls Detail for Visit
            internal const string ShowMatchingCallsDetailRoute = "api/v{version:apiVersion}/visits/{VisitID}/calltypes/{CallType}/users/{UserID}";
            internal const string ShowMatchingCallsDetailMethodRoute = "calls";
            internal const string ShowMatchingCallsDetailRouteDescription = "API for displaying the matching calls for a visit";
            #endregion

            #region Show Matching ACS Detail for Visit
            internal const string ShowMatchingACSDetailMethodRoute = "acsdata";
            internal const string ShowMatchingACSDetailRouteDescription = "API for displaying the acs details for a visit";
            #endregion

            #region Visit Details
            internal const string VisitDetailsRoute = "api/v{version:apiVersion}/visits/{VisitID}";
            internal const string VisitDetailsMethodRoute = "details";
            internal const string VisitDetailsRouteDescription = "API for display Visit details";
            #endregion

            #region Linkable Visit
            internal const string LinkableVisitRoute = "api/v{version:apiVersion}/globalvisits/caregivers/{globalcaregiverid}/patients/{globalpatientid}";
            internal const string LinkableVisitMethodRoute = "linkablevisits";
            internal const string LinkableVisitRouteDescription = "API for displaying the patient and caregiver matching calls";
            #endregion

            #region GlobalVisit
            internal const string GlobalVisitRoute = "api/v{version:apiVersion}/globalvisits/{globalvisitid}/calls/{maintenanceid}";
            internal const string GlobalVisitCallTypeRoute = "api/v{version:apiVersion}/globalvisits/{GlobalVisitID}/calltypes/{CallType}";
            internal const string GlobalACSProcess = "api/v{version:apiVersion}/globalvisits/acs";
            internal const string GlobalACSPostMethodRoute = "create";
            internal const string GlobalACSPostMethodRouteDescription = "API for Create ACS Schedules From CallMaintenance Data.";
            #endregion

            #region Reject Call
            internal const string RejectCallRoute = "/api/v{version:apiVersion}/calls/{maintenanceid}";
            internal const string RejectCallMethodRoute = "reject";
            internal const string RejectCallRouteDescription = "API for rejecting individual call";
            #endregion

            #region Get Edit Visit Reason
            internal const string EditVisitReasonRoute = "/api/v{version:apiVersion}/providers/{providerid}";
            internal const string EditVisitReasonMethodRoute = "get-edit-visit-reason";
            internal const string EditVisitReasonRouteDescription = "API for get edit visit reason by provider and contract";
            #endregion

            #region Get Action Taken Reason
            internal const string ActionTakenReasonRoute = "/api/v{version:apiVersion}/providers/{providerid}/reasons/{reasonid}";
            internal const string ActionTakenReasonMethodRoute = "get-action-taken";
            internal const string ActionTakenReasonRouteDescription = "API for get action taken reason by provider, contract and reason id";
            #endregion

            #region Common
            internal const string CommonRoute = "api/v{version:apiVersion}/providers/{providerid}";
            internal const string CommonOfficesMethodRoute = "offices";
            internal const string CommonRouteOfficesDescription = "API for get offices";
            internal const string CommonDetailsMethodRoute = "details";
            internal const string CommonRouteDetailsDescription = "API for common details";
            #endregion

            #region CaregiverCommunication
            internal const string BroadcastHistoryRoute = "api/v{version:apiVersion}/providers/{providerid}";
            internal const string BroadcastHistoryMethodRoute = "broadcasts";
            internal const string BroadcastHistoryDescription = "API for get broadcast by communication history";
            internal const string BroadcastHistoryDetailsMethodRoute = "broadcasts/{broadcastid}/details";
            internal const string BroadcastHistoryDetailsDescription = "API for get broadcast detail using broadcast id by communication history";
            internal const string BroadcastHistoryCancelByIDMethodRoute = "broadcasts/{broadcastid}/cancel";
            internal const string BroadcastHistoryCancelByIDDescription = "API for cancel broadcast detail using broadcast id by communication history";
            #endregion

            #region Mobile User
            internal const string MobileUserRoute = "api/v{version:apiVersion}/caregivers/{globalcaregiverid}";
            internal const string RegisterMobileUserMethodRoute = "registration";
            internal const string RegisterMobileUserRouteDescription = "API to register mobile user";

            internal const string CaregiverAgencyDetailsRoute = "caregiveragencydetails";
            internal const string CaregiverAgencyDetailsRouteDescription = "API to get agency and caregiver details";
            #endregion

            #region Activation Code Generation
            internal const string ActivationCodeGenerationMethodRoute = "activationcode";
            internal const string ActivationCodeGenerationDescription = "API for Activation Code Generation ";
            #endregion

            #region User Agency Link Unlink
            internal const string UserAgencyLinkUnlinkMethodRoute = "linkunlink";
            internal const string UserAgencyLinkUnlinkDescription = "User Agency Link Unlink";
            #endregion

            #region Validate Activation Code
            internal const string ValidateActivationCodeRoute = "api/v{version:apiVersion}/caregiverusers/{caregiveruserglobalid}";
            internal const string ValidateActivationCodeMethodRoute = "validateactivationcode";
            internal const string ValidateActivationCodeDescription = "API for Validate Activation Code";
            #endregion
        }
    }
}
