﻿using Caregiver.API.Constants;
using Caregiver.API.Extensions;
using Caregiver.CommandHandler.Visit;
using Caregiver.Core.Common;
using MediatR;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Options;
using Serilog;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace Caregiver.API
{
    /// <summary>
    /// Used for application start up configuration
    /// </summary>
    public class Startup
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _hostEnvironment;

        /// <summary>
        /// Constructor of a class
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="hostEnvironment"></param>
        public Startup(IConfiguration configuration, IWebHostEnvironment hostEnvironment)
        {
            _configuration = configuration;
            _hostEnvironment = hostEnvironment;
            AppSettings.Configuration = configuration;
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAWSLambdaHosting(LambdaEventSource.HttpApi);
            services.AddCustomDbContext(_configuration);
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

            services.AddMvcCore(config =>
            {
                config.EnableEndpointRouting = false;
            })
            .AddJsonOptions(options => options.JsonSerializerOptions.WriteIndented = true)
            .AddApiExplorer();

            services.AddHHACors(_hostEnvironment);
            services.AddHHAHeadersAndCookies();
            services.AddControllers();
            services.AddHttpContextAccessor();

            services.AddSingleton<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();
            services.AddApiVersioning(options =>
            {
                options.ReportApiVersions = true;
            });
            services.AddVersionedApiExplorer(options =>
            {
                options.GroupNameFormat = "'v'VVV";
                options.SubstituteApiVersionInUrl = true;
            });
            services.AddSwaggerGenCustom();
            services.AddFluentValidationService();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.Configure<CommandInfo>(_configuration.GetSection("ConnectionStrings"));
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssemblies(typeof(LinkCallHandler).Assembly));
            services.AddApplicationMapsterServices();
            services.RegisterRepositories();
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        /// <param name="provider"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IApiVersionDescriptionProvider provider)
        {
            app.UseForwardedHeaders();
            if (env.IsDevelopment()) { app.UseDeveloperExceptionPage(); }
            app.UseRouting();
            app.UseCookiePolicy();
            app.UseCors(ApiSetup.WebApi.CorsPolicyName);
            app.UseEndpoints(options => { options.MapControllers(); });
            app.UseSerilogRequestLogging();
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint(ApiSetup.WebApi.SwaggerEndpoint, $"{ApiSetup.WebApi.Name}");

                var groupNames = provider.ApiVersionDescriptions.Select(x => x.GroupName);
                foreach (var groupName in groupNames)
                {
                    options.SwaggerEndpoint($"/swagger/{groupName}/swagger.json", groupName.ToUpperInvariant());
                }
            }).Use(async (context, next) =>
            {
                if (context.Request.Path == "/")
                {
                    context.Response.Redirect("/swagger");
                    return;
                }
                await next();
            });
        }
    }
}
