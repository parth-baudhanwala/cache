﻿namespace Caregiver.Lambda.Authorizer.Helpers;

public static class Extensions
{
    public static string DefaultTo(this string value, string? defaultValue) => string.IsNullOrWhiteSpace(value) ? defaultValue : value;
}

