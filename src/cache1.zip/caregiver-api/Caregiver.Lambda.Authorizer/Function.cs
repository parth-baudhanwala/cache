[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace Caregiver.Lambda.Authorizer;

public class Function
{
    public async Task<APIGatewayCustomAuthorizerResponse> FunctionHandler(
        APIGatewayCustomAuthorizerRequest request,
        ILambdaContext context)
    {
        return await new Startup(request, context)
        .ServiceProvider.CreateScope()
        .ServiceProvider.GetRequiredService<AuthorizerHandler>()
        .HandleAuthroizationRequest();
    }
}