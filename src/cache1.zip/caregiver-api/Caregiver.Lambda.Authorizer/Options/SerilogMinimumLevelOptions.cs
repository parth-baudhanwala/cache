﻿
namespace Caregiver.Lambda.Authorizer.Options;

public sealed class SerilogMinimumLevelOptions
{
    public const string SectionName = "MinimumLevel";
    public LogEventLevel Default { get; init; }
}

