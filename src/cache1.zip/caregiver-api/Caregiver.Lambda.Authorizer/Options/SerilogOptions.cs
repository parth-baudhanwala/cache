﻿namespace Caregiver.Lambda.Authorizer.Options;

public class SerilogOptions
{
    public const string SectionName = "Serilog";
    public SerilogMinimumLevelOptions MinimumLevel { get; set; } = null!;
}
