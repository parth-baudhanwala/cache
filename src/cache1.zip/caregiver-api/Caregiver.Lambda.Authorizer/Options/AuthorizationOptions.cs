﻿namespace Caregiver.Lambda.Authorizer.Options;

public sealed class AuthorizationOptions
{
    public const string SectionName = "Authorization";
    public string IdentityJWKSUrl { get; init; } = null!;
    public string ValidIssuer { get; init; } = null!;
    public string ValidAudience { get; init; } = null!;
    public string IDPValidIssuer { get; init; } = null!;
    public string IDPJWKSUrl { get; init; } = null!;

}

