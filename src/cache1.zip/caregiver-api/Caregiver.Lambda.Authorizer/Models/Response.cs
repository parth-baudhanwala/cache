﻿namespace Caregiver.Lambda.Authorizer.Models;

public class Response : APIGatewayCustomAuthorizerResponse { }
