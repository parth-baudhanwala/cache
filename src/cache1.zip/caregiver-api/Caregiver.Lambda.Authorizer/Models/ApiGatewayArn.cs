﻿namespace Caregiver.Lambda.Authorizer.Models;

public class ApiGatewayArn
{
    public string Partition { get; set; } = null!;

    public string Service { get; set; } = null!;

    public string Region { get; set; } = null!;

    public string AWSAccountId { get; set; } = null!;

    public string RestAPIId { get; set; } = null!;

    public string Stage { get; set; } = null!;

    public string Verb { get; set; } = null!;

    public string Resource { get; set; } = null!;

    public override string ToString()
    {
        return $"arn:{Partition}:{Service}:{Region}:{AWSAccountId}:{RestAPIId}/{Stage}/{Verb}/{Resource}";
    }

    public static ApiGatewayArn Parse(string value)
    {
        try
        {
            ApiGatewayArn apiGatewayArn = new();
            string[] arnSpilt = value.Split(':');
            apiGatewayArn.Partition = arnSpilt[1];
            apiGatewayArn.Service = arnSpilt[2];
            apiGatewayArn.Region = arnSpilt[3];
            apiGatewayArn.AWSAccountId = arnSpilt[4];

            string[] pathSpilt = arnSpilt[5].Split('/');
            apiGatewayArn.RestAPIId = pathSpilt[0];
            apiGatewayArn.Stage = pathSpilt[1];
            apiGatewayArn.Verb = pathSpilt[2];

            if (pathSpilt.Length > 3)
            {
                apiGatewayArn.Resource = string.Join("/", pathSpilt.Skip(3));
            }
            return apiGatewayArn;
        }
        catch (Exception ex)
        {
            throw new ApiGatewayArnException($"Invalid method arn: '{value}'", ex.InnerException);
        }
    }

    public static bool TryParse(string arnValue, out ApiGatewayArn? apiGatewayArn)
    {
        try
        {
            apiGatewayArn = Parse(arnValue);
            return true;
        }
        catch
        {
            apiGatewayArn = null;
            return false;
        }
    }
}
