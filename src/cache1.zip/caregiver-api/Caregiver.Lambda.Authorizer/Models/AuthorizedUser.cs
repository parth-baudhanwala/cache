﻿namespace Caregiver.Lambda.Authorizer.Models;

public sealed record AuthorizedUser(long UserId, long VendorId, string? UserName, string? FirstName, string? LastName, string? UserEmailAddress, bool isImpersonated, string? ClientId);
