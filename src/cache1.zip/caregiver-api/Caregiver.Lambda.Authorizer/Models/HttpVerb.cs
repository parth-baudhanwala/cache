﻿namespace Caregiver.Lambda.Authorizer.Models;

public sealed class HttpVerb
{
    private readonly string _verb;

    private HttpVerb(string verb)
    {
        _verb = verb;
    }

    public override string ToString()
    {
        return _verb;
    }

    public static HttpVerb Get => new("GET");
    public static HttpVerb Post => new("POST");
    public static HttpVerb Put => new("PUT");
    public static HttpVerb Patch => new("PATCH");
    public static HttpVerb Head => new("HEAD");
    public static HttpVerb Delete => new("DELETE");
    public static HttpVerb Options => new("OPTIONS");
    public static HttpVerb All => new("*");
}
