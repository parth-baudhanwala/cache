﻿namespace Caregiver.Lambda.Authorizer.Enums;

public enum Effect
{
    Deny,
    Allow
}
