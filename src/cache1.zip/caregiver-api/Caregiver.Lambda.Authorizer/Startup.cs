﻿namespace Caregiver.Lambda.Authorizer;

public class Startup
{
    public IServiceProvider ServiceProvider { get; set; }
    private static IConfiguration Configuration { get; } = new ConfigurationBuilder()
        .SetBasePath(Directory.GetCurrentDirectory())
        .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
        .Build();

    public Startup(APIGatewayCustomAuthorizerRequest request, ILambdaContext lambdaContext)
    {
        lambdaContext.Logger.Log(JsonSerializer.Serialize(request));
        ServiceProvider = new ServiceCollection()
            .AddConfigurationOptions(Configuration)
            .AddLambdaLoggingService()
            .AddLambdaAuthorizerServices(request, lambdaContext)
            .BuildServiceProvider();
    }
}

