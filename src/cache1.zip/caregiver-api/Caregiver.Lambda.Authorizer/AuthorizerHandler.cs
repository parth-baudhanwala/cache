﻿#pragma warning disable CS8604 // Possible null reference argument.
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.


namespace Caregiver.Lambda.Authorizer;

public class AuthorizerHandler
{
    private readonly ILogger _logger;
    private readonly ILambdaContext _context;
    private readonly IRequestValidationService _requestValidationService;
    private readonly ITokenConfigurationService _tokenConfigurationService;
    private readonly ITokenValidationService _tokenValidationService;
    private readonly IClaimsPrincipalService _claimsPrincipalService;
    private readonly IPolicyBuilderService _policyBuilderService;
    private readonly APIGatewayCustomAuthorizerRequest _request;
    private readonly AuthorizationOptions _authorizationOptions;

    public AuthorizerHandler(
        IRequestValidationService requestValidationService,
        ITokenConfigurationService tokenConfigurationService,
        ITokenValidationService tokenValidationService,
        IClaimsPrincipalService claimsPrincipalService,
        IPolicyBuilderService policyBuilderService,
        ILambdaContext context,
        ILogger logger,
        IOptionsSnapshot<AuthorizationOptions> authorizationOptions,
    APIGatewayCustomAuthorizerRequest request
        )
    {
        _logger = logger;
        _request = request;
        _context = context;
        _requestValidationService = requestValidationService;
        _tokenConfigurationService = tokenConfigurationService;
        _tokenValidationService = tokenValidationService;
        _claimsPrincipalService = claimsPrincipalService;
        _policyBuilderService = policyBuilderService;
         _authorizationOptions = authorizationOptions.Value;
    }

    public async Task<APIGatewayCustomAuthorizerResponse> HandleAuthroizationRequest()
    {
        ApiGatewayArn? apiGatewayArn = null;
        string principalId = string.Empty;

        try
        {
            if (_request is not null && _request.MethodArn is not null && _request.MethodArn.Contains("swagger"))
            {
                _logger.Debug("Swagger UI is requested as resource");
                return _policyBuilderService.BuildSwagger(_request);
            }
            else
            {
                _logger.Debug("Authorizing the request");
                _requestValidationService.ValidateRequest(_request, out apiGatewayArn);

                string? token = _request.AuthorizationToken?.Replace("Bearer ", string.Empty);

                TokenValidationParameters jwtTokenValidationParameterConfig =new TokenValidationParameters();
                var jwtTokenhandler = new JwtSecurityTokenHandler();

                _logger.Debug("Request start for token verification");
                var jsonToken = jwtTokenhandler.ReadToken(token);
                JwtSecurityToken tokenS = jsonToken as JwtSecurityToken;
                if (tokenS != null && !string.IsNullOrEmpty(tokenS.Issuer) && tokenS.Issuer.Contains(_authorizationOptions.IDPValidIssuer))
                {
                    _logger.Debug("Request start for new IDP");
                    jwtTokenValidationParameterConfig = _tokenConfigurationService.GetJsonWebTokensConfiguration(false);
                }
                else
                {
                    _logger.Debug("Request start for old IDP");
                    jwtTokenValidationParameterConfig = _tokenConfigurationService.GetJsonWebTokensConfiguration(true);
                }

                ClaimsPrincipal userClaimsPrincipal = _tokenValidationService.ValidateToken(token, jwtTokenValidationParameterConfig);

                principalId = _claimsPrincipalService.GetPrincipalId(userClaimsPrincipal);

                _policyBuilderService.AllowAllMethods();

                _logger.Debug("Authorization Succeeded with {PrincipalId}", principalId);
            }
        }
        catch (BaseException ex)
        {
            _logger.Error("Exception Message : {ExceptionMessage}\nInner Exception : {InnerException}\nStack Trace : {StackTrace}", ex.Message, ex.InnerException, ex.StackTrace);
            _logger.Fatal("Authorization Failed for Request : {request}", JsonSerializer.Serialize(_request));
            _policyBuilderService.DenyAllMethods();
        }
        Response response = _policyBuilderService.Build(apiGatewayArn, principalId);
        return response;

    }
}
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning restore CS8604 // Possible null reference argument.
