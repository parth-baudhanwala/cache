﻿namespace Caregiver.Lambda.Authorizer.Exceptions;

public class ApiGatewayArnException : BaseException
{
    private static readonly string _name = nameof(ApiGatewayArnException);
    public ApiGatewayArnException() : base(_name) { }

    public ApiGatewayArnException(string message) : base($"{_name} : {message}") { }

    public ApiGatewayArnException(string message, Exception? innerException) : base(message, innerException) { }
}
