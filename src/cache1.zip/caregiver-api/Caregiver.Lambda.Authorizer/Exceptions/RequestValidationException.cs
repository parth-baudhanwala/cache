﻿namespace Caregiver.Lambda.Authorizer.Exceptions;

public class RequestValidationException : UnAuthorizedExpection
{
    private static readonly string _name = nameof(RequestValidationException);
    public RequestValidationException() : base(_name) { }
    public RequestValidationException(string message) : base(_name, message) { }
}
