﻿namespace Caregiver.Lambda.Authorizer.Exceptions;

public class UnAuthorizedExpection : BaseException
{
    private static readonly string _name = nameof(UnAuthorizedExpection);
    public UnAuthorizedExpection() : base(_name) { }
    public UnAuthorizedExpection(string message) : base($"{_name} : {message}") { }
    public UnAuthorizedExpection(string name, string message) : base($"{name} : {message}") { }
    public UnAuthorizedExpection(string message, Exception? innerException) : base(message, innerException) { }
    public UnAuthorizedExpection(string name, string message, Exception? innerException) : base($"{name} : {message}", innerException) { }

}
