﻿namespace Caregiver.Lambda.Authorizer.ServicesConfiguration;

internal static class CloudWatchLoggingService
{
    internal static IServiceCollection AddLambdaLoggingService(this IServiceCollection services) =>
        services.AddScoped<ILogger>(loggerService =>
             new LoggerConfiguration().WriteTo.Console(
                 restrictedToMinimumLevel: services.BuildServiceProvider().GetService<IOptions<SerilogOptions>>().Value.MinimumLevel.Default,
                 formatter: new RenderedCompactJsonFormatter()).MinimumLevel.Verbose().Enrich.FromLogContext().CreateLogger()
        );
}
