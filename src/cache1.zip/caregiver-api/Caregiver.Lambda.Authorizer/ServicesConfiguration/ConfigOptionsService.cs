﻿namespace Caregiver.Lambda.Authorizer.ServicesConfiguration;

internal static class ConfigOptionsService
{
    internal static IServiceCollection AddConfigurationOptions(this IServiceCollection services, IConfiguration configuration) =>
        services.AddValidatorsFromAssembly(typeof(Startup).Assembly, ServiceLifetime.Scoped)
        .AddoptionsAndValidate<SerilogOptions>(SerilogOptions.SectionName, configuration)
        .AddoptionsAndValidate<AuthorizationOptions>(AuthorizationOptions.SectionName, configuration);

    private static IServiceCollection AddoptionsAndValidate<T>(this IServiceCollection services, string sectionName, IConfiguration configuration) where T : class
    {
        services.AddOptions<T>().
            Bind(configuration.GetSection(sectionName)).
            ValidateFluently().
            ValidateOnStart();
        return services;
    }
}
