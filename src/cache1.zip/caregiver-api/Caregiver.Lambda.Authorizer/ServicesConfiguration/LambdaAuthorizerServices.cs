﻿namespace Caregiver.Lambda.Authorizer.ServicesConfiguration;

internal static class LambdaAuthorizerServices
{
    public static IServiceCollection AddLambdaAuthorizerServices(this IServiceCollection services, APIGatewayCustomAuthorizerRequest request, ILambdaContext lambdaContext) =>
        services.AddScoped(services => request)
        .AddScoped(services => lambdaContext)
        .AddScoped<AuthorizerHandler>()
        .AddScoped<IRequestValidationService, RequestValidationService>()
        .AddScoped<ITokenConfigurationService, TokenConfigurationService>()
        .AddScoped<IJsonWebKeyService, JsonWebKeyService>()
        .AddScoped<IJsonWebKeyClient, JsonWebKeyClient>()
        .AddScoped<ITokenValidationService, TokenValidationService>()
        .AddScoped<ISecurityTokenValidator, JwtSecurityTokenHandler>()
        .AddScoped<IAuthorizedUserService, AuthorizedUserService>()
        .AddScoped<IClaimsPrincipalService, ClaimsPrincipalService>()
        .AddScoped<IPolicyBuilderService, PolicyBuilderService>()
        .AddScoped<IIAMPolicyStatementService, IAMPolicyStatementService>()
        .AddSingleton<IEnvironmentVariableService, EnvironmentVariableService>();
}
