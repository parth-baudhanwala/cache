﻿namespace Caregiver.Lambda.Authorizer.OptionsValidators;

public sealed class AuthorizationOptionsValidator : AbstractValidator<AuthorizationOptions>
{
    public AuthorizationOptionsValidator()
    {
        RuleFor(x => x.IdentityJWKSUrl)
            .NotEmpty().WithMessage("{PropertyName} cannot have a {PropertyValue}");

        RuleFor(x => x.ValidIssuer)
            .NotEmpty().WithMessage("{PropertyName} cannot have a {PropertyValue}");
    }
}