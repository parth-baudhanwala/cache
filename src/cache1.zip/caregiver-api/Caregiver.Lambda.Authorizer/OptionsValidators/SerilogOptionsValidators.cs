﻿

namespace Caregiver.Lambda.Authorizer.OptionsValidators;

public sealed class SerilogOptionsValidators : AbstractValidator<SerilogOptions>
{
    public SerilogOptionsValidators() =>
        RuleFor(x => x.MinimumLevel.Default)
        .Cascade(CascadeMode.StopOnFirstFailure)
        .IsInEnum()
        .WithMessage("{PropertyName} contains {PropertyValue} which is not correct.");
}
