﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface ITokenConfigurationService
{
    TokenValidationParameters GetJsonWebTokensConfiguration(bool isOld);
   }
