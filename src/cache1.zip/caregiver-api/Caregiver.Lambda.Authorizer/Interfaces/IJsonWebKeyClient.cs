﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface IJsonWebKeyClient
{
    string GetJsonWebKeySet(string jsonWebKeySetUri);
}
