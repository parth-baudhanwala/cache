﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface IRequestValidationService
{
    void ValidateRequest(APIGatewayCustomAuthorizerRequest request, out ApiGatewayArn? apiGatewayArn);
}
