﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface IJsonWebKeyService
{
    ICollection<SecurityKey> GetSigningKeys(string jsonWebKeySet);
}
