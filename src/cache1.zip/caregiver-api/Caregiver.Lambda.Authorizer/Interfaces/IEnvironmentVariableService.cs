﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface IEnvironmentVariableService
{
    string? Get(string environmentVariableKey);

    void Set<T>(string environmentVaraibleKey, T objectToSet);

    bool HasKey(string environmentVaraibleKey);

}
