﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface IAuthorizedUserService
{
    AuthorizedUser GetAuthorizedUserInfoFromClaims(ClaimsPrincipal? claimsPrincipal);
}
