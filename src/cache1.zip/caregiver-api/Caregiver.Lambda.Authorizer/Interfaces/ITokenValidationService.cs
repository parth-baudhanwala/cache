﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface ITokenValidationService
{
    ClaimsPrincipal? ValidateToken(string token, TokenValidationParameters tokenValidationParameters);
}
