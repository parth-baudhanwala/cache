﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface IPolicyBuilderService
{
    void AllowAllMethods();

    void AllowMethod(HttpVerb httpVerb, string resource);

    void DenyAllMethods();

    void DenyMethod(HttpVerb httpVerb, string resource);

    Response Build(ApiGatewayArn apiGatewayArn, string principalId);

    Response BuildSwagger(APIGatewayCustomAuthorizerRequest request);

}
