﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface IClaimsPrincipalService
{
    string GetPrincipalId(ClaimsPrincipal? claimsPrincipal);
}
