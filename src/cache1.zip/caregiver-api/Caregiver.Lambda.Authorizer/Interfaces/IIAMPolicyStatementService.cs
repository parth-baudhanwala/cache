﻿namespace Caregiver.Lambda.Authorizer.Interfaces;

public interface IIAMPolicyStatementService
{
    List<APIGatewayCustomAuthorizerPolicy.IAMPolicyStatement> GetIAMPoliciesStatement(List<ApiGatewayArn> allowedMethodArns, List<ApiGatewayArn> deniedMethodArns);

    List<APIGatewayCustomAuthorizerPolicy.IAMPolicyStatement> GetSwaggerPolicyStatement(APIGatewayCustomAuthorizerRequest request);
}
