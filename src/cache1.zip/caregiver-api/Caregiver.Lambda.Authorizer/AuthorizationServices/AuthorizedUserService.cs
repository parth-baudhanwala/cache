﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class AuthorizedUserService : IAuthorizedUserService
{
    public AuthorizedUser GetAuthorizedUserInfoFromClaims(ClaimsPrincipal? claimsPrincipal) =>
         new(Convert.ToInt64(claimsPrincipal?.Claims?.FirstOrDefault(claimType => claimType.Type.Contains("nameidentifier"))?.Value),
                 Convert.ToInt64(claimsPrincipal?.Claims?.FirstOrDefault(claimType => claimType.Type.ToLower().Equals("vendorid"))?.Value),
                 claimsPrincipal?.Identity?.Name,
                 claimsPrincipal?.Claims?.FirstOrDefault(claimType => claimType.Type.ToLower().Equals("firstname"))?.Value,
                 claimsPrincipal?.Claims?.FirstOrDefault(claimType => claimType.Type.ToLower().Equals("lastname"))?.Value,
                 claimsPrincipal?.Claims?.FirstOrDefault(claimType => claimType.Type.Contains("emailaddress"))?.Value,
                 Convert.ToBoolean(claimsPrincipal?.Claims.FirstOrDefault(claimsPrincipal => claimsPrincipal.Type.ToLower().Equals("impersonated"))?.Value),
                 claimsPrincipal?.Claims?.FirstOrDefault(claimType => claimType.Type.Contains("client_id"))?.Value);

}
