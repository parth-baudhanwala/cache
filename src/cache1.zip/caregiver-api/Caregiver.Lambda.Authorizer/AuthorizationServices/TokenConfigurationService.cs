﻿using System.Globalization;

namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class TokenConfigurationService : ITokenConfigurationService
{
    private const string EnvironmentUpdateKeyVariableKey = "IdentityJWKSUpdatedDate";
    private const string EnvironmentIdentityJWKSKey = "IdentityJWKS";
    private const string EnvironmentUpdateKeyVariableKeyIDP = "IDPJWKSUpdatedDate";
    private const string EnvironmentIDPJWKSKey = "IDPJWKS";
    private readonly ILogger _logger;
    private readonly IJsonWebKeyService _jsonWebKeyService;
    private readonly IJsonWebKeyClient _jsonWebKeyClient;
    private readonly IEnvironmentVariableService _environmentVariableService;
    private readonly AuthorizationOptions _authorizationOptions;

    public TokenConfigurationService(ILogger logger, IJsonWebKeyService jsonWebKeyService, IJsonWebKeyClient jsonWebKeyClient, IOptionsSnapshot<AuthorizationOptions> authorizationOptions, IEnvironmentVariableService environmentVariableService)
    {
        _logger = logger;
        _jsonWebKeyService = jsonWebKeyService;
        _jsonWebKeyClient = jsonWebKeyClient;
        _authorizationOptions = authorizationOptions.Value;
        _environmentVariableService = environmentVariableService;
    }

    public TokenValidationParameters GetJsonWebTokensConfiguration(bool isOld = true)
    {
        _logger.Debug("Building JWT Configuration Instance");
              
        TokenValidationParameters jwtTokenValidationParameterConfig = new()
        {
            ValidIssuer = isOld ? _authorizationOptions.ValidIssuer : _authorizationOptions.IDPValidIssuer,
            ValidAudience = _authorizationOptions.ValidAudience,
            IssuerSigningKeys = GetSecurityKeys(isOld),
            ValidateAudience = false,
            ValidateIssuer = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true
        };

        _logger.Debug("Successfully built JWT Configuration Instance");

        return jwtTokenValidationParameterConfig;
    }

    private ICollection<SecurityKey> GetSecurityKeys(bool isOld = true)
    {
        string? jwksFromEnvironmentVariable;
        var jwks = string.Empty;
        if (isOld)
        {
            jwksFromEnvironmentVariable = GetJsonWebKeySetFromLambdaEnvironment();
            jwks = jwksFromEnvironmentVariable;
            if (jwks.Equals(string.Empty))
            {
                jwks = GetJsonWebKeySetFromIdentityServer();
            }
        }
        else
        {
            jwksFromEnvironmentVariable = GetJsonWebKeySetFromLambdaEnvironmentIDP();
            jwks = jwksFromEnvironmentVariable;
            if (jwks.Equals(string.Empty))
            {
                jwks = GetJsonWebKeySetFromIDPServer();
            }
        }
        try
        {
            _logger.Debug("Retrieving Signing Keys from Json received from Identity provider");

            var signingKeys = _jsonWebKeyService.GetSigningKeys(jwks);

            _logger.Debug("Successfully retrieved Signing Keys from Json received from Identity Provider");

            return signingKeys;

        }
        catch (Exception ex)
        {
            _logger.Error("Could not deserialize the signing keys provided from the identity server. JWKS Received {jwks}", jwks);
            throw new JsonWebKeyServiceException(ex);
        }
    }

    private string GetJsonWebKeySetFromIdentityServer()
    {
        string jwksUrl = _authorizationOptions.IdentityJWKSUrl;
        try
        {
            _logger.Debug("Sending Request to Identity Server with {URI}", jwksUrl);

            var jwks = _jsonWebKeyClient.GetJsonWebKeySet(jwksUrl);

            _environmentVariableService.Set(EnvironmentIdentityJWKSKey, jwks);
            _environmentVariableService.Set(EnvironmentUpdateKeyVariableKey, DateTime.UtcNow);

            _logger.Debug("Received Response From Identity Server");

            return jwks.DefaultTo(null);
        }
        catch (Exception ex)
        {
            _logger.Error("Could not successfully communicate with the Identity Service Provider.\nRequested Endpoint : {JWKSEndpont}\nException : {ExpectionMessage}", jwksUrl, ex.Message);
            throw new JsonWebKeyClientException(ex);

        }
    }
    private string GetJsonWebKeySetFromIDPServer()
    {
        string jwksUrl = _authorizationOptions.IDPJWKSUrl;
        try
        {
            _logger.Debug("Sending Request to Identity Server with {URI}", jwksUrl);

            var jwks = _jsonWebKeyClient.GetJsonWebKeySet(jwksUrl);

            _environmentVariableService.Set(EnvironmentIDPJWKSKey, jwks);
            _environmentVariableService.Set(EnvironmentUpdateKeyVariableKeyIDP, DateTime.UtcNow);

            _logger.Debug("Received Response From Identity Server");

            return jwks.DefaultTo(null);
        }
        catch (Exception ex)
        {
            _logger.Error("Could not successfully communicate with the Identity Service Provider.\nRequested Endpoint : {JWKSEndpont}\nException : {ExpectionMessage}", jwksUrl, ex.Message);
            throw new JsonWebKeyClientException(ex);

        }
    }


    private string? GetJsonWebKeySetFromLambdaEnvironment()
    {
        string? jwks = string.Empty;
        if (_environmentVariableService.HasKey(EnvironmentIdentityJWKSKey) && _environmentVariableService.HasKey(EnvironmentUpdateKeyVariableKey))
        {
            string? utcDateString = _environmentVariableService.Get(EnvironmentUpdateKeyVariableKey);
            if (DateTime.TryParse(utcDateString, null, DateTimeStyles.RoundtripKind, out DateTime utcDate))
            {
                TimeSpan elapsedTime = DateTime.UtcNow - utcDate;
                if (elapsedTime < TimeSpan.FromDays(1))
                {
                    _logger.Debug("Reading JWKS from Environment Variable");
                    jwks = _environmentVariableService.Get(EnvironmentIdentityJWKSKey);
                }
            }
        }
        return jwks;
    }
    private string? GetJsonWebKeySetFromLambdaEnvironmentIDP()
    {
        string? jwks = string.Empty;
        if (_environmentVariableService.HasKey(EnvironmentIDPJWKSKey) && _environmentVariableService.HasKey(EnvironmentUpdateKeyVariableKeyIDP))
        {
            string? utcDateString = _environmentVariableService.Get(EnvironmentUpdateKeyVariableKeyIDP);
            if (DateTime.TryParse(utcDateString, null, DateTimeStyles.RoundtripKind, out DateTime utcDate))
            {
                TimeSpan elapsedTime = DateTime.UtcNow - utcDate;
                if (elapsedTime < TimeSpan.FromDays(1))
                {
                    _logger.Debug("Reading JWKS from Environment Variable");
                    jwks = _environmentVariableService.Get(EnvironmentIDPJWKSKey);
                }
            }
        }
        return jwks;
    }
}
