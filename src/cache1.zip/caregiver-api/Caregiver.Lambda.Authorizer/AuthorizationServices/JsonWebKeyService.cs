﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class JsonWebKeyService : IJsonWebKeyService
{
    public ICollection<SecurityKey> GetSigningKeys(string jsonWebKeySet) => new JsonWebKeySet(jsonWebKeySet).GetSigningKeys();
}
