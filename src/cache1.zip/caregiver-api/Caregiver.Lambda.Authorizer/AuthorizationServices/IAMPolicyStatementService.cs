﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public sealed class IAMPolicyStatementService : IIAMPolicyStatementService
{
    private readonly string _apiAction = "execute-api:Invoke";
    public List<APIGatewayCustomAuthorizerPolicy.IAMPolicyStatement> GetIAMPoliciesStatement(List<ApiGatewayArn> allowedMethodArns, List<ApiGatewayArn> deniedMethodArns)
    {
        List<APIGatewayCustomAuthorizerPolicy.IAMPolicyStatement> iAMPolicyStatements = new();
        AddStatements(Effect.Allow, allowedMethodArns);
        AddStatements(Effect.Deny, deniedMethodArns);

        void AddStatements(Effect effect, List<ApiGatewayArn> methodArns) =>
            methodArns.ForEach(amazonResource =>
            {
                iAMPolicyStatements.Add(new APIGatewayCustomAuthorizerPolicy.IAMPolicyStatement
                {
                    Effect = effect.ToString(),
                    Resource = new HashSet<string> { amazonResource.ToString() },
                    Action = new HashSet<string> { _apiAction }
                });
            });
        return iAMPolicyStatements;
    }

    public List<APIGatewayCustomAuthorizerPolicy.IAMPolicyStatement> GetSwaggerPolicyStatement(APIGatewayCustomAuthorizerRequest request) =>
        new List<APIGatewayCustomAuthorizerPolicy.IAMPolicyStatement>
        {
            new APIGatewayCustomAuthorizerPolicy.IAMPolicyStatement
            {
                Effect = Effect.Allow.ToString(),
                Resource = new HashSet<string> {request.MethodArn},
                Action = new HashSet<string> { _apiAction }
            }
        };
}
