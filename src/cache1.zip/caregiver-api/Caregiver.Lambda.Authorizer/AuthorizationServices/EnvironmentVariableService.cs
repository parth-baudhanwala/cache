﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class EnvironmentVariableService : IEnvironmentVariableService
{
    public string? Get(string environmentVariableKey) => Environment.GetEnvironmentVariable(environmentVariableKey);

    public bool HasKey(string environmentVariableKey) => Environment.GetEnvironmentVariable(environmentVariableKey) is not null;

    public void Set<T>(string environmentVariableKey, T objectToSet) =>
        Environment.SetEnvironmentVariable(environmentVariableKey,
            objectToSet?.ToString() ?? throw new ArgumentNullException(nameof(objectToSet), "Cannot set a null object to an environment variable."));
}
