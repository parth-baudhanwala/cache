﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class PolicyBuilderService : IPolicyBuilderService
{
    private readonly IIAMPolicyStatementService _iAMPolicyStatementService;

    public PolicyBuilderService(IIAMPolicyStatementService iAMPolicyStatementService) => _iAMPolicyStatementService = iAMPolicyStatementService;


    private readonly string _policyVersion = "2012-10-17";
    private readonly Regex _pathRegex = new("^[/.a-zA-Z0-9-\\*]+$");
    private readonly List<ApiGatewayArn> _allowMethodsArns = new();
    private readonly List<ApiGatewayArn> _denyMethodsArns = new();

    public void AllowAllMethods() => AddMethod(Effect.Allow, HttpVerb.All, "*");

    public void DenyAllMethods() => AddMethod(Effect.Deny, HttpVerb.All, "*");

    public void AllowMethod(HttpVerb httpVerb, string resource) => AddMethod(Effect.Allow, httpVerb, resource);

    public void DenyMethod(HttpVerb httpVerb, string resource) => AddMethod(Effect.Deny, httpVerb, resource);

    public Response Build(ApiGatewayArn apiGatewayArn, string principalId)
    {
        PopulateMethods(apiGatewayArn);
        var iamPoliciesStatements = _iAMPolicyStatementService.GetIAMPoliciesStatement(_allowMethodsArns, _denyMethodsArns);

        return new Response
        {
            PrincipalID = principalId,
            PolicyDocument = new APIGatewayCustomAuthorizerPolicy
            {
                Version = _policyVersion,
                Statement = iamPoliciesStatements
            }
        };
    }

    public Response BuildSwagger(APIGatewayCustomAuthorizerRequest request) =>
        new()
        {
            PrincipalID = new Guid().ToString(),
            PolicyDocument = new APIGatewayCustomAuthorizerPolicy
            {
                Version = _policyVersion,
                Statement = _iAMPolicyStatementService.GetSwaggerPolicyStatement(request)
            }
        };


    private void AddMethod(Effect effect, HttpVerb httpverb, string resource)
    {
        if (httpverb is null) throw new AuthPolicyBuilderException($"{nameof(httpverb)} cannot be null");

        if (resource is null) throw new AuthPolicyBuilderException($"{nameof(resource)} cannot be null");

        if (!_pathRegex.IsMatch(resource)) throw new AuthPolicyBuilderException($"{nameof(resource)} is invalid : {resource}. Path should match {_pathRegex}");

        var cleanedResources = resource.First().Equals('/') ? resource[1..] : resource;

        var arn = new ApiGatewayArn
        {
            Verb = httpverb.ToString(),
            Resource = cleanedResources,
        };

        switch (effect)
        {
            case Effect.Deny:
                _denyMethodsArns.Add(arn);
                return;
            case Effect.Allow:
                _allowMethodsArns.Add(arn);
                return;
        }
    }

    private void PopulateMethods(ApiGatewayArn apiGatewayArn)
    {
        Populate(_allowMethodsArns);
        Populate(_denyMethodsArns);

        void Populate(List<ApiGatewayArn> methodArns)
        {
            methodArns.ForEach(amazonResource =>
            {
                amazonResource.Partition = apiGatewayArn.Partition;
                amazonResource.Service = apiGatewayArn.Service;
                amazonResource.Region = apiGatewayArn.Region;
                amazonResource.AWSAccountId = apiGatewayArn.AWSAccountId;
                amazonResource.RestAPIId = apiGatewayArn.RestAPIId;
                amazonResource.Stage = apiGatewayArn.Stage;
            });
        }
    }
}
