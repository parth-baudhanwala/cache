﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class RequestValidationService : IRequestValidationService
{
    private readonly ILogger _logger;
    public RequestValidationService(ILogger logger)
    {
        _logger = logger;
    }
    public void ValidateRequest(APIGatewayCustomAuthorizerRequest request, out ApiGatewayArn? apiGatewayArn)
    {
        _logger.Debug("Validating Request.");

        apiGatewayArn = null;
        List<string> validationMessages = new();

        if (request is null)
        {
            validationMessages.Add("Request is required.");
        }
        else
        {
            switch (request.Type)
            {
                case null:
                    validationMessages.Add($"Expected '{nameof(request.Type)}' to have been provided.");
                    break;
                case string type when !type.ToUpperInvariant().Equals("TOKEN"):
                    validationMessages.Add($"Expected '{nameof(request.Type)}' to have value 'TOKEN'.");
                    break;
            }

            switch (request.AuthorizationToken)
            {
                case null:
                    validationMessages.Add($"Expected '{nameof(request.AuthorizationToken)}'. It cannot be null.");
                    break;
                case string authorizationToken when authorizationToken.Equals(string.Empty):
                    validationMessages.Add($"Expected '{nameof(request.AuthorizationToken)}' to have been provided.");
                    break;
                case string authorizationToken when (!new Regex("^Bearer .*$").IsMatch(authorizationToken)):
                    validationMessages.Add($"Expected '{nameof(request.AuthorizationToken)}' to match '^Bearer .*$'. Authorization Token : {request.AuthorizationToken}");
                    break;
            }

            switch (request.MethodArn)
            {
                case null:
                    validationMessages.Add($"Expected '{nameof(request.MethodArn)}'. It cannot be null");
                    break;
                case string methodArn when string.IsNullOrEmpty(methodArn):
                    validationMessages.Add($"Expected '{nameof(request.MethodArn)}' to have been provided.'");
                    break;
                case string methodArn when !(ApiGatewayArn.TryParse(methodArn, out apiGatewayArn)):
                    validationMessages.Add($"Could not parse '{nameof(request.MethodArn)}'. MethodArn : {request.MethodArn}.");
                    break;
            }

            if (validationMessages.Count > 0)
            {
                string logValidationMessage = string.Empty;
                validationMessages.ForEach(action: message =>
                {
                    logValidationMessage = string.Concat(logValidationMessage, message, "\n");
                });
                _logger.Error("Request Validation Failed:\n{RequestValidationMessages}", logValidationMessage);
                throw new RequestValidationException($"Request Validation Failed with Validation Messages:\n{logValidationMessage}");
            }

            _logger.Debug("Successfully validated request");
        }
    }
}
