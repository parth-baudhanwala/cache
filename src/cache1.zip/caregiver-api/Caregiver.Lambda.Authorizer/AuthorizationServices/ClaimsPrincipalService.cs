﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class ClaimsPrincipalService : IClaimsPrincipalService
{
    private readonly ILogger _logger;

    public ClaimsPrincipalService(ILogger logger)
    {
        _logger = logger;
    }

    public string GetPrincipalId(ClaimsPrincipal? claimsPrincipal)
    {
        string principalId;
        _logger.Debug("Parsing principalId from claims principals");

        if (claimsPrincipal is null)
            throw new ClaimsPrincipalException("User Claims Found to be null");

        var nameIdentifier = claimsPrincipal.Claims.FirstOrDefault(claimsType => claimsType.Type == ClaimTypes.NameIdentifier);
        var clientIdentifier = claimsPrincipal.Claims.FirstOrDefault(claimsType => claimsType.Type == "client_id");

        if (nameIdentifier is null)
        {
            principalId = clientIdentifier?.Value ?? Guid.NewGuid().ToString();
            _logger.Debug("nameIdentifier not found in token. Client Information = {client_id}", principalId);
        }
        else
        {
            principalId = nameIdentifier.Value;
        }

        _logger.Debug("Successfully parsed principalId. {PrincipalId}", principalId);
        return principalId;

    }
}
