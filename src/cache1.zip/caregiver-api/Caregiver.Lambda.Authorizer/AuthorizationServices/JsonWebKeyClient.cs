﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class JsonWebKeyClient : IJsonWebKeyClient
{
    private static readonly Lazy<HttpClient> _httpClient = new Lazy<HttpClient>(() => new HttpClient());
    public string GetJsonWebKeySet(string jsonWebKeySetUri) => _httpClient.Value.GetStringAsync(jsonWebKeySetUri).Result;
}
