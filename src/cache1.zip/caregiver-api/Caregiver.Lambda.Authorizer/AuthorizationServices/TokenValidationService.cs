﻿namespace Caregiver.Lambda.Authorizer.AuthorizationServices;

public class TokenValidationService : ITokenValidationService
{
    private readonly ILogger _logger;
    private readonly ISecurityTokenValidator _tokenValidator;
    private readonly IAuthorizedUserService _authorizedUserService;

    public TokenValidationService(ILogger logger,
        ISecurityTokenValidator tokenValidator,
        IAuthorizedUserService authorizedUserService)
    {
        _logger = logger;
        _tokenValidator = tokenValidator;
        _authorizedUserService = authorizedUserService;
    }

    public ClaimsPrincipal? ValidateToken(string token, TokenValidationParameters tokenValidationParameters)
    {
        try
        {
            _logger.Debug("Validating token with configuration built");

            SecurityToken validatedToken;
            ClaimsPrincipal claimsPrincipal = _tokenValidator.ValidateToken(token, tokenValidationParameters, out validatedToken);

            //_logger.Debug("Successfully Validated Token For UserId : {UserID}", claimsPrincipal?.Identity?.Name);

            //_logger.Information("User Information received from Claims {UserInfo}", _authorizedUserService.GetAuthorizedUserInfoFromClaims(claimsPrincipal).ToString());

            return claimsPrincipal;
        }
        catch (Exception ex)
        {

            throw new TokenValidationException(ex);
        }
    }
}
