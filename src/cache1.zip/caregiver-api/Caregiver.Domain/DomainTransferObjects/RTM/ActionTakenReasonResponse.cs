﻿namespace Caregiver.Domain.DomainTransferObjects.RTM
{
    public class ActionTakenReasonResponse
    {
        public int ReasonID { get; set; }
        public string? ReasonText { get; set; }
        public bool OMIGEnabled { get; set; }
        public short SortOrder { get; set; }
    }
}
