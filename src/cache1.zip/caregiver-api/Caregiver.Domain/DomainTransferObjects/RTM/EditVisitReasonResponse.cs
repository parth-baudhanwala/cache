﻿namespace Caregiver.Domain.DomainTransferObjects.RTM
{
    public class EditVisitReasonResponse
    {
        public int ReasonID { get; set; }
        public string? Reason { get; set; }
        public bool ReasonNoteRequired { get; set; }
        public short ReasonNoteMinCharacterCount { get; set; }
        public short SortOrder { get; set; }
        public bool OMIGEnabled { get; set; }
        public string? CompanyType { get; set; }
    }
}
