﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.RTM
{
    public class ActionTakenReasonRequest : IRequest<List<ActionTakenReasonResponse>>
    {
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "UserID should be greater than 0.")]
        public int UserID { get; set; }

        public int ContractChhaID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "ProviderID should be greater than 0.")]
        public int ProviderID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "ReasonID should be greater than 0.")]
        public int ReasonID { get; set; }
    }
}
