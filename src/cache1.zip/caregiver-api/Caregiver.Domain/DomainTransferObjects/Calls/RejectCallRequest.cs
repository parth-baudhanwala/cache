﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Calls
{
    public class RejectCallRequest : IRequest<RejectCallResponse>
    {
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "UserID should be greater than 0.")]
        public int UserID { get; set; }
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "MaintenanceID should be greater than 0.")]
        public int MaintenanceID { get; set; }
    }
}
