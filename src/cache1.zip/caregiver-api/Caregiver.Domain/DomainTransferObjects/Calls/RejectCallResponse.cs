﻿namespace Caregiver.Domain.DomainTransferObjects.Calls
{
    public class RejectCallResponse
    {
        public int? ReturnValue { get; set; }
        public string? MessageText { get; set; }
    }
}
