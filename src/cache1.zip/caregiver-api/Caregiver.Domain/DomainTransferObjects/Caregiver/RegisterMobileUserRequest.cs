﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class RegisterMobileUserRequest : IRequest<RegisterMobileUserResponse>
    {
        public Guid CaregiverUserGlobalId { get; set; }

        public Guid ProviderGlobalId { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "ProviderId should be greater than 0.")]
        public int ProviderId { get; set; }

        public Guid CaregiverGlobalId { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "CaregiverId should be greater than 0.")]
        public int CaregiverId { get; set; }

        public Guid OfficeGlobalId { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "OfficeId should be greater than 0.")]
        public int OfficeId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string PhoneNumber { get; set; }

        public string Email { get; set; }

        public string SSNPartial { get; set; }

        public DateTime DateofBirth { get; set; }

        public string MobileDeviceID { get; set; }

        public bool IsPCIuser { get; set; }

        public string ApplicationName { get; set; }
    }
}
