﻿using MediatR;

namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class GetCaregiverAgencyDetailsRequest : IRequest<GetCaregiverAgencyDetailsResponse>
    {
        public Guid GlobalCaregiverID { get; set; }
    }
}
