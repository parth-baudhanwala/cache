﻿namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class ActivationCodeGenerationResponse
    {
        public string ActivationCode { get; set; }
        public string? MessageText { get; set; }
        public Guid TransactionId { get; set; }


    }
}
