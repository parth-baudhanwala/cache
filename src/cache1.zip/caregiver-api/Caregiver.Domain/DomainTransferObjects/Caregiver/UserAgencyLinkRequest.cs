﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class UserAgencyLinkRequest : IRequest<UserAgencyLinkResponse>
    {
       
        public Guid GlobalCaregiverUserID { get; set; }
        public Guid GlobalProviderID { get; set; }
        public Guid GlobalCaregiverID { get; set; }
        public Guid GlobalOfficeID { get; set; }    
        public bool IsAgencyLinked { get; set; }  
        public string? IsPCIUser { get; set; } 
        public string ApplicationName { get; set; } = string.Empty;  

    }
}
