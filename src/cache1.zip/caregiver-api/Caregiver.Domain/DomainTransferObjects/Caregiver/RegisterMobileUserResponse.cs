﻿namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class RegisterMobileUserResponse
    {
        public int ReturnValue { get; set; }
        public string? MessageText { get; set; }
        public Guid TransactionId { get; set; }
    }
}
