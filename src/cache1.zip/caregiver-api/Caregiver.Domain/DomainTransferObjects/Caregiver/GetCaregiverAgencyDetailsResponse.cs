﻿using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class GetCaregiverAgencyDetailsResponse
    {
        public Guid GlobalProviderID { get; set; }

        public int ProviderID { get; set; }

        public Guid GlobalCaregiverID { get; set; }

        public int CaregiverID { get; set; }

        public Guid GlobalOfficeID { get; set; }

        public int OfficeID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string OfficeName { get; set; }

        public string ProviderName { get; set; }

        public string ProviderEnvironment { get; set; }

        public Guid TransactionID { get; set; }
    }
}
