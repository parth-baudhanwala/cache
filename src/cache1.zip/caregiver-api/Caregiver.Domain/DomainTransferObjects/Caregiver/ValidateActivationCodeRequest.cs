﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class ValidateActivationCodeRequest : IRequest<ValidateActivationCodeResponse>
    {
        [Required]
        public Guid CaregiverUserGlobalID { get; set; }

        [Required]
        [StringLength(7, MinimumLength = 7, ErrorMessage = "ActivationCode should be 7 character length.")]
        public string ActivationCode { get; set; } = string.Empty;

        public Guid TransactionID { get; set; } = Guid.Empty;
    }
}
