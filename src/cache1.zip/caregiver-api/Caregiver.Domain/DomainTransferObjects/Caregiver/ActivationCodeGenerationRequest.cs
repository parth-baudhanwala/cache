﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class ActivationCodeGenerationRequest : IRequest<ActivationCodeGenerationResponse>
    {        
        public Guid CaregiverGlobalId { get; set; }
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "CaregiverId should be greater than 0.")]
        public int CaregiverId { get; set; }
        public string ProviderEnvironment { get; set; } = string.Empty;
        public int UserId { get; set; }
    }
}
