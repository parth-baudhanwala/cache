﻿namespace Caregiver.Domain.DomainTransferObjects.Caregiver
{
    public class ValidateActivationCodeResponse : GetCaregiverAgencyDetailsResponse
    {
        public Guid GlobalCaregiverUserID { get; set; }
        public string MessageText { get; set; } = string.Empty;
    }
}
