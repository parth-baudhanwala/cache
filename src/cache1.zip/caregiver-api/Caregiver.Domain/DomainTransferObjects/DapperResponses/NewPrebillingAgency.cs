﻿namespace Caregiver.Domain.DomainTransferObjects.DapperResponses;

public sealed record NewPrebillingAgency(
    int VendorID,
    string VendorName
);
