﻿namespace Caregiver.Domain.DomainTransferObjects.DapperResponses;
public sealed record CallTimeExistsValidationResponse(
    int IsVisitEndTimeExists,
    int IsVisitStartTimeExists,
    byte IsBilled
);
public sealed record CallTypeValidationResponse(
    short CallType
);