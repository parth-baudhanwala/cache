﻿namespace Caregiver.Domain.DomainTransferObjects.Dtos;

public sealed record NewPrebillingAgencyDTO(
    int VendorId,
    string Name
);
