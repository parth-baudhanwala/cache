﻿namespace Caregiver.Domain.DomainTransferObjects
{
    public class ApiResponse<T>
    {
        /// <summary>
        /// Gets or sets the ApiResult of Generic Type T.
        /// </summary>
        public T Result { get; set; }

        /// <summary>
        /// Gets or sets ErrorMessage.
        /// </summary>
        public List<ResponseMessage> ErrorMessage { get; set; } = new List<ResponseMessage>();
    }
}
