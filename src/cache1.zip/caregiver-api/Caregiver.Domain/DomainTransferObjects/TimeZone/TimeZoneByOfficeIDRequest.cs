﻿namespace Caregiver.Domain.DomainTransferObjects.TimeZone
{
    public class TimeZoneByOfficeIDRequest
    {
        public int OfficeID { get; set; }
    }
}
