﻿namespace Caregiver.Domain.DomainTransferObjects.TimeZone
{
    public class TimeZoneResponse
    {
        public int OfficeID { get; set; }
        public string? TimeZone { get; set; }
    }
}
