﻿namespace Caregiver.Domain.DomainTransferObjects.TimeZone
{
    public class TimeZoneMaster
    {
        public string? TimeZoneName { get; set; }
        public string? TimeZoneStandardName { get; set; }
        public double OffSetMinutes { get; set; }
        public double DSTOffSetMinitues { get; set; }
    }
}
