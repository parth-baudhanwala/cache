﻿using Caregiver.Domain.DomainTransferObjects.Common;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace Caregiver.Domain.DomainTransferObjects.Prebilling
{
    [XmlRoot("vs")]
    public class VisitChangeRequest
    {
        public long PkID { get; set; }

        [XmlIgnore]
        [JsonIgnore]
        public ConfigurationType TypeEnum { get; set; }

        [XmlAttribute("ProvId")]
        public int ProvID { get; set; }

        public long PLID { get; set; }

        public long PLCID { get; set; }

        public long MLCID { get; set; }

        [XmlElement("v")]
        public List<VisitDetail> Visits { get; set; }

        public int UID { get; set; }

        public VisitChangeInitiator InitByEnum { get; set; }

        public string InitBy { get { return InitByEnum.ToString(); } }

        public int TotalVisits { get; set; }

        public int TotalGroups { get; set; }

        public int CurrentGroup { get; set; }
    }
}
