﻿using System.Xml.Serialization;

namespace Caregiver.Domain.DomainTransferObjects.Prebilling
{
    public class VisitDetail
    {
        public long PLDID { get; set; }

        [XmlAttribute("id")]
        public long VID { get; set; }

        [XmlAttribute("CaregiverID")]
        public long CaregiverID { get; set; }

        [XmlAttribute("PatientID")]
        public long PatientID { get; set; }

        [XmlAttribute("VisitDate")]
        public string? VisitDate { get; set; }

        [XmlAttribute("ScheduledStartTime")]
        public string? ScheduledStartTime { get; set; }

        [XmlAttribute("ScheduledEndTime")]
        public string? ScheduledEndTime { get; set; }

        [XmlAttribute("VisitStartTime")]
        public string? VisitStartTime { get; set; }

        [XmlAttribute("VisitEndTime")]
        public string? VisitEndTime { get; set; }

        [XmlAttribute("OldVisitStartTime")]
        public string? OldVisitStartTime { get; set; }

        [XmlAttribute("OldVisitEndTime")]
        public string? OldVisitEndTime { get; set; }
    }
}
