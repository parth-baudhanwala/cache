﻿namespace Caregiver.Domain.DomainTransferObjects
{
    public class ResponseMessage
    {
        /// <summary>
        /// Get Set Key
        /// </summary>
        public string? Key { get; set; }

        /// <summary>
        /// Get Set Code
        /// </summary>
        public string? Code { get; set; }

        /// <summary>
        /// Get Set Message
        /// </summary>
        public string? Message { get; set; }

        /// <summary>
        /// Get Set Exception
        /// </summary>
        public string? Exception { get; set; }
    }
}
