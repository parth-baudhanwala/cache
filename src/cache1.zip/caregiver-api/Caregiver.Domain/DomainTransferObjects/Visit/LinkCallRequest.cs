﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class LinkCallRequest : IRequest<LinkCallResponse>
    {
        [Required]
        public int UserID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "MaintenanceID should be greater than 0.")]
        public int MaintenanceID { get; set; }

        [Required]
        [Range(1, long.MaxValue, ErrorMessage = "VisitID should be greater than 0.")]
        public long VisitID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "ProviderID should be greater than 0.")]
        public int ProviderID { get; set; }

        public string? UpdateScheduleOverTime { get; set; }
        public string? UpdateWithAideCompliant { get; set; }
        public string? AutoselectTimesheetRequired { get; set; }

        [Required]
        [Range(1, 2, ErrorMessage = "CallType should not be other than 1 or 2.")]
        public int CallType { get; set; }

        public int ReasonID { get; set; }
        public int ActionTakenReasonID { get; set; }
        public string? Notes { get; set; }
    }
}
