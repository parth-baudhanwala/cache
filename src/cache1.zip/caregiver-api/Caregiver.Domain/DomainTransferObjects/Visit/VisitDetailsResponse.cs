﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class VisitDetailsResponse
    {
        public string? PatientName { get; set; }
        public string? PatientCode { get; set; }
        public string? CaregiverName { get; set; }
        public string? CaregiverCode { get; set; }
        public DateTime? VisitStartTime { get; set; }
        public DateTime? VisitEndTime { get; set; }
        public DateTime? ScheduledStartTime { get; set; }
        public DateTime? ScheduledEndTime { get; set; }
        public string? VisitType { get; set; }
        public int VisitContractChhaID { get; set; }
        public string? EnableVisitMaintenanceWindow { get; set; }
        public bool IsReasonRequired { get; set; }
        public bool IsActionTakenRequired { get; set; }
    }
}