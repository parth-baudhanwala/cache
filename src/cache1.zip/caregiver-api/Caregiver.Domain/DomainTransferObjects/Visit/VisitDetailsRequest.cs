﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class VisitDetailsRequest : IRequest<VisitDetailsResponse>
    {
        [Required]
        [Range(1, long.MaxValue, ErrorMessage = "VisitID should be greater than 0.")]
        public long VisitID { get; set; }
    }
}
