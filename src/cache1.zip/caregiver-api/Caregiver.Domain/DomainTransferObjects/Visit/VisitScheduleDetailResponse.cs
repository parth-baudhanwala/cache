﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class VisitScheduleDetailResponse
    {
        public long VisitScheduleDetailsID { get; set; }
        public int OfficeID { get; set; }
        public int AlternateServiceType { get; set; }
        public bool AlternateVisitVerification { get; set; }
        public bool AlternateServiceVerification { get; set; }
        public string? AlternateEVVPatientSignatureStatus { get; set; }
        public string? AlternateEVVVoiceNoteStatus { get; set; }
        public Guid? AlternateEVVPatientSignature { get; set; }
        public Guid? AlternateEVVVoiceNote { get; set; }
    }
}
