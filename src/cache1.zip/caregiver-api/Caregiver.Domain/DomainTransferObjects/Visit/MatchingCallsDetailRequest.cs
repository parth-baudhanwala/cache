﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class MatchingCallsDetailRequest : IRequest<List<MatchingCallsDetailResponse>>
    {
        [Required]
        [Range(1, long.MaxValue, ErrorMessage = "VisitID should be greater than 0.")]
        public long VisitID { get; set; }

        [Required]
        [Range(1, 2, ErrorMessage = "CallType should not be other than 1 or 2.")]
        public int CallType { get; set; }

        //[Required]//todo Make it required when we did changes in UCP and globalshowmatching call
        //[Range(1, int.MaxValue, ErrorMessage = "UserID should be greater than 0.")]
        public int UserID { get; set; }

    }
}
