﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class ACSDetailResponse
    {
        public long MaintenanceID { get; set; }
        public DateTime? CallDate { get; set; }
        public string? CallTime { get; set; }
        public string? AssignmentID { get; set; }
        public int AideID { get; set; }
        public string? AideName { get; set; }
        public string? AideCode { get; set; }
        public string? PatientName { get; set; }
        public long PatientID { get; set; }
        public string? CallType { get; set; }
        public string? CallerID { get; set; }
        public string? FormattedCallerID { get; set; }
        public string? Status { get; set; }
        public bool IsCallerIDMatch { get; set; }
        public string? RoundedCallTime { get; set; }
        public int AideDisciplineType { get; set; }
        public int VendorID { get; set; }
        public int StatusID { get; set; }
        public DateTime? CallDateTime { get; set; }
        public string? CallInTime { get; set; }
        public string? CallOutTime { get; set; }
        public string? RoundedCallInTime { get; set; }
        public string? RoundedCallOutTime { get; set; }
        public double? CallInMID { get; set; }
        public double? CallOutMID { get; set; }
        public bool IsInternalPatient { get; set; }
        public int OfficeID { get; set; }
        public string? AutoScheduleServiceTypeID { get; set; }
        public int ValidateAutoScheduleServiceTypeID { get; set; }
        public int ContractID { get; set; }
        public int ServiceCodeID { get; set; }
        public int Tot { get; set; }
        public int AutoSelectContractID { get; set; }
        public int AutoSelectServiceCodeID { get; set; }
        public string? EVVSource { get; set; }
        public double? POCHeaderID { get; set; }
        public bool IsVisitLocked { get; set; }
        public string? EVVType { get; set; }
        public string? CallInLongitude { get; set; }
        public string? CallInLatitude { get; set; }
        public string? CallOutLongitude { get; set; }
        public string? CallOutLatitude { get; set; }
        public string? EVVDeviceID { get; set; }
    }
}

