﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class UnScheduledVisitLinkedCallDetailsResponse
    {
        public string? CallUniqueID { get; set; }
        public long UnscheduledVisitID { get; set; }
        public long VisitID { get; set; }
    }
}
