﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class MatchingCallsDetailResponse
    {
        public long MaintenanceID { get; set; }
        public DateTime CallDateTime { get; set; }
        public string? AideName { get; set; }
        public string? OfficeAideCode { get; set; }
        public string? PatientName { get; set; }
        public string? OfficePatientCode { get; set; }
        public string? CallerID { get; set; }
        public string? EVVSource { get; set; }
        public string? EVVType { get; set; }
        public string? Longitude { get; set; }
        public string? Latitude { get; set; }
        public string? FobDeviceID { get; set; }
        public string? Status { get; set; }
        public string? MaintenanceStatus { get; set; }
        public int LinkProcess { get; set; }
        public bool AutoSelectTimesheetRequiredForUnrecognizedNumber { get; set; }
        public bool CallerIDAndPatientPhoneMismatch { get; set; }
        public bool IsLinkableVisit { get; set; } = true;
    }
}
