using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class MoveCallsToCallMaintenanceRequest : IRequest<MoveCallsToCallMaintenanceResponse>
    {
        [Required]
        public int UserID { get; set; }

        [Required]
        [Range(1, long.MaxValue, ErrorMessage = "VisitID should be greater than 0.")]
        public long VisitID { get; set; }

        public int CallIn { get; set; }
        public int CallOut { get; set; }
    }
}
