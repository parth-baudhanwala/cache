﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class VisitLockResponse
    {
        public Int16? IsVisitLocked { get; set; }
    }
}
