﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class LinkUnlinkCallDetailResponse
    {
        public string? CallUniqueID { get; set; }
        public string? EVVSource { get; set; }
        public string? EVVType { get; set; }
        public int VendorID { get; set; }
        public string? VerificationType { get; set; }
        public int Type { get; set; }
    }
}
