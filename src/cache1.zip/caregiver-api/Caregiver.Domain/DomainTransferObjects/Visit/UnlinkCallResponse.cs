﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class UnlinkCallResponse
    {
        public string? ReturnValue { get; set; }
        public string? MessageText { get; set; }
    }
}
