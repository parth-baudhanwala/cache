﻿using MediatR;

namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class LinkUnlinkCallDetailRequest : IRequest<LinkUnlinkCallDetailResponse>
    {
        public int UserID { get; set; }
        public int MaintenanceID { get; set; }
        public long VisitID { get; set; }
        public string? LinkUnlink { get; set; }
        public string? AppVersion { get; set; }
        public decimal Version { get; set; }
        public decimal MinorVersion { get; set; }
        public string? CallerInfo { get; set; }
    }
}
