﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class VisitExceptionRequest
    {
        public int UserID { get; set; }
        public long VisitID { get; set; }
        public int ProviderID { get; set; }
        public int OfficeID { get; set; }
        public int AlternateServiceType { get; set; }
        public int AlternateVisitVerification { get; set; }
        public string? AlternateEVVPatientSignatureStatus { get; set; }
        public int AlternateServiceVerification { get; set; }
        public string? AlternateEVVVoiceNoteStatus { get; set; }
        public string? AlternateEVVPatientSignature { get; set; }
        public string? AlternateEVVVoiceNote { get; set; }
        public string? LoginUserName { get; set; }
        public string? CallerInfo { get; set; }
    }
}
