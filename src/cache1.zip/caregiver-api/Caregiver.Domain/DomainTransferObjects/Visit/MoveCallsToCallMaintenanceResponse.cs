﻿namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class MoveCallsToCallMaintenanceResponse
    {
        public int IsDeleted { get; set; }
        public bool IsMovedToCallMaintainance { get; set; }
        public string? MessageText { get; set; }
    }
}