﻿using Caregiver.Domain.DomainTransferObjects.Common;
using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.BroadcastHistory
{
    public class BroadcastHistoryRequest : IRequest<List<BroadcastHistoryResponse>>
    {
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "UserID should be greater than 0.")]

        public int UserID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "ProviderID should be greater than 0.")]
        public int ProviderID { get; set; }

        public string? OfficeIDs { get; set; }

        public string? BroadcastName { get; set; }

        public string? Status { get; set; }

        public List<int>? BroadCastTypeIDs { get; set; }

        public string? ScheduledDateFrom { get; set; }

        public string? ScheduledDateTo { get; set; }

        public string? CreatedFrom { get; set; }

        public string? CreatedTo { get; set; }

        public int PageNo { get; set; }

        public int PageSize { get; set; }

        public string? SortColumn { get; set; }

        public string? SortDirection { get; set; }

        public string? CallerInfo { get; set; }

        public int UserPrimaryOfficeID { get; set; }

        public string? EntpApiUrl { get; set; }
    }
    public class BroadcastHistoryDetailsRequest : IRequest<List<BroadcastHistoryDetailsResponse>>
    {
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "UserID should be greater than 0.")]
        public int UserID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "ProviderID should be greater than 0.")]
        public int ProviderID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "BroadcastID should be greater than 0.")]
        public int BroadcastID { get; set; }

        public int PageNo { get; set; }

        public int PageSize { get; set; }

        public string? SortColumn { get; set; }

        public string? SortDirection { get; set; }

        public string? Status { get; set; }

        public string? CallerInfo { get; set; }

        public int UserPrimaryOfficeID { get; set; }

        public string? EntpApiUrl { get; set; }
    }

    public class BroadcastHistoryCancelRequest : DefaultParam, IRequest<long>
    {
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "BroadcastID should be greater than 0.")]
        public long BroadcastID { get; set; }

        public bool IsBroadCastKill { get; set; }

        public string? CallerInfo { get; set; }

        public long Result { get; set; }
    }
}
