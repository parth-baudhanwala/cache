﻿namespace Caregiver.Domain.DomainTransferObjects.BroadcastHistory
{
    public class BroadcastHistoryResponse
    {
        public int BroadcastID { get; set; }
        public string? Name { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Scheduled { get; set; }
        public DateTime? BroadcastInitiated { get; set; }
        public DateTime? BroadcastCompleted { get; set; }
        public string? Status { get; set; }
        public string? UserName { get; set; }
        public string? Message { get; set; }
        public int TotalRecord { get; set; }
    }
    public class BroadcastHistoryDetailsResponse
    {
        public string? EmployeeName { get; set; }
        public string? AideCode { get; set; }
        public string? MessageType { get; set; }
        public string? Phone { get; set; }
        public string? EmailAddress { get; set; }
        public string? Status { get; set; }
        public string? Reason { get; set; }
        public DateTime? BroadcastTime { get; set; }
        public int AllBroadcastTotalRecord { get; set; }
        public int DeliveredBroadcastTotalRecord { get; set; }
        public int FailedBroadcastTotalRecord { get; set; }
        public int NonConfiguredBroadcastTotalRecord { get; set; }
        public int TotalRecord { get; set; }
    }

    public class BroadcastHistoryCancelResponse
    {
        public long BroadCastResultID { get; set; }
    }
}
