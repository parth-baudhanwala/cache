﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class DefaultParam
    {
        public int UserID { get; init; }
        public string? AppVersion { get; init; }
        public decimal Version { get; init; }
        public decimal MinorVersion { get; init; }
    }
}
