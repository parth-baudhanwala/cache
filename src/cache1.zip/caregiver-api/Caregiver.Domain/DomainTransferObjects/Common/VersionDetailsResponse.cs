﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class VersionDetailsResponse
    {
        public decimal? ProviderVersion { get; set; }
        public decimal? ProviderMinorVersion { get; set; }
    }
}
