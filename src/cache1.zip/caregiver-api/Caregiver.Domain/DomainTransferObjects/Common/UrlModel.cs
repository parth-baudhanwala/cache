﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class UrlModel
    {
        public string URL { get; set; } = string.Empty;
        public string RCUrl { get; set; } = string.Empty;
    }
}
