﻿using Caregiver.Domain.DomainTransferObjects.TimeZone;

namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class GetTimeZoneByOfficeIDCommand
    {
        public List<TimeZoneByOfficeIDRequest>? OfficeIDs { get; set; }
    }
}
