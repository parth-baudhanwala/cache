﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class KeywordConfigurationResponse
    {
        public string? Contract { get; set; }
        public string? Patient { get; set; }
        public string? Referral { get; set; }
        public string? Agency { get; set; }
        public string? Coordinator { get; set; }
        public string? SecondaryIdentifier { get; set; }
        public string? Caregiver { get; set; }
    }
}
