﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class ApiServiceModel
    {
        public string RequestUri { get; set; } = string.Empty;
        public HttpMethod HttpMethod { get; set; } = HttpMethod.Post;
        public Dictionary<string, string> CustomHeaders { get; set; } = new Dictionary<string, string>();
        public object? RequestContent { get; set; }
        public TimeSpan? Timeout { get; set; }
        public string TokenUrl { get; set; } = string.Empty;
        public string ClientId { get; set; } = string.Empty;
        public string ClientSecret { get; set; } = string.Empty;
        public string Scope { get; set; } = string.Empty;
        public bool IsAuthorizationTokenRequired { get; set; } = false;
    }
}
