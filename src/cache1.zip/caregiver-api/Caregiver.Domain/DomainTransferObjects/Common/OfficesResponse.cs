﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class OfficesResponse
    {
        public string? OfficeName { get; set; }
        public string? Office { get; set; }
        public int OfficeID { get; set; }
        public int ParentID { get; set; }
        public bool IsLeaf { get; set; }
        public int Level { get; set; }
        public int HirarchyLevel { get; set; }
        public string? Type { get; set; }
        public string? parent { get; set; }
        public int SortOrder { get; set; }
        public bool IsEnable { get; set; }
    }
}
