﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class DefaultApiParam
    {
        public string? ApiUrl { get; init; }
        public string? MethodName { get; init; }
        public string? AppName { get; init; }
        public string? AppSecret { get; init; }
        public int TimeOut { get; init; }
        public int EntApiAppVersionID { get; set; }
    }
}
