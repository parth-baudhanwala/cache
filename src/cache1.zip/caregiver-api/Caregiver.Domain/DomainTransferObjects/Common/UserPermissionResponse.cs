﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class UserPermissionResponse
    {
        public string? MenuText { get; set; }
        public bool HasAccess { get; set; }
    }
}
