﻿using MediatR;

namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class OfficesRequest : DefaultParam, IRequest<List<OfficesResponse>>
    {
        public string? SelectionType { get; set; }
        public string? PermissionName { get; set; }
        public string? SelectedOfficeID { get; set; }
        public int PayrollSetupID { get; set; }
    }
}
