﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public enum ConfigurationType
    {
        All
    }

    public enum VisitChangeInitiator
    {
        App_ENT_LinkVisit_VisitInfo,
        App_ENT_ConfirmVisit_Schedule_SingleSave
    }

    public enum RoleName
    {
        AllowLinkingUnrecognizedNumber,
        AllowLinkingUnrecognizedFOB,
        AllowLinkingUnrecognizedGPS
    }
}
