﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class AppServerUrlDetailsResponse
    {
        public string? URL { get; set; }
    }
}
