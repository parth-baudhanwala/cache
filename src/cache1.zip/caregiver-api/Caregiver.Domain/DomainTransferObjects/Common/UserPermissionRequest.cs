﻿using MediatR;

namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class UserPermissionRequest : DefaultParam, IRequest<IEnumerable<UserPermissionResponse>>
    {
        public string? MenuText { get; init; }
        public List<string>? MenuList { get; set; }
    }
}
