﻿using MediatR;

namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class CommonDetailsRequest : IRequest<List<CommonDetailsResponse>>
    {
        public int UserID { get; set; }
        public int ENTPAPIAppversionID { get; set; }
    }
}
