﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public static class ConstantVariable
    {
        public static readonly string MS_StatusList = "WC,CCN,CNA,UP";
        public static readonly string EVVSource_MOBILEAPP = "MOBILEAPP";
        public static readonly string MS_InvalidFOBPasscode = "IFP";
        public static readonly string MS_ExpiredFOBPasscode = "EFP";
        public static readonly string MS_GPSSignalOutofRange = "GOR";
        public static readonly string MS_PhoneNumberNotFound = "WC";
        public static readonly string MS_CallerIDNotAvailable = "CNA";
    }
}
