﻿namespace Caregiver.Domain.DomainTransferObjects.Common
{
    public class CommonDetailsResponse
    {
        public string AppName { get; set; } = string.Empty;
        public decimal Version { get; set; }
        public decimal MinorVersion { get; set; }
        public string? VendorName { get; set; }
        public string? DisplayUserName { get; set; }
        public int AgencyID { get; set; }
        public string? ENTPAPIURL { get; set; }
        public List<KeywordConfigurationResponse>? KeywordConfigurationResponse { get; set; }
    }
}
