﻿using MediatR;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Caregiver.Domain.DomainTransferObjects.GlobalVisit
{
    public class CreateACSScheduleRequest : IRequest<List<CreateACSScheduleResponse>>
    {
        [Required]
        [RegularExpression("(.*[1-9].*)|(.*[.].*[1-9].*)", ErrorMessage = "UserID should not be 0.")]
        public int UserID { get; set; }

        [Required]
        [RegularExpression("(.*[1-9].*)|(.*[.].*[1-9].*)", ErrorMessage = "ProviderID should not be 0.")]
        public int ProviderID { get; set; }

        [Required]
        public DateTime ScheduleDate { get; set; }

        [Required]
        public string? ScheduleStartTime { get; set; }

        [Required]
        public string? ScheduleEndTime { get; set; }

        public string? ScheduleType { get; set; } = string.Empty;

        [Required]
        public Guid GlobalCaregiverID { get; set; }

        [JsonIgnore]
        public int CaregiverID { get; set; }

        [Required]
        public Guid GlobalPatientID { get; set; }

        [JsonIgnore]
        public int PatientID { get; set; }

        [Required]
        public int PayRateID { get; set; }

        [Required]
        public int ContractID1 { get; set; }

        [Required]
        public int ServiceCodeID1 { get; set; }

        [Required]
        public int Hours1 { get; set; }

        [Required]
        public int Minutes1 { get; set; }

        [Required]
        [Range(0, long.MaxValue, ErrorMessage = "Call IN MaintenanceID should be greater than -1.")]
        public long CallInMID { get; set; }

        [Required]
        [Range(0, long.MaxValue, ErrorMessage = "Call OUT MaintenanceID should be greater than -1.")]
        public long CallOutMID { get; set; }

        public int POCHeaderID { get; set; } = -1;

        [JsonIgnore]
        public int POC { get; set; } = -1;

        [JsonIgnore]
        public int IsTempSchedule { get; set; } = 0;

        [JsonIgnore]
        public int IsTempAide { get; set; } = 0;

        [Required]
        [Range(0, 1, ErrorMessage = "Is Skilled Schedule should not be other than 0 or 1.")]
        public int IsSkilledSchedule { get; set; } = 0;

        [JsonIgnore]
        public bool NonBillable { get; set; } = false;

        [JsonIgnore]
        public bool OnHoldVisit { get; set; } = false;

        public string? Comments { get; set; }

        public bool IncludeInMileage { get; set; } = false;
    }
}
