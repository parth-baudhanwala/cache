﻿namespace Caregiver.Domain.DomainTransferObjects.GlobalVisit
{
    public class VisitResponse
    {
        public long VisitID { get; set; }
    }

    public class VisitDetails
    {
        public long VisitID { get; set; }

        public int MaintenanceID { get; set; }
    }
}
