﻿using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.GlobalVisit
{
    public class GlobalMatchingCallsDetailRequest : IRequest<List<MatchingCallsDetailResponse>>
    {
        [Required]
        public string? GlobalVisitID { get; set; }

        [Required]
        [Range(1, 2, ErrorMessage = "CallType should not be other than 1 or 2.")]
        public int CallType { get; set; }

    }
}
