using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.GlobalVisit
{
    public class LinkableVisitRequest : IRequest<List<LinkableVisitResponse>>
    {
        [Required]
        public int UserID { get; set; }

        [Required]
        public Guid GlobalPatientID { get; set; }

        [Required]
        public Guid GlobalCaregiverID { get; set; }

        [Required]
        public DateTime FromDate { get; set; }

        [Required]
        public DateTime ToDate { get; set; }

        [Required]
        public List<string>? GlobalVisitIDs { get; set; }
    }
}
