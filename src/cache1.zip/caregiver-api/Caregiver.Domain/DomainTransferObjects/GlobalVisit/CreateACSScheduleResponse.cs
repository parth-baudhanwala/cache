﻿using System.Text.Json.Serialization;

namespace Caregiver.Domain.DomainTransferObjects.GlobalVisit
{
    public class CreateACSScheduleResponse
    {
        public string? Patient { get; set; } = string.Empty;
        public string? Caregiver { get; set; } = string.Empty;

        [JsonPropertyName("visitDate")]
        public string? Date { get; set; } = string.Empty;

        [JsonPropertyName("scheduledTime")]
        public string? Schedule { get; set; } = string.Empty;

        [JsonPropertyName("ENTVisitId")]
        public long VisitID { get; set; } = -1;

        public string? GlobalVisitId { get; set; } = string.Empty;

        [JsonPropertyName("exception")]
        public string? Problem { get; set; } = string.Empty;

        [JsonIgnore]
        public long PatientID { get; set; } = -1;

        [JsonIgnore]
        public int AideID { get; set; } = -1;
    }
}
