﻿namespace Caregiver.Domain.DomainTransferObjects.GlobalVisit
{
    public class LinkableVisitResponse
    {
        public string? GlobalVisitID { get; set; }
        public int CallType { get; set; }
    }
}
