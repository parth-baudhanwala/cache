﻿using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.GlobalVisit
{
    public class ACSDetailRequest : IValidatableObject, IRequest<List<ACSDetailResponse>>
    {
        [RegularExpression("(.*[1-9].*)|(.*[.].*[1-9].*)", ErrorMessage = "UserID should not be 0.")]
        public int UserID { get; set; }

        [Required]
        public string? GlobalProviderID { get; set; }

        [Required]
        public string? GlobalPatientID { get; set; }

        [Required]
        public string? GlobalCaregiverID { get; set; }

        [Required]
        public string? GlobalOfficeID { get; set; }

        [Required]
        public DateTime FromDate { get; set; }

        [Required]
        public DateTime ToDate { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (ToDate < FromDate)
            {
                yield return new ValidationResult(
                    errorMessage: "ToDate must be greater than FromDate.",
                    memberNames: new[] { "ToDate" }
               );
            }
            else if ((ToDate - FromDate).TotalDays > 14)
            {
                yield return new ValidationResult(
                    errorMessage: "FromDate and ToDate difference shuold not be more then 14 days.",
                    memberNames: new[] { "ToDate" }
               );
            }
        }
    }
}
