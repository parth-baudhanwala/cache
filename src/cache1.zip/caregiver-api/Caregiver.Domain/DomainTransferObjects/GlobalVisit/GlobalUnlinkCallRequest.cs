﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Caregiver.Domain.DomainTransferObjects.Visit
{
    public class GlobalUnlinkCallRequest : IRequest<UnlinkCallResponse>
    {
        [Required]
        public int UserID { get; set; }

        [Required]
        [Range(1, 2, ErrorMessage = "CallType should not be other than 1 or 2.")]
        public int CallType { get; set; }

        [Required]
        public string? GlobalVisitID { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "ProviderID should be greater than 0.")]
        public int ProviderID { get; set; }
    }
}
