﻿using Caregiver.Core.Common;
using Caregiver.Core.Interfaces.Helper;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.Visit;
using IdentityModel.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;
using System.Net;
using System.Net.Http.Headers;
using System.Text;

namespace Caregiver.Infrastructure.Helper
{
    public class WebApiHelper : IWebApiHelper
    {
        private readonly ILogger<WebApiHelper> _logger;
        private readonly HttpClient _httpClient;
        private readonly IAsyncPolicy<HttpResponseMessage> _retryPolicy;
        private readonly IConfiguration _configuration;
        private string _reqUrl = string.Empty;

        public WebApiHelper(
            ILogger<WebApiHelper> logger,
            IConfiguration configuration)
        {
            this._configuration = configuration;
            _logger = logger;
            _httpClient = new HttpClient();
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            _retryPolicy = Policy<HttpResponseMessage>
                 .Handle<HttpRequestException>()
                 .OrResult(r => !r.IsSuccessStatusCode)
                 .WaitAndRetryAsync(Convert.ToInt32(this._configuration["MaxRetries"]), i => TimeSpan.FromMilliseconds(Convert.ToInt32(this._configuration["RetryDelayMs"])), (result, timeSpan, retryAttemptCount, context) =>
                 {
                     _logger.LogError($"{_reqUrl} request failed with StatusCode:{result.Result?.StatusCode.ToString()} and ErrorMessage:{result.Exception?.InnerException}. Retry attempt {retryAttemptCount}");
                 });
        }

        public async Task<HttpResponseMessage> POST(string apiUrl, string jsonRequest)
        {
            _reqUrl = apiUrl;
            return await SendRequestAsync(apiUrl, jsonRequest, HttpMethod.Post);
        }

        private async Task<HttpResponseMessage> SendRequestAsync(string apiUrl, string jsonRequest, HttpMethod httpMethod)
        {
            _logger.LogInformation("SendRequestAsync Call APIURL: " + apiUrl);
            var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

            var response = await _retryPolicy.ExecuteAsync(async () => await _httpClient.SendAsync(new HttpRequestMessage
            {
                Method = httpMethod,
                RequestUri = new Uri(apiUrl, UriKind.Absolute),
                Content = content
            }));
            _logger.LogInformation("SendRequestAsync Call API End");
            return response;
        }

        public async Task<HttpResponseMessage> GETOrPOSTWithGetTokenAsync(ApiServiceModel apiService)
        {
            _reqUrl = apiService.RequestUri;
            HttpResponseMessage response = await _retryPolicy.ExecuteAsync(async () => await SendRequestWithGetTokenAsync(apiService).ConfigureAwait(false)).ConfigureAwait(false);
            return response;
        }

        private async Task<HttpResponseMessage> SendRequestWithGetTokenAsync(ApiServiceModel apiService)
        {
            _logger.LogInformation("SendRequestWithGetTokenAsync Call ApiUrl : " + apiService.RequestUri);

            using HttpClient client = new();
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            TokenResponse tokenResponse = await client.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest()
            {
                Address = apiService.TokenUrl,
                ClientId = apiService.ClientId,
                ClientSecret = apiService.ClientSecret,
                Scope = apiService.Scope,
            }).ConfigureAwait(false);

            if (tokenResponse != null && !string.IsNullOrEmpty(tokenResponse.AccessToken))
            {
                var token = tokenResponse.AccessToken;

                client.DefaultRequestHeaders.Accept.Clear();

                if (apiService.IsAuthorizationTokenRequired)
                {
                    client.DefaultRequestHeaders.Add("AuthorizationToken", "Bearer " + token);
                }
                else
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                }

                foreach (var hdr in apiService.CustomHeaders)
                {
                    client.DefaultRequestHeaders.Add(hdr.Key, hdr.Value);
                }

                HttpRequestMessage request = new()
                {
                    Method = apiService.HttpMethod,
                    RequestUri = new Uri(apiService.RequestUri, UriKind.Absolute)
                };

                if (apiService.HttpMethod == HttpMethod.Post)
                {
                    request.Content = new StringContent(JsonConvert.SerializeObject(apiService.RequestContent), Encoding.UTF8, "application/json");
                }

                HttpResponseMessage httpResponse = await client.SendAsync(request).ConfigureAwait(false);
                _logger.LogInformation("SendRequestWithGetTokenAsync Call API End");
                return httpResponse;
            }
            else
            {
                _logger.LogInformation("AccessToken is null or empty.");
                return new HttpResponseMessage();
            }
        }
    }
}
