﻿using Caregiver.Domain.DomainTransferObjects.Prebilling;
using System.Data;
using System.Reflection;
using System.Text;
using System.Xml.Serialization;

namespace Caregiver.Infrastructure.Helper
{
    public static class CommonHelper
    {
        public static VisitChangeRequest DeserializeToVisit(string visitXml)
        {
            VisitChangeRequest visitRequest = new();
            var visitData = new MemoryStream(Encoding.UTF8.GetBytes(visitXml ?? ""));

            var deserializer = new XmlSerializer(typeof(VisitChangeRequest));
            using (TextReader reader = new StreamReader(visitData))
            {
                object objVisit = deserializer.Deserialize(reader);
                visitRequest = (VisitChangeRequest)objVisit;
            }

            return visitRequest;
        }

        public static List<T> CreateListFromTable<T>(DataTable tbl) where T : new()
        {
            List<T> data = new();
            foreach (DataRow r in tbl.Rows)
            {
                T item = CreateItemFromRow<T>(r);
                data.Add(item);
            }
            return data;
        }

        public static T CreateItemFromRow<T>(DataRow row) where T : new()
        {
            T item = new();
            SetItemFromRow(item, row);
            return item;
        }

        public static void SetItemFromRow<T>(T item, DataRow row) where T : new()
        {
            foreach (DataColumn c in row.Table.Columns)
            {
                PropertyInfo? p = item?.GetType().GetProperty(c.ColumnName);
                if (p != null && row[c] != DBNull.Value)
                {
                    p.SetValue(item, row[c], null);
                }
            }
        }
    }
}
