﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Enums;
using Caregiver.Core.Extensions;
using Caregiver.Core.Interfaces.BroadcastHistory;
using Caregiver.Core.TimeZone;
using Caregiver.Domain.DomainTransferObjects.BroadcastHistory;
using Caregiver.Domain.DomainTransferObjects.TimeZone;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.BroadcastHistory
{
    public class BroadcastHistoryRepository : IBroadcastHistoryRepository
    {
        readonly DateTime defaultDateTime = new(1900, 01, 01);
        private readonly IConfiguration _configuration;
        public BroadcastHistoryRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public async Task<List<BroadcastHistoryResponse>> BroadcastHistory(BroadcastHistoryRequest request, List<TimeZoneResponse> timeZoneResponses)
        {
            string timeZone = string.Empty;
            bool convertToTimeZone = false;
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.BroadcastHistory);
            List<BroadcastHistoryResponse> broadcastHistoryResponse = new();

            if (string.IsNullOrEmpty(request.OfficeIDs)) request.OfficeIDs = string.Empty;
            if (string.IsNullOrEmpty(request.Status)) request.Status = string.Empty;
            if (request.BroadCastTypeIDs == null) request.BroadCastTypeIDs = new();

            DataTable dtOfficId = ListExtensions.ConvertListToDataTable(request.OfficeIDs);
            DataTable statusId = ListExtensions.ConvertListToDataTable(request.Status);
            DataTable dtBroadCastType = ListExtensions.CreateDataTable(request.BroadCastTypeIDs);

            TimeZoneResponse timeZoneResponse = timeZoneResponses.FirstOrDefault(s => s.OfficeID == request.UserPrimaryOfficeID);

            if (timeZoneResponse != null)
            {
                if (string.IsNullOrEmpty(timeZoneResponse.TimeZone)) timeZoneResponse.TimeZone = string.Empty;
                timeZone = timeZoneResponse.TimeZone;
                convertToTimeZone = true;
            }

            if (convertToTimeZone)
            {
                if (!string.IsNullOrEmpty(request.CreatedFrom))
                {
                    DateTime createdFrom = DateTime.ParseExact(request.CreatedFrom + " 00:00:00", "MM/dd/yyyy 00:00:00", null);
                    request.CreatedFrom = createdFrom.ConvertSourceToDestinationTimeByTimeZone(timeZone, TimeZoneEnum.EST.ToString(), _configuration).ToString();
                }

                if (!string.IsNullOrEmpty(request.CreatedTo))
                {
                    DateTime createdTo = DateTime.ParseExact(request.CreatedTo + " 00:00:00", "MM/dd/yyyy 00:00:00", null);
                    request.CreatedTo = createdTo.ConvertSourceToDestinationTimeByTimeZone(timeZone, TimeZoneEnum.EST.ToString(), _configuration).ToString();
                }

                if (!string.IsNullOrEmpty(request.ScheduledDateFrom))
                {
                    DateTime scheduledDateFrom = DateTime.ParseExact(request.ScheduledDateFrom + " 00:00:00", "MM/dd/yyyy 00:00:00", null);
                    request.ScheduledDateFrom = scheduledDateFrom.ConvertSourceToDestinationTimeByTimeZone(timeZone, TimeZoneEnum.EST.ToString(), _configuration).ToString();
                }

                if (!string.IsNullOrEmpty(request.ScheduledDateTo))
                {
                    DateTime scheduledDateTo = DateTime.ParseExact(request.ScheduledDateTo + " 00:00:00", "MM/dd/yyyy 00:00:00", null);
                    request.ScheduledDateTo = scheduledDateTo.ConvertSourceToDestinationTimeByTimeZone(timeZone, TimeZoneEnum.EST.ToString(), _configuration).ToString();
                }
            }

            using (IDbConnection con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                DynamicParameters parameters = new();
                parameters.Add("@UserID", request.UserID);
                if (dtOfficId.AsEnumerable().Any())
                {
                    parameters.Add("@OfficeIDs", dtOfficId.AsTableValuedParameter());
                }
                parameters.Add("@BroadcastName", request.BroadcastName);
                if (statusId.AsEnumerable().Any())
                {
                    parameters.Add("@Status", statusId.AsTableValuedParameter());
                }
                if (dtBroadCastType.AsEnumerable().Any())
                {
                    parameters.Add("@BroadCastTypeIDs", dtBroadCastType.AsTableValuedParameter());
                }
                parameters.Add("@ScheduledDateFrom", request.ScheduledDateFrom);
                parameters.Add("@ScheduledDateTo", request.ScheduledDateTo);
                parameters.Add("@CreatedFrom", request.CreatedFrom);
                parameters.Add("@CreatedTo", request.CreatedTo);
                parameters.Add("@ProviderID", request.ProviderID);
                parameters.Add("@PageNo", request.PageNo);
                parameters.Add("@PageSize", request.PageSize);
                parameters.Add("@SortColumn", request.SortColumn);
                parameters.Add("@SortDirection", request.SortDirection);
                parameters.Add("@CallerInfo", request.CallerInfo);
                broadcastHistoryResponse = (await con.QueryAsync<BroadcastHistoryResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout)).ToList();
            }

            if (broadcastHistoryResponse.Any() && convertToTimeZone)
            {
                foreach (BroadcastHistoryResponse broadcastHistory in broadcastHistoryResponse)
                {
                    if (broadcastHistory.Created != defaultDateTime && broadcastHistory.Created != DateTime.MinValue)
                    {
                        broadcastHistory.Created = Convert.ToDateTime(broadcastHistory.Created).ConvertSourceToDestinationTimeByTimeZone(TimeZoneEnum.EST.ToString(), timeZone, _configuration);
                    }

                    if (broadcastHistory.Scheduled != defaultDateTime && broadcastHistory.Scheduled != DateTime.MinValue)
                    {
                        broadcastHistory.Scheduled = Convert.ToDateTime(broadcastHistory.Scheduled).ConvertSourceToDestinationTimeByTimeZone(TimeZoneEnum.EST.ToString(), timeZone, _configuration);
                    }

                    if (broadcastHistory.BroadcastInitiated != defaultDateTime && broadcastHistory.BroadcastInitiated != DateTime.MinValue)
                    {
                        broadcastHistory.BroadcastInitiated = Convert.ToDateTime(broadcastHistory.BroadcastInitiated).ConvertSourceToDestinationTimeByTimeZone(TimeZoneEnum.EST.ToString(), timeZone, _configuration);
                    }

                    if (broadcastHistory.BroadcastCompleted != defaultDateTime && broadcastHistory.BroadcastCompleted != DateTime.MinValue)
                    {
                        broadcastHistory.BroadcastCompleted = Convert.ToDateTime(broadcastHistory.BroadcastCompleted).ConvertSourceToDestinationTimeByTimeZone(TimeZoneEnum.EST.ToString(), timeZone, _configuration);
                    }
                }
            }
            else if (broadcastHistoryResponse.Any())
            {
                foreach (BroadcastHistoryResponse broadcastHistory in broadcastHistoryResponse)
                {
                    if (broadcastHistory.Created == defaultDateTime)
                    {
                        broadcastHistory.Created = null;
                    }

                    if (broadcastHistory.Scheduled == defaultDateTime)
                    {
                        broadcastHistory.Scheduled = null;
                    }

                    if (broadcastHistory.BroadcastInitiated == defaultDateTime)
                    {
                        broadcastHistory.BroadcastInitiated = null;
                    }

                    if (broadcastHistory.BroadcastCompleted == defaultDateTime)
                    {
                        broadcastHistory.BroadcastCompleted = null;
                    }
                }
            }

            return broadcastHistoryResponse;
        }

        public async Task<List<BroadcastHistoryDetailsResponse>> BroadcastHistoryDetailsByID(BroadcastHistoryDetailsRequest request, List<TimeZoneResponse> timeZoneResponses)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.BroadcastHistoryDetailByID);
            List<BroadcastHistoryDetailsResponse> broadcastHistoryDetailsResponse = new();

            TimeZoneResponse timeZoneResponse = timeZoneResponses.FirstOrDefault(s => s.OfficeID == request.UserPrimaryOfficeID);

            using (IDbConnection con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                DynamicParameters parameters = new();
                parameters.Add("@UserID", request.UserID);
                parameters.Add("@BroadcastID", request.BroadcastID);
                parameters.Add("@ProviderID", request.ProviderID);
                parameters.Add("@PageNo", request.PageNo);
                parameters.Add("@PageSize", request.PageSize);
                parameters.Add("@SortColumn", request.SortColumn);
                parameters.Add("@SortDirection", request.SortDirection);
                parameters.Add("@CallerInfo", request.CallerInfo);
                parameters.Add("@Status", request.Status);
                broadcastHistoryDetailsResponse = (await con.QueryAsync<BroadcastHistoryDetailsResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout)).ToList();
            }

            if (timeZoneResponse != null && broadcastHistoryDetailsResponse.Any())
            {
                foreach (BroadcastHistoryDetailsResponse broadcastHistoryDetails in broadcastHistoryDetailsResponse)
                {
                    if (broadcastHistoryDetails.BroadcastTime != defaultDateTime && broadcastHistoryDetails.BroadcastTime != DateTime.MinValue)
                    {
                        if (string.IsNullOrEmpty(timeZoneResponse.TimeZone)) timeZoneResponse.TimeZone = string.Empty;
                        broadcastHistoryDetails.BroadcastTime = Convert.ToDateTime(broadcastHistoryDetails.BroadcastTime).ConvertSourceToDestinationTimeByTimeZone(TimeZoneEnum.EST.ToString(), timeZoneResponse.TimeZone, _configuration);
                    }
                }
            }
            else if (broadcastHistoryDetailsResponse.Any())
            {
                foreach (BroadcastHistoryDetailsResponse broadcastHistoryDetails in broadcastHistoryDetailsResponse)
                {
                    if (broadcastHistoryDetails.BroadcastTime == defaultDateTime)
                    {
                        broadcastHistoryDetails.BroadcastTime = null;
                    }
                }
            }

            return broadcastHistoryDetailsResponse;
        }

        public async Task<long> BroadcastHistoryCancelByID(BroadcastHistoryCancelRequest request)
        {
            long broadCastResultID = 0;
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.BroadcastHistoryCancelByID);

            using (IDbConnection con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                DynamicParameters parameters = new();
                parameters.Add("@BroadCastId", request.BroadcastID);
                parameters.Add("@IsKill", request.IsBroadCastKill);
                parameters.Add("@UserId", request.UserID);
                parameters.Add("@AppVersion", request.AppVersion);
                parameters.Add("@Version", request.Version);
                parameters.Add("@MinorVersion", request.MinorVersion);
                parameters.Add("@CallerInfo", request.CallerInfo);
                parameters.Add("@Result", request.Result, DbType.Int64, ParameterDirection.Output);
                await con.QueryAsync(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout);
                broadCastResultID = parameters.Get<long>("@Result");
            }

            return broadCastResultID;
        }
    }
}
