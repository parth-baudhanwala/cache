﻿using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Common;
using Caregiver.Core.Interfaces.Helper;
using Caregiver.Core.Interfaces.Prebilling;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.Prebilling;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Caregiver.Infrastructure.Repositories.Prebilling
{
    public class PrebillingRepository : IPrebillingRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ICommonRepository _commonRepository;
        private readonly IWebApiHelper _webApiHelper;

        public PrebillingRepository(IConfiguration configuration,
                ICommonRepository commonRepository,
                IWebApiHelper webApiHelper)
        {
            this._configuration = configuration;
            this._commonRepository = commonRepository;
            _webApiHelper = webApiHelper;
        }

        public async Task CallVisitChangeApi(VisitChangeRequest visitChangeRequest, DefaultParam defaultParam, bool isPriority = true)
        {
            int entApiAppVersionId = Convert.ToInt32(_configuration["EntApiAppVersionID"]);
            string entpUrl = await _commonRepository.GetAppServerURLDetails(visitChangeRequest.ProvID, entApiAppVersionId, defaultParam).ConfigureAwait(false);
            visitChangeRequest.UID = defaultParam.UserID;
            string methodName,
                   entApiUrl;

            if (isPriority)
            {
                methodName = ExternalApiNames.AppVisitChangeProcessVisitChange;
            }
            else
            {
                methodName = ExternalApiNames.VisitChangeProcessVisitChange;
            }
            entApiUrl = entpUrl + methodName;
            if (visitChangeRequest != null && visitChangeRequest.Visits != null && visitChangeRequest.Visits.Count > 0 && visitChangeRequest.Visits.Count == 1)
            {
                string requestJson = JsonConvert.SerializeObject(visitChangeRequest);
                await _webApiHelper.POST(entApiUrl, requestJson);
            }
            else if (visitChangeRequest != null && visitChangeRequest.Visits != null && visitChangeRequest.Visits.Count > 0 && visitChangeRequest.Visits.Count > 1)
            {
                int MaxVisitToProcess;
                int.TryParse(Convert.ToString(this._configuration["MaxVisitToProcess"]), out MaxVisitToProcess);

                MaxVisitToProcess = MaxVisitToProcess <= 0 ? 100 : MaxVisitToProcess;

                int groupID = 0;

                visitChangeRequest.TotalVisits = visitChangeRequest.Visits.Count;
                visitChangeRequest.TotalGroups = (visitChangeRequest.TotalVisits / MaxVisitToProcess) + ((visitChangeRequest.TotalVisits % MaxVisitToProcess) > 0 ? 1 : 0);
                List<VisitDetail> visits = visitChangeRequest.Visits;

                for (int i = 0; i <= visitChangeRequest.TotalVisits; i = i + MaxVisitToProcess)
                {
                    var v = visits.Skip(groupID * MaxVisitToProcess).Take(MaxVisitToProcess).ToList();
                    visitChangeRequest.Visits = v;
                    groupID = groupID + 1;
                    visitChangeRequest.CurrentGroup = groupID;
                    JObject json = JObject.FromObject(visitChangeRequest);
                    string requestJson = JsonConvert.SerializeObject(json);
                    await _webApiHelper.POST(entApiUrl, requestJson);
                }
            }
        }

    }
}