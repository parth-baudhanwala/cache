﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Common;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.DapperResponses;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Caregiver.Infrastructure.Repositories.Common
{
    /// <summary>
    /// Common Repository
    /// </summary>
    public class CommonRepository : ICommonRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<CommonRepository> _logger;
        public CommonRepository(IConfiguration configuration, ILogger<CommonRepository> logger)
        {
            this._configuration = configuration;
            _logger = logger;
        }

        public async Task<NewPrebillingAgency> GetAgenciesUsingNewPrebilling(int vendorID)
        {
            NewPrebillingAgency result;

            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                result = await con.QueryFirstOrDefaultAsync<NewPrebillingAgency>(CommonSqlQueries.GetAgenciesUsingNewPrebilling, new { VendorId = vendorID }, commandType: CommandType.Text).ConfigureAwait(false);
            }

            return result;
        }

        public int VisitAPIWebRequestTimeoutinMS()
        {
            int WebRequestTimeoutinMSVisitAPI = 150000;
            if (_configuration["VisitAPIWebRequestTimeoutinMS"] != null)
            {
                WebRequestTimeoutinMSVisitAPI = Convert.ToInt32(_configuration["VisitAPIWebRequestTimeoutinMS"]);
            }
            return WebRequestTimeoutinMSVisitAPI;
        }

        public async Task<VersionDetailsResponse> VersionDetails(int vendorID)
        {
            VersionDetailsResponse versionDetails;
            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                versionDetails = await con.QueryFirstOrDefaultAsync<VersionDetailsResponse>(CommonSqlQueries.VersionDetails, new { VendorId = vendorID }, commandType: CommandType.Text).ConfigureAwait(false);
            }

            return versionDetails;
        }

        public async Task<List<UserPermissionResponse>> GetUserPermissionDetail(UserPermissionRequest requestParams)
        {
            StringBuilder nodeXml = new();

            if (string.IsNullOrEmpty(requestParams.MenuText) && requestParams.MenuList != null && requestParams.MenuList.Count != 0)
            {
                for (int i = 0; i <= requestParams.MenuList.Count - 1; i++)
                {
                    nodeXml.Append(string.Format("<Node Name=\"{0}\" />", requestParams.MenuList[i]));
                }
            }
            else
            {
                nodeXml.Append(string.Format("<Node Name=\"{0}\" />", requestParams.MenuText));
            }

            string permissionNodes = string.Format("<Nodes>{0}</Nodes>", nodeXml.ToString());
            List<UserPermissionResponse> permissionList;

            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.CheckAccess);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                DynamicParameters parameters = new();
                parameters.Add("@UserID", requestParams.UserID);
                parameters.Add("@Nodes", permissionNodes);
                parameters.Add("@AppVersion", requestParams.AppVersion);
                parameters.Add("@Version", requestParams.Version);
                parameters.Add("@MinorVersion", requestParams.MinorVersion);
                parameters.Add("@CallerInfo", CallerInfo.GetUserPermissionDetail);
                permissionList = (await con.QueryAsync<UserPermissionResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false)).ToList();
            }

            _logger.LogInformation("ShowMatchingCallsDetailRepository permissionList Found:" + permissionList.Count);
            if (permissionList.Any())
            {
                for (int i = 0; i <= permissionList.Count - 1; i++)
                {
                    permissionList[i].HasAccess = true;
                }
            }
            else
            {
                permissionList = new List<UserPermissionResponse> { new UserPermissionResponse { MenuText = requestParams.MenuText, HasAccess = false } };
            }

            return permissionList;
        }

        public async Task<string> GetAppServerURLDetails(int providerId, int appVersionId, DefaultParam requestParams)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetUrlFromAppServers);
            DynamicParameters parameters = new();
            string url = string.Empty;
            parameters.Add("@UserID", requestParams.UserID);
            parameters.Add("@ProviderID", providerId);
            parameters.Add("@AppVersionID", appVersionId);
            parameters.Add("@Version", requestParams.Version);
            parameters.Add("@MinorVersion", requestParams.MinorVersion);
            parameters.Add("@CallerInfo", CallerInfo.AppServerURLDetails);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                AppServerUrlDetailsResponse appServerUrlDetails = await con.QueryFirstOrDefaultAsync<AppServerUrlDetailsResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false);
                if (!string.IsNullOrEmpty(appServerUrlDetails.URL)) url = appServerUrlDetails.URL;
            }

            return await Task.FromResult(url);
        }

        public async Task<List<OfficesResponse>> Offices(OfficesRequest request)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetAllOffices);
            List<OfficesResponse> offices = new();

            using (IDbConnection con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@SelectionType", request.SelectionType);
                parameters.Add("@UserID", request.UserID);
                parameters.Add("@AppVersion", request.AppVersion);
                parameters.Add("@Version", request.Version);
                parameters.Add("@MinorVersion", request.MinorVersion);
                parameters.Add("@PermissionName", request.PermissionName);
                parameters.Add("@PayrollSetupID", request.PayrollSetupID);
                parameters.Add("@SelectedOfficeID", request.SelectedOfficeID);
                parameters.Add("@CallerInfo", "CommonRepository.cs > Offices()");
                offices = (await con.QueryAsync<OfficesResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout)).ToList();
            }

            return offices;
        }

        public async Task<List<CommonDetailsResponse>> CommonDetails(CommonDetailsRequest request)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetVersionInfoByUserID);
            List<CommonDetailsResponse> commonDetails = new();

            using (IDbConnection con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserID", request.UserID);
                parameters.Add("@CallerInfo", "CommonRepository.cs >> CommonDetails()");
                commonDetails = (await con.QueryAsync<CommonDetailsResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout)).ToList();
            }

            if (commonDetails.Any())
            {
                commonDetails[0].KeywordConfigurationResponse = await GetKeywordByVendorId(request.UserID, commonDetails[0].AgencyID);
                commonDetails[0].DisplayUserName = commonDetails[0].DisplayUserName + " " + "(" + commonDetails[0].VendorName + ")";
                commonDetails[0].ENTPAPIURL = await GetApplicationURL(request.UserID, commonDetails[0].AgencyID, request.ENTPAPIAppversionID);
            }

            return commonDetails;
        }

        public async Task<List<KeywordConfigurationResponse>> GetKeywordByVendorId(int userId, int vendorId)
        {
            List<KeywordConfigurationResponse> response = new();
            response = SetDefaultKeywords();
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetKeywordByVendorId);
            using (IDbConnection con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserID", userId);
                parameters.Add("@VendorId", vendorId);
                parameters.Add("@CallerInfo", "CommonRepository.cs >> GetKeywordByVendorId()");
                response = (await con.QueryAsync<KeywordConfigurationResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout)).ToList();
            }
            return response;
        }

        public List<KeywordConfigurationResponse> SetDefaultKeywords()
        {
            List<KeywordConfigurationResponse> response = new List<KeywordConfigurationResponse>
            {
                new KeywordConfigurationResponse { Patient = "0~Patient" },
                new KeywordConfigurationResponse { Contract = "0~Contract" },
                new KeywordConfigurationResponse { Caregiver = "0~Caregiver" },
                new KeywordConfigurationResponse { Coordinator = "0~Coordinator" },
                new KeywordConfigurationResponse { Agency = "0~Provider" },
                new KeywordConfigurationResponse { Referral = "0~Referral Patient" },
                new KeywordConfigurationResponse { SecondaryIdentifier = "0~Secondary Identifier" }
            };
            return response;
        }

        private async Task<string> GetApplicationURL(int userID, int providerID, int appVersionID)
        {
            string applicationURL = string.Empty;
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetUrlFromAppServers);
            List<UrlModel> urlDetails = new();

            using (IDbConnection con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                if (con.State == ConnectionState.Closed) con.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserID", userID);
                parameters.Add("@ProviderID", providerID);
                parameters.Add("@AppVersionID", appVersionID);
                parameters.Add("@CallerInfo", "CommonRepository.cs >> GetApplicationURL()");
                urlDetails = (await con.QueryAsync<UrlModel>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout)).ToList();
            }

            if (urlDetails != null && urlDetails.Any())
            {
                if (appVersionID == 4)
                {
                    if (string.IsNullOrEmpty(urlDetails[0].RCUrl))
                    {
                        applicationURL = urlDetails[0].URL;
                    }
                    else
                    {
                        applicationURL = urlDetails[0].RCUrl;
                    }
                }
                else
                {
                    applicationURL = urlDetails[0].URL;
                }
            }

            return applicationURL;
        }
    }
}
