﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Calls;
using Caregiver.Core.Interfaces.Common;
using Caregiver.Core.Interfaces.Prebilling;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Core.Models;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.DapperResponses;
using Caregiver.Domain.DomainTransferObjects.Dtos;
using Caregiver.Domain.DomainTransferObjects.Prebilling;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Caregiver.Infrastructure.Helper;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using MapsterMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.Visit
{
    public class UnlinkCallRepository : IUnlinkCallRepository
    {
        private readonly ILinkUnlinkCallDetailRepository _linkUnlinkCallDetailRepository;
        private readonly ICommonRepository _commonRepository;
        private readonly IPrebillingRepository _prebillingRepository;
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly ILogger<UnlinkCallRepository> _logger;
        private readonly ICallExceptionsRepository _callExceptionsRepository;


        public UnlinkCallRepository(ILinkUnlinkCallDetailRepository linkUnlinkCallDetailRepository,
            ICommonRepository commonRepository,
            IPrebillingRepository prebillingRepository,
            IMapper mapper,
            IConfiguration configuration,
            ILogger<UnlinkCallRepository> logger,
            ICallExceptionsRepository callExceptionsRepository
            )
        {
            _linkUnlinkCallDetailRepository = linkUnlinkCallDetailRepository;
            _commonRepository = commonRepository;
            _prebillingRepository = prebillingRepository;
            _mapper = mapper;
            _configuration = configuration;
            _logger = logger;
            _callExceptionsRepository = callExceptionsRepository;
        }

        public async Task<UnlinkCallResponse> UnlinkCall(UnlinkCallRequest request)
        {
            _logger.LogInformation("UnlinkCallValidations Start");
            UnlinkCallResponse response = new();
            ValidationMessage checkUnlinkCallValidations = await this.UnlinkCallValidations(request.VisitID, request.MaintenanceID).ConfigureAwait(false);
            _logger.LogInformation("UnlinkCallValidations End");
            if (!checkUnlinkCallValidations.IsValid)
            {
                response.ReturnValue = "-1";
                response.MessageText = checkUnlinkCallValidations.MessageText;
                return await Task.FromResult(response);
            }
            _logger.LogInformation("VersionDetails Start");
            VersionDetailsResponse versionDetailsResponse = await _commonRepository.VersionDetails(request.ProviderID).ConfigureAwait(false);
            _logger.LogInformation("VersionDetails End");
            DefaultParam defaultParam = new()
            {
                UserID = request.UserID,
                AppVersion = _configuration["AppVersion"],
                Version = Convert.ToDecimal(versionDetailsResponse.ProviderVersion),
                MinorVersion = Convert.ToDecimal(versionDetailsResponse.ProviderMinorVersion)
            };

            #region Get Unlink CallDetails            
            LinkUnlinkCallDetailRequest linkUnlinkCallDetailRequest = new()
            {
                UserID = request.UserID,
                MaintenanceID = request.MaintenanceID,
                VisitID = request.VisitID,
                LinkUnlink = "UNLINK",
                AppVersion = defaultParam.AppVersion,
                Version = defaultParam.Version,
                MinorVersion = defaultParam.MinorVersion,
                CallerInfo = CallerInfo.UnlinkCallCallerInfo
            };
            _logger.LogInformation("GetDetailsForLinkUnlinkCall Start");
            LinkUnlinkCallDetailResponse linkUnlinkCallDetail = await _linkUnlinkCallDetailRepository.GetDetailsForLinkUnlinkCall(linkUnlinkCallDetailRequest).ConfigureAwait(false);
            _logger.LogInformation("GetDetailsForLinkUnlinkCall End");
            #endregion

            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.UnlinkCall);
            var parameters = new DynamicParameters();
            parameters.Add("@UserID", request.UserID);
            parameters.Add("@MaintenanceID", request.MaintenanceID);
            parameters.Add("@LinkedVisitID", request.VisitID);
            parameters.Add("@AppVersion", defaultParam.AppVersion);
            parameters.Add("@Version", defaultParam.Version);
            parameters.Add("@MinorVersion", defaultParam.MinorVersion);
            parameters.Add("@IsDeleted", 0, DbType.Int32, ParameterDirection.Output);
            parameters.Add("@VisitChangeData", string.Empty, DbType.Xml, ParameterDirection.Output);
            _logger.LogInformation("Unlink SP Start");
            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                await con.QueryAsync(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false);
            }
            _logger.LogInformation("Unlink SP End");

            int returnValue = parameters.Get<int>("@IsDeleted");
            string visitChangeData = parameters.Get<string>("@VisitChangeData");
            response.MessageText = GetReturnMessageFromValue(returnValue);

            if (linkUnlinkCallDetail != null)
            {
                _logger.LogInformation("UpdateScheduledVisitAfterUnlinkCall SP Start");
                if (returnValue > 0)
                {
                    await _linkUnlinkCallDetailRepository.UpdateScheduledVisitAfterUnlinkCall(request.VisitID, defaultParam);
                }
                _logger.LogInformation("UpdateScheduledVisitAfterUnlinkCall SP End");
                _logger.LogInformation("UpdateInterruptDetails Start");
                if (!string.IsNullOrEmpty(linkUnlinkCallDetail.CallUniqueID) && !string.IsNullOrEmpty(linkUnlinkCallDetail.EVVSource) && !string.IsNullOrEmpty(linkUnlinkCallDetail.EVVType))
                {
                    await _linkUnlinkCallDetailRepository.UpdateInterruptDetails(linkUnlinkCallDetail.CallUniqueID, request.VisitID, linkUnlinkCallDetail.VendorID, linkUnlinkCallDetail.EVVSource, linkUnlinkCallDetail.EVVType, "UNLINK", defaultParam);
                }
                _logger.LogInformation("UpdateInterruptDetails End");
            }
            _logger.LogInformation("SaveReasonNotesForLinkUnlinkCall Start");
            if (returnValue == 1 && (request.ReasonID > 0 || request.ActionTakenReasonID > 0))
            {
                await _linkUnlinkCallDetailRepository.SaveReasonNotesForLinkUnlinkCall(defaultParam, request.VisitID, request.ReasonID, request.ActionTakenReasonID, request.Notes ?? string.Empty);
            }
            _logger.LogInformation("SaveReasonNotesForLinkUnlinkCall End");
            _logger.LogInformation("GetAgenciesUsingNewPrebilling Start");
            NewPrebillingAgency newPrebillingAgency = await _commonRepository.GetAgenciesUsingNewPrebilling(request.ProviderID).ConfigureAwait(false);
            NewPrebillingAgencyDTO newPrebillingAgencyDto = _mapper.Map<NewPrebillingAgencyDTO>(newPrebillingAgency);
            _logger.LogInformation("GetAgenciesUsingNewPrebilling End");
            _logger.LogInformation("Prebilling API Call Start");
            if (!string.IsNullOrEmpty(visitChangeData) && visitChangeData.Length > 0 && newPrebillingAgencyDto != null && newPrebillingAgencyDto.VendorId > 0)
            {
                VisitChangeRequest objVisitChangeRequest = CommonHelper.DeserializeToVisit(visitChangeData);
                objVisitChangeRequest.InitByEnum = VisitChangeInitiator.App_ENT_ConfirmVisit_Schedule_SingleSave;
                objVisitChangeRequest.TypeEnum = ConfigurationType.All;

                int maxRetries = Convert.ToInt32(_configuration["MaxRetries"]);
                int retryDelayMs = Convert.ToInt32(_configuration["RetryDelayMs"]);
                await _prebillingRepository.CallVisitChangeApi(objVisitChangeRequest, defaultParam);
            }
            _logger.LogInformation("Prebilling API Call End");

            #region Call Generate Exception
            if (linkUnlinkCallDetail != null && linkUnlinkCallDetail.Type == 2)
            {
                _logger.LogInformation("GenerateCallExceptions Start");
                VisitExceptionRequest objVisitExceptionRequest = new()
                {
                    UserID = request.UserID,
                    VisitID = request.VisitID,
                    ProviderID = request.ProviderID,
                    OfficeID = 0,
                    AlternateServiceType = 0,
                    AlternateVisitVerification = 0,
                    AlternateEVVPatientSignatureStatus = string.Empty,
                    AlternateServiceVerification = 0,
                    AlternateEVVVoiceNoteStatus = string.Empty,
                    AlternateEVVPatientSignature = "reset",
                    AlternateEVVVoiceNote = "reset",
                    LoginUserName = string.Empty,
                    CallerInfo = CallerInfo.GenerateCallExceptions
                };

                await _callExceptionsRepository.GenerateCallExceptions(objVisitExceptionRequest, defaultParam);

                _logger.LogInformation("GenerateCallExceptions End");
            }
            #endregion

            response.ReturnValue = returnValue.ToString();

            return await Task.FromResult(response);
        }

        public async Task<ValidationMessage> UnlinkCallValidations(long visitID, int maintenanceID)
        {
            ValidationMessage result = new() { IsValid = true, MessageText = string.Empty };
            _logger.LogInformation("GetLockedVisitValidation Start");
            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                VisitLockResponse visitLockResponse = await con.QueryFirstOrDefaultAsync<VisitLockResponse>(VisitSqlQueries.GetLockedVisitValidation, new { VisitID = visitID }, commandType: CommandType.Text).ConfigureAwait(false);
                _logger.LogInformation("GetLockedVisitValidation End");
                if (visitLockResponse.IsVisitLocked != null && visitLockResponse.IsVisitLocked == 1)
                {
                    result.MessageText = ValidationMessageText.CallUnlinkLockedValidateTextMsg;
                    result.IsValid = false;
                    return result;
                }
                _logger.LogInformation("GetCallUnlinkTypeValidation Start");
                var validateAideCallHistory = await con.QueryMultipleAsync(VisitSqlQueries.GetCallUnlinkTypeValidation, new { VisitID = visitID, MaintenanceID = maintenanceID }, commandType: CommandType.Text).ConfigureAwait(false);
                var isCallsFound = validateAideCallHistory.ReadSingleOrDefault();
                var isVisitFound = validateAideCallHistory.ReadSingleOrDefault();
                _logger.LogInformation("GetCallUnlinkTypeValidation End");
                if (isVisitFound == null)
                {
                    result.MessageText = ValidationMessageText.VisitNotFoundTextMsg;
                    result.IsValid = false;
                    return result;
                }
                else if (isCallsFound == null)
                {
                    result.MessageText = ValidationMessageText.CallUnlinkTypeValidateTextMsg;
                    result.IsValid = false;
                    return result;
                }
                _logger.LogInformation("GetCallLinkUnlinkValidation Start");
                var preValidations = await con.QueryMultipleAsync(VisitSqlQueries.GetCallLinkUnlinkValidation, new { VisitID = visitID, MaintenanceID = maintenanceID, ChType = 1 }, commandType: CommandType.Text).ConfigureAwait(false);
                var callTimeExistsValidationResponse = preValidations.ReadSingleOrDefault<CallTimeExistsValidationResponse>();
                var callTypeValidationResponse = preValidations.ReadSingleOrDefault<CallTypeValidationResponse>();
                _logger.LogInformation("GetCallLinkUnlinkValidation End");
                if (callTimeExistsValidationResponse != null)
                {
                    if (callTimeExistsValidationResponse.IsBilled == 1)
                    {
                        result.MessageText = ValidationMessageText.CallUnlinkBilledVisitValidationTextMsg;
                        result.IsValid = false;
                    }
                    else if (callTimeExistsValidationResponse.IsVisitStartTimeExists == 0)
                    {
                        result.MessageText = ValidationMessageText.CallUnlinkVisitStartTimeValidationTextMsg;
                        result.IsValid = false;
                    }
                    else if (callTypeValidationResponse != null && callTimeExistsValidationResponse.IsVisitEndTimeExists == 1)
                    {
                        result.MessageText = ValidationMessageText.VisitEndTimeValidationTextMsg;
                        result.IsValid = false;
                    }
                }
            }
            _logger.LogInformation("Validation Unlink End");
            return result;
        }

        private static string GetReturnMessageFromValue(int returnValue)
        {
            if (returnValue == -1)
            {
                return ValidationMessageText.CallUnLinkLockedVisitValidationTextMsg;
            }
            else if (returnValue == 0)
            {
                return ValidationMessageText.CallUnlinkBilledVisitValidationTextMsg;
            }
            else if (returnValue == 1)
            {
                return ValidationMessageText.CallUnLinkSuccessValidationTextMsg;
            }
            else if (returnValue == -2)
            {
                return ValidationMessageText.RemoveConfirmedTimeValidationMsg;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
