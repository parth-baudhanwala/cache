﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.Visit
{
    public class MoveCallsToCallMaintenanceRepository : IMoveCallsToCallMaintenanceRepository
    {
        public MoveCallsToCallMaintenanceRepository()
        {
        }

        public async Task<MoveCallsToCallMaintenanceResponse> MoveCallsToCallMaintenance(MoveCallsToCallMaintenanceRequest request)
        {
            MoveCallsToCallMaintenanceResponse response = new();
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.MoveCallsToCallMaintenanceUnconfirmedVisit);

            await Task.Run(() =>
            {
                var parameters = new DynamicParameters();
                parameters.Add("@UserID", request.UserID);
                parameters.Add("@VisitID", request.VisitID);
                parameters.Add("@CallIn", request.CallIn);
                parameters.Add("@CallOut", request.CallOut);
                parameters.Add("@CallerInfo", CallerInfo.MoveCallsToCallMaintenanceUnconfirmedVisit);
                parameters.Add("@IsDeleted", 0, DbType.Int32, ParameterDirection.Output, 20);
                parameters.Add("@IsMovedToCallMaintainance", false, DbType.Boolean, ParameterDirection.Output);

                using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
                {
                    con.Query(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout);
                }

                int isDeleted = parameters.Get<int>("@IsDeleted");
                bool isMovedToCallMaintainance = parameters.Get<bool>("@IsMovedToCallMaintainance");
                response.IsDeleted = isDeleted;
                response.IsMovedToCallMaintainance = isMovedToCallMaintainance;
                if (isDeleted == -2)
                    response.MessageText = ValidationMessageText.RemoveConfirmedTimeValidationMsg;
            });

            return response;
        }
    }
}
