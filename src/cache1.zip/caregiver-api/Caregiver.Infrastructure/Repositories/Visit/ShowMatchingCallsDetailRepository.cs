﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Common;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.Visit
{
    public class ShowMatchingCallsDetailRepository : IShowMatchingCallsDetailRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ICommonRepository _commonRepository;
        private readonly ILogger<ShowMatchingCallsDetailRepository> _logger;
        public ShowMatchingCallsDetailRepository(IConfiguration configuration, ICommonRepository commonRepository, ILogger<ShowMatchingCallsDetailRepository> logger)
        {
            _configuration = configuration;
            _commonRepository = commonRepository;
            _logger = logger;
        }

        public async Task<List<MatchingCallsDetailResponse>> ShowMatchingCalls(MatchingCallsDetailRequest request)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.ShowMatchingCallsDetail);
            var parameters = new DynamicParameters();
            List<MatchingCallsDetailResponse> matchingCallsDetailResponse = new();
            int userID = 0;
            decimal minorVersion = 0;
            decimal version = 0;
            string appVersion = _configuration["AppVersion"];

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                var getSPParametersUsingVisitIDResult = await con.QuerySingleOrDefaultAsync(VisitSqlQueries.GetMatchingCallsSPParamsByVisitID, new { VisitID = request.VisitID }, commandType: CommandType.Text).ConfigureAwait(false);

                if (getSPParametersUsingVisitIDResult != null)
                {
                    version = Convert.ToDecimal(getSPParametersUsingVisitIDResult.Version);
                    minorVersion = Convert.ToDecimal(getSPParametersUsingVisitIDResult.MinorVersion);

                    if (request.UserID > 0)
                    {
                        userID = request.UserID;
                    }
                    else
                    {
                        var getUserIDUsingVendorIDResult = await con.QueryFirstOrDefaultAsync(CommonSqlQueries.GetUserIDUsingVendorID, new { ID = getSPParametersUsingVisitIDResult.VendorID }, commandType: CommandType.Text).ConfigureAwait(false);
                        userID = Convert.ToInt32(getUserIDUsingVendorIDResult.UserID);
                    }

                    parameters.Add("@UserID", userID);
                    parameters.Add("@ProviderID", getSPParametersUsingVisitIDResult.VendorID);
                    parameters.Add("@VisitID", request.VisitID);
                    parameters.Add("@VisitDate", getSPParametersUsingVisitIDResult.VisitDate);
                    parameters.Add("@PatientID", getSPParametersUsingVisitIDResult.PatientID);
                    parameters.Add("@AideID", getSPParametersUsingVisitIDResult.AideID);
                    parameters.Add("@CallType", request.CallType);
                    parameters.Add("@CallTime", string.Empty);
                    parameters.Add("@AppVersion", appVersion);
                    parameters.Add("@Version", version);
                    parameters.Add("@MinorVersion", minorVersion);
                    parameters.Add("@CallerInfo", CallerInfo.LinkUnlinkCallDetail);

                    matchingCallsDetailResponse = (await con.QueryAsync<MatchingCallsDetailResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false)).ToList();
                }
            }
            _logger.LogInformation("ShowMatchingCallsDetailRepository UserDetails: " + matchingCallsDetailResponse.Count);
            if (matchingCallsDetailResponse.Any())
            {
                List<string> menuTextList = new()
                {
                    RoleName.AllowLinkingUnrecognizedNumber.ToString(),
                    RoleName.AllowLinkingUnrecognizedFOB.ToString(),
                    RoleName.AllowLinkingUnrecognizedGPS.ToString()
                };

                UserPermissionRequest requestParams = new()
                {
                    MenuList = menuTextList,
                    UserID = userID,
                    Version = version,
                    MinorVersion = minorVersion,
                    AppVersion = appVersion
                };

                List<UserPermissionResponse> permissionList = await _commonRepository.GetUserPermissionDetail(requestParams).ConfigureAwait(false);
                if (permissionList != null && permissionList.Any())
                {

                    bool allowLinkingUnrecognizedNumber = false,
                         allowLinkingUnrecognizedFOB = false,
                         allowLinkingUnrecognizedGPS = false;

                    foreach (var itemPermission in permissionList)
                    {
                        if (itemPermission.MenuText == RoleName.AllowLinkingUnrecognizedNumber.ToString())
                        {
                            allowLinkingUnrecognizedNumber = true;
                        }
                        else if (itemPermission.MenuText == RoleName.AllowLinkingUnrecognizedFOB.ToString())
                        {
                            allowLinkingUnrecognizedFOB = true;
                        }
                        else if (itemPermission.MenuText == RoleName.AllowLinkingUnrecognizedGPS.ToString())
                        {
                            allowLinkingUnrecognizedGPS = true;
                        }
                    }
                    _logger.LogInformation("ShowMatchingCallsDetailRepository allowLinkingUnrecognizedGPS Found: " + allowLinkingUnrecognizedGPS.ToString());

                    foreach (var item in matchingCallsDetailResponse)
                    {
                        _logger.LogInformation("ShowMatchingCallsDetailRepository EVVSource Found: " + item.EVVSource + " Item Maintenance Status: " + item.MaintenanceStatus);
                        if (!string.IsNullOrEmpty(item.EVVSource) && item.EVVSource.ToUpper() == ConstantVariable.EVVSource_MOBILEAPP)
                        {
                            item.IsLinkableVisit = true;
                            if (!allowLinkingUnrecognizedGPS && item.MaintenanceStatus == ConstantVariable.MS_GPSSignalOutofRange)
                            {
                                item.IsLinkableVisit = false;
                            }
                        }
                        else if (item.CallerIDAndPatientPhoneMismatch || ConstantVariable.MS_StatusList.Split(',').Contains(item.MaintenanceStatus))
                        {
                            if (!string.IsNullOrEmpty(item.MaintenanceStatus) &&
                                    ((allowLinkingUnrecognizedFOB && (item.MaintenanceStatus == ConstantVariable.MS_InvalidFOBPasscode || item.MaintenanceStatus == ConstantVariable.MS_ExpiredFOBPasscode)) ||
                                    (allowLinkingUnrecognizedGPS && item.MaintenanceStatus == ConstantVariable.MS_GPSSignalOutofRange) ||
                                    (allowLinkingUnrecognizedNumber && (item.MaintenanceStatus == ConstantVariable.MS_PhoneNumberNotFound || item.MaintenanceStatus == ConstantVariable.MS_CallerIDNotAvailable)))
                                    )
                            {
                                item.IsLinkableVisit = true;
                            }
                            else if (!string.IsNullOrEmpty(item.MaintenanceStatus) && item.MaintenanceStatus != ConstantVariable.MS_PhoneNumberNotFound && item.MaintenanceStatus != ConstantVariable.MS_CallerIDNotAvailable && item.MaintenanceStatus != ConstantVariable.MS_GPSSignalOutofRange && item.MaintenanceStatus != ConstantVariable.MS_InvalidFOBPasscode && item.MaintenanceStatus != ConstantVariable.MS_ExpiredFOBPasscode)
                            {
                                item.IsLinkableVisit = true;
                            }
                            else
                            {
                                item.IsLinkableVisit = false;
                            }
                        }
                    }
                }
                matchingCallsDetailResponse = matchingCallsDetailResponse.Where(x => x.IsLinkableVisit == true).ToList();
                _logger.LogInformation("ShowMatchingCallsDetailRepository  matchingCallsDetailResponse: " + matchingCallsDetailResponse.Count.ToString());
            }

            return matchingCallsDetailResponse;
        }
    }
}
