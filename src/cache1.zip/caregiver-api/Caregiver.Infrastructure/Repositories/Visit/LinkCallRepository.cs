﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Calls;
using Caregiver.Core.Interfaces.Common;
using Caregiver.Core.Interfaces.Prebilling;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Core.Models;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.DapperResponses;
using Caregiver.Domain.DomainTransferObjects.Dtos;
using Caregiver.Domain.DomainTransferObjects.Prebilling;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using MapsterMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.Visit
{
    public class LinkCallRepository : ILinkCallRepository
    {
        private readonly ILinkUnlinkCallDetailRepository _linkUnlinkCallDetailRepository;
        private readonly ICommonRepository _commonRepository;
        private readonly IPrebillingRepository _prebillingRepository;
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly IShowMatchingCallsDetailRepository _showMatchingCallsDetailRepository;
        private readonly ILogger<LinkCallRepository> _logger;
        private readonly ICallExceptionsRepository _callExceptionsRepository;
        public LinkCallRepository(ILinkUnlinkCallDetailRepository linkUnlinkCallDetailRepository,
            ICommonRepository commonRepository,
            IPrebillingRepository prebillingRepository,
            IMapper mapper, IConfiguration configuration,
            IShowMatchingCallsDetailRepository showMatchingCallsDetailRepository,
            ILogger<LinkCallRepository> logger,
            ICallExceptionsRepository callExceptionsRepository
            )
        {
            _linkUnlinkCallDetailRepository = linkUnlinkCallDetailRepository;
            _commonRepository = commonRepository;
            _prebillingRepository = prebillingRepository;
            _mapper = mapper;
            _configuration = configuration;
            _showMatchingCallsDetailRepository = showMatchingCallsDetailRepository;
            _logger = logger;
            _callExceptionsRepository = callExceptionsRepository;
        }

        public async Task<LinkCallResponse> LinkCall(LinkCallRequest request)
        {
            LinkCallResponse response = new();
            _logger.LogInformation("Link Call Validation Start");
            ValidationMessage checkLinkCallValidations = await this.LinkCallValidations(request.VisitID, request.MaintenanceID, request.CallType).ConfigureAwait(false);
            _logger.LogInformation("Link Call Validation End");
            if (!checkLinkCallValidations.IsValid)
            {
                response.ReturnValue = "-1";
                response.MessageText = checkLinkCallValidations.MessageText;
                return await Task.FromResult(response);
            }
            _logger.LogInformation("VersionDetails Start");
            VersionDetailsResponse versionDetailsResponse = await _commonRepository.VersionDetails(request.ProviderID).ConfigureAwait(false);
            _logger.LogInformation("VersionDetails End");
            DefaultParam defaultParam = new()
            {
                UserID = request.UserID,
                AppVersion = _configuration["AppVersion"],
                Version = Convert.ToDecimal(versionDetailsResponse.ProviderVersion),
                MinorVersion = Convert.ToDecimal(versionDetailsResponse.ProviderMinorVersion)
            };

            #region Get CallDetails            
            LinkUnlinkCallDetailRequest linkUnlinkCallDetailRequest = new()
            {
                UserID = defaultParam.UserID,
                MaintenanceID = request.MaintenanceID,
                VisitID = request.VisitID,
                LinkUnlink = "LINK",
                AppVersion = defaultParam.AppVersion,
                Version = defaultParam.Version,
                MinorVersion = defaultParam.MinorVersion,
                CallerInfo = CallerInfo.LinkCallCallerInfo
            };
            _logger.LogInformation("Get Details For Link Unlink Call Start");
            LinkUnlinkCallDetailResponse linkUnlinkCallDetail = await _linkUnlinkCallDetailRepository.GetDetailsForLinkUnlinkCall(linkUnlinkCallDetailRequest).ConfigureAwait(false);
            _logger.LogInformation("Get Details For Link Unlink Call End");
            #endregion

            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.LinkCall);

            var parameters = new DynamicParameters();
            parameters.Add("@UserID", request.UserID);
            parameters.Add("@MaintenanceID", request.MaintenanceID);
            parameters.Add("@VisitID", request.VisitID);
            parameters.Add("@UpdateScheduleOverTime", !string.IsNullOrEmpty(request.UpdateScheduleOverTime) ? request.UpdateScheduleOverTime : "0");
            parameters.Add("@UpdateWithAideCompliant", !string.IsNullOrEmpty(request.UpdateWithAideCompliant) ? request.UpdateWithAideCompliant : "0");
            parameters.Add("@AutoselectTimesheetRequired", !string.IsNullOrEmpty(request.AutoselectTimesheetRequired) ? request.AutoselectTimesheetRequired : string.Empty);
            parameters.Add("@CallerInfo", CallerInfo.LinkCallCallerInfo);
            parameters.Add("@IsDifferentAide", 0, DbType.Int32, ParameterDirection.Output);
            parameters.Add("@NotSavedMessage", 0, DbType.String, ParameterDirection.Output, 5000);
            _logger.LogInformation("Link Call SP Start");
            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                await con.QueryAsync(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false);
            }
            _logger.LogInformation("Link Call SP End");
            string returnValue = Convert.ToString(parameters.Get<int>("@IsDifferentAide"));
            string notSavedMessage = !string.IsNullOrEmpty(parameters.Get<string>("@NotSavedMessage")) ? parameters.Get<string>("@NotSavedMessage") : string.Empty;

            if (returnValue == "-20" || returnValue == "-4" || returnValue == "-7" || returnValue == "-1")
            {
                returnValue += "_" + notSavedMessage;
            }
            else if (returnValue == "0")
            {
                response.MessageText = ValidationMessageText.CallLinkSuccessValidationTextMsg;

                if (linkUnlinkCallDetail?.VendorID != null)
                {
                    string visitXML = string.Empty;
                    _logger.LogInformation("UpdateUnscheduleToScheduleVisit Start");
                    if (linkUnlinkCallDetail.VerificationType?.ToLower() == "unsch")
                    {
                        visitXML += "<Visits><Visit VId='" + request.VisitID + "' CallUniqueID='" + linkUnlinkCallDetail.CallUniqueID + "' /></Visits>";
                        await _linkUnlinkCallDetailRepository.UpdateUnscheduleToScheduleVisit(visitXML, request.UserID, defaultParam);
                        returnValue += "_" + linkUnlinkCallDetail.CallUniqueID;
                    }
                    _logger.LogInformation("UpdateUnscheduleToScheduleVisit End");
                    _logger.LogInformation("UpdateInterruptDetails Start");
                    if (!string.IsNullOrEmpty(linkUnlinkCallDetail.CallUniqueID)
                        && !string.IsNullOrEmpty(linkUnlinkCallDetail.EVVSource)
                        && !string.IsNullOrEmpty(linkUnlinkCallDetail.EVVType))
                    {
                        await _linkUnlinkCallDetailRepository.UpdateInterruptDetails(linkUnlinkCallDetail.CallUniqueID, request.VisitID, linkUnlinkCallDetail.VendorID, linkUnlinkCallDetail.EVVSource, linkUnlinkCallDetail.EVVType, "LINK", defaultParam);
                    }
                    _logger.LogInformation("UpdateInterruptDetails End");
                }
                _logger.LogInformation("SaveReasonNotesForLinkUnlinkCall Start");
                if (request.ReasonID > 0 || request.ActionTakenReasonID > 0)
                {
                    await _linkUnlinkCallDetailRepository.SaveReasonNotesForLinkUnlinkCall(defaultParam, request.VisitID, request.ReasonID, request.ActionTakenReasonID, request.Notes ?? string.Empty);
                }
                _logger.LogInformation("SaveReasonNotesForLinkUnlinkCall End");
                _logger.LogInformation("GetAgenciesUsingNewPrebilling Start");
                NewPrebillingAgency newPrebillingAgency = await _commonRepository.GetAgenciesUsingNewPrebilling(request.ProviderID).ConfigureAwait(false);
                NewPrebillingAgencyDTO newPrebillingAgencyDto = _mapper.Map<NewPrebillingAgencyDTO>(newPrebillingAgency);
                _logger.LogInformation("GetAgenciesUsingNewPrebilling End");

                if (newPrebillingAgencyDto != null && newPrebillingAgencyDto.VendorId > 0)
                {
                    _logger.LogInformation("Newprebilling API Call Start");
                    VisitDetail visitDetail = new()
                    {
                        VID = request.VisitID
                    };

                    VisitChangeRequest objVisitChangeRequest = new()
                    {
                        UID = request.UserID,
                        ProvID = request.ProviderID,
                        PkID = request.VisitID,
                        Visits = new List<VisitDetail> { visitDetail },
                        InitByEnum = VisitChangeInitiator.App_ENT_LinkVisit_VisitInfo,
                        TypeEnum = ConfigurationType.All
                    };

                    await _prebillingRepository.CallVisitChangeApi(objVisitChangeRequest, defaultParam);
                    _logger.LogInformation("Newprebilling API Call End");
                }

                if (request.CallType == 2)
                {
                    _logger.LogInformation("VisitScheduleDetailByVisitID Start");
                    var visitScheduleDetails = await _linkUnlinkCallDetailRepository.VisitScheduleDetailByVisitID(request.UserID, request.VisitID).ConfigureAwait(false);
                    _logger.LogInformation("VisitScheduleDetailByVisitID End");
                    if (visitScheduleDetails != null)
                    {
                        int alternateServiceVerification = 0, alternateVisitVerification = 0, alternateServiceType = 0;
                        if (visitScheduleDetails.AlternateServiceVerification)
                            alternateServiceVerification = 1;
                        if (visitScheduleDetails.AlternateVisitVerification)
                            alternateVisitVerification = 1;
                        alternateServiceType = visitScheduleDetails.AlternateServiceType;
                        _logger.LogInformation("GenerateCallExceptions Start");
                        VisitExceptionRequest objVisitExceptionRequest = new()
                        {
                            UserID = request.UserID,
                            VisitID = request.VisitID,
                            ProviderID = request.ProviderID,
                            OfficeID = visitScheduleDetails.OfficeID,
                            AlternateServiceType = alternateServiceType,
                            AlternateVisitVerification = alternateVisitVerification,
                            AlternateEVVPatientSignatureStatus = visitScheduleDetails.AlternateEVVPatientSignatureStatus,
                            AlternateServiceVerification = alternateServiceVerification,
                            AlternateEVVVoiceNoteStatus = visitScheduleDetails.AlternateEVVVoiceNoteStatus,
                            AlternateEVVPatientSignature = Convert.ToString(visitScheduleDetails.AlternateEVVPatientSignature),
                            AlternateEVVVoiceNote = Convert.ToString(visitScheduleDetails.AlternateEVVVoiceNote),
                            LoginUserName = string.Empty,
                            CallerInfo = CallerInfo.GenerateCallExceptions
                        };

                        await _callExceptionsRepository.GenerateCallExceptions(objVisitExceptionRequest, defaultParam);
                        _logger.LogInformation("GenerateCallExceptions End");
                    }
                }
            }
            _logger.LogInformation("Link Call End");
            response.ReturnValue = returnValue;
            return await Task.FromResult(response);
        }

        public async Task<ValidationMessage> LinkCallValidations(long visitID, int maintenanceID, int callType)
        {
            ValidationMessage result = new() { IsValid = true, MessageText = string.Empty };
            _logger.LogInformation("GetLockedVisitValidation Start");
            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                VisitLockResponse visitLockResponse = await con.QueryFirstOrDefaultAsync<VisitLockResponse>(VisitSqlQueries.GetLockedVisitValidation, new { VisitID = visitID }, commandType: CommandType.Text).ConfigureAwait(false);
                _logger.LogInformation("GetLockedVisitValidation End");
                if (visitLockResponse.IsVisitLocked != null && visitLockResponse.IsVisitLocked == 1)
                {
                    result.MessageText = ValidationMessageText.CallLinkLockedValidateTextMsg;
                    result.IsValid = false;
                    return result;
                }
                _logger.LogInformation("GetCallLinkUnlinkValidation Start");
                var preCallLinkValidations = await con.QueryMultipleAsync(VisitSqlQueries.GetCallLinkUnlinkValidation, new { VisitID = visitID, MaintenanceID = maintenanceID, ChType = 2 }, commandType: CommandType.Text).ConfigureAwait(false);
                var callTimeExistsValidationResponse = preCallLinkValidations.ReadSingleOrDefault();
                var callTypeValidationResponse = preCallLinkValidations.ReadSingleOrDefault<CallTypeValidationResponse>();
                _logger.LogInformation("GetCallLinkUnlinkValidation End");
                if (callTimeExistsValidationResponse != null)
                {
                    if (callTimeExistsValidationResponse.IsBilled == 1)
                    {
                        result.MessageText = ValidationMessageText.CallLinkBilledVisitValidationTextMsg;
                        result.IsValid = false;
                        return result;
                    }
                    else if (callTypeValidationResponse != null && callTimeExistsValidationResponse.IsVisitStartTimeExists == 0)
                    {
                        result.MessageText = ValidationMessageText.CallLinkVisitStartTimeValidationTextMsg;
                        result.IsValid = false;
                        return result;
                    }
                    else if (callTimeExistsValidationResponse.IsVisitStartTimeExists == 1 && callTimeExistsValidationResponse.IsVisitEndTimeExists == 1)
                    {
                        result.MessageText = ValidationMessageText.CallLinkConfirmedVisitValidationTextMsg;
                        result.IsValid = false;
                        return result;
                    }
                }
            }

            MatchingCallsDetailRequest matchingCallRequest = new()
            {
                CallType = callType,
                VisitID = visitID
            };
            _logger.LogInformation("ShowMatchingCalls Start");
            var matchingCalls = await _showMatchingCallsDetailRepository.ShowMatchingCalls(matchingCallRequest).ConfigureAwait(false);
            if (matchingCalls != null)
            {
                var isMaintenanceIDFound = matchingCalls.FirstOrDefault(x => x.MaintenanceID == maintenanceID);
                if (isMaintenanceIDFound == null)
                {
                    result.MessageText = ValidationMessageText.CallLinkMaintenanceIDValidateTextMsg;
                    result.IsValid = false;
                    return result;
                }
            }
            _logger.LogInformation("ShowMatchingCalls End");
            return result;
        }
    }
}
