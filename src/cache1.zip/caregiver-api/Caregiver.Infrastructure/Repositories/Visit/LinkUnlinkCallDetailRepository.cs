﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Dapper;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Caregiver.Infrastructure.Repositories.Visit
{
    public class LinkUnlinkCallDetailRepository : ILinkUnlinkCallDetailRepository
    {
        public async Task<LinkUnlinkCallDetailResponse> GetDetailsForLinkUnlinkCall(LinkUnlinkCallDetailRequest request)
        {
            LinkUnlinkCallDetailResponse response = new();
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.LinkUnlinkCallDetail);

            var parameters = new DynamicParameters();
            parameters.Add("@UserID", request.UserID);
            parameters.Add("@MaintenanceID", request.MaintenanceID);
            parameters.Add("@VisitID", request.VisitID);
            parameters.Add("@LinkUnlink", request.LinkUnlink);
            parameters.Add("@AppVersion", request.AppVersion);
            parameters.Add("@Version", request.Version);
            parameters.Add("@MinorVersion", request.MinorVersion);
            parameters.Add("@CallerInfo", request.CallerInfo);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                var callDetails = con.Query<LinkUnlinkCallDetailResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ToList();
                if (callDetails != null && callDetails.Count > 0)
                {
                    response = callDetails.First();
                }
            }

            return await Task.FromResult(response);
        }

        public async Task UpdateUnscheduleToScheduleVisit(string visitXML, int userId, DefaultParam defaultParam)
        {
            List<UnScheduledVisitLinkedCallDetailsResponse> visitDetails;
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.UnScheduledVisitLinkedCalls);

            var parameters = new DynamicParameters();
            parameters.Add("@UserID", userId);
            parameters.Add("@VisitXML", visitXML);
            parameters.Add("@AppVersion", defaultParam.AppVersion);
            parameters.Add("@Version", defaultParam.Version);
            parameters.Add("@MinorVersion", defaultParam.MinorVersion);
            parameters.Add("@CallerInfo", CallerInfo.UnScheduledVisitLinkedCalls);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                visitDetails = con.Query<UnScheduledVisitLinkedCallDetailsResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ToList();
            }

            StringBuilder unscheduledVisitXML = new();
            if (visitDetails != null && visitDetails.Count > 0)
            {
                unscheduledVisitXML.Append("<Visits>");
                foreach (var item in visitDetails)
                {
                    unscheduledVisitXML.Append("<Visit VId='" + item.VisitID + "' CallUniqueID='" + item.CallUniqueID + "'  UnscheduledVId='" + item.UnscheduledVisitID + "'/>");
                }
                unscheduledVisitXML.Append("</Visits>");

                await UpdateUnscheduledVisitToScheduledVisit(unscheduledVisitXML.ToString(), userId, defaultParam);
            }
        }

        private static async Task UpdateUnscheduledVisitToScheduledVisit(string visitXML, int userId, DefaultParam defaultParam)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.UpdateUnscheduledVisitToScheduledVisit);

            var parameters = new DynamicParameters();
            parameters.Add("@UserID", userId);
            parameters.Add("@VisitXML", visitXML);
            parameters.Add("@AppVersion", defaultParam.AppVersion);
            parameters.Add("@Version", defaultParam.Version);
            parameters.Add("@MinorVersion", defaultParam.MinorVersion);
            parameters.Add("@CallerInfo", CallerInfo.UpdateUnScheduledVisitToScheduledVisit);
            parameters.Add("@Saved", 0, DbType.Int32, ParameterDirection.Output);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                await con.QueryAsync<UnScheduledVisitLinkedCallDetailsResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout);
            }
        }

        public async Task UpdateInterruptDetails(string callUniqueID, long visitId, int vendorId, string evvSource, string evvType, string linkUnlink, DefaultParam defaultParam)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.UpdateInterruptDetails);

            var parameters = new DynamicParameters();
            parameters.Add("@CallUniqueID", callUniqueID);
            parameters.Add("@UserID", defaultParam.UserID);
            parameters.Add("@VisitID", visitId);
            parameters.Add("@VendorID", vendorId);
            parameters.Add("@EVVSource", evvSource);
            parameters.Add("@EVVType", evvType);
            parameters.Add("@LinkUnlink", linkUnlink);
            parameters.Add("@AppVersion", defaultParam.AppVersion);
            parameters.Add("@Version", defaultParam.Version);
            parameters.Add("@MinorVersion", defaultParam.MinorVersion);
            parameters.Add("@CallerInfo", CallerInfo.UpdateInterruptDetails);
            parameters.Add("@OutputResult", 0, DbType.Int32, ParameterDirection.Output);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                await con.QueryAsync<UnScheduledVisitLinkedCallDetailsResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout);
            }
        }

        public async Task<VisitScheduleDetailResponse> VisitScheduleDetailByVisitID(int userId, long visitId)
        {
            VisitScheduleDetailResponse response = new();
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.VisitScheduleDetailByVisitID);

            var parameters = new DynamicParameters();
            parameters.Add("@UserID", userId);
            parameters.Add("@VisitID", visitId);
            parameters.Add("@CallerInfo", CallerInfo.VisitScheduleDetailByVisitID);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                var visitDetails = con.Query<VisitScheduleDetailResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ToList();
                if (visitDetails != null && visitDetails.Count > 0)
                {
                    response = visitDetails.First();
                }
            }

            return await Task.FromResult(response);
        }

        public async Task UpdateScheduledVisitAfterUnlinkCall(long visitId, DefaultParam defaultParam)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.UpdateScheduledVisitAfterUnlinkCall);

            var parameters = new DynamicParameters();
            parameters.Add("@UserID", defaultParam.UserID);
            parameters.Add("@VisitID", visitId);
            parameters.Add("@AppVersion", defaultParam.AppVersion);
            parameters.Add("@Version", defaultParam.Version);
            parameters.Add("@MinorVersion", defaultParam.MinorVersion);
            parameters.Add("@CallerInfo", CallerInfo.UpdateScheduledVisitAfterUnlinkCall);
            parameters.Add("@Saved", 0, DbType.Int32, ParameterDirection.Output);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                await con.QueryAsync<UnScheduledVisitLinkedCallDetailsResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout);
            }
        }

        public async Task SaveReasonNotesForLinkUnlinkCall(DefaultParam defaultParam, long visitID, int reasonID, int actionTakenReasonID, string notes)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.SaveReasonNotesForLinkUnlinkCall);

            var parameters = new DynamicParameters();
            parameters.Add("@UserID", defaultParam.UserID);
            parameters.Add("@VisitID", visitID);
            parameters.Add("@ReasonID", reasonID);
            parameters.Add("@ActionTakenReasonID", actionTakenReasonID);
            parameters.Add("@Notes", notes);
            parameters.Add("@AppVersion", defaultParam.AppVersion);
            parameters.Add("@Version", defaultParam.Version);
            parameters.Add("@MinorVersion", defaultParam.MinorVersion);
            parameters.Add("@CallerInfo", CallerInfo.SaveReasonNotesForLinkUnlinkCall);
            parameters.Add("@IsSaved", 0, DbType.Int32, ParameterDirection.Output);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                await con.ExecuteScalarAsync<int>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout);
            }
        }
    }
}
