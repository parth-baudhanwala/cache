﻿using Caregiver.Core.Interfaces.Common;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.Visit
{
    public class VisitDetailsRepository : IVisitDetailsRepository
    {
        private readonly IConfiguration _configuration;
        public VisitDetailsRepository(IConfiguration configuration, ICommonRepository commonRepository)
        {
            _configuration = configuration;
        }

        public async Task<VisitDetailsResponse> VisitDetails(VisitDetailsRequest request)
        {
            VisitDetailsResponse result;

            using (var con = new SqlConnection(_configuration["ConnectionStrings:HHAMirror"]))
            {
                result = await con.QueryFirstOrDefaultAsync<VisitDetailsResponse>(VisitSqlQueries.GetVisitDetailsUsingVisitID, new { VisitID = request.VisitID }, commandType: CommandType.Text).ConfigureAwait(false);
            }

            return result;
        }
    }
}
