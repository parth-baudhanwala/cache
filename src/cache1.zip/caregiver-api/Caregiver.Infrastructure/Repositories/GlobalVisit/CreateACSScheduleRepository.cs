﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Common;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Infrastructure.Helper;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.GlobalVisit
{
    public class CreateACSScheduleRepository : ICreateACSScheduleRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<CreateACSScheduleRepository> _logger;
        private readonly ICommonRepository _commonRepository;

        public CreateACSScheduleRepository(IConfiguration configuration,
            ICommonRepository commonRepository,
            ILogger<CreateACSScheduleRepository> logger)
        {
            _configuration = configuration;
            _commonRepository = commonRepository;
            _logger = logger;
        }

        public async Task<List<CreateACSScheduleResponse>> CreateACSSchedule(CreateACSScheduleRequest request)
        {
            List<CreateACSScheduleResponse> response = new();
            VersionDetailsResponse versionDetail;
            string CallsXML;

            _logger.LogInformation("CreateACSSchedule() Start");

            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                var resultCG = await con.QueryFirstOrDefaultAsync(CommonSqlQueries.GetCaregiverIDByGlobalCaregiverID, new { request.GlobalCaregiverID }, commandType: CommandType.Text).ConfigureAwait(false);
                request.CaregiverID = Convert.ToInt32(resultCG.AideID);
                _logger.LogInformation($"GetCaregiverIDByGlobalCaregiverID : {request.CaregiverID}");

                var resultPT = await con.QueryFirstOrDefaultAsync(CommonSqlQueries.GetPatientIDByGlobalPatientID, new { request.GlobalPatientID }, commandType: CommandType.Text).ConfigureAwait(false);
                request.PatientID = Convert.ToInt32(resultPT.PatientID);
                _logger.LogInformation($"GetPatientIDByGlobalPatientID : {request.PatientID}");

                versionDetail = await _commonRepository.VersionDetails(request.ProviderID).ConfigureAwait(false);
                _logger.LogInformation($"Provider Version Detail {versionDetail.ProviderVersion}");

                if (request.CallInMID > 0)
                {
                    var resultCallInMID = await con.QueryFirstOrDefaultAsync(CommonSqlQueries.FindMaintenanceIDFromCallMaintenance, new { MaintenanceID = request.CallInMID }, commandType: CommandType.Text).ConfigureAwait(false);
                    if (resultCallInMID == null)
                    {
                        response.Add(new CreateACSScheduleResponse { Problem = "Call IN MaintenanceID is not found in ENT database." });
                        return response;
                    }

                    request.CallInMID = Convert.ToInt64(resultCallInMID.MaintenanceID);
                    _logger.LogInformation($"FindMaintenanceIDFromCallMaintenance : CallInMID : {request.CallInMID}");
                }

                if (request.CallOutMID > 0)
                {
                    var resultCallOutMID = await con.QueryFirstOrDefaultAsync(CommonSqlQueries.FindMaintenanceIDFromCallMaintenance, new { MaintenanceID = request.CallOutMID }, commandType: CommandType.Text).ConfigureAwait(false);
                    if (resultCallOutMID == null)
                    {
                        response.Add(new CreateACSScheduleResponse { Problem = "Call OUT MaintenanceID is not found in ENT database." });
                        return response;
                    }

                    request.CallOutMID = Convert.ToInt64(resultCallOutMID.MaintenanceID);
                    _logger.LogInformation($"FindMaintenanceIDFromCallMaintenance : CallOutMID : {request.CallOutMID}");
                }

                if (request.CallInMID == 0 && request.CallOutMID == 0)
                {
                    response.Add(new CreateACSScheduleResponse { Problem = "Call INT/OUT MaintenanceID should not be blank or 0." });
                    return response;
                }
            }

            if (request.ProviderID > 0 && request.CaregiverID > 0 && request.PatientID > 0 && versionDetail != null)
            {
                _logger.LogInformation("CreateSchedulesFromCallMaintenance Call SP Start.");
                CallsXML = GenerateCallsXML(request);
                SqlParameter[] sqlParameters = new SqlParameter[] {
                    new() { ParameterName = "@UserID", Value = request.UserID, DbType = DbType.Int32 },
                    new() { ParameterName = "@CallsXML", Value = CallsXML, DbType = DbType.Xml },
                    new() { ParameterName = "@AppVersion", Value = _configuration["AppVersion"], DbType = DbType.String },
                    new() { ParameterName = "@Version", Value = Convert.ToDecimal(versionDetail.ProviderVersion), DbType = DbType.Decimal },
                    new() { ParameterName = "@MinorVersion", Value = Convert.ToDecimal(versionDetail.ProviderMinorVersion), DbType = DbType.Decimal },
                    new() { ParameterName = "@CallerInfo", Value = CallerInfo.CreateACSInfo, DbType = DbType.String },
                    new() { ParameterName = "@ScheduleType", Value = request.ScheduleType, DbType = DbType.String },
                    new() { ParameterName = "@IsByPassScheduleValidation", Value = true, DbType = DbType.Boolean },
                    new() { ParameterName = "@IsSaved", Value = 0, DbType = DbType.Int32, Direction = ParameterDirection.Output }
                    };


                DataSet dataSet = new();
                CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.CreateSchedulesFromCallMaintenance);
                using (var sqlConnection = new SqlConnection(cmdInfo.ConnectionStrings))
                using (var command = new SqlCommand(cmdInfo.SPName, sqlConnection))
                {
                    command.Parameters.AddRange(sqlParameters);
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = cmdInfo.Timeout;

                    SqlDataAdapter sqlDataAdapter = new(command);
                    sqlDataAdapter.Fill(dataSet);
                    sqlDataAdapter.Dispose();


                    if (dataSet.Tables.Count > 2 && dataSet.Tables[dataSet.Tables.Count - 1].Rows.Count > 0)
                    {
                        response = CommonHelper.CreateListFromTable<CreateACSScheduleResponse>(dataSet.Tables[dataSet.Tables.Count - 1]);
                    }
                    if (dataSet.Tables.Count > 3 && dataSet.Tables[dataSet.Tables.Count - 2].Rows.Count > 0)
                    {
                        response = CommonHelper.CreateListFromTable<CreateACSScheduleResponse>(dataSet.Tables[dataSet.Tables.Count - 2]);
                    }
                }

                _logger.LogInformation("CreateSchedulesFromCallMaintenance Call SP End.");
            }
            else
            {
                response.Add(new CreateACSScheduleResponse { Problem = "ProviderID or CaregiverID or PatientID should not be blank or 0." });
            }


            _logger.LogInformation("CreateACSSchedule() End.");

            return response ?? new List<CreateACSScheduleResponse>();
        }

        private static string GenerateCallsXML(CreateACSScheduleRequest request)
        {
            System.Text.StringBuilder sb = new();
            if (request != null)
            {
                sb.Append("<Visits>");
                sb.Append("<Data>");
                sb.Append("<Visit");

                sb.Append($" Date=\"{request.ScheduleDate.ToString("MM/dd/yyyy")}\"");
                sb.Append($" SS=\"{request.ScheduleStartTime}\"");
                sb.Append($" SE=\"{request.ScheduleEndTime}\"");
                sb.Append($" AideID=\"{request.CaregiverID}\"");
                sb.Append($" PatientID=\"{request.PatientID}\"");
                sb.Append($" PayRateID=\"{request.PayRateID}\"");
                sb.Append($" ContractID1=\"{request.ContractID1}\"");
                sb.Append($" RateID1=\"{request.ServiceCodeID1}\"");
                sb.Append($" Hours1=\"{request.Hours1}\"");
                sb.Append($" Minutes1=\"{request.Minutes1}\"");
                sb.Append($" POCHeaderID=\"{request.POCHeaderID}\"");
                sb.Append($" POC=\"{request.POC}\"");
                sb.Append($" IsTempSchedule=\"{request.IsTempSchedule}\"");
                sb.Append($" IsTempAide=\"{request.IsTempAide}\"");
                sb.Append($" CallInMID=\"{request.CallInMID}\"");
                sb.Append($" CallOutMID=\"{request.CallOutMID}\"");
                sb.Append($" IsSkilledSchedule=\"{request.IsSkilledSchedule}\"");
                sb.Append($" NonBillable=\"{(request.NonBillable ? 1 : 0)}\"");
                sb.Append($" OnHoldVisit=\"{(request.OnHoldVisit ? 1 : 0)}\"");
                sb.Append($" Comments=\"{request.Comments}\"");
                sb.Append($" IncludeInMileage=\"{(request.IncludeInMileage ? 1 : 0)}\"");

                sb.Append("/>");
                sb.Append("</Data>");
                sb.Append("</Visits>");
            }

            return sb.ToString();
        }
    }
}
