﻿using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.GlobalVisit
{
    public class GlobalUnlinkCallRepository : IGlobalUnlinkCallRepository
    {
        private readonly IConfiguration _configuration;
        private readonly IUnlinkCallRepository _unlinkCallRepository;

        public GlobalUnlinkCallRepository(IConfiguration configuration, IUnlinkCallRepository unlinkCallRepository)
        {
            _configuration = configuration;
            _unlinkCallRepository = unlinkCallRepository;
        }

        /// <summary>
        /// Used to un link call from global visitId
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return value,MessageText</returns>
        public async Task<UnlinkCallResponse> UnLinkCall(GlobalUnlinkCallRequest request)
        {
            UnlinkCallResponse result = new();
            VisitDetails visitDetails = new();

            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                visitDetails = await con.QuerySingleOrDefaultAsync<VisitDetails>(VisitSqlQueries.GetVisitMaintenanceIDByCallType, new { CallType = request.CallType, GlobalVisitId = new DbString() { Value = request.GlobalVisitID, IsAnsi = true, Length = 100 } }, commandType: CommandType.Text).ConfigureAwait(false);
            }

            if (visitDetails != null && visitDetails.VisitID > 0 && visitDetails.MaintenanceID > 0)
            {
                UnlinkCallRequest unlinkCallRequest = new()
                {
                    UserID = request.UserID,
                    MaintenanceID = visitDetails.MaintenanceID,
                    VisitID = visitDetails.VisitID,
                    ProviderID = request.ProviderID,
                };

                result = await _unlinkCallRepository.UnlinkCall(unlinkCallRequest);
            }
            else
            {
                result.ReturnValue = "-1";
                result.MessageText = ValidationMessageText.VisitNotManuallyLinkedTextMsg;
            }

            return result;
        }
    }
}
