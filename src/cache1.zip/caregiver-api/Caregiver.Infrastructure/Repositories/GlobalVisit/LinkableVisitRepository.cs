﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Extensions;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.GlobalVisit
{
    public class LinkableVisitRepository : ILinkableVisitRepository
    {
        public LinkableVisitRepository() { }

        /// <summary>
        /// Used to get Linkable Visits Globel VisitIDs.
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Linkable Visits Globel VisitIDs</returns>
        public async Task<List<LinkableVisitResponse>> LinkableVisits(LinkableVisitRequest request)
        {
            List<LinkableVisitResponse> response = new();

            if (request != null && request.GlobalVisitIDs != null && request.GlobalVisitIDs.Any())
            {
                DataTable? dtVisitIDs = ListExtensions.StringListToDataTable(request.GlobalVisitIDs);
                CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetGlobalLinkableVisits);

                var parameters = new DynamicParameters();
                parameters.Add("@UserID", request.UserID);
                parameters.Add("@GlobalPatientID", request.GlobalPatientID);
                parameters.Add("@GlobalCaregiverID", request.GlobalCaregiverID);
                parameters.Add("@FromDate", request.FromDate);
                parameters.Add("@ToDate", request.ToDate);
                parameters.Add("@GlobalVisitIDs", dtVisitIDs.AsTableValuedParameter());

                using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
                {
                    response = (await con.QueryAsync<LinkableVisitResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout)).ToList();
                }
            }

            return await Task.FromResult(response);
        }
    }
}
