﻿using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.GlobalVisit
{
    public class GlobalLinkCallRepository : IGlobalLinkCallRepository
    {
        private readonly IConfiguration _configuration;
        private readonly ILinkCallRepository _linkCallRepository;

        public GlobalLinkCallRepository(IConfiguration configuration, ILinkCallRepository linkCallRepository)
        {
            _configuration = configuration;
            _linkCallRepository = linkCallRepository;
        }

        /// <summary>
        /// Used to Link call from global visitId
        /// </summary>
        /// <param name="request"></param>
        /// <returns>Return value,MessageText</returns>
        public async Task<LinkCallResponse> LinkCall(GlobalLinkCallRequest request)
        {
            VisitResponse visitResponse = new();
            LinkCallResponse result = new();

            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                visitResponse = await con.QuerySingleOrDefaultAsync<VisitResponse>(VisitSqlQueries.GetVisitIDByGlobalVisitID, new { GlobalVisitId = new DbString() { Value = request.GlobalVisitID, IsAnsi = true, Length = 100 } }, commandType: CommandType.Text).ConfigureAwait(false);
            }

            if (visitResponse != null)
            {
                LinkCallRequest linkCallRequest = new()
                {
                    UserID = request.UserID,
                    MaintenanceID = request.MaintenanceID,
                    VisitID = visitResponse.VisitID,
                    ProviderID = request.ProviderID,
                    CallType = request.CallType,
                    AutoselectTimesheetRequired = request.AutoselectTimesheetRequired,
                    UpdateScheduleOverTime = request.UpdateScheduleOverTime,
                    UpdateWithAideCompliant = request.UpdateWithAideCompliant
                };

                result = await _linkCallRepository.LinkCall(linkCallRequest);
            }
            else
            {
                result.ReturnValue = "-1";
                result.MessageText = ValidationMessageText.VisitNotFoundTextMsg;
            }

            return result;
        }
    }
}
