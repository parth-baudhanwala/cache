﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Caregiver.Infrastructure.Repositories.GlobalVisit
{
    public class ACSRepository : IACSRepository
    {
        private readonly IConfiguration _configuration;


        public ACSRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<List<ACSDetailResponse>> GetACSData(ACSDetailRequest request)
        {
            List<ACSDetailResponse> result = new();
            string patientNumber = "";
            int officeID = 0;
            string caregiverCode = "";
            decimal minorVersion = 0;
            decimal version = 0;
            string appVersion = _configuration["AppVersion"];
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetCallMaintenanceWithNoSchedule);
            var parameters = new DynamicParameters();

            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                var providerData = await con.QuerySingleOrDefaultAsync(ACSSqlQueries.GetProviderVersionByGlobalID, new { GlobalProviderID = new DbString() { Value = request.GlobalProviderID, IsAnsi = true, Length = 100 } }, commandType: CommandType.Text).ConfigureAwait(false);
                if (providerData != null)
                {
                    minorVersion = Convert.ToDecimal(providerData.MinorVersion);
                    version = Convert.ToDecimal(providerData.Version);
                }

                var patientData = await con.QuerySingleOrDefaultAsync(ACSSqlQueries.GetPatientNumberByGlobalID, new { GlobalPatientID = new DbString() { Value = request.GlobalPatientID, IsAnsi = true, Length = 100 } }, commandType: CommandType.Text).ConfigureAwait(false);
                if (patientData != null)
                {
                    patientNumber = Convert.ToString(patientData.PatientNumber);
                }

                var officeData = await con.QuerySingleOrDefaultAsync(ACSSqlQueries.GetOfficeIDByGlobalID, new { GlobalOfficeID = new DbString() { Value = request.GlobalOfficeID, IsAnsi = true, Length = 100 } }, commandType: CommandType.Text).ConfigureAwait(false);
                if (officeData != null)
                {
                    officeID = Convert.ToInt32(officeData.OfficeID);
                }

                var caregiverData = await con.QuerySingleOrDefaultAsync(ACSSqlQueries.GetCaregiverCodeByGlobalID, new { GlobalCaregiverID = new DbString() { Value = request.GlobalCaregiverID, IsAnsi = true, Length = 100 } }, commandType: CommandType.Text).ConfigureAwait(false);
                if (caregiverData != null)
                {
                    caregiverCode = Convert.ToString(caregiverData.AideCode);
                }
            }

            StringBuilder sbData = new StringBuilder("<Offices>");
            sbData.Append("<Office ID=\"" + officeID + "\"/>");
            sbData.Append("</Offices>");
            string xmlData = sbData.ToString();

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                parameters.Add("@UserID", request.UserID);
                parameters.Add("@FromDate", request.FromDate);
                parameters.Add("@ToDate", request.ToDate);
                parameters.Add("@IsCallInAndCallOut", false);
                parameters.Add("@DisciplineXML", "");
                parameters.Add("@OfficeIDs", xmlData);
                parameters.Add("@PatientTeamIDs", null);
                parameters.Add("@LocationIDs", null);
                parameters.Add("@BranchIDs", null);
                parameters.Add("@CaregiverTeamIDs", null);
                parameters.Add("@CaregiverLocationIDs", null);
                parameters.Add("@CaregiverBranchIDs", null);
                parameters.Add("@ContractIDs", null);
                parameters.Add("@DisciplineIDs", null);
                parameters.Add("@CoordinatorIDs", null);
                parameters.Add("@AdmissionID", patientNumber);
                parameters.Add("@CaregiverCode", caregiverCode);
                parameters.Add("@Version", version);
                parameters.Add("@MinorVersion", minorVersion);
                parameters.Add("@AppVersion", appVersion);
                parameters.Add("@Pagesize", _configuration["ACSProcess:GetTopACSDataCount"] != null ? Convert.ToInt32(_configuration["ACSProcess:GetTopACSDataCount"]) : 1000);
                parameters.Add("@PageNo", 1);
                parameters.Add("@CallerInfo", "Caregiver.API > ACS Controller > GetACSData");

                using (var queryOutput = await con.QueryMultipleAsync(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false))
                {
                    if (queryOutput != null)
                    {
                        result = queryOutput.Read<ACSDetailResponse>().ToList();
                    }
                }
            }

            return result;
        }
    }
}
