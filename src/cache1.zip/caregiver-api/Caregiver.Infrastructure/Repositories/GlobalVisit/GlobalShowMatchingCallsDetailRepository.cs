﻿using Caregiver.Core.Interfaces.GlobalVisit;
using Caregiver.Core.Interfaces.Visit;
using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.GlobalVisit
{
    public class GlobalShowMatchingCallsDetailRepository : IGlobalShowMatchingCallsDetailRepository
    {
        private readonly IConfiguration _configuration;
        private readonly IShowMatchingCallsDetailRepository _showMatchingCallsDetailRepository;


        public GlobalShowMatchingCallsDetailRepository(IConfiguration configuration, IShowMatchingCallsDetailRepository showMatchingCallsDetailRepository)
        {
            _configuration = configuration;
            _showMatchingCallsDetailRepository = showMatchingCallsDetailRepository;
        }

        /// <summary>
        /// Used to show mathing calls from global visitId
        /// </summary>
        /// <param name="matchingCallsDetailRequest"></param>
        /// <returns>Return details of matching calls</returns>
        public async Task<List<MatchingCallsDetailResponse>> ShowMatchingCalls(GlobalMatchingCallsDetailRequest matchingCallsDetailRequest)
        {
            List<MatchingCallsDetailResponse> result = new();
            VisitResponse visitResponse = new();

            using (var con = new SqlConnection(this._configuration["ConnectionStrings:HHAMirror"]))
            {
                visitResponse = await con.QuerySingleOrDefaultAsync<VisitResponse>(VisitSqlQueries.GetVisitIDByGlobalVisitID, new { GlobalVisitId = new DbString() { Value = matchingCallsDetailRequest.GlobalVisitID, IsAnsi = true, Length = 100 } }, commandType: CommandType.Text).ConfigureAwait(false);
            }

            if (visitResponse != null)
            {
                MatchingCallsDetailRequest matchingCallRequest = new()
                {
                    CallType = matchingCallsDetailRequest.CallType,
                    VisitID = visitResponse.VisitID
                };

                result = await _showMatchingCallsDetailRepository.ShowMatchingCalls(matchingCallRequest);
            }
            return result;
        }
    }
}
