﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.RTM;
using Caregiver.Domain.DomainTransferObjects.RTM;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.RTM
{
    public class ActionTakenReasonRepository : IActionTakenReasonRepository
    {

        public ActionTakenReasonRepository()
        {
        }

        public async Task<List<ActionTakenReasonResponse>> GetActionTakenReasonsByReasonID(ActionTakenReasonRequest request)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetActionTakenReasonsByReasonID);
            var parameters = new DynamicParameters();
            parameters.Add("@UserID", request.UserID);
            parameters.Add("@ChhaID", request.ContractChhaID);
            parameters.Add("@VendorID", request.ProviderID);
            parameters.Add("@ReasonID", request.ReasonID);

            List<ActionTakenReasonResponse> actionTakenReasonResponse;

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                actionTakenReasonResponse = (await con.QueryAsync<ActionTakenReasonResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false)).ToList();
            }

            return actionTakenReasonResponse;
        }
    }
}
