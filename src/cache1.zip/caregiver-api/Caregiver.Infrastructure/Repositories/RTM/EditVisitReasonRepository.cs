﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.RTM;
using Caregiver.Domain.DomainTransferObjects.RTM;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.RTM
{
    public class EditVisitReasonRepository : IEditVisitReasonRepository
    {

        public EditVisitReasonRepository()
        {
        }

        public async Task<List<EditVisitReasonResponse>> GetEditVisitReasons(EditVisitReasonRequest request)
        {
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.GetEditVisitReasons);
            var parameters = new DynamicParameters();
            parameters.Add("@UserID", request.UserID);
            parameters.Add("@ChhaID", request.ContractChhaID);
            parameters.Add("@VendorID", request.ProviderID);

            List<EditVisitReasonResponse> reasonResponse;

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                reasonResponse = (await con.QueryAsync<EditVisitReasonResponse>(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false)).ToList();
            }

            return reasonResponse;
        }
    }
}
