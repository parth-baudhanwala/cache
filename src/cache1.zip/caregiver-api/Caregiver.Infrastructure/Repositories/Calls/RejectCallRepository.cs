﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Calls;
using Caregiver.Domain.DomainTransferObjects.Calls;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace Caregiver.Infrastructure.Repositories.Calls
{
    public class RejectCallRepository : IRejectCallRepository
    {
        public RejectCallRepository()
        {
        }

        public async Task<RejectCallResponse> RejectCall(RejectCallRequest request)
        {
            RejectCallResponse result = new();
            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.RejectCall);
            var parameters = new DynamicParameters();
            parameters.Add("@UserID", request.UserID);
            parameters.Add("@MaintenanceID", request.MaintenanceID);
            parameters.Add("@ReasonID", 0);
            parameters.Add("@CallerInfo", CallerInfo.RejectCalls);
            parameters.Add("@IsDeleted", 0, DbType.Int32, ParameterDirection.Output);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                con.Query(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout);
            }

            int returnValue = parameters.Get<int>("@IsDeleted");

            if (returnValue > 0)
            {
                result.MessageText = ValidationMessageText.RejectCallSuccessTextMsg;
            }
            else
            {
                result.MessageText = ValidationMessageText.RejectCallFailTextMsg;
            }

            result.ReturnValue = returnValue;
            return await Task.FromResult(result);
        }
    }
}
