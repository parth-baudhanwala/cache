﻿using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Calls;
using Caregiver.Core.Interfaces.Common;
using Caregiver.Core.Interfaces.Helper;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.Visit;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Caregiver.Infrastructure.Repositories.Calls
{
    public class CallExceptionsRepository : ICallExceptionsRepository
    {

        private readonly IConfiguration _configuration;
        private readonly ICommonRepository _commonRepository;
        private readonly IWebApiHelper _webApiHelper;

        public CallExceptionsRepository(IConfiguration configuration,
              ICommonRepository commonRepository,
              IWebApiHelper webApiHelper)
        {
            this._configuration = configuration;
            this._commonRepository = commonRepository;
            _webApiHelper = webApiHelper;
        }
        public async Task GenerateCallExceptions(VisitExceptionRequest visitExceptionRequest, DefaultParam defaultParam)
        {

            int entApiAppVersionId = Convert.ToInt32(_configuration["EntApiAppVersionID"]);
            string entpUrl = await _commonRepository.GetAppServerURLDetails(visitExceptionRequest.ProviderID, entApiAppVersionId, defaultParam).ConfigureAwait(false);

            string methodName,
                   entApiUrl;

            methodName = ExternalApiNames.GenerateCallExceptions;

            entApiUrl = entpUrl + methodName;

            string requestJson = JsonConvert.SerializeObject(visitExceptionRequest);
            await _webApiHelper.POST(entApiUrl, requestJson);

        }
    }
}
