﻿using Microsoft.Extensions.Configuration;
using Caregiver.Core.Interfaces.Caregiver;
using Caregiver.Domain.DomainTransferObjects.Caregiver;
using Caregiver.Infrastructure.Contexts;
using Microsoft.EntityFrameworkCore;
using Caregiver.Infrastructure.DBEntity;
using Caregiver.Core.Constants;
using Caregiver.Core.Common;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Core.Interfaces.Helper;
using Newtonsoft.Json;

namespace Caregiver.Infrastructure.Repositories.Visit
{
    public class ValidateActivationCodeRepository : IValidateActivationCodeRepository
    {
        private readonly IConfiguration _configuration;
        private readonly HhaCaregiverDbContext _hhaCaregiverDbContext;
        private readonly IMobileUserRepository _mobileRepository;
        private readonly IWebApiHelper _webApiHelper;

        public ValidateActivationCodeRepository(IConfiguration configuration, HhaCaregiverDbContext hhaCaregiverDbContext, IMobileUserRepository mobileRepository, IWebApiHelper webApiHelper)
        {
            _configuration = configuration;
            _hhaCaregiverDbContext = hhaCaregiverDbContext;
            _mobileRepository = mobileRepository;
            _webApiHelper = webApiHelper;
        }

        public async Task<ValidateActivationCodeResponse> ValidateActivationCode(ValidateActivationCodeRequest request)
        {
            ValidateActivationCodeResponse response = new();
            string providerEnvironment = string.Empty;
            Guid globalcaregiverID = Guid.Empty;

            var activationCodeDetails = await Task.FromResult(_hhaCaregiverDbContext.ActivationCode.AsNoTracking()
                .FirstOrDefault(x => x.ActivationCode == request.ActivationCode && x.IsActive == true && x.ExpiryDate > DateTime.Now))
                .ConfigureAwait(false);

            if (activationCodeDetails == null)
            {
                response.MessageText = ValidationMessageText.ActivationCodeNotValidMsg;
                return response;
            }

            providerEnvironment = activationCodeDetails.ProviderEnvironment;
            globalcaregiverID = activationCodeDetails.GlobalCaregiverID;

            if (string.IsNullOrEmpty(providerEnvironment))
            {
                response.MessageText = ValidationMessageText.ProviderEnvironmentEmptyMsg;
                return response;
            }

            if (providerEnvironment.Trim().ToLower() == "clo")
            {
                return await this.GetCaregiverAgencyDetails(globalcaregiverID, request.CaregiverUserGlobalID);
            }
            else
            {
                ApiServiceModel apiService = new()
                {
                    HttpMethod = HttpMethod.Get,
                    RequestUri = AppSettings.Configuration.GetValue<string>(AppSettings.CaregiverAppApiCaregiverAPIURL) + ExternalApiNames.CaregiverAgencyDetails.Replace("globalcaregiverid", request.CaregiverUserGlobalID.ToString()),
                    TokenUrl = AppSettings.Configuration.GetValue<string>(AppSettings.IdentityTokenUrl),
                    ClientId = AppSettings.Configuration.GetValue<string>(AppSettings.CaregiverAppApiClientId),
                    ClientSecret = AppSettings.Configuration.GetValue<string>(AppSettings.CaregiverAppApiClientSecret),
                    Scope = AppSettings.Configuration.GetValue<string>(AppSettings.CaregiverAppApiScope),
                    IsAuthorizationTokenRequired = true,
                };

                apiService.CustomHeaders.Add("transaction_id", request.TransactionID.ToString());

                var activationCodeResponse = _webApiHelper.GETOrPOSTWithGetTokenAsync(apiService).Result;

                if (activationCodeResponse.IsSuccessStatusCode)
                {
                    var content = activationCodeResponse.Content.ReadAsStringAsync().Result;
                    var agencyDetails = JsonConvert.DeserializeObject<GetCaregiverAgencyDetailsResponse>(content);
                    if (agencyDetails == null)
                    {
                        response.MessageText = ValidationMessageText.CaregiverAgencyDetailNotFoundMsg;
                        return response;
                    }

                    return MapAgencyResponse(agencyDetails, request.CaregiverUserGlobalID);
                }
            }

            return response;
        }

        private async Task<ValidateActivationCodeResponse> GetCaregiverAgencyDetails(Guid globalCaregiverID, Guid globalCaregiverUserID)
        {
            ValidateActivationCodeResponse response = new();

            GetCaregiverAgencyDetailsRequest agencyRequest = new()
            {
                GlobalCaregiverID = globalCaregiverID
            };

            var agencyDetails = await _mobileRepository.GetCaregiverAgencyDetails(agencyRequest);

            if (agencyDetails == null)
            {
                response.MessageText = ValidationMessageText.CaregiverAgencyDetailNotFoundMsg;
                return response;
            }

            return MapAgencyResponse(agencyDetails, globalCaregiverUserID);
        }

        private ValidateActivationCodeResponse MapAgencyResponse(GetCaregiverAgencyDetailsResponse agencyDetails, Guid globalCaregiverUserID)
        {
            ValidateActivationCodeResponse response = new()
            {
                GlobalCaregiverUserID = globalCaregiverUserID,
                GlobalProviderID = agencyDetails.GlobalProviderID,
                ProviderID = agencyDetails.ProviderID,
                GlobalCaregiverID = agencyDetails.GlobalCaregiverID,
                CaregiverID = agencyDetails.CaregiverID,
                GlobalOfficeID = agencyDetails.GlobalOfficeID,
                OfficeID = agencyDetails.OfficeID,
                FirstName = agencyDetails.FirstName,
                LastName = agencyDetails.LastName,
                OfficeName = agencyDetails.OfficeName,
                ProviderName = agencyDetails.ProviderName,
                ProviderEnvironment = agencyDetails.ProviderEnvironment,
                TransactionID = agencyDetails.TransactionID
            };

            return response;
        }
    }
}
