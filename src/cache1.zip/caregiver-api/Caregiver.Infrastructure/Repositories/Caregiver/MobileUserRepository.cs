﻿using Caregiver.Core.Common;
using Caregiver.Core.Constants;
using Caregiver.Core.Interfaces.Caregiver;
using Caregiver.Core.Models.Caregiver;
using Caregiver.Domain.DomainTransferObjects.Caregiver;
using Caregiver.Infrastructure.Contexts;
using Caregiver.Infrastructure.DBEntity;
using Caregiver.Infrastructure.SqlQueries;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace Caregiver.Infrastructure.Repositories.Visit
{
    public class MobileUserRepository : IMobileUserRepository
    {
        private readonly IConfiguration _configuration;
        private readonly HhaCaregiverDbContext _hhaCaregiverDbContext;
        private readonly HhaDbContext _hhaDbContext;
        public MobileUserRepository(IConfiguration configuration, HhaCaregiverDbContext hhaCaregiverDbContext, HhaDbContext hhaDbContext)
        {
            _configuration = configuration;
            _hhaCaregiverDbContext = hhaCaregiverDbContext;
            _hhaDbContext = hhaDbContext;

        }

        public async Task<GetCaregiverAgencyDetailsResponse> GetCaregiverAgencyDetails(GetCaregiverAgencyDetailsRequest request)
        {
            var response = new GetCaregiverAgencyDetailsResponse();
            using (var con = new SqlConnection(_configuration["ConnectionStrings:HHAMirror"]))
            {
                response = await con.QueryFirstOrDefaultAsync<GetCaregiverAgencyDetailsResponse>(CaregiverSqlQueries.GetCaregiverAgencyDetailsByGlobalCaregiverId, new { GlobalCaregiverId = request.GlobalCaregiverID }, commandType: CommandType.Text).ConfigureAwait(false);
            }
            return response ?? new GetCaregiverAgencyDetailsResponse();
        }

        public async Task<RegisterMobileUserResponse> RegisterMobileUser(RegisterMobileUserRequest request)
        {
            var caregiver = new AideMaster();
            var response = new RegisterMobileUserResponse();
            using (var con = new SqlConnection(_configuration["ConnectionStrings:HHAMirror"]))
            {
                caregiver = await con.QueryFirstOrDefaultAsync<AideMaster>(CaregiverSqlQueries.GetCaregiverByGlobalCaregiverId, new { GlobalCaregiverId = request.CaregiverGlobalId }, commandType: CommandType.Text).ConfigureAwait(false);
            }

            var ssnPartial = caregiver.Ssn.Substring(Math.Max(0, caregiver.Ssn.Length - 4));
            if (!ssnPartial.Equals(request.SSNPartial) && !caregiver.DateofBirth.ToString("yyyy-MM-dd").Equals(request.DateofBirth.ToString("yyyy-MM-dd")))
            {
                response.ReturnValue = -1;
                response.MessageText = ValidationMessageText.LinkMobileUserSSNDOBValidationMsg;
                return response;
            }
            else if (!ssnPartial.Equals(request.SSNPartial))
            {
                response.ReturnValue = -2;
                response.MessageText = ValidationMessageText.LinkMobileUserSSNValidationMsg;
                return response;
            }
            else if (!caregiver.DateofBirth.ToString("yyyy-MM-dd").Equals(request.DateofBirth.ToString("yyyy-MM-dd")))
            {
                response.ReturnValue = -3;
                response.MessageText = ValidationMessageText.LinkMobileUserDOBValidationMsg;
                return response;
            }

            CommandInfo cmdInfo = DataAccess.GetCommandDetails(SPNames.CaregiverRegisterMobileUser);

            var parameters = new DynamicParameters();
            parameters.Add("@GlobalCaregiverUserID", request.CaregiverUserGlobalId);
            parameters.Add("@GlobalProviderID", request.ProviderGlobalId);
            parameters.Add("@ProviderID", request.ProviderId);
            parameters.Add("@GlobalOfficeID", request.OfficeGlobalId);
            parameters.Add("@OfficeID", request.OfficeId);
            parameters.Add("@GlobalCaregiverID", request.CaregiverGlobalId);
            parameters.Add("@CaregiverID", request.CaregiverId);
            parameters.Add("@FirstName", request.FirstName);
            parameters.Add("@LastName", request.LastName);
            parameters.Add("@PhoneNumber", request.PhoneNumber);
            parameters.Add("@Email", request.Email);
            parameters.Add("@SSNPartial", request.SSNPartial);
            parameters.Add("@DateOfBirth", request.DateofBirth);
            parameters.Add("@MobileDeviceID", request.MobileDeviceID);
            parameters.Add("@ApplicationName", request.ApplicationName);
            parameters.Add("@IsPCIUser", request.IsPCIuser);

            parameters.Add("@IsSaved", 0, DbType.Int32, ParameterDirection.Output);

            using (var con = new SqlConnection(cmdInfo.ConnectionStrings))
            {
                await con.QueryAsync(cmdInfo.SPName, parameters, commandType: CommandType.StoredProcedure, commandTimeout: cmdInfo.Timeout).ConfigureAwait(false);
            }

            int returnValue = parameters.Get<int>("@IsSaved");

            if (returnValue == 1)
            {
                response.ReturnValue = returnValue;
                response.MessageText = ValidationMessageText.LinkMobileUserSuccessMsg;
            }

            return response;
        }

        public async Task<ActivationCodeGenerationResponse> ActivationCodeGeneration(ActivationCodeGenerationRequest request)
        {
            string activationcode = GetActivationCode();

            ActivationCodes ActivationCode = new()
            {
                ActivationCode = activationcode,
                GlobalCaregiverID = request.CaregiverGlobalId,
                ProviderEnvironment = request.ProviderEnvironment,
                ExpiryDate = DateTime.Now.AddHours(Convert.ToInt32(_configuration["ActivationCodeExpiryHours"])),
                IsActive = true,
                CreatedBy = request.UserId,
                CreatedUTCDate = DateTime.UtcNow
            };
            _hhaCaregiverDbContext.ActivationCode.Add(ActivationCode);

            List<ActivationCodes> ActivationCodes = _hhaCaregiverDbContext.ActivationCode.AsNoTracking()
                .Where(h => h.ActivationCode != activationcode && h.IsActive && h.GlobalCaregiverID == request.CaregiverGlobalId)
                .ToList();

            foreach (var h in ActivationCodes)
            {
                h.IsActive = false;
                h.UpdatedBy = request.UserId;
                h.UpdatedUTCDate = DateTime.UtcNow;
                _hhaCaregiverDbContext.ActivationCode.Add(h);
            }
            _hhaCaregiverDbContext.UpdateRange(ActivationCodes);

            await _hhaCaregiverDbContext.SaveChangesAsync();

            ActivationCodeGenerationResponse response = new()
            {
                MessageText = ValidationMessageText.ActivationCodeGenerationSuccessMsg,
                ActivationCode = activationcode
            };
            return response;
        }

        public async Task<UserAgencyLinkResponse> LinkUnlinkMobileUser(UserAgencyLinkRequest request)
        {
            UserAgencyLinkingDetails? UserAgencyLinkingDetail = _hhaDbContext.UserAgencyLinkingDetail.AsNoTracking()
                                                    .Where(h => h.GlobalCaregiverUserID == request.GlobalCaregiverUserID 
                                                    && h.GlobalCaregiverID == request.GlobalCaregiverID 
                                                    && h.GlobalOfficeID == request.GlobalOfficeID)
                                                        .FirstOrDefault();
           
            long caregiverUserAgencyLinkingDetailsID;            
            var isAgencyLinked = request.IsAgencyLinked ? "Yes" : "No";

            if (UserAgencyLinkingDetail != null 
                && UserAgencyLinkingDetail.CaregiverUserAgencyLinkingDetailsID > 0)
            {
                if (UserAgencyLinkingDetail.IsAgencyLinked != isAgencyLinked)
                {
                    UserAgencyLinkingDetail.IsAgencyLinked = isAgencyLinked;
                    if (request.IsAgencyLinked)
                    {
                        UserAgencyLinkingDetail.LinkedUTCDate = DateTime.UtcNow;
                    }
                    else
                    {
                        UserAgencyLinkingDetail.UnLinkedUTCDate = DateTime.UtcNow;
                    }
                    _hhaDbContext.UserAgencyLinkingDetail.Update(UserAgencyLinkingDetail);
                    _hhaDbContext.SaveChanges();
                   
                }
                caregiverUserAgencyLinkingDetailsID = UserAgencyLinkingDetail.CaregiverUserAgencyLinkingDetailsID;

            }
            else
            {
                int AideID, VendorID, OfficeID;
                using (var con = new SqlConnection(_configuration["ConnectionStrings:HHAMirror"]))
                {
                    (AideID, VendorID, OfficeID) = await con.QueryFirstOrDefaultAsync<(int, int, int)>(CaregiverSqlQueries.GetIdByGlobalID,
                        new
                        {
                            GlobalCaregiverID = request.GlobalCaregiverID,
                            GlobalProviderID = request.GlobalProviderID,
                            GlobalOfficeID = request.GlobalOfficeID
                        },
                        commandType: CommandType.Text).ConfigureAwait(false);
                }

                UserAgencyLinkingDetails AddUserAgencyLinkingDetail = new UserAgencyLinkingDetails()
                {
                    GlobalCaregiverUserID = request.GlobalCaregiverUserID,
                    GlobalCaregiverID = request.GlobalCaregiverID,
                    GlobalOfficeID = request.GlobalOfficeID,
                    IsAgencyLinked = isAgencyLinked,
                    CreatedUTCDate = DateTime.UtcNow,
                    ApplicationName = request.ApplicationName,
                    GlobalProviderID = request.GlobalProviderID,
                    ProviderID = VendorID,
                    OfficeID = OfficeID,
                    CaregiverID = AideID
                };
                if (request.IsAgencyLinked)
                {
                    AddUserAgencyLinkingDetail.LinkedUTCDate = DateTime.UtcNow;
                }
                else
                {
                    AddUserAgencyLinkingDetail.UnLinkedUTCDate = DateTime.UtcNow;
                }

                _hhaDbContext.UserAgencyLinkingDetail.Add(AddUserAgencyLinkingDetail);
                _hhaDbContext.SaveChanges();
                caregiverUserAgencyLinkingDetailsID = AddUserAgencyLinkingDetail.CaregiverUserAgencyLinkingDetailsID;
            }

            var response = new UserAgencyLinkResponse()
            {
                MessageText = request.IsAgencyLinked ? ValidationMessageText.LinkUserAgencySuccessMsg : ValidationMessageText.UnlinkUserAgencySuccessMsg,
                ReturnValue = caregiverUserAgencyLinkingDetailsID
            };


            return response;

        }

        private string GetActivationCode()
        {
            string activationcode;
            do
            {
                activationcode = GetRandomActivationCode();
            } while (ActivationCodeExistsInDB(activationcode));
            return activationcode;
        }

        private bool ActivationCodeExistsInDB(string code)
        {
            bool isExists = _hhaCaregiverDbContext.ActivationCode.AsNoTracking()
                .Select(h => h.ActivationCode)
                .Contains(code);
            return isExists;
        }

        private string GetRandomActivationCode()
        {
            string randomNumberFormat = "00000";
            int randomTextlength = 2;
            string randomText = "";
            for (var i = 0; i < randomTextlength; i++)
            {
                randomText += ((char)(RandomNumberGenerator.GetInt32(1, 26) + 64)).ToString().ToUpper();
            }
            int randomNumber = 0;
            randomNumber = RandomNumberGenerator.GetInt32(10000, 99999);
            randomText += randomNumber.ToString(randomNumberFormat);
            return randomText;
        }

    }
}
