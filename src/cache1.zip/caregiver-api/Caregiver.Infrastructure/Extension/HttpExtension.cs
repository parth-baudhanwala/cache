﻿using IdentityModel.Client;
using System.IdentityModel.Tokens.Jwt;
using System.Net;

namespace Caregiver.Infrastructure.Extension
{
    public static class HttpExtension
    {
        private static Dictionary<string, string> _tokenStore = new Dictionary<string, string>();
        private static Dictionary<string, DateTime> _tokenTime = new Dictionary<string, DateTime>();

        public static async Task<string> GetCredentials(ClientCredentialsTokenRequest tokenRequest)
        {
            if (string.IsNullOrEmpty(tokenRequest.Address)) tokenRequest.Address = string.Empty;
            UriBuilder tokenUrl = new UriBuilder(tokenRequest.Address);
            var client = new HttpClient();
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
            TokenResponse tokenResponse = await client.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest
            {
                Address = tokenUrl.Uri.ToString(),
                ClientId = tokenRequest.ClientId,
                ClientSecret = tokenRequest.ClientSecret,
                Scope = tokenRequest.Scope,
            }).ConfigureAwait(false);

            if (tokenResponse != null)
            {
                if (tokenResponse.IsError)
                {
                    System.Console.WriteLine(tokenResponse.Error);
                    return string.Empty;
                }
                if (!string.IsNullOrEmpty(tokenResponse.AccessToken))
                {
                    return tokenResponse.AccessToken;
                }
            }
            return string.Empty;
        }

        public static Task<bool> ValidateTokenExpiry(string token)
        {
            if (string.IsNullOrEmpty(token))
                return Task.FromResult(true);

            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            JwtSecurityToken jwt = tokenHandler.ReadJwtToken(token);
            DateTimeOffset currentOffset = new DateTimeOffset(DateTime.UtcNow.Ticks, TimeSpan.Zero);
            DateTimeOffset validFrom = new DateTimeOffset(jwt.ValidFrom.Ticks, TimeSpan.Zero);
            DateTimeOffset validTo = new DateTimeOffset(jwt.ValidTo.Ticks, TimeSpan.Zero);

            if (validFrom > currentOffset)
            {
                System.Threading.Thread.Sleep(1000);
            }

            if (currentOffset >= validTo)
            {
                return Task.FromResult(true);
            }

            return Task.FromResult(false);
        }
    }
}
