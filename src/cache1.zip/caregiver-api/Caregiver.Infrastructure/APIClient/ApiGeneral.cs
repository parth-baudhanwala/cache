﻿using Caregiver.Infrastructure.Cache;
using Caregiver.Infrastructure.Extension;
using IdentityModel.Client;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Headers;
using System.Text;

namespace Caregiver.Infrastructure.APIClient
{
    public class ApiGeneral
    {
        private readonly IConfiguration _configuration;
        private readonly IRedisConnectionService _redisConnectionService;

        public ApiGeneral(IConfiguration configuration, IRedisConnectionService redisConnectionService)
        {
            _configuration = configuration;
            _redisConnectionService = redisConnectionService;
        }

        public async Task<string> GetTokenForENTAPI()
        {
            string token, keyName = _configuration["Token:ENTAPPApiKeyName"];

            ClientCredentialsTokenRequest tokenRequest = new ClientCredentialsTokenRequest
            {
                Address = _configuration["Identity:TokenUrl"],
                ClientId = _configuration["OAuthDetails:ClientId"],
                ClientSecret = _configuration["OAuthDetails:ClientSecret"],
                Scope = _configuration["OAuthDetails:Scope"]
            };

            if (_redisConnectionService.IsRedisCacheEnabled)
            {
                string identityTokenRedisKeyFeature = _configuration["UserAuth:IdentityTokenRedisKeyFeature"];
                string hashField = identityTokenRedisKeyFeature;
                int tokenExpiryInMinute = Convert.ToInt32(_configuration["Token:ExpiryInMinute"]);

                token = await _redisConnectionService.GetRedisCacheDataByHashID(keyName, hashField);

                if (string.IsNullOrEmpty(token))
                {
                    token = await HttpExtension.GetCredentials(tokenRequest).ConfigureAwait(false);
                    await _redisConnectionService.SaveRedisCacheDataByHashID(keyName, hashField, token, tokenExpiryInMinute);
                }

                bool isTokenExpired = await HttpExtension.ValidateTokenExpiry(token).ConfigureAwait(false);
                if (isTokenExpired)
                {
                    token = await HttpExtension.GetCredentials(tokenRequest).ConfigureAwait(false);
                    await _redisConnectionService.SaveRedisCacheDataByHashID(keyName, hashField, token, tokenExpiryInMinute);
                }
            }
            else
            {
                token = await HttpExtension.GetCredentials(tokenRequest).ConfigureAwait(false);
            }
            return token;
        }

        public async Task<HttpResponseMessage> GetResultFromENTAPI(string requestParams, string methodName, string baseUrl, string httpMethod = "POST")
        {
            HttpMethod httpVerb = new HttpMethod(httpMethod);
            var token = await GetTokenForENTAPI().ConfigureAwait(false);
            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var request = new HttpRequestMessage
            {
                Method = httpVerb,
                RequestUri = new Uri(baseUrl + methodName),
            };

            if (httpVerb != HttpMethod.Get)
            {
                request.Content = new StringContent(requestParams, Encoding.UTF8, "application/json");
            }
            HttpResponseMessage response = await client.SendAsync(request).ConfigureAwait(false);
            return response;
        }
    }
}
