﻿using Caregiver.Core.Interfaces;
using Caregiver.Core.Models.Caregiver;
using Caregiver.Infrastructure.DBEntity;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace Caregiver.Infrastructure.Contexts
{
    public class HhaDbContext : DbContext, IDbContext
    {
        public const string DefaultSchema = "dbo";

        public HhaDbContext(DbContextOptions<HhaDbContext> options)
            : base(options)
        {
        }

        public DbContext Context => this;
        public DbSet<UserAgencyLinkingDetails> UserAgencyLinkingDetail { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            List<Type> typesToRegister = Assembly.GetExecutingAssembly().GetTypes()
                         .Where(t => t.GetInterfaces().Any(gi => gi.IsGenericType && gi.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>))).ToList();

            foreach (Type type in typesToRegister)
            {
                dynamic? configurationInstance = Activator.CreateInstance(type);
                modelBuilder.ApplyConfiguration(configurationInstance);
            }
        }
    }
}