﻿
using Caregiver.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace Caregiver.Infrastructure.Contexts
{
    public class HhaReadDbContext : DbContext, IDbContext
    {
        public HhaReadDbContext(DbContextOptions<HhaReadDbContext> options)
        : base(options)
        {
        }

        public DbContext Context => this;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}
