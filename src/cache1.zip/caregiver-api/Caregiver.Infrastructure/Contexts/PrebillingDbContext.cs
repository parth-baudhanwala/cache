﻿
using Caregiver.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace Caregiver.Infrastructure.Contexts
{
    public class PrebillingDbContext : DbContext, IDbContext
    {
        public PrebillingDbContext(DbContextOptions<PrebillingDbContext> options)
        : base(options)
        {
        }

        public DbContext Context => this;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}
