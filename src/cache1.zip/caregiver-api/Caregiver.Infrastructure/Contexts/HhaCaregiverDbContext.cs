﻿using Caregiver.Infrastructure.DBEntity;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace Caregiver.Infrastructure.Contexts
{
    public class HhaCaregiverDbContext : DbContext
    {

        public HhaCaregiverDbContext(DbContextOptions<HhaCaregiverDbContext> options) : base(options) { }

        public DbSet<ActivationCodes> ActivationCode { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            List<Type> typesToRegister = Assembly.GetExecutingAssembly().GetTypes()
                         .Where(t => t.GetInterfaces().Any(gi => gi.IsGenericType && gi.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>))).ToList();

            foreach (Type type in typesToRegister)
            {
                dynamic? configurationInstance = Activator.CreateInstance(type);
                modelBuilder.ApplyConfiguration(configurationInstance);
            }
        }
    }
}