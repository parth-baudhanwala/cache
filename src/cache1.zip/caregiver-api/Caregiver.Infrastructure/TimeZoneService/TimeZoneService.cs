﻿using Caregiver.Domain.DomainTransferObjects;
using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.TimeZone;
using Caregiver.Infrastructure.APIClient;
using Caregiver.Infrastructure.Cache;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Caregiver.Infrastructure
{
    /// <summary>
    /// TimeZone Service.
    /// </summary>
    public class TimeZoneService : ITimeZoneService
    {
        private readonly IConfiguration _configuration;
        private readonly IRedisConnectionService _redisConnectionService;
        /// <summary>
        /// Constructor for TimeZone Service.
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="redisConnectionService"></param>

        public TimeZoneService(IConfiguration configuration, IRedisConnectionService redisConnectionService)
        {
            _configuration = configuration;
            _redisConnectionService = redisConnectionService;
        }

        /// <summary>
        /// Used to Get Office TimeZone.
        /// </summary>
        /// <param name="officeIDs"></param>
        /// <param name="entpApiUrl"></param>
        public List<TimeZoneResponse> GetOfficeTimeZone(List<int> officeIDs, string entpApiUrl)
        {
            List<TimeZoneResponse> timeZoneResponseList = new();
            List<TimeZoneResponse> timeZoneResponseListFinal = new();
            TimeZoneResponse timeZoneResponse;
            List<int> officeIDsForApiCall = new();

            if (_redisConnectionService.IsRedisCacheEnabled)
            {
                string uniqueKey;
                string timeZoneHashKey = _configuration.GetValue<string>("TimeZone:TimeZoneHashKey");
                string timeZoneRedisKeyFeature = _configuration.GetValue<string>("TimeZone:TimeZoneRedisKeyFeature");
                int timeZoneRedisKeyExpiryInSeconds = _configuration.GetValue<int>("TimeZone:TimeZoneRedisKeyExpiryInSeconds");

                foreach (int officeID in officeIDs)
                {
                    uniqueKey = timeZoneRedisKeyFeature;
                    timeZoneResponse = new TimeZoneResponse
                    {
                        OfficeID = officeID
                    };

                    if (!string.IsNullOrEmpty(uniqueKey))
                    {
                        uniqueKey = uniqueKey.Replace("{officeid}", officeID.ToString());
                    }

                    if (_redisConnectionService.IsRedisHashCacheExists(timeZoneHashKey, uniqueKey))
                    {
                        string cacheResult = _redisConnectionService.GetRedisCacheDataByHashID(timeZoneHashKey, uniqueKey).Result;

                        if (string.IsNullOrEmpty(cacheResult))
                        {
                            officeIDsForApiCall.Add(officeID);
                        }
                        else
                        {
                            timeZoneResponse.TimeZone = JsonConvert.DeserializeObject<string>(cacheResult);
                        }
                    }
                    else
                    {
                        officeIDsForApiCall.Add(officeID);
                    }

                    if (!string.IsNullOrEmpty(timeZoneResponse.TimeZone))
                    {
                        timeZoneResponseListFinal.Add(timeZoneResponse);
                    }
                }

                if (officeIDsForApiCall.Any())
                {
                    timeZoneResponseList = GetOfficeTimeZoneFromAPI(officeIDsForApiCall, entpApiUrl);
                    foreach (var item in timeZoneResponseList)
                    {
                        uniqueKey = timeZoneRedisKeyFeature;

                        if (!string.IsNullOrEmpty(uniqueKey))
                        {
                            uniqueKey = uniqueKey.Replace("{officeid}", item.OfficeID.ToString());
                        }

                        string cacheValue = JsonConvert.SerializeObject(item.TimeZone);

                        _redisConnectionService.SaveRedisCacheDataByHashID(timeZoneHashKey, uniqueKey, cacheValue, timeZoneRedisKeyExpiryInSeconds);
                    }
                }
            }
            else
            {
                timeZoneResponseList = GetOfficeTimeZoneFromAPI(officeIDs, entpApiUrl);
            }

            timeZoneResponseListFinal.AddRange(timeZoneResponseList);

            return timeZoneResponseListFinal;
        }

        private List<TimeZoneResponse> GetOfficeTimeZoneFromAPI(List<int> officeIDList, string entpApiUrl)
        {
            GetTimeZoneByOfficeIDCommand officeIDCommand = new()
            {
                OfficeIDs = new List<TimeZoneByOfficeIDRequest>()
            };
            TimeZoneByOfficeIDRequest officeIDObj;

            foreach (int officeID in officeIDList)
            {
                officeIDObj = new TimeZoneByOfficeIDRequest
                {
                    OfficeID = officeID
                };
                officeIDCommand.OfficeIDs.Add(officeIDObj);
            }

            ApiGeneral apiGeneral = new(_configuration, _redisConnectionService);
            string requestParams = JsonConvert.SerializeObject(officeIDCommand);

            HttpResponseMessage webResponse = apiGeneral.GetResultFromENTAPI(requestParams, "Office/GetTimeZone", entpApiUrl).Result;

            List<TimeZoneResponse> timeZoneResponse = new();
            if (webResponse != null && webResponse.IsSuccessStatusCode)
            {
                string responseContent = webResponse.Content.ReadAsStringAsync().Result;
                ApiResponse<List<TimeZoneResponse>> apiResponse = JsonConvert.DeserializeObject<ApiResponse<List<TimeZoneResponse>>>(responseContent);

                if (apiResponse != null && apiResponse.Result != null)
                {
                    timeZoneResponse = apiResponse.Result;
                }
            }

            return timeZoneResponse;
        }
    }
}
