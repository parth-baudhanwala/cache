﻿using Caregiver.Domain.DomainTransferObjects.TimeZone;

namespace Caregiver.Infrastructure
{
    /// <summary>
    /// TimeZone Service Interface
    /// </summary>
    public interface ITimeZoneService
    {
        /// <summary>
        /// Get Office TimeZone Interface
        /// </summary>
        public List<TimeZoneResponse> GetOfficeTimeZone(List<int> officeIDs, string entpApiUrl);
    }
}
