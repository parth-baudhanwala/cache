﻿namespace Caregiver.Infrastructure.DBEntity
{
    public partial class ActivationCodes
    {
        public int CaregiverActivationCodesID { get; set; }
        public string ActivationCode { get; set; } = string.Empty;
        public Guid GlobalCaregiverID { get; set; }
        public string ProviderEnvironment { get; set; } = string.Empty;
        public DateTime ExpiryDate { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedUTCDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedUTCDate { get; set; }
    }
}
