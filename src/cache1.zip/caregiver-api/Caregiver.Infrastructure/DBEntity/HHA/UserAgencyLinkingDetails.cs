﻿namespace Caregiver.Core.Models.Caregiver
{
    public class UserAgencyLinkingDetails
    {

        public long CaregiverUserAgencyLinkingDetailsID { get; set; }
        public Guid GlobalCaregiverUserID { get; set; }
        public Guid GlobalProviderID { get; set; }
        public int ProviderID { get; set; }
        public Guid GlobalOfficeID { get; set; }
        public int OfficeID { get; set; }
        public Guid GlobalCaregiverID { get; set; }
        public int CaregiverID { get; set; }
        public string? IsAgencyLinked { get; set; }
        public DateTime LinkedUTCDate { get; set; }
        public DateTime? UnLinkedUTCDate { get; set; }
        public bool? InActiveBannerRead { get; set; }
        public string? IsPCIUser { get; set; }
        public string? ApplicationName { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedUTCDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedUTCDate { get; set; }
    }
}
