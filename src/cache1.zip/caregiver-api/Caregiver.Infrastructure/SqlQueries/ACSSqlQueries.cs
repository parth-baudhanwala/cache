﻿namespace Caregiver.Infrastructure.SqlQueries
{
    internal static class ACSSqlQueries
    {
        internal static readonly string GetPatientNumberByGlobalID = @"SELECT TOP 1 PatientNumber
                                                                      FROM [dbo].[TblPatientMaster] (NOLOCK)
                                                                      WHERE GlobalPatientID = @GlobalPatientID";

        internal static readonly string GetOfficeIDByGlobalID = @"SELECT TOP 1 OfficeID
                                                                      FROM [Office].[Offices] (NOLOCK)
                                                                      WHERE GlobalOfficeID = @GlobalOfficeID";

        internal static readonly string GetCaregiverCodeByGlobalID = @"SELECT TOP 1 AideCode
                                                                      FROM [dbo].[tblAideMaster] (NOLOCK)
                                                                      WHERE GlobalCaregiverID = @GlobalCaregiverID";

        internal static readonly string GetProviderVersionByGlobalID = @"SELECT ProviderVersion AS Version,
                                                                                ProviderMinorVersion AS MinorVersion
                                                                            FROM [dbo].[Vendors]  (NOLOCK)
                                                                            WHERE GlobalProviderID = @GlobalProviderID";
    }
}
