﻿namespace Caregiver.Infrastructure.SqlQueries
{
    public class CaregiverSqlQueries
    {
        #region Caregiver

        internal static readonly string GetCaregiverByGlobalCaregiverId = @"SELECT SSN,DateofBirth 
                                                                    FROM [dbo].[tblAideMaster] (NOLOCK)
                                                                    WHERE GlobalCaregiverID = @GlobalCaregiverId";

        internal static readonly string GetCaregiverAgencyDetailsByGlobalCaregiverId = @"SELECT am.GlobalCaregiverID,
																							am.AideID AS CaregiverID,
																							vm.VendorID AS ProviderId,
																							LTRIM(RTRIM(vm.EnvironmentCode)) AS ProviderEnvironment,
																							vm.GlobalProviderID,
																							vm.VendorName AS ProviderName,
																							am.FirstName,
																							am.LastName,
																							oo.OfficeID,
																							oo.OfficeName,
																							oo.GlobalOfficeID
																					FROM tblAidemaster (NOLOCK) am 
																						INNER JOIN Vendors (NOLOCK) vm on am.VendorID = vm.VendorID
																						INNER JOIN Office.Offices (NOLOCK) oo ON am.OfficeID = oo.OfficeID
																					WHERE am.GlobalCaregiverId=@GlobalCaregiverId";
        internal static readonly string GetIdByGlobalID = @"DECLARE @AideID int,@VendorID int,@OfficeID int
                                                            SELECT  
                                                            @AideID=AideID 
                                                            FROM [dbo].[tblAideMaster] (NOLOCK)
                                                            WHERE GlobalCaregiverID=@GlobalCaregiverID
                                                            
                                                            SELECT @VendorID=VendorID
                                                            From [dbo].[Vendors] (NOLOCK)
                                                            WHERE GlobalProviderID=@GlobalProviderID
                                                            
                                                            SELECT @OfficeID=OfficeID 
                                                            from [Office].[Offices] (NOLOCK)
                                                            WHERE GlobalOfficeID=@GlobalOfficeID
                                                            SELECT @AideID,@VendorID,@OfficeID";
        #endregion
    }
}
