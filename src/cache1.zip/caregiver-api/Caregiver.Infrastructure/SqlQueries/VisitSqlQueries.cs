﻿namespace Caregiver.Infrastructure.SqlQueries
{
    internal static class VisitSqlQueries
    {
        #region CallLink & Unlink Validations

        internal static readonly string GetCallLinkUnlinkValidation = @"SELECT  TOP 1 ISDATE(v.VisitEndTime) AS IsVisitEndTimeExists,
                                                                            ISDATE(v.VisitStartTime) AS IsVisitStartTimeExists,
                                                                            v.Billed AS IsBilled
		                                                                FROM [dbo].[TblVisits] v (NOLOCK)
                                                                        WHERE v.VisitID = @VisitID;
                                                                    
                                                                        SELECT  TOP 1 ch.Type AS CallType
		                                                                FROM [dbo].[TblCallHistory] ch (NOLOCK)
                                                                        WHERE ch.Type = @ChType 
                                                                           AND ch.VisitID = @VisitID
                                                                           AND ch.MaintenanceID = @MaintenanceID";

        internal static readonly string GetCallUnlinkTypeValidation = @"SELECT TOP 1 1
                                                                        FROM [dbo].[TblCallHistory] ch(NOLOCK)
                                                                        WHERE ch.VisitID = @VisitID
                                                                           AND ch.MaintenanceID = @MaintenanceID;
                                                                        
                                                                        SELECT TOP 1 1
                                                                        FROM [dbo].[TblVisits] v(NOLOCK)
                                                                        WHERE v.VisitID = @VisitID";

        internal static readonly string GetLockedVisitValidation = @"SELECT CASE WHEN ve.LockDate IS NOT NULL AND (CAST(ve.LockDate AS DATE) <= CAST(GETDATE() AS DATE)) THEN 1 ELSE 0 END AS IsVisitLocked
                                                                    FROM Visit.EVVDetail ve(NOLOCK)
                                                                    WHERE ve.VisitID = @VisitID";
        #endregion

        internal static readonly string GetMatchingCallsSPParamsByVisitID = @"SELECT tv.AideID AS AideID, 
                                                                                     tv.PatientID AS PatientID,
                                                                                     tv.VendorID AS VendorID,
                                                                                     tv.VisitDate AS VisitDate,
                                                                                     v.ProviderVersion AS Version,
                                                                                     v.ProviderMinorVersion AS MinorVersion
                                                                            FROM [dbo].[TblVisits] tv (NOLOCK)
                                                                            INNER JOIN [dbo].[Vendors] v (NOLOCK) ON tv.VendorID = v.VendorID 
                                                                            WHERE tv.VisitID = @VisitID";

        internal static readonly string GetVisitDetailsUsingVisitID = @"SELECT  pm.ComPatientName AS PatientName, 
                                                                                vp.OfficePatientCode AS PatientCode, 
                                                                                am.ComAideName AS CaregiverName, 
                                                                                am.OfficeAideCode AS CaregiverCode, 
                                                                                CASE 
					                                                                WHEN vi.IsSkilledVisit = 1 THEN 'Skilled'
					                                                                WHEN vi.IsSkilledVisit = 0 THEN 'Non Skilled'
				                                                                END AS VisitType, 
                                                                                v.ScheduledStartTime AS ScheduledStartTime, v.ScheduledEndTime AS ScheduledEndTime, 
                                                                                v.VisitStartTime AS VisitStartTime, v.VisitEndTime AS VisitEndTime,
                                                                                v.vContractChhaID AS VisitContractChhaID,
                                                                                ISNULL(o.EnableVisitMaintenanceWindow, 'No') AS EnableVisitMaintenanceWindow,
                                                                                ISNULL(cv.IsReasonRequired,0) AS IsReasonRequired,
                                                                                ISNULL(cv.ConfirmActionTaken,0) AS IsActionTakenRequired
                                                                       FROM [dbo].[TblVisits] v (NOLOCK)
                                                                       INNER JOIN [dbo].[TblAideMaster] am (NOLOCK) on v.AideID = am.AideID
                                                                       INNER JOIN [dbo].[TblPatientMaster] pm (NOLOCK) on v.PatientID = pm.PatientID
                                                                       INNER JOIN [dbo].[VisitInfo] vi (NOLOCK) on v.VisitID = vi.VisitID
                                                                       INNER JOIN [dbo].[VendorPatients] vp (NOLOCK) on v.PatientID = vp.PatientID AND vp.VendorID = v.VendorID
                                                                       INNER JOIN [Office].[Offices] AS o (NOLOCK) ON o.OfficeID = v.OfficeID
                                                                       LEFT JOIN dbo.ChhaVendors AS cv (NOLOCK) ON cv.ChhaId = v.vContractChhaID AND cv.VendorId = v.VendorID
                                                                       WHERE v.VisitID = @VisitID 
                                                                            AND vp.DELETED = 0";


        #region GlobalVisitIDs
        internal static readonly string GetVisitIDByGlobalVisitID = @"SELECT TOP 1 v.VisitID
                                                                      FROM [Visit].[EVVDetail] v (NOLOCK)
                                                                      WHERE v.EVVMSID = @GlobalVisitId";

        internal static readonly string GetVisitMaintenanceIDByCallType = @"SELECT TOP 1 CH.VisitID, CH.MaintenanceID 
                                                                            FROM [dbo].[TblCallHistory] CH (NOLOCK) 
                                                                            INNER JOIN [Visit].[EVVDetail] VE (NOLOCK) ON CH.VisitID = VE.VisitID 
                                                                                AND CH.[Type] = @CallType 
                                                                                AND VE.EVVMSID = @GlobalVisitId";
        #endregion
    }
}
