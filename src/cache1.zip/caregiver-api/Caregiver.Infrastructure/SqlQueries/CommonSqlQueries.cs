﻿namespace Caregiver.Infrastructure.SqlQueries
{

    internal static class CommonSqlQueries
    {
        #region NewPrebillingAgency

        internal static readonly string GetAgenciesUsingNewPrebilling = @"SELECT v.VendorID, v.VendorName
                                                                          FROM [dbo].[Vendors] v (NOLOCK)
                                                                          WHERE v.AppVersionid = 4 
                                                                              AND v.NewPrebillingChanges = 'Yes' 
                                                                              AND v.VendorID = @VendorId";

        #endregion

        #region GetuserID

        internal static readonly string GetUserIDUsingVendorID = @"SELECT TOP 1 UserID
                                                                   FROM dbo.TblUserMaster (NOLOCK)
                                                                  WHERE ID = @ID 
                                                                       AND ISActive = 1  
                                                                       AND UserID > 0 
                                                                       AND UserMasterRole ='VENDOR'";
        #endregion

        #region Get Provider Version Details
        internal static readonly string VersionDetails = @"SELECT v.ProviderVersion, v.ProviderMinorVersion
                                                           FROM [dbo].[Vendors] v (NOLOCK)
                                                           WHERE v.VendorID = @VendorId";
        #endregion

        internal static readonly string GetCaregiverIDByGlobalCaregiverID = @"SELECT TOP 1 A.AideID
                                                                        FROM [dbo].TblAideMaster AS A WITH(NOLOCK) 
                                                                        WHERE A.GlobalCaregiverID = @GlobalCaregiverID";

        internal static readonly string GetPatientIDByGlobalPatientID = @"SELECT TOP 1 P.PatientID
                                                                        FROM dbo.TblPatientMaster AS P WITH(NOLOCK)
                                                                        WHERE P.GlobalPatientID = @GlobalPatientID";

        internal static readonly string FindMaintenanceIDFromCallMaintenance = @"SELECT TOP 1 C.MaintenanceID
                                                                        FROM dbo.CallMaintenance AS C WITH(NOLOCK)
                                                                        WHERE C.MaintenanceID = @MaintenanceID";
    }
}