﻿using Caregiver.Infrastructure.DBEntity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Caregiver.Infrastructure.DBEntityConfiguration
{
    internal class ActivationCodeEntityTypeConfiguration : IEntityTypeConfiguration<ActivationCodes>
    {
        public void Configure(EntityTypeBuilder<ActivationCodes> builder)
        {
            builder.ToTable("ActivationCodes", "Caregiver");
            builder.HasIndex(e => e.CaregiverActivationCodesID, "pk_CaregiverActivationCode");
            builder.HasKey(e => e.CaregiverActivationCodesID).HasName("CaregiverActivationCodesID");
        }
    }
}
