﻿using Caregiver.Core.Models.Caregiver;
using Caregiver.Infrastructure.DBEntity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Caregiver.Infrastructure.DBEntityConfiguration.HHA
{
    internal class UserAgencyLinkingDetailEntityTypeConfiguration : IEntityTypeConfiguration<UserAgencyLinkingDetails>
    {
        public void Configure(EntityTypeBuilder<UserAgencyLinkingDetails> builder)
        {
            builder.ToTable("UserAgencyLinkingDetails", "Caregiver");            
            builder.HasKey(e => e.CaregiverUserAgencyLinkingDetailsID).HasName("CaregiverUserAgencyLinkingDetailsID");
        }
    }
}
