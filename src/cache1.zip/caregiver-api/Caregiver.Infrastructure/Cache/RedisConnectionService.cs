﻿using Microsoft.Extensions.Configuration;
using StackExchange.Redis;
using System.Runtime.InteropServices;

namespace Caregiver.Infrastructure.Cache
{
    public class RedisConnectionService : IRedisConnectionService
    {
        private readonly Lazy<ConnectionMultiplexer> _redisLazyConnection;
        private readonly Lazy<IDatabase> _redisLazyDatabase;
        private readonly RedisCacheConfig _redisCacheConfig;

        private class RedisCacheConfig
        {
            internal bool IsRedisEnable { get; set; }
            internal bool IsCacheExpired { get; set; }
            internal int CacheExpirationDurationInMinute { get; set; }
            internal string? Endpoints { get; set; }
            internal string? UserPermissionKey { get; set; }
            internal string? ReportCaregiverList { get; set; }
        }

        public string GetRedisKeyByID(int userID, [Optional] string cacheKey)
        {
            if (cacheKey != null && cacheKey.Equals("CaregiverApiReportCaregivers"))
            {
                return $"{_redisCacheConfig.ReportCaregiverList}_{userID}";
            }
            else
            {
                return $"{_redisCacheConfig.UserPermissionKey}_{userID}";
            }
        }

        public RedisConnectionService(IConfiguration configuration)
        {
            var redisConfig = configuration.GetSection("RedisConfiguration");
            _redisCacheConfig = new RedisCacheConfig
            {
                IsRedisEnable = Convert.ToBoolean(redisConfig.GetValue<string>("RedisEnable")),
                IsCacheExpired = Convert.ToBoolean(redisConfig.GetValue<string>("CacheExpired")),
                CacheExpirationDurationInMinute = redisConfig.GetValue<int>("CacheExpirationDurationInMinute"),
                Endpoints = redisConfig.GetValue<string>("EndPoints"),
                UserPermissionKey = redisConfig.GetValue<string>("UserPermissionKey"),
                ReportCaregiverList = redisConfig.GetValue<string>("ReportCaregiverList")
            };
            _redisLazyConnection = new Lazy<ConnectionMultiplexer>(() => ConnectionMultiplexer.Connect(_redisCacheConfig.Endpoints));
            _redisLazyDatabase = new Lazy<IDatabase>(() => _redisLazyConnection.Value.GetDatabase());
        }

        public bool IsRedisCacheEnabled => _redisCacheConfig.IsRedisEnable;

        public bool IsRedisHashCacheExists(string key, string hashField)
        {
            return IsRedisCacheEnabled && _redisLazyDatabase.Value.HashExists(key, hashField);
        }

        public async Task<string> GetRedisCacheDataByHashID(string key, string hashField)
        {
            var result = await _redisLazyDatabase.Value.HashGetAsync(key, hashField);

            if (!result.IsNull && result.HasValue)
            {
                return result.ToString();
            }
            return default;
        }

        public async Task SaveRedisCacheDataByHashID(string key, string hashField, string value, int cacheExpirationDurationInMinute = 0)
        {
            await _redisLazyDatabase.Value.HashSetAsync(key, hashField, value);

            if (cacheExpirationDurationInMinute == 0)
            {
                cacheExpirationDurationInMinute = _redisCacheConfig.CacheExpirationDurationInMinute;
            }

            if (_redisCacheConfig.IsCacheExpired && cacheExpirationDurationInMinute > 0)
            {
                _redisLazyDatabase.Value.KeyExpire(key, TimeSpan.FromMinutes(cacheExpirationDurationInMinute));
            }
        }
    }
}
