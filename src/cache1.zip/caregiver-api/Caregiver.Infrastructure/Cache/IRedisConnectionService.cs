﻿using System.Runtime.InteropServices;

namespace Caregiver.Infrastructure.Cache
{
    public interface IRedisConnectionService
    {
        bool IsRedisHashCacheExists(string key, string hashField);
        string GetRedisKeyByID(int userID, [Optional] string cacheKey);
        Task<string> GetRedisCacheDataByHashID(string key, string hashField);
        Task SaveRedisCacheDataByHashID(string key, string hashField, string value, int cacheExpirationDurationInMinute = 0);
        bool IsRedisCacheEnabled { get; }
    }
}
