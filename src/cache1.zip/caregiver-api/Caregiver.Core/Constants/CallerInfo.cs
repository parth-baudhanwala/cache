﻿namespace Caregiver.Core.Constants
{
    public static class CallerInfo
    {
        public const string LinkCallCallerInfo = "Caregiver.API.LinkCall";
        public const string LinkUnlinkCallDetail = "LinkUnLink";
        public const string UnScheduledVisitLinkedCalls = "GetUnscheduledVisitLinkedCalls";
        public const string UpdateUnScheduledVisitToScheduledVisit = "UpdateUnScheduledVisitToScheduledVisit";
        public const string UpdateInterruptDetails = "UpdateInterruptDetails";
        public const string VisitScheduleDetailByVisitID = "GetVisitScheduleDetailByVisitID";
        public const string SaveVisitProcessLog = "SaveVisitProcessLog";
        public const string SaveVisitProcessLogDetails = "SaveVisitProcessLogDetails";
        public const string GenerateCallExceptions = "GenerateCallExceptions";
        public const string UnlinkCallCallerInfo = "Caregiver.API.UnlinkCall";
        public const string UpdateScheduledVisitAfterUnlinkCall = "UpdateScheduledVisitAfterUnlinkCall";
        public const string MoveCallsToCallMaintenanceUnconfirmedVisit = "MoveCallsToCallMaintenanceUnconfirmedVisit";
        public const string ShowMatchingCallsDetail = "Caregiver.API.ShowMatchingCallsDetailRepository";
        public const string GetUserPermissionDetail = "Caregiver.API.GetUserPermissionDetail";
        public const string RejectCalls = "RejectCall";
        public const string AppServerURLDetails = "GetAppServerURLDetails";
        public const string SaveReasonNotesForLinkUnlinkCall = "SaveReasonNotesForLinkUnlinkCall";
        public const string CreateACSInfo = "Call.API.CreateSchedulesFromCallMaintenance";
    }
}
