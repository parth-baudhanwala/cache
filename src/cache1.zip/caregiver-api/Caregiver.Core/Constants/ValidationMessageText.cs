﻿namespace Caregiver.Core.Constants
{
    public static class ValidationMessageText
    {
        public const string CallLinkBilledVisitValidationTextMsg = "You cannot link this visit because it has already been billed.";
        public const string CallLinkVisitStartTimeValidationTextMsg = "This visit cannot be linked, because visit Start Time is not set for this visit. You are not able to performed call Out.";
        public const string CallLinkSuccessValidationTextMsg = "Call linked successfully!";
        public const string CallUnlinkBilledVisitValidationTextMsg = "You cannot unlink this visit because it has already been billed.";
        public const string VisitEndTimeValidationTextMsg = "This visit Start Time cannot be unlinked, as a visit End Time is already logged for the visit. To remove the visit Start Time, you must first remove the visit End Time.";
        public const string CallUnlinkVisitStartTimeValidationTextMsg = "This visit cannot be unlinked, because visit Start Time is not set for this visit. You are not able to performed call In or call Out.";
        public const string CallUnLinkLockedVisitValidationTextMsg = "This visit is locked. You may not remove EVV.";
        public const string CallUnLinkSuccessValidationTextMsg = "Call unlinked successfully!";
        public const string VisitNotFoundTextMsg = "Visit not found.";
        public const string VisitNotManuallyLinkedTextMsg = "This visit cannot be unlinked, because it's not manually linked.";
        public const string RejectCallSuccessTextMsg = "Call rejected successfully.";
        public const string RejectCallFailTextMsg = "Provided call does not exist.";
        public const string CallLinkConfirmedVisitValidationTextMsg = "This visit cannot be linked, because it's already confirmed.";
        public const string CallLinkLockedValidateTextMsg = "This visit cannot be linked, because it's locked.";
        public const string CallUnlinkLockedValidateTextMsg = "This visit cannot be unlinked, because it's locked.";
        public const string CallUnlinkTypeValidateTextMsg = "The maintenanceID does not matched with visit.";
        public const string CallLinkMaintenanceIDValidateTextMsg = "The maintenanceID does not matched with matching calls.";
        public const string RemoveConfirmedTimeValidationMsg = "Visit Start and End Date/Time values cannot be removed for a visit that has Accepted status on the EVV Aggregation Transaction Manager.";
        public const string LinkMobileUserSSNValidationMsg = "SSN does not matched.";
        public const string LinkMobileUserDOBValidationMsg = "DOB does not matched.";
        public const string LinkMobileUserSSNDOBValidationMsg = "SSN and DOB does not matched.";
        public const string LinkMobileUserSuccessMsg = "Mobile user linked successfully.";
        public const string ActivationCodeGenerationSuccessMsg = "Activation Code Generated successfully.";
        public const string LinkUserAgencySuccessMsg = "Agency user linked successfully.";
        public const string UnlinkUserAgencySuccessMsg = "Agency user unlinked successfully.";
        public const string ActivationCodeNotValidMsg = "Activation Code is not valid.";
        public const string ProviderEnvironmentEmptyMsg = "Provider environment is empty.";
        public const string CaregiverAgencyDetailNotFoundMsg = "Caregiver agency detail is not found.";
        public const string CommonNoResultMsg = "There is some issue while fetch result.";
        public const string TransactionIDNotFoundMsg = "Transaction ID in request header is missing or not in proper format.";
    }
}
