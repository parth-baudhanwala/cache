﻿namespace Caregiver.Core.Constants
{
    public static class SPNames
    {
        public const string CheckAccess = "Caregiver.API.CheckAccess";
        public const string GetUserInfoBySessionID = "Caregiver.GetUserInfoBySessionID";
        public const string GetVersionInfoByUserID = "Caregiver.API.GetVersionInfoByUserID";
        public const string GetUrlFromAppServers = "Caregiver.API.GetUrlFromAppServers";
        public const string GetAllOffices = "Caregiver.API.GetAllOffices";
        public const string GetKeywordByVendorId = "Caregiver.API.GetKeywordByVendorId";

        public const string LinkCall = "Caregiver.API.LinkCall";
        public const string LinkUnlinkCallDetail = "Caregiver.API.LinkUnlinkCallDetail";
        public const string UnScheduledVisitLinkedCalls = "Caregiver.API.UnScheduledVisitLinkedCalls";
        public const string UpdateUnscheduledVisitToScheduledVisit = "Caregiver.API.UpdateUnscheduledVisitToScheduledVisit";
        public const string UpdateInterruptDetails = "Caregiver.API.UpdateInterruptDetails";
        public const string VisitScheduleDetailByVisitID = "Caregiver.API.VisitScheduleDetailByVisitID";
        public const string SaveVisitProcessLog = "Caregiver.API.SaveVisitProcessLog";
        public const string SaveVisitProcessLogDetails = "Caregiver.API.SaveVisitProcessLogDetails";
        public const string UnlinkCall = "Caregiver.API.UnlinkCall";
        public const string UpdateScheduledVisitAfterUnlinkCall = "Caregiver.API.UpdateScheduledVisitAfterUnlinkCall";
        public const string MoveCallsToCallMaintenanceUnconfirmedVisit = "Caregiver.API.MoveCallsToCallMaintenanceUnconfirmedVisit";
        public const string ShowMatchingCallsDetail = "Caregiver.API.ShowMatchingCallsDetail";
        public const string GetGlobalLinkableVisits = "Caregiver.API.GetGlobalLinkableVisits";
        public const string RejectCall = "Caregiver.API.RejectCall";
        public const string BroadcastHistory = "Caregiver.API.BroadcastHistory";
        public const string BroadcastHistoryDetailByID = "Caregiver.API.BroadcastHistoryDetailByID";
        public const string BroadcastHistoryCancelByID = "Caregiver.API.BroadcastHistoryCancelByID";

        public const string GetEditVisitReasons = "Caregiver.API.GetEditVisitReasons";
        public const string GetActionTakenReasonsByReasonID = "Caregiver.API.GetActionTakenReasonsByReasonID";
        public const string SaveReasonNotesForLinkUnlinkCall = "Caregiver.API.SaveReasonNotesForLinkUnlinkCall";
        public const string GetCallMaintenanceWithNoSchedule = "Call.API.GetCallMaintenanceWithNoSchedule";
        public const string CreateSchedulesFromCallMaintenance = "Call.API.CreateSchedulesFromCallMaintenance";

        public const string CaregiverRegisterMobileUser = "Caregiver.API.RegisterMobileUser";
    }
}
