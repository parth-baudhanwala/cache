﻿namespace Caregiver.Core.Constants
{
    public static class ExternalApiNames
    {
        public const string GenerateCallExceptions = "api/VisitVerification/GenerateCallExceptions";
        public const string AppVisitChangeProcessVisitChange = "api/AppVisitChange/ProcessVisitChange";
        public const string VisitChangeProcessVisitChange = "api/VisitChange/ProcessVisitChange";
        public const string CaregiverAgencyDetails = "api/v1/caregivers/globalcaregiverid/caregiveragencydetails";
    }
}
