﻿using System.Net;

namespace Caregiver.Core.Common
{
    public class WebClientExtended : WebClient
    {
        private int _Timeout;
        public int Timeout
        {
            get
            {
                return _Timeout;
            }
            set
            {
                _Timeout = value;
            }
        }
        protected override WebRequest GetWebRequest(Uri address)
        {
            var request = base.GetWebRequest(address);
            request.Timeout = Timeout;
            return request;
        }
    }
}
