﻿namespace Caregiver.Core.Common
{
    public class CommonFilterModel
    {
        public int ID { get; set; }
        public string? Text { get; set; }
    }
}
