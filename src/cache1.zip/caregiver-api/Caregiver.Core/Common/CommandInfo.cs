﻿namespace Caregiver.Core.Common
{
    public class CommandInfo
    {
        public string? SPName { get; set; }
        public int Timeout { get; set; }
        public string? ConnectionStrings { get; set; }
    }
}
