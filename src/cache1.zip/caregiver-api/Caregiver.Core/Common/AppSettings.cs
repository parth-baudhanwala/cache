﻿using Microsoft.Extensions.Configuration;

namespace Caregiver.Core.Common
{
    public static class AppSettings
    {
        public static IConfiguration? Configuration { get; set; }

        public const string IdentityTokenUrl = "Identity:TokenUrl";
        public const string CaregiverAppApiCaregiverAPIURL = "CaregiverAppApi:CaregiverAPIURL";
        public const string CaregiverAppApiClientId = "CaregiverAppApi:ClientId";
        public const string CaregiverAppApiClientSecret = "CaregiverAppApi:ClientSecret";
        public const string CaregiverAppApiScope = "CaregiverAppApi:Scope";
    }
}
