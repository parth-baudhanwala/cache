﻿namespace Caregiver.Core.Common
{
    public static class DataAccess
    {
        public static CommandInfo GetCommandDetails(string key)
        {
            var objCommandInfo = new CommandInfo
            {
                SPName = AppSettings.Configuration["StoredProcedures:" + key + ":Mappings:SPName"],
                Timeout = Convert.ToInt32(AppSettings.Configuration["StoredProcedures:" + key + ":Mappings:Timeout"]),
                ConnectionStrings = AppSettings.Configuration["ConnectionStrings:" + AppSettings.Configuration["StoredProcedures:" + key + ":Mappings:ConnectionStrings"] + ""]
            };
            return objCommandInfo;
        }
    }
}
