﻿using Ardalis.GuardClauses;
using Caregiver.Core.Interfaces;
using Caregiver.Core.Models;

namespace Caregiver.Core.Services
{
    public class StoredProcedureFinder : IStoredProcedureFinder
    {
        private readonly StoredProceduresMetadata _storedProceduresMetadata;

        public StoredProcedureFinder(StoredProceduresMetadata storedProceduresMetadata)
        {
            _storedProceduresMetadata = storedProceduresMetadata;
        }

        public StoredProcedure GetStoredProcedure(string key)
        {
            var storedProcedure = _storedProceduresMetadata.StoredProcedures.SingleOrDefault(x => x.Key == key);
            Guard.Against.Null(storedProcedure);
            return storedProcedure;
        }
    }
}
