﻿using Caregiver.Core.Common;
using System.Data;
using System.Reflection;

namespace Caregiver.Core.Extensions
{
    /// <summary>
    /// List Extensions Class
    /// </summary>
    public static class ListExtensions
    {
        public static DataTable? StringListToDataTable(IEnumerable<string> values)
        {
            DataTable dt = new();
            dt.Columns.Add("ID", typeof(long));
            dt.Columns.Add("Text", typeof(string));

            if (values == null)
            {
                return null;
            }

            foreach (string value in values)
            {
                dt.Rows.Add(0, value);
            }

            return dt;
        }
        public static DataTable ToDataTable<T>(this List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in Props)
            {
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                dataTable.Columns.Add(prop.Name, type);
            }

            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }
        public static DataTable ConvertListToDataTable(string val)
        {
            CommonFilterModel commonFilterModel;
            List<CommonFilterModel> lstCommonFilter = new List<CommonFilterModel>();
            List<string> lstString;
            DataTable dtCommon = new();

            if (string.IsNullOrEmpty(val) || val.ToLower() == "null" || (val == "-1"))
            {
                return dtCommon;
            }

            lstString = val.Split(',').ToList();

            if (lstString != null && lstString.Count > 0)
            {
                foreach (string value in lstString)
                {
                    commonFilterModel = new CommonFilterModel
                    {
                        ID = Convert.ToInt32(value),
                        Text = ""
                    };
                    lstCommonFilter.Add(commonFilterModel);
                }
            }

            dtCommon = lstCommonFilter.ToDataTable();
            return dtCommon;
        }
        public static DataTable CreateDataTable(IEnumerable<int> ids)
        {
            DataTable table = new();
            table.Columns.Add("ID", typeof(long));
            table.Columns.Add("Text", typeof(string));
            if (ids == null)
            {
                return table;
            }
            foreach (int id in ids)
            {
                table.Rows.Add(id, "");
            }
            return table;
        }
    }
}
