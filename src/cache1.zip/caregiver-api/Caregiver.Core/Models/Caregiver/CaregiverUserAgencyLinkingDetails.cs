﻿namespace Caregiver.Core.Models.Caregiver
{
    public class CaregiverUserAgencyLinkingDetails
    {
        public long CaregiverUserAgencyLinkingDetailsID { get; set; }
        public int ProviderID { get; set; }
        public int OfficeID { get; set; }
        public int CaregiverID { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }

    }
}
