﻿namespace Caregiver.Core.Models.Caregiver
{
    public class CaregiverUserProfileInformation
    {
        public long CaregiverUserProfileInformationID { get; set; }
        public long CaregiverUserAgencyLinkingDetailsID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string SSNPartial { get; set; }
        public DateOnly? DateOfBirth { get; set; }
    }
}
