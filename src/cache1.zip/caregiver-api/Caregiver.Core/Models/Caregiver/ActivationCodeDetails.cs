﻿
namespace Caregiver.Core.Models.Caregiver
{
    public class ActivationCodeDetails
    {
        public string ActivationCode { get; set; }
    }
}
