﻿
namespace Caregiver.Core.Models.Caregiver
{
    public class AideMaster
    {
        public string Ssn { get; set; }
        public DateTime DateofBirth { get; set; }
    }
}
