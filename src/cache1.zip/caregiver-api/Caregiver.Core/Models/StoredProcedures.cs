﻿namespace Caregiver.Core.Models
{
    public class StoredProcedure
    {
        public string? Key { get; set; }
        public string? Name { get; set; }
        public int? Timeout { get; set; }
        public string? Database { get; set; }

    }

    public class StoredProceduresMetadata
    {
        public StoredProcedure[]? StoredProcedures { get; set; }
    }
}
