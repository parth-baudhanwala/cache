﻿namespace Caregiver.Core.Models
{
    public class ValidationMessage
    {
        public bool IsValid { get; set; }
        public string? MessageText { get; set; }
    }
}
