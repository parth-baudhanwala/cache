﻿using Caregiver.Domain.DomainTransferObjects.TimeZone;
using Microsoft.Extensions.Configuration;


namespace Caregiver.Core.TimeZone
{
    public static class TimeZoneModule
    {
        private static readonly string defaultTimeZone = "EST";

        public static DateTime ConvertSourceToDestinationTimeByTimeZone(this DateTime sourceTime, string sourceTimeZone, string destinationTimeZone, IConfiguration configuration)
        {
            if (string.IsNullOrEmpty(sourceTimeZone))
                sourceTimeZone = defaultTimeZone;

            if (string.IsNullOrEmpty(destinationTimeZone))
                destinationTimeZone = defaultTimeZone;

            List<TimeZoneMaster> timeZoneMasterList = configuration.GetSection("TimeZoneMaster").Get<List<TimeZoneMaster>>();

            TimeZoneMaster sourceInstance = timeZoneMasterList.Find(c => c.TimeZoneName == sourceTimeZone);

            if (sourceInstance == null)
                throw new ArgumentException("Invalid source timezone instance, Passed source TimeZone Not found in TimezoneData.json sourceTimeZone: " + sourceTimeZone);

            TimeZoneMaster destinationInstance = timeZoneMasterList.Find(c => c.TimeZoneName == destinationTimeZone);

            if (destinationInstance == null)
                throw new ArgumentException("Invalid destination timezone instance, Passed destination TimeZone Not found in TimezoneData.json destinationTimeZone: " + destinationTimeZone);

            DateTime destDateTime = sourceTime.AddMinutes(sourceInstance.OffSetMinutes - destinationInstance.OffSetMinutes);

            if (string.IsNullOrEmpty(sourceInstance.TimeZoneStandardName)) sourceInstance.TimeZoneStandardName = string.Empty;

            if (TimeZoneInfo.FindSystemTimeZoneById(sourceInstance.TimeZoneStandardName).IsDaylightSavingTime(sourceTime))
                destDateTime = destDateTime.AddMinutes(destinationInstance.DSTOffSetMinitues);

            return destDateTime;
        }
    }
}
