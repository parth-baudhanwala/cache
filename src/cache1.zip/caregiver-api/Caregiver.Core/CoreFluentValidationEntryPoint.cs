﻿namespace Caregiver.Core
{
    public class CoreFluentValidationEntryPoint
    {
    }
}
