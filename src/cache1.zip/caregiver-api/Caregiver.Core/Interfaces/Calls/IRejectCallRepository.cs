﻿using Caregiver.Domain.DomainTransferObjects.Calls;

namespace Caregiver.Core.Interfaces.Calls
{
    public interface IRejectCallRepository
    {
        /// <summary>
        /// Reject Call Interface
        /// </summary>
        Task<RejectCallResponse> RejectCall(RejectCallRequest request);
    }
}
