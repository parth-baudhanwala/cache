﻿using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.Calls
{
    public interface ICallExceptionsRepository
    {
        Task GenerateCallExceptions(VisitExceptionRequest visitExceptionRequest, DefaultParam defaultParam);
    }
}
