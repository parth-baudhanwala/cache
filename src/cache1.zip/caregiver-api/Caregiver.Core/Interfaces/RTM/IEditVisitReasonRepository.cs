﻿using Caregiver.Domain.DomainTransferObjects.RTM;

namespace Caregiver.Core.Interfaces.RTM
{
    public interface IEditVisitReasonRepository
    {
        Task<List<EditVisitReasonResponse>> GetEditVisitReasons(EditVisitReasonRequest request);
    }
}
