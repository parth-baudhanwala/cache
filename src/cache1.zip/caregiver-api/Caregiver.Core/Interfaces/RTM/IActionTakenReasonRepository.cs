﻿using Caregiver.Domain.DomainTransferObjects.RTM;

namespace Caregiver.Core.Interfaces.RTM
{
    public interface IActionTakenReasonRepository
    {
        Task<List<ActionTakenReasonResponse>> GetActionTakenReasonsByReasonID(ActionTakenReasonRequest request);
    }
}
