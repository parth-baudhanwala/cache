﻿using Caregiver.Domain.DomainTransferObjects.GlobalVisit;

namespace Caregiver.Core.Interfaces.GlobalVisit
{
    public interface ICreateACSScheduleRepository
    {
        Task<List<CreateACSScheduleResponse>> CreateACSSchedule(CreateACSScheduleRequest request);
    }
}
