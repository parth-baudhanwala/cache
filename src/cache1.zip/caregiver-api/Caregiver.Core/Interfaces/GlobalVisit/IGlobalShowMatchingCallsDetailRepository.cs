﻿using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.GlobalVisit
{
    /// <summary>
    /// Global Show Matching Calls Details Interface
    /// </summary>
    public interface IGlobalShowMatchingCallsDetailRepository
    {
        Task<List<MatchingCallsDetailResponse>> ShowMatchingCalls(GlobalMatchingCallsDetailRequest matchingCallsDetailRequest);

    }
}
