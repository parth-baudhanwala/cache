﻿using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.GlobalVisit
{
    /// <summary>
    /// Global Unlink Call Interface
    /// </summary>
    public interface IGlobalUnlinkCallRepository
    {
        Task<UnlinkCallResponse> UnLinkCall(GlobalUnlinkCallRequest request);
    }
}
