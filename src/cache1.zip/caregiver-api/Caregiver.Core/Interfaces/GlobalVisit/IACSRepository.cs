﻿using Caregiver.Domain.DomainTransferObjects.GlobalVisit;
using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.GlobalVisit
{
    public interface IACSRepository
    {
        Task<List<ACSDetailResponse>> GetACSData(ACSDetailRequest matchingACSDetailRequest);
    }
}
