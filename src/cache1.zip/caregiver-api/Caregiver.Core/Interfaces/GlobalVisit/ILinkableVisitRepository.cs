﻿using Caregiver.Domain.DomainTransferObjects.GlobalVisit;

namespace Caregiver.Core.Interfaces.GlobalVisit
{
    /// <summary>
    /// Linkable Visit Interface
    /// </summary>
    public interface ILinkableVisitRepository
    {
        Task<List<LinkableVisitResponse>> LinkableVisits(LinkableVisitRequest request);
    }
}
