﻿using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.GlobalVisit
{
    /// <summary>
    /// Global Link Call Interface
    /// </summary>
    public interface IGlobalLinkCallRepository
    {
        Task<LinkCallResponse> LinkCall(GlobalLinkCallRequest request);
    }
}
