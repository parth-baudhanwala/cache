﻿using Caregiver.Core.Models;

namespace Caregiver.Core.Interfaces
{
    public interface IStoredProcedureFinder
    {
        StoredProcedure GetStoredProcedure(string key);
    }
}
