﻿using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.DapperResponses;

namespace Caregiver.Core.Interfaces.Common
{
    public interface ICommonRepository
    {
        public Task<NewPrebillingAgency> GetAgenciesUsingNewPrebilling(int vendorID);
        public int VisitAPIWebRequestTimeoutinMS();
        public Task<VersionDetailsResponse> VersionDetails(int vendorID);
        public Task<List<UserPermissionResponse>> GetUserPermissionDetail(UserPermissionRequest requestParams);
        public Task<string> GetAppServerURLDetails(int providerId, int appVersionId, DefaultParam requestParams);
        public Task<List<OfficesResponse>> Offices(OfficesRequest request);
        public Task<List<CommonDetailsResponse>> CommonDetails(CommonDetailsRequest request);
    }
}
