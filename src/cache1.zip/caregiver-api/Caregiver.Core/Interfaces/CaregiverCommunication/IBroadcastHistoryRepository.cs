﻿using Caregiver.Domain.DomainTransferObjects.BroadcastHistory;
using Caregiver.Domain.DomainTransferObjects.TimeZone;

namespace Caregiver.Core.Interfaces.BroadcastHistory
{
    /// <summary>
    /// Caregiver Communication Interface
    /// </summary>
    public interface IBroadcastHistoryRepository
    {
        Task<List<BroadcastHistoryResponse>> BroadcastHistory(BroadcastHistoryRequest request, List<TimeZoneResponse> timeZoneResponses);
        Task<List<BroadcastHistoryDetailsResponse>> BroadcastHistoryDetailsByID(BroadcastHistoryDetailsRequest request, List<TimeZoneResponse> timeZoneResponses);
        Task<long> BroadcastHistoryCancelByID(BroadcastHistoryCancelRequest request);
    }
}
