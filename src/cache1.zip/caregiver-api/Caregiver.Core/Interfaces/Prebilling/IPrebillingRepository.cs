﻿using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.Prebilling;

namespace Caregiver.Core.Interfaces.Prebilling
{
    public interface IPrebillingRepository
    {
        Task CallVisitChangeApi(VisitChangeRequest visitChangeRequest, DefaultParam defaultParam, bool isPriority = true);

    }
}
