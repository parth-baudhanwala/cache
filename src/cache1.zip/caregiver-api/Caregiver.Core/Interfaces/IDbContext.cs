﻿using Microsoft.EntityFrameworkCore;

namespace Caregiver.Core.Interfaces
{
    public interface IDbContext
    {
        DbContext Context { get; }
    }
}
