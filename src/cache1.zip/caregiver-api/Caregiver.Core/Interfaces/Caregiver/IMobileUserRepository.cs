﻿using Caregiver.Domain.DomainTransferObjects.Caregiver;

namespace Caregiver.Core.Interfaces.Caregiver
{
    public interface IMobileUserRepository
    {
        Task<RegisterMobileUserResponse> RegisterMobileUser(RegisterMobileUserRequest request);

        Task<ActivationCodeGenerationResponse> ActivationCodeGeneration(ActivationCodeGenerationRequest request);
        Task<GetCaregiverAgencyDetailsResponse> GetCaregiverAgencyDetails(GetCaregiverAgencyDetailsRequest request);
        Task<UserAgencyLinkResponse> LinkUnlinkMobileUser(UserAgencyLinkRequest request);
    }
}
