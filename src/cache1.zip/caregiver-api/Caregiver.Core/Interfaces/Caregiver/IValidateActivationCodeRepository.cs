﻿using Caregiver.Domain.DomainTransferObjects.Caregiver;

namespace Caregiver.Core.Interfaces.Caregiver
{
    public interface IValidateActivationCodeRepository
    {
        Task<ValidateActivationCodeResponse> ValidateActivationCode(ValidateActivationCodeRequest request);
    }
}
