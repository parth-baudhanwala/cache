﻿using Caregiver.Domain.DomainTransferObjects.Common;

namespace Caregiver.Core.Interfaces.Helper
{
    public interface IWebApiHelper
    {
        Task<HttpResponseMessage> POST(string apiUrl, string jsonRequest);
        Task<HttpResponseMessage> GETOrPOSTWithGetTokenAsync(ApiServiceModel apiService);
    }
}
