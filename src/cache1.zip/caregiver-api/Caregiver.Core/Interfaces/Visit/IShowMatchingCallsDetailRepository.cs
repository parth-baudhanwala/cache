﻿using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.Visit
{
    public interface IShowMatchingCallsDetailRepository
    {
        Task<List<MatchingCallsDetailResponse>> ShowMatchingCalls(MatchingCallsDetailRequest request);
    }
}
