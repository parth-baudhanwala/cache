﻿using Caregiver.Domain.DomainTransferObjects.Common;
using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.Visit
{
    public interface ILinkUnlinkCallDetailRepository
    {
        Task<LinkUnlinkCallDetailResponse> GetDetailsForLinkUnlinkCall(LinkUnlinkCallDetailRequest request);
        Task UpdateUnscheduleToScheduleVisit(string visitXML, int userId, DefaultParam defaultParam);
        Task UpdateInterruptDetails(string callUniqueID, long visitId, int vendorId, string evvSource, string evvType, string linkUnlink, DefaultParam defaultParam);
        Task<VisitScheduleDetailResponse> VisitScheduleDetailByVisitID(int userId, long visitId);
        Task UpdateScheduledVisitAfterUnlinkCall(long visitId, DefaultParam defaultParam);
        Task SaveReasonNotesForLinkUnlinkCall(DefaultParam defaultParam, long visitID, int reasonID, int actionTakenReasonID, string notes);
    }
}
