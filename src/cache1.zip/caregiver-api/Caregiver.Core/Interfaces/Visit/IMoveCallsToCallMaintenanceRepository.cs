﻿using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.Visit
{
    public interface IMoveCallsToCallMaintenanceRepository
    {
        Task<MoveCallsToCallMaintenanceResponse> MoveCallsToCallMaintenance(MoveCallsToCallMaintenanceRequest request);
    }
}
