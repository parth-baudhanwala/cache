﻿using Caregiver.Core.Models;
using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.Visit
{
    public interface ILinkCallRepository
    {
        Task<LinkCallResponse> LinkCall(LinkCallRequest request);
        Task<ValidationMessage> LinkCallValidations(long visitID, int maintenanceID, int callType);
    }
}
