﻿using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.Visit
{
    public interface IVisitDetailsRepository
    {
        Task<VisitDetailsResponse> VisitDetails(VisitDetailsRequest request);
    }
}
