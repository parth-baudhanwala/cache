﻿using Caregiver.Core.Models;
using Caregiver.Domain.DomainTransferObjects.Visit;

namespace Caregiver.Core.Interfaces.Visit
{
    public interface IUnlinkCallRepository
    {
        Task<UnlinkCallResponse> UnlinkCall(UnlinkCallRequest request);
        Task<ValidationMessage> UnlinkCallValidations(long visitID, int maintenanceID);
    }
}
