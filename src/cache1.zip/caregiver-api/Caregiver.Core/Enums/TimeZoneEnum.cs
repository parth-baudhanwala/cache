﻿using System.ComponentModel;

namespace Caregiver.Core.Enums
{
    public enum TimeZoneEnum
    {
        [Description("Eastern")]
        EST,
        [Description("Central")]
        CST,
        [Description("Mountain MST")]
        MST,
        [Description("Pacific")]
        PST,
        [Description("Alaska")]
        AKST,
        [Description("Hawaii")]
        HAST,
        [Description("Mountain")]
        MDT
    }
}
