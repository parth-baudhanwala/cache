﻿using Caregiver.Domain.DomainTransferObjects.Visit;
using FluentValidation;

namespace Caregiver.Core.Validators.Visit
{
    public class MoveCallsToCallMaintenanceRequestValidators : AbstractValidator<MoveCallsToCallMaintenanceRequest>
    {
        public MoveCallsToCallMaintenanceRequestValidators()
        {
            RuleLevelCascadeMode = CascadeMode.Stop;

            RuleFor(x => x.UserID)
                .NotNull()
                .GreaterThanOrEqualTo(1)
                .WithMessage("Value Cannot be {PropertyValue}. Value Should be Greater than equal to {ComparisonValue}.");

            RuleFor(x => x.VisitID)
                .NotNull()
                .GreaterThanOrEqualTo(1)
                .WithMessage("Value Cannot be {PropertyValue}. Value Should be Greater than equal to {ComparisonValue}.");
        }
    }
}
