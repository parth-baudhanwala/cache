﻿using Caregiver.Domain.DomainTransferObjects.Visit;
using FluentValidation;

namespace Caregiver.Core.Validators.Visit
{
    public class UnlinkCallRequestValidators : AbstractValidator<UnlinkCallRequest>
    {
        public UnlinkCallRequestValidators()
        {
            RuleLevelCascadeMode = CascadeMode.Stop;

            RuleFor(x => x.UserID)
                .NotNull()
                .GreaterThanOrEqualTo(1)
                .WithMessage("Value Cannot be {PropertyValue}. Value Should be Greater than equal to {ComparisonValue}.");

            RuleFor(x => x.MaintenanceID)
                .NotNull()
                .GreaterThanOrEqualTo(1)
                .WithMessage("Value Cannot be {PropertyValue}. Value Should be Greater than equal to {ComparisonValue}.");

            RuleFor(x => x.VisitID)
                .NotNull()
                .GreaterThanOrEqualTo(1)
                .WithMessage("Value Cannot be {PropertyValue}. Value Should be Greater than equal to {ComparisonValue}.");
        }
    }
}
