﻿using Caregiver.API.EndPoints.V1.Visit;
using Caregiver.Domain.DomainTransferObjects.Visit;
using MediatR;
using Moq;
using Xunit;

namespace Caregiver.API.Tests.Controllers
{
    public class VisitDetailsControllerTest
    {
        private readonly Mock<IMediator> _mediatorMock;
        private readonly VisitDetailsController _controller;

        public VisitDetailsControllerTest()
        {
            _mediatorMock = new Mock<IMediator>();
            _controller = new VisitDetailsController(_mediatorMock.Object);
        }

        [Fact]
        public async Task VisitDetails_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            var request = new VisitDetailsRequest
            {
                VisitID = 206726839
            };

            var response = new VisitDetailsResponse();
            _mediatorMock.Setup(m => m.Send(request, default)).ReturnsAsync(response);

            // Act
            var result = await _controller.VisitDetails(request);

            // Assert
            Assert.NotNull(result);
        }
    }
}
