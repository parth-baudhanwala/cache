﻿using Caregiver.API.EndPoints.V1.BroadcastHistory;
using Caregiver.Core.Interfaces.BroadcastHistory;
using Caregiver.Domain.DomainTransferObjects.BroadcastHistory;
using MediatR;
using Moq;
using Xunit;

namespace Caregiver.API.Tests.Controllers
{
    public class BroadcastHistoryControllerTests
    {
        private readonly Mock<IMediator> _mediatorMock;
        private Mock<IBroadcastHistoryRepository> _caregiverCommunicationRepository;
        private readonly BroadcastHistoryController _controller;
        public BroadcastHistoryControllerTests()
        {
            _mediatorMock = new Mock<IMediator>();
            _controller = new BroadcastHistoryController(_mediatorMock.Object);
            _caregiverCommunicationRepository = new Mock<IBroadcastHistoryRepository>();
        }

        [Fact]
        public async Task BroadcastHistory_ReturnsRequest()
        {
            //Arrange
            var lstBroadCastTypeIDs = new List<int>();
            lstBroadCastTypeIDs.Add(1);
            lstBroadCastTypeIDs.Add(2);
            lstBroadCastTypeIDs.Add(3);
            var model = new BroadcastHistoryRequest();
            model.UserID = 27398;
            model.OfficeIDs = "851,1428,342,852,1731,1592,766";
            model.BroadcastName = "Vidula testing";
            model.Status = "1,2,3,4,5";
            model.BroadCastTypeIDs = lstBroadCastTypeIDs;
            model.ScheduledDateFrom = "2018-12-11";
            model.ScheduledDateTo = "2018-12-11";
            model.CreatedFrom = "2018-12-11";
            model.CreatedTo = "2018-12-11";
            model.ProviderID = 691;
            model.PageNo = 1;
            model.PageSize = 200;
            model.UserPrimaryOfficeID = 0;
            model.SortColumn = "Name";
            model.SortDirection = "DESC";
            model.CallerInfo = "Test Case";

            // Act
            var result = await _controller.BroadcastHistory(model);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task BroadcastHistoryAllDetailsByID_ReturnsRequest()
        {
            //Arrange
            var model = new BroadcastHistoryDetailsRequest();
            model.UserID = 27398;
            model.ProviderID = 691;
            model.UserPrimaryOfficeID = 0;
            model.EntpApiUrl = "https://localhost:7067/api/";
            model.BroadcastID = 143240;
            model.PageNo = 1;
            model.PageSize = 200;
            model.Status = "All";
            model.SortColumn = "BroadcastTime";
            model.SortDirection = "DESC";
            model.CallerInfo = "Test Case";

            // Act
            var result = await _controller.BroadcastHistoryDetailsByID(model);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task BroadcastHistoryDeliveredDetailsByID_ReturnsRequest()
        {
            //Arrange
            var model = new BroadcastHistoryDetailsRequest();
            model.UserID = 27398;
            model.ProviderID = 691;
            model.UserPrimaryOfficeID = 0;
            model.EntpApiUrl = "https://localhost:7067/api/";
            model.BroadcastID = 143240;
            model.PageNo = 1;
            model.PageSize = 200;
            model.Status = "Delivered";
            model.SortColumn = "BroadcastTime";
            model.SortDirection = "DESC";
            model.CallerInfo = "Test Case";

            // Act
            var result = await _controller.BroadcastHistoryDetailsByID(model);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task BroadcastHistoryFailedDetailsByID_ReturnsRequest()
        {
            //Arrange
            var model = new BroadcastHistoryDetailsRequest();
            model.UserID = 27398;
            model.ProviderID = 691;
            model.UserPrimaryOfficeID = 0;
            model.EntpApiUrl = "https://localhost:7067/api/";
            model.BroadcastID = 143240;
            model.PageNo = 1;
            model.PageSize = 200;
            model.Status = "Failed";
            model.SortColumn = "BroadcastTime";
            model.SortDirection = "DESC";
            model.CallerInfo = "Test Case";

            // Act
            var result = await _controller.BroadcastHistoryDetailsByID(model);

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public async Task BroadcastHistoryCancelByID_ReturnsRequest()
        {
            //Arrange
            var model = new BroadcastHistoryCancelRequest();
            model.BroadcastID = 143240;
            model.IsBroadCastKill = true;
            model.Result = 0;
            model.CallerInfo = "Test Case";

            //// Act
            var result = await _controller.BroadcastHistoryCancelByID(model);

            // Assert
            Assert.NotNull(result);
        }
    }
}
