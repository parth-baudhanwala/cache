﻿using Caregiver.API.EndPoints.V1.Common;
using Caregiver.Domain.DomainTransferObjects.Common;
using MediatR;
using Moq;
using Xunit;

namespace Caregiver.API.Tests.Controllers
{
    public class CommonControllerTests
    {
        private readonly Mock<IMediator> _mediatorMock;
        private readonly CommonController _controller;
        public CommonControllerTests()
        {
            _mediatorMock = new Mock<IMediator>();
            _controller = new CommonController(_mediatorMock.Object);
        }

        [Fact]
        public async Task Offices_ReturnsRequest()
        {
            //Arrange
            var officesParam = new OfficesRequest
            {
                AppVersion = "ENT",
                Version = Convert.ToDecimal("23.01"),
                MinorVersion = 1,
                UserID = 24926,
                SelectionType = "filter",
                PermissionName = "Smart Map Beta",
                SelectedOfficeID = null
            };

            // Act
            var result = await _controller.Offices(officesParam);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task CommonDetails_ReturnsRequest()
        {
            //Arrange
            var commonDetailsRequestParam = new CommonDetailsRequest
            {
                UserID = 24926,
                ENTPAPIAppversionID = 19,
            };

            // Act
            var result = await _controller.CommonDetails(commonDetailsRequestParam);

            // Assert
            Assert.NotNull(result);
        }
    }
}
