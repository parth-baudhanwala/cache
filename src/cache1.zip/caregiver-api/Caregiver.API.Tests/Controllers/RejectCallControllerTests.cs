﻿using Caregiver.API.EndPoints.V1.Calls;
using Caregiver.Domain.DomainTransferObjects.Calls;
using MediatR;
using Moq;
using Xunit;

namespace Caregiver.API.Tests.Controllers
{
    public class RejectCallControllerTests
    {
        private readonly Mock<IMediator> _mediatorMock;
        private readonly RejectCallController _controller;

        public RejectCallControllerTests()
        {
            _mediatorMock = new Mock<IMediator>();
            _controller = new RejectCallController(_mediatorMock.Object);
        }

        [Fact]
        public async Task RejectCall_InvalidRequest_ReturnsBadRequest()
        {
            // Arrange
            var request = new RejectCallRequest();
            _controller.ModelState.AddModelError("UserID", "UserID is required.");

            // Act
            var result = await _controller.RejectCall(request);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task RejectCall_RepositoryReturnsZero_ReturnsNoContent()
        {
            // Arrange
            var request = new RejectCallRequest
            {
                UserID = 1,
                MaintenanceID = 123
            };

            var response = new RejectCallResponse
            {
                ReturnValue = -1,
                MessageText = "Failed to reject call."
            };

            _mediatorMock.Setup(m => m.Send(request, CancellationToken.None)).ReturnsAsync(response);

            // Act
            var result = await _controller.RejectCall(request);

            // Assert
            Assert.NotNull(result);
        }
    }
}
