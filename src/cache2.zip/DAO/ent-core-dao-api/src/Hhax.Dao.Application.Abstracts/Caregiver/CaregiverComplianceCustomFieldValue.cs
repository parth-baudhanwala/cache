﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CaregiverComplianceCustomFieldValue
{
    [JsonPropertyName("caregiverComplianceCustomFieldValueId")]
    public int CaregiverComplianceCustomFieldValueId { get; set; }

    [JsonPropertyName("caregiverComplianceCustomFieldId")]
    public int CaregiverComplianceCustomFieldId { get; set; }

    [JsonPropertyName("complianceFieldId")]
    public int ComplianceFieldId { get; set; }

    [JsonPropertyName("customFieldName")]
    public Guid CustomFieldName { get; set; }

    [JsonPropertyName("complianceCustomFieldValueId")]
    public int ComplianceCustomFieldValueId { get; set; }

    [JsonPropertyName("optionText")]
    public string? OptionText { get; set; }

    [JsonPropertyName("optionValue")]
    public string? OptionValue { get; set; }
}
