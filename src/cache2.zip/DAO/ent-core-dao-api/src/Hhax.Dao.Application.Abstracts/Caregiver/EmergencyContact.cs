﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class EmergencyContact
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("relationshipId")]
    public int RelationshipId { get; set; }

    [JsonPropertyName("address")]
    public string? Address { get; set; }

    [JsonPropertyName("phone1")]
    public string? Phone1 { get; set; }

    [JsonPropertyName("phone2")]
    public string? Phone2 { get; set; }

    [JsonPropertyName("otherRelationship")]
    public string? OtherRelationship { get; set; }
}
