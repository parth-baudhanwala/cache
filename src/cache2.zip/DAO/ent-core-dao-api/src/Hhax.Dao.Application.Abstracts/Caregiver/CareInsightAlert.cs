﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CareInsightAlert
{
    [JsonPropertyName("receiveAlertEmail")]
    public bool ReceiveAlertEmail { get; set; }

    [JsonPropertyName("alertPriorities")]
    public List<AlertPriority>? AlertPriorities { get; set; }
}
