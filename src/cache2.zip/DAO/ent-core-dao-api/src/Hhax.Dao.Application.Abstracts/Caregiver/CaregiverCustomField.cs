﻿namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CaregiverCustomField
{
    public int Id { get; set; }
    public string? SectionName { get; set; }
    public string? CustomFieldType { get; set; }
    public string? CustomFieldLabel { get; set; }
    public string? CustomFieldValue { get; set; }
    public string? FileUrl { get; set; }
}
