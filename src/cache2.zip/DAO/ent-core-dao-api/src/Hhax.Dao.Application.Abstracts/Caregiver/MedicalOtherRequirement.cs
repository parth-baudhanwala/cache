﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class MedicalOtherRequirement
{
    [JsonPropertyName("caregiverComplianceExpItemId")]
    public int CaregiverComplianceExpItemId { get; set; }

    [JsonPropertyName("expirationItemId")]
    public int ExpirationItemId { get; set; }

    [JsonPropertyName("expirationItem")]
    public string? ExpirationItem { get; set; }

    [JsonPropertyName("expirationItemType")]
    public string? ExpirationItemType { get; set; }

    [JsonPropertyName("complianceExpItemResultId")]
    public int ComplianceExpItemResultId { get; set; }

    [JsonPropertyName("result")]
    public string? Result { get; set; }

    [JsonPropertyName("dateCompleted")]
    public DateTime? DateCompleted { get; set; }

    [JsonPropertyName("compliant")]
    public string? Compliant { get; set; }

    [JsonPropertyName("dueDate")]
    public DateTime DueDate { get; set; }

    [JsonPropertyName("notes")]
    public string? Notes { get; set; }

    [JsonPropertyName("score")]
    public int Score { get; set; }

    [JsonPropertyName("oldComplianceExpItemResultId")]
    public int OldComplianceExpItemResultId { get; set; }

    [JsonPropertyName("filePath")]
    public string? FilePath { get; set; }

    [JsonPropertyName("fileGUID")]
    public string? FileGUID { get; set; }
}
