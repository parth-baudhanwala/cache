﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CaregiverComplianceCustomField
{
    [JsonPropertyName("caregiverComplianceCustomFieldId")]
    public int CaregiverComplianceCustomFieldId { get; set; }

    [JsonPropertyName("complianceFieldId")]
    public int ComplianceFieldId { get; set; }

    [JsonPropertyName("customFieldName")]
    public Guid CustomFieldName { get; set; }

    [JsonPropertyName("customFieldType")]
    public string? CustomFieldType { get; set; }

    [JsonPropertyName("customFieldLabel")]
    public string? CustomFieldLabel { get; set; }

    [JsonPropertyName("customFieldValue")]
    public string? CustomFieldValue { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("required")]
    public string? Required { get; set; }

    [JsonPropertyName("displayOrder")]
    public int DisplayOrder { get; set; }

    [JsonPropertyName("disciplineText")]
    public string? DisciplineText { get; set; }
}
