﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CaregiverCriminalBackground
{
    [JsonPropertyName("caregiverCriminalBackgroundId")]
    public int CaregiverCriminalBackgroundId { get; set; }

    [JsonPropertyName("result")]
    public string? Result { get; set; }

    [JsonPropertyName("sentOutDate")]
    public DateTime? SentOutDate { get; set; }

    [JsonPropertyName("receivedDate")]
    public DateTime? ReceivedDate { get; set; }

    [JsonPropertyName("scanFilePath")]
    public string? ScanFilePath { get; set; }

    [JsonPropertyName("scanFileGUID")]
    public string? ScanFileGUID { get; set; }

    [JsonPropertyName("cbCheckStatusMasterId")]
    public int CbCheckStatusMasterId { get; set; }
}
