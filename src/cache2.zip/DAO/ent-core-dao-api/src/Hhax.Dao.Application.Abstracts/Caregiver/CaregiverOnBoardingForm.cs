namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CaregiverOnBoardingForm
{
    public int OnBoardingFormId { get; set; }
    public string? OnBoardingFormName { get; set; }
    public int FormResponseId { get; set; }
}
