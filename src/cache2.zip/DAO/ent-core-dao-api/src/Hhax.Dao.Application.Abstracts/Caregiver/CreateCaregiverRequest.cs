﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CreateCaregiverRequest
{
    [JsonPropertyName("currentUserId")]
    public int CurrentUserId { get; set; }

    [JsonPropertyName("caregiverProfile")]
    public CaregiverProfile? CaregiverProfile { get; set; }

    [JsonPropertyName("maxNumberOfVisits")]
    public MaxNumberOfVisits? MaxNumberOfVisits { get; set; }

    [JsonPropertyName("complianceInfo")]
    public ComplianceInfo? ComplianceInfo { get; set; }

    [JsonPropertyName("trainingSchools")]
    public List<TrainingSchool>? TrainingSchools { get; set; }

    [JsonPropertyName("medicalOtherRequirements")]
    public List<MedicalOtherRequirement>? MedicalOtherRequirements { get; set; }

    [JsonPropertyName("caregiverCriminalBackgrounds")]
    public List<CaregiverCriminalBackground>? CaregiverCriminalBackgrounds { get; set; }

    [JsonPropertyName("caregiverComplianceCustomFields")]
    public List<CaregiverComplianceCustomField>? CaregiverComplianceCustomFields { get; set; }

    [JsonPropertyName("caregiverComplianceCustomFieldValues")]
    public List<CaregiverComplianceCustomFieldValue>? CaregiverComplianceCustomFieldValues { get; set; }

    [JsonPropertyName("inservices")]
    public List<Inservice>? Inservices { get; set; }

    [JsonPropertyName("permanentWeeks")]
    public List<PermanentWeek>? PermanentWeeks { get; set; }

    [JsonPropertyName("customFields")]
    public List<CaregiverCustomField>? CustomFields { get; set; }

    [JsonPropertyName("onBoardingForms")]
    public List<CaregiverOnBoardingForm>? OnBoardingForms { get; set; }
}
