﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class MaxNumberOfVisits
{
    [JsonPropertyName("saturdayMaxVisit")]
    public int SaturdayMaxVisit { get; set; }

    [JsonPropertyName("sundayMaxVisit")]
    public int SundayMaxVisit { get; set; }

    [JsonPropertyName("mondayMaxVisit")]
    public int MondayMaxVisit { get; set; }

    [JsonPropertyName("tuesdayMaxVisit")]
    public int TuesdayMaxVisit { get; set; }

    [JsonPropertyName("wednesdayMaxVisit")]
    public int WednesdayMaxVisit { get; set; }

    [JsonPropertyName("thursdayMaxVisit")]
    public int ThursdayMaxVisit { get; set; }

    [JsonPropertyName("fridayMaxVisit")]
    public int FridayMaxVisit { get; set; }

    [JsonPropertyName("editAvailabilityViaMobile")]
    public string? EditAvailabilityViaMobile { get; set; }

    [JsonPropertyName("caregiverOpenCasesView")]
    public string? CaregiverOpenCasesView { get; set; }

    [JsonPropertyName("caregiverOpenCasesRequestAccept")]
    public string? CaregiverOpenCasesRequestAccept { get; set; }

    [JsonPropertyName("caregiverOpenCaseRequestLimit")]
    public string? CaregiverOpenCaseRequestLimit { get; set; }

    [JsonPropertyName("caregiverOpenCaseRequestLimitValue")]
    public string? CaregiverOpenCaseRequestLimitValue { get; set; }

    [JsonPropertyName("overrideVisitTimeCorrection")]
    public string? OverrideVisitTimeCorrection { get; set; }

    [JsonPropertyName("allowCaregiverVisitTimeCorrection")]
    public string? AllowCaregiverVisitTimeCorrection { get; set; }

    [JsonPropertyName("allowCaregiverVisitTimeCorrectionWithoutEvv")]
    public string? AllowCaregiverVisitTimeCorrectionWithoutEvv { get; set; }

    [JsonPropertyName("isMaxVisitChanged")]
    public bool IsMaxVisitChanged { get; set; }
}
