﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CaregiverStatus
{
    [JsonPropertyName("status")]
    public int Status { get; set; }

    [JsonPropertyName("reason")]
    public int Reason { get; set; }

    [JsonPropertyName("notes")]
    public string? Notes { get; set; }

    [JsonPropertyName("changeDate")]
    public string? ChangeDate { get; set; }

    [JsonPropertyName("terminationDate")]
    public string? TerminationDate { get; set; }

    [JsonPropertyName("send105")]
    public bool Send105 { get; set; }
}
