﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class Inservice
{
    [JsonPropertyName("inserviceId")]
    public int InserviceId { get; set; }

    [JsonPropertyName("noShow")]
    public bool NoShow { get; set; }

    [JsonPropertyName("noShowReason")]
    public int NoShowReason { get; set; }

    [JsonPropertyName("inserviceDate")]
    public DateTime InserviceDate { get; set; }

    [JsonPropertyName("fromTime")]
    public string? FromTime { get; set; }

    [JsonPropertyName("endTime")]
    public string? EndTime { get; set; }

    [JsonPropertyName("topicIds")]
    public List<int>? TopicIds { get; set; }

    [JsonPropertyName("location")]
    public string? Location { get; set; }

    [JsonPropertyName("instructor")]
    public int Instructor { get; set; }

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("languageId")]
    public int LanguageId { get; set; }

    [JsonPropertyName("companyType")]
    public string? CompanyType { get; set; }

    [JsonPropertyName("disciplineId")]
    public int DisciplineId { get; set; }

    [JsonPropertyName("payRateId")]
    public int PayRateId { get; set; }

    [JsonPropertyName("scheduledOrConfirmed")]
    public bool ScheduledOrConfirmed { get; set; }

    [JsonPropertyName("disciplineId2")]
    public int DisciplineId2 { get; set; }

    [JsonPropertyName("payRateId2")]
    public int PayRateId2 { get; set; }

    [JsonPropertyName("updateFlag")]
    public int UpdateFlag { get; set; }

    [JsonPropertyName("maxAttendees")]
    public int MaxAttendees { get; set; }

    [JsonPropertyName("validateAbsentOverlapping")]
    public bool ValidateAbsentOverlapping { get; set; }

    [JsonPropertyName("firstCountTowardsCompliance")]
    public string? FirstCountTowardsCompliance { get; set; }

    [JsonPropertyName("inserviceCountCompliance")]
    public string? InserviceCountCompliance { get; set; }

    [JsonPropertyName("allowForInserviceOverlap")]
    public bool AllowForInserviceOverlap { get; set; }

    [JsonPropertyName("bypassAbsenceOverlapWarnings")]
    public bool BypassAbsenceOverlapWarnings { get; set; }
}
