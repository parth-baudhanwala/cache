﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class ComplianceInfo
{
    [JsonPropertyName("complianceId")]
    public int ComplianceId { get; set; }

    [JsonPropertyName("hireDate")]
    public DateTime? HireDate { get; set; }

    [JsonPropertyName("oldHireDate")]
    public DateTime? OldHireDate { get; set; }

    [JsonPropertyName("i9FormExpirationDate")]
    public DateTime? I9FormExpirationDate { get; set; }

    [JsonPropertyName("document")]
    public int Document { get; set; }

    [JsonPropertyName("documentNotes")]
    public string? DocumentNotes { get; set; }

    [JsonPropertyName("document1")]
    public int Document1 { get; set; }

    [JsonPropertyName("i9Verified")]
    public bool I9Verified { get; set; }

    [JsonPropertyName("i9EVerifyNumber")]
    public string? I9EVerifyNumber { get; set; }

    [JsonPropertyName("documentName")]
    public string? DocumentName { get; set; }

    [JsonPropertyName("columnCDocumentName")]
    public string? ColumnCDocumentName { get; set; }

    [JsonPropertyName("i9DocumentFilePath")]
    public string? I9DocumentFilePath { get; set; }

    [JsonPropertyName("i9DocumentFileGUID")]
    public string? I9DocumentFileGUID { get; set; }

    [JsonPropertyName("i9ColumnCDocumentFilePath")]
    public string? I9ColumnCDocumentFilePath { get; set; }

    [JsonPropertyName("i9ColumnCDocumentFileGUID")]
    public string? I9ColumnCDocumentFileGUID { get; set; }

    [JsonPropertyName("notesFilePath")]
    public string? NotesFilePath { get; set; }

    [JsonPropertyName("notesFileGUID")]
    public string? NotesFileGUID { get; set; }
}
