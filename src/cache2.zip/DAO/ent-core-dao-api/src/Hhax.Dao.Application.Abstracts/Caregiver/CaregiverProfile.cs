﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class CaregiverProfile
{
    [JsonPropertyName("userId")]
    public long UserId { get; set; }

    [JsonPropertyName("userName")]
    public string? UserName { get; set; }

    [JsonPropertyName("providerId")]
    public long ProviderId { get; set; }

    [JsonPropertyName("appVersion")]
    public string AppVersion { get; set; } = "ENT";

    [JsonPropertyName("version")]
    public decimal Version { get; set; }

    [JsonPropertyName("minorVersion")]
    public decimal MinorVersion { get; set; }

    [JsonPropertyName("offices")]
    public List<Office>? Offices { get; set; }

    [JsonPropertyName("firstName")]
    public string? FirstName { get; set; }

    [JsonPropertyName("middleName")]
    public string? MiddleName { get; set; }

    [JsonPropertyName("lastName")]
    public string? LastName { get; set; }

    [JsonPropertyName("gender")]
    public Gender? Gender { get; set; }

    [DataType(DataType.Date)]
    [JsonPropertyName("dateOfBirth")]
    public DateTime? DateOfBirth { get; set; }

    [JsonPropertyName("dependents")]
    public string? Dependents { get; set; }

    [JsonPropertyName("alternateCode")]
    public string? AlternateCode { get; set; }

    [JsonPropertyName("ssn")]
    public string? Ssn { get; set; }

    [JsonPropertyName("ethnicityId")]
    public int EthnicityId { get; set; }

    [JsonPropertyName("mobileDetail")]
    public MobileDetail? MobileDetail { get; set; }

    [JsonPropertyName("rehireDate")]
    public string? RehireDate { get; set; }

    [JsonPropertyName("maritalStatus")]
    public int MaritalStatus { get; set; }

    [JsonPropertyName("countryOfBirth")]
    public string? CountryOfBirth { get; set; }

    [JsonPropertyName("referralSource")]
    public ReferralSource? ReferralSource { get; set; }

    [JsonPropertyName("employmentTypes")]
    public List<string>? EmploymentTypes { get; set; }

    [JsonPropertyName("referralPerson")]
    public string? ReferralPerson { get; set; }

    [JsonPropertyName("applicationDate")]
    [DataType(DataType.Date)]
    public DateTime? ApplicationDate { get; set; }

    [JsonPropertyName("hireDate")]
    [DataType(DataType.Date)]
    public DateTime? HireDate { get; set; }

    [JsonPropertyName("caregiverType")]
    public int CaregiverType { get; set; }

    [JsonPropertyName("caregiverStatus")]
    public CaregiverStatus? CaregiverStatus { get; set; }

    [JsonPropertyName("employeeId")]
    public string? EmployeeId { get; set; }

    [JsonPropertyName("payrollAgreement")]
    public PayrollAgreement? PayrollAgreement { get; set; }

    [JsonPropertyName("stateRegistry")]
    public StateRegistry? StateRegistry { get; set; }

    [JsonPropertyName("profLicenseNumber")]
    public string? ProfLicenseNumber { get; set; }

    [JsonPropertyName("npiNumber")]
    public string? NpiNumber { get; set; }

    [JsonPropertyName("nycRegistryReference")]
    public NycRegistryReference? NycRegistryReference { get; set; }

    [JsonPropertyName("teamId")]
    public int TeamId { get; set; }

    [JsonPropertyName("locationId")]
    public int LocationId { get; set; }

    [JsonPropertyName("branchId")]
    public int BranchId { get; set; }

    [JsonPropertyName("payerIds")]
    public List<int>? PayerIds { get; set; }

    [JsonPropertyName("address")]
    public Address? Address { get; set; }

    [JsonPropertyName("emergencyContacts")]
    public List<EmergencyContact>? EmergencyContacts { get; set; }

    [JsonPropertyName("notificationPreference")]
    public NotificationPreference? NotificationPreference { get; set; }

    [JsonPropertyName("specialPreference")]
    public SpecialPreference? SpecialPreference { get; set; }

    [JsonPropertyName("updateStatus")]
    public int UpdateStatus { get; set; }

    [JsonPropertyName("allowCommunityVisit")]
    public string? AllowCommunityVisit { get; set; }

    [JsonPropertyName("transportationMethod")]
    public string? TransportationMethod { get; set; }

    [JsonPropertyName("oldFirstName")]
    public string? OldFirstName { get; set; }

    [JsonPropertyName("oldLastName")]
    public string? OldLastName { get; set; }

    [JsonPropertyName("oldSSN")]
    public string? OldSSN { get; set; }

    [JsonPropertyName("oldDateOfBirth")]
    public string? OldDateOfBirth { get; set; }

    [JsonPropertyName("externalSource")]
    public string? ExternalSource { get; set; }

    [JsonPropertyName("filePath")]
    public string? FilePath { get; set; }

    [JsonPropertyName("fileGUID")]
    public string? FileGUID { get; set; }

    [JsonPropertyName("totalUploadedFileSize")]
    public long? TotalUploadedFileSize { get; set; }
}
