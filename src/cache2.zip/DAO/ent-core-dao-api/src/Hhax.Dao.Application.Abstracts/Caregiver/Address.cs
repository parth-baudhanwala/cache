﻿using System.Text.Json.Serialization;

namespace Hhax.Dao.Application.Abstracts.Caregiver;

public class Address
{
    [JsonPropertyName("line1")]
    public string? Line1 { get; set; }

    [JsonPropertyName("line2")]
    public string? Line2 { get; set; }

    [JsonPropertyName("city")]
    public string? City { get; set; }

    [JsonPropertyName("state")]
    public string? State { get; set; }

    [JsonPropertyName("zipCode")]
    public int ZipCode { get; set; }

    [JsonPropertyName("zip4")]
    public int Zip4 { get; set; }

    [JsonPropertyName("phone1")]
    public string? Phone1 { get; set; }

    [JsonPropertyName("phone2")]
    public string? Phone2 { get; set; }

    [JsonPropertyName("phone3")]
    public string? Phone3 { get; set; }
}
