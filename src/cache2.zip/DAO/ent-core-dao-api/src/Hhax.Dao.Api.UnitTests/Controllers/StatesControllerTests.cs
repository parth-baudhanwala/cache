﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Globalization;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Domain.Globalization;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class StatesControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;

    private readonly StatesController _statesController;

    public StatesControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();

        _statesController = new StatesController(_mediatorServiceMock.Object);
    }

    [Fact]
    public async Task States_ShouldGetStates_Success()
    {
        // Arrange
        const string stateName = "NY";

        var request = new SearchStatesRequest
        {
            StateName = stateName
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<SearchStatesQuery, IEnumerable<State>>(It.IsAny<SearchStatesQuery>())).ReturnsAsync((IEnumerable<State>)new List<State> {
            new State(1, stateName, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var result = await _statesController.SearchStatesAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<SearchStatesQuery, IEnumerable<State>>(It.IsAny<SearchStatesQuery>()), Times.Once());
    }

    [Fact]
    public async Task States_ShouldGetCitiesForState_Success()
    {
        // Arrange
        const string stateName = "NY";

        var request = new PaginationRequest<SearchCitiesRequest>
        {
            Filters = new SearchCitiesRequest
            {
                StateName = stateName
            }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<SearchCitiesQuery, IEnumerable<City>>(It.IsAny<SearchCitiesQuery>())).ReturnsAsync((IEnumerable<City>)new List<City> {
            new City(1, "NY", "City Name", "10001", DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var result = await _statesController.SearchCitiesAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<SearchCitiesQuery, IEnumerable<City>>(It.IsAny<SearchCitiesQuery>()), Times.Once());
    }

    [Fact]
    public async Task States_ShouldGetCitiesByName_Success()
    {
        // Arrange
        var request = new PaginationRequest<SearchCitiesRequest>
        {
            Filters = new SearchCitiesRequest
            {
                CityName = "New"
            }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<SearchCitiesQuery, IEnumerable<City>>(It.IsAny<SearchCitiesQuery>())).ReturnsAsync((IEnumerable<City>)new List<City> {
            new City(1, "NY", "City Name", "10001", DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var result = await _statesController.SearchCitiesAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<SearchCitiesQuery, IEnumerable<City>>(It.IsAny<SearchCitiesQuery>()), Times.Once());
    }

    [Fact]
    public async Task States_ShouldGetCityByZipCode_Success()
    {
        // Arrange
        const string zipCodeNewYork = "10001";

        var request = new PaginationRequest<SearchCitiesByZipCodeRequest>
        {
            Filters = new SearchCitiesByZipCodeRequest
            {
                ZipCode = zipCodeNewYork
            }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<SearchCitiesByZipCodeQuery, IEnumerable<City>>(It.IsAny<SearchCitiesByZipCodeQuery>())).ReturnsAsync((IEnumerable<City>)new List<City> {
            new City (1, "NY", "City Name", "10001", DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var result = await _statesController.SearchCitiesByZipCodeAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<SearchCitiesByZipCodeQuery, IEnumerable<City>>(It.IsAny<SearchCitiesByZipCodeQuery>()), Times.Once());
    }
}
