﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Compliance;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Compliance;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class CompliancesControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;
    private readonly Mock<IFilesUploadService> _filesUploadServiceMock;

    private readonly CompliancesController _controller;

    public CompliancesControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();
        _filesUploadServiceMock = new Mock<IFilesUploadService>();

        _controller = new CompliancesController(_mediatorServiceMock.Object,
                                                _filesUploadServiceMock.Object);
    }

    [Fact]
    public async Task Compliances_ShouldRetrieveFileLink_Success()
    {
        // Arrange
        const string request = "file.png";
        const string response = "https://file.png";

        _filesUploadServiceMock.Setup(x => x.GetFileUrlAsync(It.IsAny<string>())).ReturnsAsync(response);

        // Action
        var result = await _controller.GetFileLink(request);

        // Assert
        Assert.NotNull(result);

        _filesUploadServiceMock.Verify(x => x.GetFileUrlAsync(It.IsAny<string>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldRetrieveApplicantI9Requirements_Success()
    {
        // Arrange
        const int applicantId = 111;

        _mediatorServiceMock.Setup(x => x.SendAsync<GetI9RequirementsQuery, ComplianceI9Requirement>(It.IsAny<GetI9RequirementsQuery>())).ReturnsAsync(new ComplianceI9Requirement(1, applicantId, 1, 1, "abDocumentFileKey", 1, false, "cdDocumentFileKey", 1, false,
                                                                                                                                                                                   DateTime.UtcNow, "eds", "ss_card.jpg", 0, false, true, DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        // Action
        var response = await _controller.GetI9Requirements(applicantId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetI9RequirementsQuery, ComplianceI9Requirement>(It.IsAny<GetI9RequirementsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldSetupApplicantI9Requirements_Success()
    {
        // Arrange
        const int applicantId = 111;

        var complianceI9Requirement = new ComplianceI9Requirement(1, applicantId, 1, 1, "abDocumentFileKey", 1, false, "cdDocumentFileKey", 1, false, DateTime.UtcNow, "eds", "ss_card.jpg", 0, false, true, DateTime.UtcNow, 1, DateTime.UtcNow, 1);

        _mediatorServiceMock.Setup(x => x.SendAsync<ComplianceI9Requirement, UpsertI9RequirementCommand, BaseResponse>(It.IsAny<ComplianceI9Requirement>())).ReturnsAsync(new BaseResponse { Id = 1 });

        // Action
        var result = await _controller.SetupI9Requirements(applicantId, complianceI9Requirement);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<ComplianceI9Requirement, UpsertI9RequirementCommand, BaseResponse>(It.IsAny<ComplianceI9Requirement>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldRetrieveColumnCDocuments_Success()
    {
        // Arrange

        _mediatorServiceMock.Setup(x => x.SendAsync<GetColumnCdDocumentsQuery, IEnumerable<I9ColumnCDocument>>(It.IsAny<GetColumnCdDocumentsQuery>())).ReturnsAsync(new I9ColumnCDocument[] {
            new I9ColumnCDocument(1, "Doc 1", 1, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
            new I9ColumnCDocument(2, "Doc 2", 1, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var result = await _controller.GetI9ColumnCDocuments();

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetColumnCdDocumentsQuery, IEnumerable<I9ColumnCDocument>>(It.IsAny<GetColumnCdDocumentsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldRetrieveColumnABDocuments_Success()
    {
        // Arrange
        GetColumnABDocumentsRequest request = new()
        {
            OfficeId = 1
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<GetColumnAbDocumentsQuery, IEnumerable<I9ColumnABDocument>>(It.IsAny<GetColumnAbDocumentsQuery>())).ReturnsAsync(new I9ColumnABDocument[] {
            new I9ColumnABDocument(1, 1, "Doc 33", false, false, false, 1, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
            new I9ColumnABDocument(2, 1, "Doc 44", false, false, false, 1, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var result = await _controller.GetI9ColumnABDocuments(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetColumnAbDocumentsQuery, IEnumerable<I9ColumnABDocument>>(It.IsAny<GetColumnAbDocumentsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldRetrieveApplicantBackgroundCheck_Success()
    {
        // Arrange
        const int applicantId = 111;

        const string firstFileName = "file.pdf";
        const string secondFileName = "vadym_verloka.jpeg";

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicantComplianceBackgroundCheckQuery, IEnumerable<ComplianceBackgroundCheck>>(It.IsAny<GetApplicantComplianceBackgroundCheckQuery>())).ReturnsAsync(new ComplianceBackgroundCheck[] {
            new ComplianceBackgroundCheck(1, applicantId, DateTime.UtcNow, DateTime.UtcNow, 1, firstFileName, 1, firstFileName, false, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
            new ComplianceBackgroundCheck(2, applicantId, DateTime.UtcNow, DateTime.UtcNow, 1, secondFileName, 1, secondFileName, false, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var result = await _controller.GetBackgroundCheck(applicantId);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicantComplianceBackgroundCheckQuery, IEnumerable<ComplianceBackgroundCheck>>(It.IsAny<GetApplicantComplianceBackgroundCheckQuery>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldSetupApplicantBackgroundCheck_Success()
    {
        // Arrange
        const int applicantId = 111;

        const string firstFileName = "file.png";
        const string secondFileName = "cow_super_hero_shot.png";

        var complianceBackgroundChecks = new ComplianceBackgroundCheck[] {
            new ComplianceBackgroundCheck(0, applicantId, DateTime.UtcNow, DateTime.UtcNow, 11, firstFileName, 1, firstFileName, false, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
            new ComplianceBackgroundCheck(1, applicantId, DateTime.UtcNow, DateTime.UtcNow, 22, secondFileName, 1, secondFileName, false, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<UpsertApplicationBackgroundChecksCommand, IEnumerable<int>>(It.IsAny<UpsertApplicationBackgroundChecksCommand>())).ReturnsAsync(new int[] {
            1, 2
        });

        // Action
        var result = await _controller.SetupBackgroundCheck(applicantId, complianceBackgroundChecks);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<UpsertApplicationBackgroundChecksCommand, IEnumerable<int>>(It.IsAny<UpsertApplicationBackgroundChecksCommand>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldDeleteApplicantBackgroundCheck_Success()
    {
        // Arrange
        const int applicantId = 111;

        var ids = new int[] { 1, 2, 3 };

        _mediatorServiceMock.Setup(x => x.SendAsync(It.IsAny<DeleteApplicationBackgroundChecksCommand>())).Returns(Task.FromResult(true));

        // Action
        await _controller.DeleteBackgroundCheck(applicantId, ids);

        // Assert
        _mediatorServiceMock.Verify(x => x.SendAsync(It.IsAny<DeleteApplicationBackgroundChecksCommand>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldRetrieveBackgroundCheckResults_Success()
    {
        // Arrange
        _mediatorServiceMock.Setup(x => x.SendAsync<GetBackgroundCheckResultsQuery, IEnumerable<BackgroundCheckResponse>>(It.IsAny<GetBackgroundCheckResultsQuery>())).ReturnsAsync(new BackgroundCheckResponse[] {
            new BackgroundCheckResponse(1, "Passed", 1, 1, 3, string.Empty, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
            new BackgroundCheckResponse(2, "Rejected", 1, 1, 2, string.Empty, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var result = await _controller.BackgroundCheckResultsAsync(new() { OfficeId = 1 });

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetBackgroundCheckResultsQuery, IEnumerable<BackgroundCheckResponse>>(It.IsAny<GetBackgroundCheckResultsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldRetrieveTrainingSchools_Success()
    {
        // Arrange
        GetTrainingSchoolRequest request = new() { OfficeId = 888 };

        _mediatorServiceMock.Setup(x => x.SendAsync<GetTrainingSchoolsQuery, IEnumerable<TrainingSchool>>(It.IsAny<GetTrainingSchoolsQuery>())).ReturnsAsync(new TrainingSchool[]
        {
            new()
            {
                Id = 1,
                SchoolName = "SN 1"
            },
            new()
            {
                Id = 2,
                SchoolName = "SN 2"
            }
        });

        // Action
        var result = await _controller.GetTrainingSchools(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetTrainingSchoolsQuery, IEnumerable<TrainingSchool>>(It.IsAny<GetTrainingSchoolsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldRetrieveApplicantTrainingSchools_Success()
    {
        // Arrange
        PaginationRequest<GetApplicantTrainingSchools> request = new();

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicantComplianceTrainingSchoolQuery, PaginatationResponse<ComplianceTrainingSchool>>(It.IsAny<GetApplicantComplianceTrainingSchoolQuery>())).ReturnsAsync(new PaginatationResponse<ComplianceTrainingSchool>());

        // Action
        var result = await _controller.GetApplicantTrainingSchools(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicantComplianceTrainingSchoolQuery, PaginatationResponse<ComplianceTrainingSchool>>(It.IsAny<GetApplicantComplianceTrainingSchoolQuery>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldSaveApplicantTrainingSchools_Success()
    {
        // Arrange
        const int applicantId = 111;

        ComplianceTrainingSchool school = new()
        {
            DisciplineId = 44,
            SchoolId = 22,
            InstructorName = "Vadym Verloka"
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<ComplianceTrainingSchool, UpsertApplicationTrainingSchoolCommand, BaseResponse>(It.IsAny<ComplianceTrainingSchool>())).ReturnsAsync(new BaseResponse { Id = 1 });

        // Action
        var result = await _controller.SaveApplicantTrainingSchools(applicantId, school);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<ComplianceTrainingSchool, UpsertApplicationTrainingSchoolCommand, BaseResponse>(It.IsAny<ComplianceTrainingSchool>()), Times.Once());
    }

    [Fact]
    public async Task Compliances_ShouldDeleteApplicantTrainingSchools_Success()
    {
        // Arrange
        const int applicantId = 111;
        const int rowId = 222;

        _mediatorServiceMock.Setup(x => x.SendAsync(It.IsAny<DeleteApplicationComplianceTrainingSchoolCommand>())).Returns(Task.FromResult(true));

        // Action
        await _controller.DeleteApplicantTrainingSchools(applicantId, rowId);

        // Assert
        _mediatorServiceMock.Verify(x => x.SendAsync(It.IsAny<DeleteApplicationComplianceTrainingSchoolCommand>()), Times.Once());
    }
}
