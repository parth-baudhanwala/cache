﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.InService;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.InService;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.InService;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class InServiceControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;
    private readonly InServiceController _inServiceController;

    public InServiceControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();
        _inServiceController = new InServiceController(_mediatorServiceMock.Object);
    }

    [Fact]
    public async Task InService_ShouldRetrieveInServiceInstructors_Success()
    {
        // Arrange
        _mediatorServiceMock.Setup(x => x.SendAsync<GetInServiceInstructorsQuery, IEnumerable<InServiceInstructor>>(It.IsAny<GetInServiceInstructorsQuery>()))
            .ReturnsAsync(new List<InServiceInstructor>
            {
                new InServiceInstructor { Id = 1, InstructorName = "Test 1" },
                new InServiceInstructor { Id = 2, InstructorName = "Test 2" }
            });

        // Action
        var response = await _inServiceController.GetInServiceInstructors();

        // Assert
        Assert.NotNull(response);
        _mediatorServiceMock.Verify(x => x.SendAsync<GetInServiceInstructorsQuery, IEnumerable<InServiceInstructor>>(It.IsAny<GetInServiceInstructorsQuery>()), Times.Once());
    }

    [Fact]
    public async Task InService_ShouldRetrievePayCodes_Success()
    {
        // Arrange
        const int disciplineId = 222;
        _mediatorServiceMock.Setup(x => x.SendAsync<GetPaycodesQuery, IEnumerable<InServicePayRate>>(It.IsAny<GetPaycodesQuery>()))
            .ReturnsAsync(new List<InServicePayRate>
            {
                new InServicePayRate { Id = 1, PayRate = "Test 1" },
                new InServicePayRate { Id = 2, PayRate = "Test 2" }
            });

        // Action
        var response = await _inServiceController.GetPayCodes(disciplineId);

        // Assert
        Assert.NotNull(response);
        _mediatorServiceMock.Verify(x => x.SendAsync<GetPaycodesQuery, IEnumerable<InServicePayRate>>(It.IsAny<GetPaycodesQuery>()), Times.Once());
    }

    [Fact]
    public async Task InService_ShouldRetrieveNoShowReasons_Success()
    {
        // Arrange
        _mediatorServiceMock.Setup(x => x.SendAsync<GetInServiceNoShowReasonsQuery, IEnumerable<InServiceNoShowReason>>(It.IsAny<GetInServiceNoShowReasonsQuery>()))
            .ReturnsAsync(new List<InServiceNoShowReason>
            {
                new InServiceNoShowReason { Id = 1, Reason = "Test 1" },
                new InServiceNoShowReason { Id = 2, Reason = "Test 2" }
            });

        // Action
        var response = await _inServiceController.GetNoShowReasons();

        // Assert
        Assert.NotNull(response);
        _mediatorServiceMock.Verify(x => x.SendAsync<GetInServiceNoShowReasonsQuery, IEnumerable<InServiceNoShowReason>>(It.IsAny<GetInServiceNoShowReasonsQuery>()), Times.Once());
    }

    [Fact]
    public async Task InService_ShouldRetrieveTopics_Success()
    {
        // Arrange
        const int officeId = 1;
        _mediatorServiceMock.Setup(x => x.SendAsync<GetTopicsQuery, IEnumerable<InServiceTopic>>(It.IsAny<GetTopicsQuery>()))
            .ReturnsAsync(new List<InServiceTopic>
            {
                new InServiceTopic { Id = 1, TopicDescription = "Test 1" },
                new InServiceTopic { Id = 2, TopicDescription = "Test 2" }
            });

        // Action
        var response = await _inServiceController.GetTopics(officeId);

        // Assert
        Assert.NotNull(response);
        _mediatorServiceMock.Verify(x => x.SendAsync<GetTopicsQuery, IEnumerable<InServiceTopic>>(It.IsAny<GetTopicsQuery>()), Times.Once());
    }

    [Fact]
    public async Task InService_ShouldCheckIfApplicantHasInServices_Success()
    {
        // Arrange
        const int applicantId = 1;
        _mediatorServiceMock.Setup(x => x.SendAsync<HasApplicantInServicesQuery, HasApplicantInServices>(It.IsAny<HasApplicantInServicesQuery>()))
            .ReturnsAsync(new HasApplicantInServices
            {
                ApplicationId = applicantId,
                HasInServices = true
            });

        // Action
        var response = await _inServiceController.HasApplicantInServices(applicantId);

        // Assert
        Assert.NotNull(response);
        _mediatorServiceMock.Verify(x => x.SendAsync<HasApplicantInServicesQuery, HasApplicantInServices>(It.IsAny<HasApplicantInServicesQuery>()), Times.Once());
    }

    [Fact]
    public async Task InService_ShouldRetrieveApplicantInServices_Success()
    {
        // Arrange
        const int applicantId = 1;
        var request = new PaginationRequest<GetApplicantInServices>();

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicantInServicesQuery, PaginatationResponse<ApplicantInServiceTableItem>>(It.IsAny<GetApplicantInServicesQuery>()))
            .ReturnsAsync(new PaginatationResponse<ApplicantInServiceTableItem>
            {
                PageInfo = new Application.Abstracts.Common.PageInfo
                {
                    TotalRecordCount = 2    
                },
                Data = new List<ApplicantInServiceTableItem>
                {
                    new ApplicantInServiceTableItem { Id = 1 },
                    new ApplicantInServiceTableItem { Id = 2 }
                }
            });

        // Action
        var response = await _inServiceController.GetApplicantInServicesForTable(applicantId, request);

        // Assert
        Assert.NotNull(response);
        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicantInServicesQuery, PaginatationResponse<ApplicantInServiceTableItem>>(It.IsAny<GetApplicantInServicesQuery>()), Times.Once());
    }

    [Fact]
    public async Task InService_ShouldSaveInService_Success()
    {
        // Arrange
        const int applicantId = 1;
        var command = new UpsertInServiceCommand
        {
            Id = 1,
            ApplicantId = applicantId
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<UpsertInServiceCommand, BaseResponse>(It.IsAny<UpsertInServiceCommand>()))
            .ReturnsAsync(new BaseResponse
            {
                Id = 1
            });

        // Action
        var response = await _inServiceController.SaveInService(applicantId, command);

        // Assert
        Assert.NotNull(response);
        _mediatorServiceMock.Verify(x => x.SendAsync<UpsertInServiceCommand, BaseResponse>(It.IsAny<UpsertInServiceCommand>()), Times.Once());
    }

    [Fact]
    public async Task InService_ShouldDeleteInService_Success()
    {
        // Arrange
        const int applicantId = 1;
        const int inServiceId = 1;
        var command = new DeleteInServiceCommand(applicantId, inServiceId);

        _mediatorServiceMock.Setup(x => x.SendAsync(It.IsAny<DeleteInServiceCommand>()));

        // Action
        var response = await _inServiceController.DeleteInServiceAsync(applicantId, inServiceId);

        // Assert
        Assert.NotNull(response);
        _mediatorServiceMock.Verify(x => x.SendAsync(It.IsAny<DeleteInServiceCommand>()), Times.Once());
    }
}
