﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Office;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Domain.User;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Security.Claims;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class HumanResourcePersonaControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;

    private readonly HumanResourcePersonasController _controller;

    public HumanResourcePersonaControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();

        _controller = new HumanResourcePersonasController(_mediatorServiceMock.Object);
    }

    [Fact]
    public async Task HumanResourcePersona_ShouldAddHumanResourcePersona_Success()
    {
        // Arrange
        var request = new HumanResourcePersonaRequest
        {
            Name = "Test",
            StatusId = 1,
            UserId = 2,
            OfficeIds = new int[] { 1, 2, }
        };
        var baseResponse = new BaseResponse { Id = 1 };

        _mediatorServiceMock.Setup(x => x.SendAsync<HumanResourcePersonaRequest, AddHumanResourcePersonaCommand, BaseResponse>(It.IsAny<HumanResourcePersonaRequest>())).ReturnsAsync(baseResponse);

        // Action
        var result = await _controller.AddHumanResourcePersonaAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<HumanResourcePersonaRequest, AddHumanResourcePersonaCommand, BaseResponse>(It.IsAny<HumanResourcePersonaRequest>()), Times.Once());
    }

    [Fact]
    public async Task HumanResourcePersona_ShouldUpdateHumanResourcePersona_Success()
    {
        // Arrange
        const int humanResourcePersonaId = 1;
        var request = new HumanResourcePersonaRequest
        {
            Name = "Test",
            StatusId = 1,
            UserId = 2,
            OfficeIds = new int[] { 1, 2, }
        };
        var baseResponse = new BaseResponse { Id = 1 };

        _mediatorServiceMock.Setup(x => x.SendAsync<HumanResourcePersonaRequest, UpdateHumanResourcePersonaCommand, BaseResponse>(It.IsAny<HumanResourcePersonaRequest>())).ReturnsAsync(baseResponse);

        // Action
        var result = await _controller.UpdateHumanResourcePersonaAsync(humanResourcePersonaId, request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<HumanResourcePersonaRequest, UpdateHumanResourcePersonaCommand, BaseResponse>(It.IsAny<HumanResourcePersonaRequest>()), Times.Once());
    }

    [Fact]
    public async Task HumanResourcePersona_ShouldGetHumanResourcePersona_Success()
    {
        // Arrange
        const int humanResourcePersonaId = 1;

        var humanResourcePersona = new HumanResourcePersona(1, "Test", 3, "Offices", 4, "userName", "firstName", "lastName", new int[] { 1, 2, 3 }, DateTime.UtcNow, 1, DateTime.UtcNow, 1);

        _mediatorServiceMock.Setup(x => x.SendAsync<GetHumanResourcePersonaQuery, HumanResourcePersona>(It.IsAny<GetHumanResourcePersonaQuery>())).ReturnsAsync(humanResourcePersona);

        // Action
        var result = await _controller.GetHumanResourcePersonaAsync(humanResourcePersonaId);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetHumanResourcePersonaQuery, HumanResourcePersona>(It.IsAny<GetHumanResourcePersonaQuery>()), Times.Once());
    }

    [Fact]
    public async Task HumanResourcePersona_ShouldGetHumanResourcePersonas_Success()
    {
        // Arrange
        var request = new PaginationRequest<SearchHumanResourcePersonaRequest>
        {
            Page = new Page { PageSize = 1, PageNumber = 1 },
            Filters = new SearchHumanResourcePersonaRequest
            {
                Name = "Test",
                StatusId = 1,
                Offices = "2, 4 "
            }
        };

        var baseResult = new PaginatationResponse<HumanResourcePersona>
        {
            Data = new List<HumanResourcePersona> {
                new HumanResourcePersona(1, "Test", 3, "Offices", 4, "userName", "firstName", "lastName", new int[] { 1, 2, 3 }, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
            },
            PageInfo = new PageInfo { TotalRecordCount = 1 }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<GetHumanResourcePersonasQuery, PaginatationResponse<HumanResourcePersona>>(It.IsAny<GetHumanResourcePersonasQuery>())).ReturnsAsync(baseResult);

        // Action
        var result = await _controller.GetHumanResourcePersonasAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetHumanResourcePersonasQuery, PaginatationResponse<HumanResourcePersona>>(It.IsAny<GetHumanResourcePersonasQuery>()), Times.Once());
    }

    [Fact]
    public async Task HumanResourcePersona_ShouldGetStatuses_Success()
    {
        // Arrange
        var humanResourcePersonaStatuses = new List<HumanResourcePersonaStatus>
        {
            new HumanResourcePersonaStatus(1, "Active", true, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
            new HumanResourcePersonaStatus(2, "Inactive", true, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<GetHumanResourcePersonaStatusesQuery, IEnumerable<HumanResourcePersonaStatus>>(It.IsAny<GetHumanResourcePersonaStatusesQuery>())).ReturnsAsync(humanResourcePersonaStatuses);

        // Action
        var result = await _controller.GetStatusesAsync();

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetHumanResourcePersonaStatusesQuery, IEnumerable<HumanResourcePersonaStatus>>(It.IsAny<GetHumanResourcePersonaStatusesQuery>()), Times.Once());
    }

    [Fact]
    public async Task HumanResourcePersona_ShouldGetUsers_Success()
    {
        // Arrange
        const string vendoridType = "vendorid";

        const int userId = 38974;
        const int vendorId = 691;

        var baseResult = new List<UserInfo> {
            new UserInfo(1, "TestName", DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        };

        var claims = new List<Claim> {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
            new Claim(vendoridType, vendorId.ToString())
        };
        var claimsIdentity = new ClaimsIdentity(claims);
        var user = new ClaimsPrincipal(claimsIdentity);
        var controllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext
            {
                User = user
            }
        };
        _controller.ControllerContext = controllerContext;

        _mediatorServiceMock.Setup(x => x.SendAsync<GetUsersQuery, IEnumerable<UserInfo>>(It.IsAny<GetUsersQuery>())).ReturnsAsync(baseResult);

        // Action
        var result = await _controller.GetUsersAsync();

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetUsersQuery, IEnumerable<UserInfo>>(It.IsAny<GetUsersQuery>()), Times.Once());
    }

    [Theory]
    [InlineData(1, "Application Submitted")]
    [InlineData(2, "Application Submitted")]
    public async Task HumanResourcePersona_ShouldAssignHumanResourcePersonaToApplicant_Success(int applicantId, string workflowStatus)
    {
        // Arrange 
        AssignApplicant[] assignApplicants = new AssignApplicant[] { new AssignApplicant { ApplicantId = applicantId, WorkflowStatus = workflowStatus } };
        var parameters = new AssignApplicantRequest
        {
            NoteText = "TestText",
            AssignApplicants = assignApplicants.ToList(),
            HumanResourcePersonaId = 1
        };

        var baseRangeResponse = new BaseRangeResponse( new List<int>() { 1 });

        _mediatorServiceMock.Setup(x => x.SendAsync<AssignApplicantRequest, AssignHumanResourcePersonaToApplicantCommand, BaseRangeResponse>(It.IsAny<AssignApplicantRequest>())).ReturnsAsync(baseRangeResponse);

        // Action
        var result = await _controller.AssignApplicantAsync(parameters);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<AssignApplicantRequest, AssignHumanResourcePersonaToApplicantCommand, BaseRangeResponse>(It.IsAny<AssignApplicantRequest>()), Times.Once());
    }
}
