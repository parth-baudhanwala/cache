﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class ApplicationWorkflowStatusesControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;

    private readonly ApplicationWorkflowStatusesController _controller;

    public ApplicationWorkflowStatusesControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();
        
        _controller = new ApplicationWorkflowStatusesController(_mediatorServiceMock.Object);
    }

    [Fact]
    public async Task ApplicationWorkflowStatuses_ShouldAddApplicationWorkflowStatus_Success()
    {
        // Arrange
        var request = new ApplicationWorkflowStatusRequest
        {
            Name = "Test",
            ColorId = 1,
            NextApplicationWorkflowStatusIds = new int[] { 1, 2, 3 }
        };
        var baseResponse = new BaseResponse { Id = 1 };

        _mediatorServiceMock.Setup(x => x.SendAsync<ApplicationWorkflowStatusRequest, AddApplicationWorkflowStatusCommand, BaseResponse>(It.IsAny<ApplicationWorkflowStatusRequest>())).ReturnsAsync(baseResponse);

        // Action
        var response = await _controller.AddApplicationWorkflowStatusAsync(request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<ApplicationWorkflowStatusRequest, AddApplicationWorkflowStatusCommand, BaseResponse>(It.IsAny<ApplicationWorkflowStatusRequest>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationWorkflowStatuses_ShouldUpdateApplicationWorkflowStatus_Success()
    {
        // Arrange
        int applicationWorkflowStatusId = 1;
        var request = new ApplicationWorkflowStatusRequest
        {
            Name = "TestNew",
            ColorId = 2,
            NextApplicationWorkflowStatusIds = new int[] { 1, 3 }
        };
        var baseResponse = new BaseResponse { Id = applicationWorkflowStatusId };

        _mediatorServiceMock.Setup(x => x.SendAsync<ApplicationWorkflowStatusRequest, UpdateApplicationWorkflowStatusCommand, BaseResponse>(It.IsAny<ApplicationWorkflowStatusRequest>())).ReturnsAsync(baseResponse);

        // Action
        var response = await _controller.UpdateApplicationWorkflowStatusAsync(applicationWorkflowStatusId, request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<ApplicationWorkflowStatusRequest, UpdateApplicationWorkflowStatusCommand, BaseResponse>(It.IsAny<ApplicationWorkflowStatusRequest>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationWorkflowStatuses_ShouldGetApplicationWorkflowStatus_Success()
    {
        // Arrange
        int applicationWorkflowStatusId = 1;

        var applicationWorkflowStatus = new ApplicationWorkflowStatus(1, "Test", "Test", 1, 1, 0, false, true, false, false, true, new List<ApplicationWorkflowStatus>()
            {
                new ApplicationWorkflowStatus(2,  "TestName", "TestDescription", 1, 1, 0, false, true, false, false, true, Enumerable.Empty<ApplicationWorkflowStatus>(), true, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
                new ApplicationWorkflowStatus(3,  "NameTest", "DescriptionTest", 1, 5, 0, false, true, false, false, true, Enumerable.Empty<ApplicationWorkflowStatus>(), true, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
            }, true, DateTime.UtcNow, 1, DateTime.UtcNow, 1);

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicationWorkflowStatusQuery, ApplicationWorkflowStatus>(It.IsAny<GetApplicationWorkflowStatusQuery>())).ReturnsAsync(applicationWorkflowStatus);

        // Action
        var response = await _controller.GetApplicationWorkflowStatusAsync(applicationWorkflowStatusId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicationWorkflowStatusQuery, ApplicationWorkflowStatus>(It.IsAny<GetApplicationWorkflowStatusQuery>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationWorkflowStatuses_ShouldGetApplicationWorkflowStatuses_Success()
    {
        // Arrange
        var request = new PaginationRequest<SearchApplicationWorkflowStatusRequest>
        {
            Page = new Page { PageSize = 1, PageNumber = 1 },
            Filters = new SearchApplicationWorkflowStatusRequest
            {
                Name = "Test",
                AgencyId = 1
            }
        };

        var paginatationResponse = new PaginatationResponse<ApplicationWorkflowStatus>
        {
            Data = new List<ApplicationWorkflowStatus> 
            {
                new ApplicationWorkflowStatus(1, "Name", "Description", 1, 1, 0, false, true, false, false, true, new List<ApplicationWorkflowStatus> {
                    new ApplicationWorkflowStatus(2, "TestName", "TestDescription", 1, 1, 0, false, true, false, false, true, Enumerable.Empty<ApplicationWorkflowStatus>(), true, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
                    new ApplicationWorkflowStatus(3, "NameTest", "DescriptionTest", 1, 1, 0, false, true, false, false, true, Enumerable.Empty<ApplicationWorkflowStatus>(), true, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
                }, true, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
            },
            PageInfo = new PageInfo { TotalRecordCount = 10 }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicationWorkflowStatusesQuery, PaginatationResponse<ApplicationWorkflowStatus>>(It.IsAny<GetApplicationWorkflowStatusesQuery>())).ReturnsAsync(paginatationResponse);

        // Action
        var response = await _controller.GetApplicationWorkflowStatusesAsync(request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicationWorkflowStatusesQuery, PaginatationResponse<ApplicationWorkflowStatus>>(It.IsAny<GetApplicationWorkflowStatusesQuery>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationWorkflowStatuses_ShouldGetApplicationWorkflowStatusBadgeColors_Success()
    {
        // Arrange
        var applicationWorkflowStatusBadgeColors = new List<ApplicationWorkflowStatusBadgeColor>
        {
            new ApplicationWorkflowStatusBadgeColor(1, "Color1", true, DateTime.UtcNow, 1, DateTime.UtcNow, 1),
            new ApplicationWorkflowStatusBadgeColor(2, "Color2", true, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicationWorkflowStatusBadgeColorsQuery, IEnumerable<ApplicationWorkflowStatusBadgeColor>>(It.IsAny<GetApplicationWorkflowStatusBadgeColorsQuery>())).ReturnsAsync(applicationWorkflowStatusBadgeColors);

        // Action
        var response = await _controller.GetColorsAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicationWorkflowStatusBadgeColorsQuery, IEnumerable<ApplicationWorkflowStatusBadgeColor>>(It.IsAny<GetApplicationWorkflowStatusBadgeColorsQuery>()), Times.Once());
    }
}
