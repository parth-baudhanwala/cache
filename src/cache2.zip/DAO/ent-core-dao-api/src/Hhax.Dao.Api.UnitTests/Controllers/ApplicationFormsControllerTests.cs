using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Application;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class ApplicationFormsControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;

    private readonly ApplicationFormsController _controller;

    public ApplicationFormsControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();

        _controller = new ApplicationFormsController(_mediatorServiceMock.Object);
    }

    [Fact]
    public async Task ApplicationForm_ShouldAddApplicationForm_Success()
    {
        // Arrange
        var request = new ApplicationFormRequest
        {
            OfficeIds = new[] { 1, 2, 3 },
            Name = "Application Form"
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<ApplicationFormRequest, AddApplicationFormCommand, BaseResponse>(It.IsAny<ApplicationFormRequest>())).ReturnsAsync(new BaseResponse { Id = 1 });

        // Action
        var response = await _controller.AddApplicationFormAsync(request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<ApplicationFormRequest, AddApplicationFormCommand, BaseResponse>(It.IsAny<ApplicationFormRequest>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationForm_ShouldUpdateApplicationForm_Success()
    {
        // Arrange
        const int applicationFormId = 1;

        var request = new ApplicationFormRequest
        {
            OfficeIds = new[] { 1, 2, 3 },
            Name = "Application Form"
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<ApplicationFormRequest, UpdateApplicationFormCommand, BaseResponse>(It.IsAny<ApplicationFormRequest>())).ReturnsAsync(new BaseResponse { Id = 1 });

        // Action
        var response = await _controller.UpdateApplicationFormAsync(applicationFormId, request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<ApplicationFormRequest, UpdateApplicationFormCommand, BaseResponse>(It.IsAny<ApplicationFormRequest>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationForm_ShouldGetApplicationFormById_Success()
    {
        // Arrange
        const int applicationFormId = 1;

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicationFormByIdQuery, ApplicationForm>(It.IsAny<GetApplicationFormByIdQuery>())).ReturnsAsync(
            new ApplicationForm(1, "Name", new[] { 1, 2 }, "Offices", Guid.NewGuid(), true, 1, Enumerable.Empty<ApplicationFormOffice>(),
                                Enumerable.Empty<ApplicationFormApplicantRequirement>(), DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        // Action
        var response = await _controller.GetApplicationFormAsync(applicationFormId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicationFormByIdQuery, ApplicationForm>(It.IsAny<GetApplicationFormByIdQuery>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationForm_ShouldGetApplicationFormByUniqueUrlId_Success()
    {
        // Arrange
        const int officeId = 1;
        var uniqueUrlId = Guid.NewGuid();

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicationFormByUniqueIdQuery, ApplicationForm>(It.IsAny<GetApplicationFormByUniqueIdQuery>())).ReturnsAsync(
               new ApplicationForm(1, "Name", new[] { 1, 2 }, "Offices", Guid.NewGuid(), true, 1, Enumerable.Empty<ApplicationFormOffice>(),
                                   Enumerable.Empty<ApplicationFormApplicantRequirement>(), DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        // Action
        var response = await _controller.GetApplicationFormAsync(uniqueUrlId, officeId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicationFormByUniqueIdQuery, ApplicationForm>(It.IsAny<GetApplicationFormByUniqueIdQuery>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationForm_ShouldGetLinkToApplicationFormByOffice_Success()
    {
        // Arrange
        const int officeId = 1;

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicationFormUrlQuery, string>(It.IsAny<GetApplicationFormUrlQuery>())).ReturnsAsync(officeId.ToString());

        // Action
        var response = await _controller.GetLinkToApplicationFormByOfficeAsync(officeId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicationFormUrlQuery, string>(It.IsAny<GetApplicationFormUrlQuery>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationForm_ShouldGetApplicantRequirements_Success()
    {
        // Arrange
        var uniqueUrlId = Guid.NewGuid();

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicantRequirementsByUniqueIdQuery, IEnumerable<ApplicationFormApplicantRequirement>>(It.IsAny<GetApplicantRequirementsByUniqueIdQuery>())).ReturnsAsync((IEnumerable<ApplicationFormApplicantRequirement>)new List<ApplicationFormApplicantRequirement> {
            new ApplicationFormApplicantRequirement(1, 1, 1, 1, true, true, DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var response = await _controller.GetApplicantRequirementsAsync(uniqueUrlId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicantRequirementsByUniqueIdQuery, IEnumerable<ApplicationFormApplicantRequirement>>(It.IsAny<GetApplicantRequirementsByUniqueIdQuery>()), Times.Once());
    }

    [Fact]
    public void ApplicationForm_ShouldGetApplicationRequirementsWithoutUniqueUrlId_Failure()
    {
        // Arrange
        var uniqueUrlId = Guid.NewGuid();

        // Action & Assert
        Assert.ThrowsAsync<ApplicationFormNotFoundException>(async () => await _controller.GetApplicantRequirementsAsync(uniqueUrlId));
    }

    [Fact]
    public async Task ApplicantForm_ShouldGetOfficesGroupedByCompliance_Success()
    {
        // Arrange
        const int applicationFormId = 1;

        _mediatorServiceMock.Setup(x => x.SendAsync<GetCompliancesQuery, CompliancesResponse>(It.IsAny<GetCompliancesQuery>())).ReturnsAsync(new CompliancesResponse());

        // Action
        var result = await _controller.GetCompliancesAsync(applicationFormId);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetCompliancesQuery, CompliancesResponse>(It.IsAny<GetCompliancesQuery>()), Times.Once());
    }

    [Fact]
    public async Task ApplicationForm_ShouldGetApplicationFormApplicantSections_Success() 
    {
        // Arrange
        var resquest = new GetApplicationFormApplicantSectionsRequest { };

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicationFormApplicantSectionsQuery, IEnumerable<ApplicationFormApplicantSection>>(It.IsAny<GetApplicationFormApplicantSectionsQuery>())).ReturnsAsync((IEnumerable<ApplicationFormApplicantSection>) new List<ApplicationFormApplicantSection>
        {
            new ApplicationFormApplicantSection { 
                Id = (int)ApplicationFormApplicantSections.Demographics,
                ComplianceSetupName = "Compliance Setup",
                Created = DateTime.UtcNow,
                CreatedBy = 1,
                IsActive = true,
                IsPostHire = true,
                Name = "Demographics",
                Order = 1,
                Updated = DateTime.UtcNow,
                UpdatedBy = 1,
                ApplicationFormApplicantFields = new List<ApplicationFormApplicantField> { 
                    new ApplicationFormApplicantField { 
                        Id = 1,
                        Name = "Applicant Field",
                        ApplicantSectionId = (int)ApplicationFormApplicantSections.Demographics,
                        Created = DateTime.UtcNow,
                        CreatedBy = 1,
                        DefaultIsRequire = false,
                        DefaultIsShow = true,
                        IsActive = true,
                        IsRequireEnabled = true,
                        IsShowEnabled = true,
                        Order = 1,
                        Updated = DateTime.UtcNow,
                        UpdatedBy = 1
                    }
                }
            }
        });


        // Action
        var result = await _controller.GetApplicationFormApplicantSectionsAsync(resquest);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicationFormApplicantSectionsQuery, IEnumerable<ApplicationFormApplicantSection>>(It.IsAny<GetApplicationFormApplicantSectionsQuery>()), Times.Once());
    }
}
