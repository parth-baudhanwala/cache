﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Globalization;
using MediatR;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class ApplicantsControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;
    private readonly Mock<IFilesUploadService> _filesUploadServiceMock;

    private readonly ApplicantsController _controller;

    public ApplicantsControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();
        _filesUploadServiceMock = new Mock<IFilesUploadService>();
        _controller = new ApplicantsController(_mediatorServiceMock.Object, _filesUploadServiceMock.Object);
    }

    [Fact]
    public async Task Applicant_ShouldAddApplicant_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            FirstName = "demo",
            LastName = "demo",
            DateOfBirth = DateTime.Now,
            SocialSecurityNumber = "123-45-6789",
            Ethnicity = 3,
            Gender = 1,
            EmploymentTypeIds = new[] { 1, 2, 3 },
            RegistryNumber = "122e45ha8il0ee3pjb",
            RegistryDate = DateTime.Now,
            NationalProviderIdentity = "123p5j78bh",
            ProfessionalLicenseNumber = "212jsjjshaileeparth9i",
            Signatures = new List<Signature>()
            {
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 1
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 2
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 3
                }
            }
        };

        var baseResponse = new BaseResponse { Id = 1 };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<ApplicantAddRequest, AddApplicantCommand, BaseResponse>(It.IsAny<ApplicantAddRequest>())).ReturnsAsync(baseResponse);

        // Action
        var response = await _controller.AddApplicantAsync(request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<ApplicantAddRequest, AddApplicantCommand, BaseResponse>(It.IsAny<ApplicantAddRequest>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldUpdateApplicant_Success()
    {
        // Arrange
        const int applicantId = 1;

        var request = new ApplicantUpdateRequest
        {
            ContactEmail = "demo@hhaexchange.com",
            FirstName = "demo",
            LastName = "demo",
            DateOfBirth = DateTime.Now,
            SocialSecurityNumber = "123-45-6789",
            Ethnicity = 3,
            Gender = 1,
            EmploymentTypeIds = new[] { 1, 2, 3 },
            RegistryNumber = "122e45ha8il0ee3pjb",
            RegistryDate = DateTime.Now,
            NationalProviderIdentity = "123p5j78bh",
            ProfessionalLicenseNumber = "212jsjjshaileeparth9i",
            Signatures = new List<Signature>()
            {
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 1
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 2
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 3
                }
            }
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<ApplicantUpdateRequest, UpdateApplicantCommand, BaseResponse>(It.IsAny<ApplicantUpdateRequest>())).Returns(Task.FromResult(new BaseResponse
        {
            Id = applicantId
        }));

        // Action
        _ = await _controller.UpdateApplicantAsync(applicantId, request);

        // Assert
        _mediatorServiceMock.Verify(x => x.SendAsync<ApplicantUpdateRequest, UpdateApplicantCommand, BaseResponse>(It.IsAny<ApplicantUpdateRequest>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldUpdateAsyncApplicant_Success()
    {
        // Arrange
        const int applicantId = 1;
        const int statusId = 2;

        var request = new ApplicantUpdateWorkflowStatusRequest()
        {
            StatusBackgroundColor = "#FFF1D2",
            StatusBorderColor = "1px solid #FDB81E",
            Domain = "test.com"
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<UpdateApplicantStatusCommand, BaseResponse>(It.IsAny<UpdateApplicantStatusCommand>())).Returns(Task.FromResult(new BaseResponse
        {
            Id = applicantId
        }));

        // Action
        _ = await _controller.UpdateApplicantStatusAsync(applicantId, statusId, request);

        // Assert
        _mediatorServiceMock.Verify(x => x.SendAsync<UpdateApplicantStatusCommand, BaseResponse>(It.IsAny<UpdateApplicantStatusCommand>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldDeleteApplicant_Success()
    {
        // Arrange
        const int applicantId = 1;

        _ = _mediatorServiceMock.Setup(x => x.SendAsync(It.IsAny<DeleteApplicantCommand>())).Returns(Task.FromResult(true));

        // Action
        _ = await _controller.DeleteApplicantAsync(applicantId);

        // Assert
        _mediatorServiceMock.Verify(x => x.SendAsync(It.IsAny<DeleteApplicantCommand>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldGetApplicant_Success()
    {
        // Arrange
        const int applicantId = 1;

        var applicant = new Applicant(1, 1, "demo@mail.com", 0, 1, false, true, "demo", "demo", "demo", "country", 1, "demo", 1, new[] { 1 }, DateTime.UtcNow.ToString(), "primaryStreet", "secondaryStreet", "city", "state", "zip", "primaryPhone", "additionalPhone1",
                                     "additionalPhone2", "firstEmergencyContactName", "firstEmergencyContacctAddress", "firstEmergencyContactPhone1", "firstEmergencyContactPhone2", 1,
                                     "secondEmergencyContactName", "secondEmergencyContactAddress", "secondEmergencyContactPhone1", "secondEmergencyContactPhone2", 1, 1, "demo@demo.com",
                                     "textMessagePhone", 1, 1, 1, 1, 1, 1, 1, 1, 1, DateTime.UtcNow, Enumerable.Empty<string>(), "humanResourcePersonaName", 1, true, DateTime.UtcNow, 1, DateTime.UtcNow, 1, 0)
        {
            SocialSecurityNumber = "123-45-6789",
            Ethnicity = 3,
            Gender = 1,
            EmploymentTypeIds = new[] { 1, 2, 3 },
            RegistryNumber = "122e45ha8il0ee3pjb",
            RegistryDate = DateTime.Now,
            NationalProviderIdentity = "123p5j78bh",
            ProfessionalLicenseNumber = "212jsjjshaileeparth9i",
            Signatures = new List<Signature>()
            {
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 1
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 2
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 3
                }
            }
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicantQuery, Applicant>(It.IsAny<GetApplicantQuery>())).ReturnsAsync(applicant);

        // Action
        var response = await _controller.GetApplicantAsync(applicantId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicantQuery, Applicant>(It.IsAny<GetApplicantQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldGetApplicants_Success()
    {
        // Arrange
        var request = new PaginationRequest<SearchApplicantsRequest>
        {
            Filters = new SearchApplicantsRequest { ApplicantName = "Search" },
            Page = new Page { PageNumber = 1, PageSize = 1 }
        };

        var applicant = new Applicant(1, 1, "demo@mail.com", 0, 1, false, true, "demo", "demo", "demo", "country", 1, "demo", 1, new[] { 1 }, DateTime.UtcNow.ToString(), "primaryStreet", "secondaryStreet", "city", "state",
                                    "zip", "primaryPhone", "additionalPhone1", "additionalPhone2", "firstEmergencyContactName", "firstEmergencyContacctAddress", "firstEmergencyContactPhone1", "firstEmergencyContactPhone2", 1,
                                    "secondEmergencyContactName", "secondEmergencyContactAddress", "secondEmergencyContactPhone1", "secondEmergencyContactPhone2", 1, 1, "demo@demo.com",
                                    "textMessagePhone", 1, 1, 1, 1, 1, 1, 1, 1, 1, DateTime.UtcNow, Enumerable.Empty<string>(), "humanResourcePersonaName", 1, true, DateTime.UtcNow, 1, DateTime.UtcNow, 1, 0);

        PaginatationResponse<Applicant> paginatationResponse = new()
        {
            Data = new List<Applicant> { applicant },
            PageInfo = new PageInfo { TotalRecordCount = 1 }
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<SearchApplicantsQuery, PaginatationResponse<Applicant>>(It.IsAny<SearchApplicantsQuery>())).ReturnsAsync(paginatationResponse);

        // Action
        var response = await _controller.SearchApplicantsAsync(request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<SearchApplicantsQuery, PaginatationResponse<Applicant>>(It.IsAny<SearchApplicantsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldFetchAllEmploymentTypes_Success()
    {
        // Arrange
        var employmentTypes = Enumerable.Empty<EmploymentType>().Append(new EmploymentType(1, "HPA", 1, "HPA (skilled)", DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetEmploymentTypesQuery, IEnumerable<EmploymentType>>(It.IsAny<GetEmploymentTypesQuery>())).ReturnsAsync(employmentTypes);

        // Action
        var response = await _controller.GetEmploymentTypesAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetEmploymentTypesQuery, IEnumerable<EmploymentType>>(It.IsAny<GetEmploymentTypesQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldFetchReferalSources_Success()
    {
        const int companyId = 2;
        const int officeId = 3;

        // Arrange
        var referralSources = Enumerable.Empty<ReferralSource>().Append(new ReferralSource(1, "Next source", "Simple", "Caregiver Referral Source", string.Empty, true, officeId, companyId, 'V', true, 1, 1, DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetReferralSourcesQuery, IEnumerable<ReferralSource>>(It.IsAny<GetReferralSourcesQuery>())).ReturnsAsync(referralSources);

        // Action
        var response = await _controller.GetReferralSourcesAsync(new() { OfficeId = officeId });

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetReferralSourcesQuery, IEnumerable<ReferralSource>>(It.IsAny<GetReferralSourcesQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldFetchAllLanguages_Success()
    {
        // Arrange
        var languages = Enumerable.Empty<Language>().Append(new Language(1, "English", "EN", DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetLanguagesQuery, IEnumerable<Language>>(It.IsAny<GetLanguagesQuery>())).ReturnsAsync(languages);

        // Action
        var response = await _controller.GetLanguagesAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetLanguagesQuery, IEnumerable<Language>>(It.IsAny<GetLanguagesQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldFetchAllMaritalStatuses_Success()
    {
        // Arrange
        var statuses = Enumerable.Empty<MaritalStatus>().Append(new MaritalStatus(1, "Single", DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetMaritalStatusesQuery, IEnumerable<MaritalStatus>>(It.IsAny<GetMaritalStatusesQuery>())).ReturnsAsync(statuses);

        // Action
        var response = await _controller.GetMaritalStatusesAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetMaritalStatusesQuery, IEnumerable<MaritalStatus>>(It.IsAny<GetMaritalStatusesQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldFetchAllContactMethods_Success()
    {
        // Arrange
        var contactMethods = Enumerable.Empty<ContactMethod>().Append(new ContactMethod(1, "Email", DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetPreferredContactMethodsQuery, IEnumerable<ContactMethod>>(It.IsAny<GetPreferredContactMethodsQuery>())).ReturnsAsync(contactMethods);

        // Action
        var response = await _controller.GetPreferredContactMethodsAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetPreferredContactMethodsQuery, IEnumerable<ContactMethod>>(It.IsAny<GetPreferredContactMethodsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldFetchRelationships_Success()
    {
        // Arrange
        var relationships = Enumerable.Empty<Relationship>().Append(new Relationship(1, string.Empty, "Brother", string.Empty, string.Empty, true, 1, string.Empty, Guid.NewGuid(), DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        GetRelationshipsRequest request = new() { OfficeId = 1 };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetRelationshipsQuery, IEnumerable<Relationship>>(It.IsAny<GetRelationshipsQuery>())).ReturnsAsync(relationships);

        // Action
        var response = await _controller.GetRelationshipsAsync(request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetRelationshipsQuery, IEnumerable<Relationship>>(It.IsAny<GetRelationshipsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldFetchAllCountries_Success()
    {
        // Arrange
        var countries = Enumerable.Empty<Country>().Append(new Country(1, "Ukraine", "UA", DateTime.UtcNow, 1, DateTime.UtcNow, 1));

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetCountriesQuery, IEnumerable<Country>>(It.IsAny<GetCountriesQuery>())).ReturnsAsync(countries);

        // Action
        var response = await _controller.GetCountriesAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetCountriesQuery, IEnumerable<Country>>(It.IsAny<GetCountriesQuery>()), Times.Once());
    }

    [Fact]
    public async Task Appliant_ShouldFetchAllPreferredContactMethods_Success()
    {
        // Arrange
        var contactMethods = Enumerable.Empty<ContactMethod>().Append(new ContactMethod(1, "Email", DateTime.UtcNow, 12345, DateTime.UtcNow, 12345));

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetPreferredContactMethodsQuery, IEnumerable<ContactMethod>>(It.IsAny<GetPreferredContactMethodsQuery>())).ReturnsAsync(contactMethods);

        // Action
        var response = await _controller.GetPreferredContactMethodsAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetPreferredContactMethodsQuery, IEnumerable<ContactMethod>>(It.IsAny<GetPreferredContactMethodsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldGetLanguageProficiencies_Success()
    {
        // Arrange
        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetLanguageProficienciesQuery, IEnumerable<LanguageProficiency>>(It.IsAny<GetLanguageProficienciesQuery>())).ReturnsAsync((IEnumerable<LanguageProficiency>)new List<LanguageProficiency> {
            new LanguageProficiency (1, "Name", DateTime.UtcNow, 1, DateTime.UtcNow, 1)
        });

        // Action
        var response = await _controller.GetLanguageProficienciesAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetLanguageProficienciesQuery, IEnumerable<LanguageProficiency>>(It.IsAny<GetLanguageProficienciesQuery>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldFetchEthnicity_Success()
    {
        // Arrange
        var ethnicity = new List<Ethnicity>()
        {
            new Ethnicity()
            {
                Id = 1,
                Name = "Native American"
            },
            new Ethnicity()
            {
                Id = 2,
                Name = "Canadian"
            },
            new Ethnicity()
            {
                Id = 3,
                Name = "Indian"
            },
            new Ethnicity()
            {
                Id = 4,
                Name = "African"
            },
            new Ethnicity()
            {
                Id = 5,
                Name = "Nazi"
            }
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetEthnicityQuery, IEnumerable<Ethnicity>>(It.IsAny<GetEthnicityQuery>())).ReturnsAsync(ethnicity);

        // Action
        var response = await _controller.GetEthnicityAsync();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetEthnicityQuery, IEnumerable<Ethnicity>>(It.IsAny<GetEthnicityQuery>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldFetchGender_Success()
    {
        // Arrange
        const int officeId = 851;

        var gender = new List<Gender>()
        {
            new Gender()
            {
                Id = 1,
                Name = "Male"
            },
            new Gender()
            {
                Id = 2,
                Name = "Female"
            },
            new Gender()
            {
                Id = 3,
                Name = "Transgender"
            },
            new Gender()
            {
                Id = 4,
                Name = "Neutral"
            },
            new Gender()
            {
                Id = 5,
                Name = "Other"
            }
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetGenderQuery, IEnumerable<Gender>>(It.IsAny<GetGenderQuery>())).ReturnsAsync(gender);

        // Action
        var response = await _controller.GetGenderAsync(officeId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetGenderQuery, IEnumerable<Gender>>(It.IsAny<GetGenderQuery>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldFetchOnboarding_forms_Success()
    {
        // Arrange
        const int officeId = 851;
        const int applicantId = 921;

        var onboardingForms = new List<ApplicantOnBoardingFormInfo>()
        {
            new ApplicantOnBoardingFormInfo()
            {
                Id = 1,
                OnBoardingFormId= 1,
                Name = "Form 1",
                ApplicantId = applicantId,
                FormResponseId = 21,
                IsActive = true
            },
            new ApplicantOnBoardingFormInfo()
            {
                Id = 2,
                OnBoardingFormId= 2,
                Name = "Form 2",
                IsActive = true
            },
            new ApplicantOnBoardingFormInfo()
            {
                Id = 3,
                OnBoardingFormId= 3,
                Name = "Form 3",
                IsActive = true
            }
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicantOnBoardingFormsQuery, IEnumerable<ApplicantOnBoardingFormInfo>>(It.IsAny<GetApplicantOnBoardingFormsQuery>())).ReturnsAsync(onboardingForms);

        // Action
        var response = await _controller.GetOnboardingForms(officeId, applicantId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicantOnBoardingFormsQuery, IEnumerable<ApplicantOnBoardingFormInfo>>(It.IsAny<GetApplicantOnBoardingFormsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldFetchOnboarding_forms_Signature_Success()
    {
        //Arrange 
        const int applicnatId = 1238;

        var Record = new OnBoardingFormSignatureInfo()
        {
            IsSignatureDrawn = false,
            Signature = "test1",
            SignatureDate = DateTime.UtcNow
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicantOnBoardingFormSignatureQuery, OnBoardingFormSignatureInfo>(It.IsAny<GetApplicantOnBoardingFormSignatureQuery>())).ReturnsAsync(Record);

        //Action
        var response = await _controller.GetOnBoardingFormsSignatureAsync(applicnatId);

        //Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicantOnBoardingFormSignatureQuery, OnBoardingFormSignatureInfo>(It.IsAny<GetApplicantOnBoardingFormSignatureQuery>()), Times.Once());
    }

    [Theory]
    [InlineData(false, "test", false)]
    [InlineData(true, "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mJ8WgAAAAABJRU5ErkJggg==", true)]
    [InlineData(true, "", true)]
    [InlineData(false, "", false)]
    public async Task Applicant_ShouldSaveOnBoardingFormSignature_Success(bool isSignature, string signature, bool isClearOldSignature)
    {
        //Arrange
        const int applicantId = 1;
        var request = new SaveApplicantOnBoardingFormSignatureCommand()
        {
            ApplicantId = applicantId,
            IsSignatureDrawn = isSignature,
            Signature = signature,
            SignatureDate = DateTime.UtcNow,
            IsClearOldSignature = isClearOldSignature
        };

        //Action
        _ = _mediatorServiceMock.Setup(x => x.SendAsync<SaveApplicantOnBoardingFormSignatureCommand, BaseResponse>(It.IsAny<SaveApplicantOnBoardingFormSignatureCommand>())).Returns(Task.FromResult(new BaseResponse
        {
            Id = applicantId
        }));

        var response = await _controller.SaveApplicantOnBoardingFormSignature(request);

        //Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<SaveApplicantOnBoardingFormSignatureCommand, BaseResponse>(It.IsAny<SaveApplicantOnBoardingFormSignatureCommand>()), Times.Once());
    }

    [Fact]
    public async Task Applicant_ShouldUpdateActivityStatus_Success()
    {
        // Arrange
        int[] applicantIds = new int[3] { 1, 2, 3 };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync(It.IsAny<UpdateApplicantActivityStatusCommand>())).Returns(Task.FromResult(Unit.Value));

        // Action
        _ = await _controller.UpdateApplicantActivityStatusAsync(false, applicantIds);
        _ = await _controller.UpdateApplicantActivityStatusAsync(true, applicantIds);

        // Assert
        _mediatorServiceMock.Verify(x => x.SendAsync(It.IsAny<UpdateApplicantActivityStatusCommand>()), Times.Exactly(2));
    }
}
