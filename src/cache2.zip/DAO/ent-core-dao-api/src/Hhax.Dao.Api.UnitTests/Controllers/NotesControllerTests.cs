﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Notes;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Notes;
using Hhax.Dao.Application.Queries.Notes;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Notes;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class NotesControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;
    private readonly NotesController _controller;

    public NotesControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();
        _controller = new NotesController(_mediatorServiceMock.Object);
    }

    [Fact]
    public async Task Notes_ShouldAddNote_Success()
    {
        // Arrange
        AddApplicantNoteRequest request = new()
        {
            ApplicantId = 1,
            Note = "Glorious Purpose - For All Time, Always",
            Status = "OK",
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<AddApplicantNoteRequest, AddApplicantNoteCommand, BaseResponse>(It.IsAny<AddApplicantNoteRequest>())).ReturnsAsync(new BaseResponse()
        {
            Id = 1
        });

        // Action
        var response = await _controller.AddApplicantNoteAsync(request);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<AddApplicantNoteRequest, AddApplicantNoteCommand, BaseResponse>(It.IsAny<AddApplicantNoteRequest>()), Times.Once());
    }

    [Fact]
    public async Task Notes_ShouldFetchAllNotes_Success()
    {
        // Arrange
        const int applicantId = 1;

        List<ApplicantNoteInfo> notes = new()
        {
            new ApplicantNoteInfo()
            {
                NoteId = 1,
                AgencyName = "A",
                ApplicantFirstName = "Parth",
                ApplicantLastName = "Baudhanwala",
                ApplicationWorkflowStatusName = "Application Submitted",
                Text = "Glorious Purpose - For All Time, Always",
                Status = "OK",
            }
        };

        var applicantNoteInfo = new PaginatationResponse<ApplicantNoteInfo>() { Data = notes, PageInfo = new PageInfo { TotalRecordCount = 1 } };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicantNotesQuery, PaginatationResponse<ApplicantNoteInfo>>(It.IsAny<GetApplicantNotesQuery>())).ReturnsAsync(applicantNoteInfo);

        // Action
        var response = await _controller.GetApplicantNotesAsync(applicantId, new PaginationRequest<GetApplicantNotesRequest>());

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicantNotesQuery, PaginatationResponse<ApplicantNoteInfo>>(It.IsAny<GetApplicantNotesQuery>()), Times.Once());
    }

    [Fact]
    public async Task Notes_ShouldFetchAllNoteSubjects_Success()
    {
        // Arrange
        List<NoteSubject> noteSubjects = new()
        {
            new NoteSubject()
            {
                SubjectId = 1,
                Subject = "Glorious Purpose",
                SubjectDescription = string.Empty
            },

            new NoteSubject()
            {
                SubjectId = 2,
                Subject = "Match Fixing",
                SubjectDescription = "IPL Match Fixing."
            },

            new NoteSubject()
            {
                SubjectId = 3,
                Subject = "Global Warming",
                SubjectDescription = null
            }
        };

        _ = _mediatorServiceMock.Setup(x => x.SendAsync<GetNoteSubjectsCommand, IEnumerable<NoteSubject>>(It.IsAny<GetNoteSubjectsCommand>())).ReturnsAsync(noteSubjects);

        // Action
        var response = await _controller.GetNoteSubjects();

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetNoteSubjectsCommand, IEnumerable<NoteSubject>>(It.IsAny<GetNoteSubjectsCommand>()), Times.Once());
    }
}
