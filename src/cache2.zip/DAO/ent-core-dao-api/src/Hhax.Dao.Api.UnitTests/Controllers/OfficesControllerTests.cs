﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Compliance;
using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Application;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class OfficesControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;

    private readonly OfficesController _controller;

    public OfficesControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();

        _controller = new OfficesController(_mediatorServiceMock.Object);
    }

    [Fact]
    public async Task Office_ShouldValidateOfficesComplianceSetups_Success()
    {
        // Arrange
        var request = new OfficeComplianceRequest
        {
            OfficeIds = new[] { 1, 2, 3 }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(It.IsAny<ValidateOfficeComplianceSetupsQuery>())).ReturnsAsync(new CompliancesSetupsValidationResponse
        {
            ComplianceSetupsValidations = new List<ComplianceSetupsValidationResponse> {
                new ComplianceSetupsValidationResponse {
                    IsSuccess = true,
                    Message = string.Empty,
                    OfficeId = 1
                }
            },
            IsValid = true
        });

        // Action
        var result = await _controller.ValidateOfficeComplianceSetupsAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(It.IsAny<ValidateOfficeComplianceSetupsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Office_ShouldValidateSuccessOfficeWithOfficeComplianceSetups_Success()
    {
        // Arrange
        var request = new OfficeComplianceRequest
        {
            OfficeIds = new[] { 1, 2, 3 }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(It.IsAny<ValidateOfficeComplianceSetupsQuery>())).ReturnsAsync(new CompliancesSetupsValidationResponse
        {
            ComplianceSetupsValidations = new List<ComplianceSetupsValidationResponse> {
                new ComplianceSetupsValidationResponse {
                    IsSuccess = true,
                    Message = string.Empty,
                    OfficeId = 1
                },
                 new ComplianceSetupsValidationResponse {
                    IsSuccess = true,
                    Message = string.Empty,
                    OfficeId = 2
                },
                 new ComplianceSetupsValidationResponse {
                    IsSuccess = true,
                    Message = string.Empty,
                    OfficeId = 3
                }
            },
            IsValid = true
        });

        // Action
        var result = await _controller.ValidateOfficeComplianceSetupsAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(It.IsAny<ValidateOfficeComplianceSetupsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Office_ShouldValidateOfficeWithDifferentOfficeComplianceSetups_Success()
    {
        // Arrange
        var request = new OfficeComplianceRequest
        {
            OfficeIds = new[] { 1, 2, 3 }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(It.IsAny<ValidateOfficeComplianceSetupsQuery>())).ReturnsAsync(new CompliancesSetupsValidationResponse
        {
            ComplianceSetupsValidations = new List<ComplianceSetupsValidationResponse> {
                new ComplianceSetupsValidationResponse{
                    IsSuccess = true,
                    Message = "Office compliance setups were validated succssfully.",
                    OfficeId = 1
                },
                 new ComplianceSetupsValidationResponse {
                    IsSuccess = false,
                    Message = "You cannot select offices with different compliance setups applied.",
                    OfficeId = 2
                },
                 new ComplianceSetupsValidationResponse {
                    IsSuccess = false,
                    Message = "You cannot select offices with different compliance setups applied.",
                    OfficeId = 3
                }
            },
            IsValid = true
        });

        // Action
        var result = await _controller.ValidateOfficeComplianceSetupsAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(It.IsAny<ValidateOfficeComplianceSetupsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Office_ShouldValidateOfficeWithoutOfficeComplianceSetups_Success()
    {
        // Arrange
        var request = new OfficeComplianceRequest
        {
            OfficeIds = new[] { 1, 2, 3 }
        };

        _mediatorServiceMock.Setup(x => x.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(It.IsAny<ValidateOfficeComplianceSetupsQuery>())).ReturnsAsync(new CompliancesSetupsValidationResponse
        {
            ComplianceSetupsValidations = new List<ComplianceSetupsValidationResponse> {
                new ComplianceSetupsValidationResponse {
                    IsSuccess = true,
                    Message = "Office compliance setups were validated succssfully.",
                    OfficeId = 1
                },
                 new ComplianceSetupsValidationResponse {
                    IsSuccess = false,
                    Message = "Please create the compliance setup for the selected offices before proceeding with office management setup.",
                    OfficeId = 2
                },
                 new ComplianceSetupsValidationResponse {
                    IsSuccess = false,
                    Message = "Please create the compliance setup for the selected offices before proceeding with office management setup.",
                    OfficeId = 3
                }
            },
            IsValid = true
        });

        // Action
        var result = await _controller.ValidateOfficeComplianceSetupsAsync(request);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(It.IsAny<ValidateOfficeComplianceSetupsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Office_ShouldGetOfficeSetupApplicantRequirements_Success()
    {
        // Arrange
        const int officeId = 1;

        _mediatorServiceMock.Setup(x => x.SendAsync<GetApplicationFormApplicantRequirementsByOfficeIdQuery, IEnumerable<ApplicationFormApplicantRequirement>>(It.IsAny<GetApplicationFormApplicantRequirementsByOfficeIdQuery>())).ReturnsAsync(new List<ApplicationFormApplicantRequirement>());

        // Action
        var result = await _controller.GetApplicationFormApplicantRequirementsAsync(officeId);

        // Assert
        Assert.NotNull(result);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetApplicationFormApplicantRequirementsByOfficeIdQuery, IEnumerable<ApplicationFormApplicantRequirement>>(It.IsAny<GetApplicationFormApplicantRequirementsByOfficeIdQuery>()), Times.Once());
    }
}
