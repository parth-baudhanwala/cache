﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Message;
using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Application.Commands.Message;
using Hhax.Dao.Domain.Message;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers
{
    public class MessagesControllerTests
    {
        private readonly Mock<IMediatorService> _serviceMock;
        private readonly MessagesController _controller;

        public MessagesControllerTests()
        {
            _serviceMock = new Mock<IMediatorService>();
            _controller = new MessagesController(_serviceMock.Object);
        }

        [Fact]
        public async Task Messages_ShouldSendEmai_Success()
        {
            // Arrange
            var request = new SendEmailRequest()
            {
                EmailRecipients = new List<EmailRecipient>(),
                Message = "",
                Subject = ""
            };

            _serviceMock.Setup(x => x.SendAsync<SendEmailRequest, SendEmailCommand, SendMessagesResponse>(It.IsAny<SendEmailRequest>())).ReturnsAsync(new SendMessagesResponse());

            // Action
            var response = await _controller.SendEmailAsync(request);

            // Assert
            Assert.NotNull(response);
            _serviceMock.Verify(x => x.SendAsync<SendEmailRequest, SendEmailCommand, SendMessagesResponse>(It.IsAny<SendEmailRequest>()), Times.Once());
        }

        [Fact]
        public async Task Messages_ShouldSendSms_Success()
        {
            // Arrange
            var request = new SendSmsRequest()
            {
                SmsRecipients = new List<SmsRecipient>(),
                Message = ""
            };

            _serviceMock.Setup(x => x.SendAsync<SendSmsRequest, SendSmsCommand, SendMessagesResponse>(It.IsAny<SendSmsRequest>())).ReturnsAsync(new SendMessagesResponse());

            // Action
            var response = await _controller.SendSmsAsync(request);

            // Assert
            Assert.NotNull(response);
            _serviceMock.Verify(x => x.SendAsync<SendSmsRequest, SendSmsCommand, SendMessagesResponse>(It.IsAny<SendSmsRequest>()), Times.Once());
        }

        [Theory]
        [InlineData(MessageTemplateType.Sms)]
        [InlineData(MessageTemplateType.Email)]
        public async Task Messages_ShouldReturnTemplates_Success(MessageTemplateType messageTemplateType)
        {
            // Arrange
            var request = new GetTemplatesRequest()
            {
                OfficeIds = new List<int>() { 851 },
                TemplateType = messageTemplateType
            };

            _serviceMock.Setup(x => x.SendAsync<GetTemplatesRequest, IEnumerable<MessageTemplate>>(It.IsAny<GetTemplatesRequest>())).ReturnsAsync(new List<MessageTemplate>());

            // Action
            var response = await _controller.GetMessageTemplates(request);

            // Assert
            Assert.NotNull(response);
            _serviceMock.Verify(x => x.SendAsync<GetTemplatesRequest, IEnumerable<MessageTemplate>>(It.IsAny<GetTemplatesRequest>()), Times.Once());
        }
    }
}
