﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.MedicalsOther;
using Hhax.Dao.Application.Queries.MedicalsOther;
using Hhax.Dao.Domain.MedicalsOther;
using Moq;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class MedicalsOtherRequirementsControllerTests
{
    private readonly Mock<IMediatorService> _mediatorServiceMock;
    private readonly Mock<IFilesUploadService> _complianceFileGatewayMock;

    private readonly MedicalsOtherRequirementsController _controller;

    public MedicalsOtherRequirementsControllerTests()
    {
        _mediatorServiceMock = new Mock<IMediatorService>();
        _complianceFileGatewayMock = new Mock<IFilesUploadService>();

        _controller = new MedicalsOtherRequirementsController(_mediatorServiceMock.Object,
                                                              _complianceFileGatewayMock.Object);
    }

    [Fact]
    public async Task MedicalsOtherRequirements_ShouldRetrieveMedicalsRequirements_Success()
    {
        // Arrange
        const int applicantId = 111;
        const int officeId = 222;

        _mediatorServiceMock.Setup(x => x.SendAsync<GetMedicalsRequirementsQuery, IEnumerable<MedicalsApplicantValue>>(It.IsAny<GetMedicalsRequirementsQuery>())).ReturnsAsync(new List<MedicalsApplicantValue>
        {
            new() { Id = 1 },
            new() { Id = 2 },
        });

        // Action
        var response = await _controller.GetMedicalsRequirements(applicantId, officeId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetMedicalsRequirementsQuery, IEnumerable<MedicalsApplicantValue>>(It.IsAny<GetMedicalsRequirementsQuery>()), Times.Once());
    }

    [Fact]
    public async Task MedicalsOtherRequirements_ShouldDeleteMedicalsRequirements_Success()
    {
        // Arrange
        const int applicantId = 111;
        List<int> ids = new() { 1, 2 };

        // Action
        var response = await _controller.DeleteMedicalsRequirements(applicantId, ids);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync(It.IsAny<DeleteMedicalsRequirementsCommand>()), Times.Once());
    }

    [Fact]
    public async Task MedicalsOtherRequirements_ShouldUpsertMedicalsRequirements_Success()
    {
        // Arrange
        const int applicantId = 111;
        MedicalsApplicantValue data = new() { Id = 1, ApplicantId = applicantId };

        _mediatorServiceMock.Setup(x => x.SendAsync<UpsertMedicalsRequirementsCommand, BaseResponse>(It.IsAny<UpsertMedicalsRequirementsCommand>())).ReturnsAsync(new BaseResponse
        {
            Id = 1
        });

        // Action
        var response = await _controller.SaveMedicalsRequirements(applicantId, data);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<UpsertMedicalsRequirementsCommand, BaseResponse>(It.IsAny<UpsertMedicalsRequirementsCommand>()), Times.Once());
    }

    [Fact]
    public async Task MedicalsOtherRequirements_ShouldRetrieveOtherRequirements_Success()
    {
        // Arrange
        const int applicantId = 111;
        const int officeId = 222;

        _mediatorServiceMock.Setup(x => x.SendAsync<GetOtherRequirementsQuery, IEnumerable<OtherApplicantValue>>(It.IsAny<GetOtherRequirementsQuery>())).ReturnsAsync(new List<OtherApplicantValue>
        {
            new() { Id = 1 },
            new() { Id = 2 },
        });

        // Action
        var response = await _controller.GetOtherRequirements(applicantId, officeId);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<GetOtherRequirementsQuery, IEnumerable<OtherApplicantValue>>(It.IsAny<GetOtherRequirementsQuery>()), Times.Once());
    }

    [Fact]
    public async Task MedicalsOtherRequirements_ShouldDeleteOtherRequirements_Success()
    {
        // Arrange
        const int applicantId = 111;
        List<int> ids = new() { 1, 2 };

        // Action
        var response = await _controller.DeleteOtherRequirements(applicantId, ids);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync(It.IsAny<DeleteOtherRequirementsCommand>()), Times.Once());
    }

    [Fact]
    public async Task MedicalsOtherRequirements_ShouldUpsertOtherRequirements_Success()
    {
        // Arrange
        const int applicantId = 111;
        OtherApplicantValue data = new() { Id = 1, ApplicantId = applicantId };

        _mediatorServiceMock.Setup(x => x.SendAsync<UpsertOtherRequirementsCommand, BaseResponse>(It.IsAny<UpsertOtherRequirementsCommand>())).ReturnsAsync(new BaseResponse
        {
            Id = 1
        });

        // Action
        var response = await _controller.SaveOtherRequirements(applicantId, data);

        // Assert
        Assert.NotNull(response);

        _mediatorServiceMock.Verify(x => x.SendAsync<UpsertOtherRequirementsCommand, BaseResponse>(It.IsAny<UpsertOtherRequirementsCommand>()), Times.Once());
    }
}
