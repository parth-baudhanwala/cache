﻿using Hhax.Dao.Api.Host.Controllers;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Permission;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using Hhax.Dao.Application.Commands.Account;
using Hhax.Dao.Application.Queries.Account;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Security.Claims;
using Xunit;

namespace Hhax.Dao.Api.UnitTests.Controllers;

public class AccountsControllerTests
{
    private readonly Mock<IMediatorService> _serviceMock;

    private readonly AccountsController _controller;

    public AccountsControllerTests()
    {
        _serviceMock = new Mock<IMediatorService>();

        _controller = new AccountsController(_serviceMock.Object);

        const string vendoridType = "vendorid";

        const int userId = 38974;
        const int vendorId = 691;

        var claims = new List<Claim> {
            new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
            new Claim(vendoridType, vendorId.ToString())
        };
        var claimsIdentity = new ClaimsIdentity(claims);
        var user = new ClaimsPrincipal(claimsIdentity);
        var controllerContext = new ControllerContext
        {
            HttpContext = new DefaultHttpContext
            {
                User = user
            }
        };
        _controller.ControllerContext = controllerContext;
    }

    [Fact]
    public async Task Account_ShouldGetPermissions_Success()
    {
        // Arrange
        _serviceMock.Setup(x => x.SendAsync<GetPermissionsQuery, PermissionsResponse>(It.IsAny<GetPermissionsQuery>())).ReturnsAsync(new PermissionsResponse
        {
            Permissions = new[] { HhaxPermissions.CanViewApplicationProcessManagement }
        });

        // Action
        var response = await _controller.GetPermissionsAsync();

        // Assert
        Assert.NotNull(response);

        _serviceMock.Verify(x => x.SendAsync<GetPermissionsQuery, PermissionsResponse>(It.IsAny<GetPermissionsQuery>()), Times.Once());
    }

    [Fact]
    public async Task Account_ShouldValidatePermissions_Success()
    {
        // Arrange
        var request = new PermissionsRequest();

        _serviceMock.Setup(x => x.SendAsync<PermissionsRequest, ValidatePermissionsByIdsCommand, ValidatePermissionsResponse>(request)).ReturnsAsync(new ValidatePermissionsResponse
        {
            IsAccessDenied = false
        });

        // Action
        var response = await _controller.ValidatePermissionsAsync(request);

        // Assert
        Assert.NotNull(response);

        _serviceMock.Verify(x => x.SendAsync<PermissionsRequest, ValidatePermissionsByIdsCommand, ValidatePermissionsResponse>(request), Times.Once());
    }
}
