﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Compliance;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using Hhax.Dao.Application.Commands.Office;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Office;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IO;

namespace Hhax.Dao.Api.Host.Controllers;

[Authorize,
 ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/offices"),
 ApiController]
public class OfficesController : ControllerBase
{
    private readonly IMediatorService _service;

    public OfficesController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Validate office compliance setups
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [HttpPost("compliances/setups/validate"),
     ProducesResponseType(typeof(CompliancesSetupsValidationResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ValidateOfficeComplianceSetupsAsync([FromBody] OfficeComplianceRequest request)
    {
        var query = new ValidateOfficeComplianceSetupsQuery(request.OfficeIds);

        var response = await _service.SendAsync<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get offices
    /// </summary>
    /// <returns></returns>
    [HttpGet,
     ProducesResponseType(typeof(IEnumerable<OfficeHierarchy>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetOfficesAsync()
    {
        var query = new GetOfficesQuery();

        var response = await _service.SendAsync<GetOfficesQuery, IEnumerable<OfficeHierarchy>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get application form applicant requirements
    /// </summary>
    /// <returns></returns>
    [HttpGet("{officeId}/applicant-requirements"),
     ProducesResponseType(typeof(IEnumerable<ApplicationFormApplicantRequirement>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicationFormApplicantRequirementsAsync([FromRoute] int officeId)
    {
        var query = new GetApplicationFormApplicantRequirementsByOfficeIdQuery(officeId);

        var response = await _service.SendAsync<GetApplicationFormApplicantRequirementsByOfficeIdQuery, IEnumerable<ApplicationFormApplicantRequirement>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get image
    /// </summary>
    [HttpGet("{officeId}/image"),
     ProducesResponseType(typeof(FileContentResult), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetImageAsync([FromRoute] int officeId, [FromQuery] OfficeImageRequest request)
    { 
        const string imageContentType = "image/webp";

        var query = new GetOfficeImageQuery(officeId, request.Type!);

        var fileContents = await _service.SendAsync<GetOfficeImageQuery, byte[]>(query);

        return File(fileContents, imageContentType);
    }

    /// <summary>
    /// Get image url
    /// </summary>
    [HttpGet("{officeId}/image-url"),
     ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetImageUrlAsync([FromRoute] int officeId, [FromQuery] OfficeImageRequest request)
    {
        var query = new GetOfficeImageUrlQuery(officeId, request.Type!);

        var response = await _service.SendAsync<GetOfficeImageUrlQuery, string>(query);

        return Ok(response);
    }

    /// <summary>
    /// Upload image
    /// </summary>
    [HttpPost("{officeId}/image"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> UploadImageAsync([FromRoute] int officeId, [FromQuery] UploadOfficeImageRequest request, [FromForm] IFormFile file)
    {
        using (var inputStream = file.OpenReadStream())
        {
            var recyclableMemoryStreamManager = new RecyclableMemoryStreamManager();
            using var memoryStream = recyclableMemoryStreamManager.GetStream();
            inputStream.CopyTo(memoryStream);
            memoryStream.Seek(0, SeekOrigin.Begin);

            var command = new UploadImageCommand(officeId, request.Type!, file.FileName, memoryStream, request.Width, request.Height);

            await _service.SendAsync(command);
        }

        return NoContent();
    }

    /// <summary>
    /// Office level disciplines
    /// </summary>
    /// <param name="officeId"></param>
    /// <returns>Office level configured disciplines</returns>
    [AllowAnonymous,
    HttpGet("{officeId}/disciplines"),
    ProducesResponseType(typeof(IEnumerable<OfficeDisciplineResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetOfficeDisciplines([FromRoute] int officeId)
    {
        var query = new GetOfficeDisciplinesQuery(officeId);

        var response = await _service.SendAsync<GetOfficeDisciplinesQuery, IEnumerable<OfficeDisciplineResponse>>(query);

        return Ok(response);
    }
}
