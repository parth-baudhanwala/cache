﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Notes;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Notes;
using Hhax.Dao.Application.Queries.Notes;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Notes;

namespace Hhax.Dao.Api.Host.Controllers;

[ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/notes"),
 ApiController]
public class NotesController : ControllerBase
{
    private readonly IMediatorService _service;

    public NotesController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Add applicant note.
    /// </summary>
    /// <param name="request"></param>
    /// <returns>1 for note added successfully otherwise 0.</returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpPost("applicant-notes"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> AddApplicantNoteAsync([FromBody] AddApplicantNoteRequest request)
    {
        var response = await _service.SendAsync<AddApplicantNoteRequest, AddApplicantNoteCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Get applicant notes.
    /// </summary>
    /// <param name="applicantId"></param>
    /// <returns>List of applicant notes.</returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("applicant-notes/{applicantId}"),
     ProducesResponseType(typeof(PaginatationResponse<ApplicantNoteInfo>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantNotesAsync([FromRoute] int applicantId, [FromQuery] PaginationRequest<GetApplicantNotesRequest> request)
    {
        var query = new GetApplicantNotesQuery(applicantId, request);

        var response = await _service.SendAsync<GetApplicantNotesQuery, PaginatationResponse<ApplicantNoteInfo>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get note subjects.
    /// </summary>
    /// <returns>List of note subjects.</returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("note-subjects"),
     ProducesResponseType(typeof(IEnumerable<NoteSubject>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetNoteSubjects()
    {
        var noteSubjects = await _service.SendAsync<GetNoteSubjectsCommand, IEnumerable<NoteSubject>>(new());

        return Ok(noteSubjects);
    }
}
