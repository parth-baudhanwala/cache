﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Availability;
using Hhax.Dao.Application.Queries.Availability;
using Hhax.Dao.Domain.Availability;
using Hhax.Dao.Infrastructure.Host.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hhax.Dao.Api.Host.Controllers;

[ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/availability"),
 ApiController]
public class AvailabilityController : ControllerBase
{
    private readonly IMediatorService _service;

    public AvailabilityController(IMediatorService service)
        => _service = service;

    [Authorize,
     HttpGet("work-preferences"),
     ProducesResponseType(typeof(IEnumerable<WorkPreference>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetPreferences()
    {
        var query = new GetWorkPreferencesQuery();

        var response = await _service.SendAsync<GetWorkPreferencesQuery, IEnumerable<WorkPreference>>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}"),
     ProducesResponseType(typeof(ApplicantAvailability), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantAvailability([FromRoute] int applicantId)
    {
        var query = new GetApplicantAvailabilityQuery(applicantId);

        var response = await _service.SendAsync<GetApplicantAvailabilityQuery, ApplicantAvailability>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpPut("{applicantId}/days"),
     ProducesResponseType(typeof(IEnumerable<BaseRangeResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> SetupApplicantAvailability([FromRoute] int applicantId, [FromBody] ApplicantAvailability availability)
    {
        var command = new UpsertApplicantAvailabilityCommand(applicantId, availability.Days, availability.Signature);

        var resposne = await _service.SendAsync<UpsertApplicantAvailabilityCommand, BaseRangeResponse>(command);

        return Ok(resposne);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpDelete("{applicantId}/time-shifts"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteApplicantAvailabilityTimeShifts([FromRoute] int applicantId, [FromForm] IEnumerable<int> ids)
    {
        var command = new DeleteApplicantAvailabilityCommand(applicantId, ids.Where(x => x > 0));

        await _service.SendAsync(command);

        return NoContent();
    }
}
