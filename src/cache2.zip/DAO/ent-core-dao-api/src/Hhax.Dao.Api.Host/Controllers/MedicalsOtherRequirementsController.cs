﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.MedicalsOther;
using Hhax.Dao.Application.Queries.MedicalsOther;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Host.Attributes;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Hhax.Dao.Api.Host.Controllers;

[ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/medicals-other-requirements"),
 ApiController]
public class MedicalsOtherRequirementsController : ControllerBase
{
    private readonly IMediatorService _service;
    private readonly IFilesUploadService _filesUploadService;

    public MedicalsOtherRequirementsController(IMediatorService service,
                                               IFilesUploadService filesUploadService)
    {
        _service = service;
        _filesUploadService = filesUploadService;
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("medicals/{applicantId:int}"),
     ProducesResponseType(typeof(IEnumerable<MedicalsApplicantValue>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetMedicalsRequirements([FromRoute] int applicantId, [FromQuery] int officeId)
    {
        var query = new GetMedicalsRequirementsQuery(applicantId, officeId);

        var response = await _service.SendAsync<GetMedicalsRequirementsQuery, IEnumerable<MedicalsApplicantValue>>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpPut("medicals/{applicantId:int}"),
     OnlyForApplicants,
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveMedicalsRequirements([FromRoute] int applicantId, [FromForm] MedicalsApplicantValue data)
    {
        IFormFileCollection? files = Request?.Form?.Files;

        if (files is not null)
        {
            var filesSize = files.Sum(c => c.Length);
            var validationResponse = await _filesUploadService.ValidateTotalFileSizeLimitByProviderAsync(filesSize);
            if (validationResponse != null && !validationResponse.IsSaved) throw new ValidationException(validationResponse.ErrorMessage);

            data.FileKey = await _filesUploadService.UploadDocumentAsync(ComplianceFileType.MedicalsRequirements, files, applicantId, documentTypeId: data.ComplianceExpItemId);
        }

        var command = new UpsertMedicalsRequirementsCommand(applicantId, data);

        var response = await _service.SendAsync<UpsertMedicalsRequirementsCommand, BaseResponse>(command);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpDelete("medicals/{applicantId:int}"),
     OnlyForApplicants,
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteMedicalsRequirements([FromRoute] int applicantId, [FromForm] IEnumerable<int> ids)
    {
        var command = new DeleteMedicalsRequirementsCommand(applicantId, ids);

        await _service.SendAsync(command);

        return NoContent();
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("other/{applicantId:int}"),
     ProducesResponseType(typeof(IEnumerable<OtherApplicantValue>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetOtherRequirements([FromRoute] int applicantId, [FromQuery] int officeId)
    {
        var query = new GetOtherRequirementsQuery(applicantId, officeId);

        var response = await _service.SendAsync<GetOtherRequirementsQuery, IEnumerable<OtherApplicantValue>>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpPut("other/{applicantId:int}"),
     OnlyForApplicants,
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveOtherRequirements([FromRoute] int applicantId, [FromForm] OtherApplicantValue data)
    {
        IFormFileCollection? files = Request?.Form?.Files;

        if (files is not null)
        {
            var filesSize = files.Sum(c => c.Length);
            var validationResponse = await _filesUploadService.ValidateTotalFileSizeLimitByProviderAsync(filesSize);
            if (validationResponse != null && !validationResponse.IsSaved) throw new ValidationException(validationResponse.ErrorMessage);

            data.FileKey = await _filesUploadService.UploadDocumentAsync(ComplianceFileType.OtherRequirements, files, applicantId, documentTypeId: data.ComplianceExpItemId);
        }

        var command = new UpsertOtherRequirementsCommand(applicantId, data);

        var response = await _service.SendAsync<UpsertOtherRequirementsCommand, BaseResponse>(command);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpDelete("other/{applicantId:int}"),
     OnlyForApplicants,
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteOtherRequirements([FromRoute] int applicantId, [FromForm] IEnumerable<int> ids)
    {
        var command = new DeleteOtherRequirementsCommand(applicantId, ids);

        await _service.SendAsync(command);

        return NoContent();
    }
}
