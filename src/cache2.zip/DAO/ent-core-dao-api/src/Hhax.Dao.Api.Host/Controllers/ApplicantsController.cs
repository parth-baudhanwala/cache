﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Application;
using Hhax.Dao.Application.Abstracts.Responses.Caregiver;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.FormBuilder;
using Hhax.Dao.Application.Abstracts.Responses.MailVerification;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Caregiver;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Host.Attributes;
using System.ComponentModel.DataAnnotations;
using System.Net;

namespace Hhax.Dao.Api.Host.Controllers;

[ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/applicants"),
 ApiController]
public class ApplicantsController : ControllerBase
{
    private readonly IMediatorService _service;
    private readonly IFilesUploadService _filesUploadService;

    public ApplicantsController(IMediatorService service, IFilesUploadService filesUploadService)
    {
        _service = service;
        _filesUploadService = filesUploadService;
    }

    /// <summary>
    /// Add applicant
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpPost,
     ProducesResponseType(typeof(IEnumerable<BaseResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> AddApplicantAsync([FromBody] ApplicantAddRequest request)
    {
        var response = await _service.SendAsync<ApplicantAddRequest, AddApplicantCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Resent Applicant Email
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpPost("{applicantId}/resent-mail"),
     ProducesResponseType(typeof(MailVerificationResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ResentApplicantEmail([FromRoute] int applicantId, [FromBody] ApplicantEmailResentRequest request)
    {
        var query = new ResentApplicantMailQuery(applicantId, request);

        var response = await _service.SendAsync<ResentApplicantMailQuery, MailVerificationResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Verify Applicant Email
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("{applicantId}/verify-mail/{key}"),
     ProducesResponseType(typeof(MailVerificationResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> VerifyApplicantEmail([FromRoute] int applicantId, [FromRoute] string key)
    {
        var query = new VerifyApplicantMailQuery(applicantId, key);

        var response = await _service.SendAsync<VerifyApplicantMailQuery, MailVerificationResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Send Applicant Forgot Password Email
    /// </summary>
    [AllowAnonymous,
     HttpPost("forgot-password"),
     ProducesResponseType(typeof(ForgotPasswordApplicantResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ForgotPasswordApplicant([FromBody] ForgotPasswordApplicantRequest request)
    {
        var query = new ForgotPasswordApplicantQuery(request.Email, request.Domain);

        var response = await _service.SendAsync<ForgotPasswordApplicantQuery, ForgotPasswordApplicantResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Check if reset password key is expired
    /// </summary>
    [AllowAnonymous,
     HttpGet("{applicantId}/ckeck-reset-password/{key}"),
     ProducesResponseType(typeof(CheckResetPasswordKeyApplicantResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> CheckResetPasswordKeyApplicant([FromRoute] int applicantId, [FromRoute] string key)
    {
        var query = new CheckResetPasswordKeyApplicantQuery(applicantId, key);

        var response = await _service.SendAsync<CheckResetPasswordKeyApplicantQuery, CheckResetPasswordKeyApplicantResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Reset password
    /// </summary>
    [AllowAnonymous,
     HttpPost("{applicantId}/reset-password"),
     ProducesResponseType(typeof(ResetPasswordApplicantResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ResetPasswordApplicant([FromRoute] int applicantId, [FromBody] ResetPasswordApplicantRequest request)
    {
        var query = new ResetPasswordApplicantQuery(applicantId, request.Key, request.Password);

        var response = await _service.SendAsync<ResetPasswordApplicantQuery, ResetPasswordApplicantResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Search applicants
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet,
     ProducesResponseType(typeof(PaginatationResponse<Applicant>), StatusCodes.Status200OK)]
    public async Task<IActionResult> SearchApplicantsAsync([FromQuery] PaginationRequest<SearchApplicantsRequest> request)
    {
        var query = new SearchApplicantsQuery(request);

        var response = await _service.SendAsync<SearchApplicantsQuery, PaginatationResponse<Applicant>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get applicant
    /// </summary>
    /// <param name="applicantId"></param>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}"),
     ProducesResponseType(typeof(Applicant), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantAsync([FromRoute] int applicantId)
    {
        var query = new GetApplicantQuery(applicantId);

        var response = await _service.SendAsync<GetApplicantQuery, Applicant>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get current user applicant
    /// </summary>
    [Authorize,
     HttpGet("for-current-user"),
     ProducesResponseType(typeof(Applicant), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetCurrentUserApplicantAsync()
    {
        var query = new GetApplicantForUserQuery();

        var response = await _service.SendAsync<GetApplicantForUserQuery, Applicant>(query);

        return Ok(response);
    }

    /// <summary>
    /// Update applicant
    /// </summary>
    /// <param name="applicantId"></param>
    /// <param name="request"></param>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpPut("{applicantId}"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateApplicantAsync([FromRoute] int applicantId, [FromBody] ApplicantUpdateRequest request)
    {
        request.Id = applicantId;

        var response = await _service.SendAsync<ApplicantUpdateRequest, UpdateApplicantCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Get status if applicant data for the CAP
    /// </summary>
    /// <param name="applicantId"></param>
    /// <param name="officeId"></param>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/data-status"),
     ProducesResponseType(typeof(ApplicantDataStatus), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantDataStatusAsync([FromRoute] int applicantId, [FromQuery] int officeId)
    {
        var query = new GetApplicantDataStatusQuery(applicantId, officeId);

        var response = await _service.SendAsync<GetApplicantDataStatusQuery, ApplicantDataStatus>(query);

        return Ok(response);
    }

    /// <summary>
    /// Update applicant
    /// </summary>
    /// <param name="applicantId"></param>
    /// <param name="request"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpPut("{applicantId}/set-status/{statusId}"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateApplicantStatusAsync([FromRoute] int applicantId, [FromRoute] int statusId, [FromBody] ApplicantUpdateWorkflowStatusRequest request)
    {
        var command = new UpdateApplicantStatusCommand(applicantId, statusId, request);

        var response = await _service.SendAsync<UpdateApplicantStatusCommand, BaseResponse>(command);

        return Ok(response);
    }

    /// <summary>
    /// Delete applicant
    /// </summary>
    /// <param name="applicantId"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpDelete("{applicantId}"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteApplicantAsync([FromRoute] int applicantId)
    {
        var command = new DeleteApplicantCommand(applicantId);

        await _service.SendAsync(command);

        return NoContent();
    }

    /// <summary>
    /// Retrieve employment types
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("employment-types"),
     ProducesResponseType(typeof(IEnumerable<EmploymentType>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetEmploymentTypesAsync()
    {
        var query = new GetEmploymentTypesQuery();

        var response = await _service.SendAsync<GetEmploymentTypesQuery, IEnumerable<EmploymentType>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Retrieve referal sources
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("referral-sources"),
     ProducesResponseType(typeof(IEnumerable<ReferralSource>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetReferralSourcesAsync([FromQuery] GetReferralSourcesRequest request)
    {
        var query = new GetReferralSourcesQuery(request.OfficeId);

        var response = await _service.SendAsync<GetReferralSourcesQuery, IEnumerable<ReferralSource>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Retrieve languages
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("languages"),
     ProducesResponseType(typeof(IEnumerable<Language>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetLanguagesAsync()
    {
        var query = new GetLanguagesQuery();

        var response = await _service.SendAsync<GetLanguagesQuery, IEnumerable<Language>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Retrieve marital statuses
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("marital-statuses"),
     ProducesResponseType(typeof(IEnumerable<MaritalStatus>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetMaritalStatusesAsync()
    {
        var query = new GetMaritalStatusesQuery();

        var response = await _service.SendAsync<GetMaritalStatusesQuery, IEnumerable<MaritalStatus>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Retrieve relationships
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("relationships"),
     ProducesResponseType(typeof(IEnumerable<Relationship>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetRelationshipsAsync([FromQuery] GetRelationshipsRequest request)
    {
        var query = new GetRelationshipsQuery(request.OfficeId);

        var response = await _service.SendAsync<GetRelationshipsQuery, IEnumerable<Relationship>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Retrieve relationships
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("countries"),
     ProducesResponseType(typeof(IEnumerable<Country>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetCountriesAsync()
    {
        var query = new GetCountriesQuery();

        var response = await _service.SendAsync<GetCountriesQuery, IEnumerable<Country>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Retrieve contact methods
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("preferred-contact-methods"),
     ProducesResponseType(typeof(IEnumerable<ContactMethod>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetPreferredContactMethodsAsync()
    {
        var query = new GetPreferredContactMethodsQuery();

        var response = await _service.SendAsync<GetPreferredContactMethodsQuery, IEnumerable<ContactMethod>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get language proficiences
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("language-proficiencies"),
     ProducesResponseType(typeof(IEnumerable<ContactMethod>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetLanguageProficienciesAsync()
    {
        var query = new GetLanguageProficienciesQuery();

        var response = await _service.SendAsync<GetLanguageProficienciesQuery, IEnumerable<LanguageProficiency>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Validate uniqueness for login email
    /// </summary>
    /// <returns></returns>
    [HttpGet("credentials/email-unique"),
     ProducesResponseType(typeof(ValidationResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ValidateLoginEmailUniquenessAsync([FromQuery] string email)
    {
        var query = new ValidateLoginEmailUniquenessQuery(email);

        var response = await _service.SendAsync<ValidateLoginEmailUniquenessQuery, ValidationResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Validate uniqueness for contact email
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("preferred-contact-methods/email-unique"),
     ProducesResponseType(typeof(ValidationResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ValidateContactEmailUniquenessAsync([FromQuery] string email)
    {
        var query = new ValidateContactEmailUniquenessQuery(email);

        var response = await _service.SendAsync<ValidateContactEmailUniquenessQuery, ValidationResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Validate uniqueness for contact email
    /// </summary>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/preferred-contact-methods/email-unique"),
     ProducesResponseType(typeof(ValidationResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ValidateContactEmailUniquenessAsync([FromRoute] int applicantId, [FromQuery] string email)
    {
        var query = new ValidateContactEmailUniquenessQuery(email, applicantId);

        var response = await _service.SendAsync<ValidateContactEmailUniquenessQuery, ValidationResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Validate uniqueness for phone
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("preferred-contact-methods/phone-unique"),
     ProducesResponseType(typeof(ValidationResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ValidatePhoneUniquenessAsync([FromQuery] string phoneNumber)
    {
        var query = new ValidatePhoneUniquenessQuery(phoneNumber);

        var response = await _service.SendAsync<ValidatePhoneUniquenessQuery, ValidationResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Validate uniqueness for phone
    /// </summary>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/preferred-contact-methods/phone-unique"),
     ProducesResponseType(typeof(ValidationResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ValidatePhoneUniquenessAsync([FromRoute] int applicantId, [FromQuery] string phoneNumber)
    {
        var query = new ValidatePhoneUniquenessQuery(phoneNumber, applicantId);

        var response = await _service.SendAsync<ValidatePhoneUniquenessQuery, ValidationResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Convert applicant to caregiver.
    /// </summary>
    /// <param name="applicantId"></param>
    /// <returns>Caregiver identity with errors or warnings. If caregiver identity is less than or equal to 0 then caregiver has not saved.</returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpPost("convert-applicant-to-caregiver/{applicantId}/set-status/{statusId}"),
     ProducesResponseType(typeof(CreateCaregiverResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ConvertApplicantToCaregiver([FromRoute] int applicantId, [FromRoute] int statusId, [FromBody] ApplicantUpdateWorkflowStatusRequest request)
    {
        ConvertToCaregiverCommand command = new(applicantId);

        var caregiverResponse = await _service.SendAsync<ConvertToCaregiverCommand, CreateCaregiverResponse>(command);

        if (caregiverResponse.CaregiverId <= 0)
        {
            if (!caregiverResponse.ResponseMessages.Any())
            {
                return Problem(statusCode: (int)HttpStatusCode.InternalServerError);
            }
            return BadRequest(caregiverResponse);
        }

        await _service.SendAsync<UpdateApplicantStatusCommand, BaseResponse>(new(applicantId, statusId, request, caregiverResponse.GlobalCaregiverId));
        return Ok(caregiverResponse);
    }

    /// <summary>
    /// Get applicant custom fields
    /// </summary>
    /// <param name="applicantId"></param>
    /// <param name="officeId"></param>
    /// <returns>List of applicant's custom fields with values.</returns>
    [AllowAnonymous,
     HttpGet("{applicantId}/applicant-custom-fields/{officeId}"),
     ProducesResponseType(typeof(IEnumerable<ApplicantCustomFieldInfo>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantCustomFields([FromRoute] int applicantId, [FromRoute] int officeId)
    {
        GetApplicantCustomFieldCommand command = new(applicantId, officeId);

        var applicantCustomFields = await _service.SendAsync<GetApplicantCustomFieldCommand, IEnumerable<ApplicantCustomFieldInfo>>(command);

        return Ok(applicantCustomFields);
    }

    /// <summary>
    /// Save applicant custom fields.
    /// </summary>
    /// <param name="applicantId"></param>
    /// <param name="applicantCustomFields"></param>
    /// <returns>Saved identities of applicant custom fields.</returns>
    [AllowAnonymous,
     HttpPut("{applicantId}/applicant-custom-fields"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveApplicantCustomFields([FromRoute] int applicantId, [FromForm] IEnumerable<ApplicantCustomField> applicantCustomFields)
    {
        var customFieldsFileSize = applicantCustomFields.Sum(c => c.FileSize);
        var validationResponse = await _filesUploadService.ValidateTotalFileSizeLimitByProviderAsync(customFieldsFileSize);
        if (validationResponse != null && !validationResponse.IsSaved) throw new ValidationException(validationResponse.ErrorMessage);

        SaveApplicantCustomFieldCommand command = new(applicantId, applicantCustomFields);
        var response = await _service.SendAsync<SaveApplicantCustomFieldCommand, BaseResponse>(command);

        return Ok(response);
    }

    /// <summary>
    /// Retrieve ethnicity
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("ethnicity"),
     ProducesResponseType(typeof(IEnumerable<Ethnicity>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetEthnicityAsync()
    {
        var response = await _service.SendAsync<GetEthnicityQuery, IEnumerable<Ethnicity>>(new());

        return Ok(response);
    }

    /// <summary>
    /// Retrieve gender
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("gender"),
     ProducesResponseType(typeof(IEnumerable<Gender>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetGenderAsync([FromQuery] int officeId)
    {
        var response = await _service.SendAsync<GetGenderQuery, IEnumerable<Gender>>(new(officeId));

        return Ok(response);
    }

    /// <summary> 
    /// Retrive Application Onboarding Forms
    /// </summary>
    /// <param name="officeId"></param>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/onboarding_forms"),
     ProducesResponseType(typeof(IEnumerable<ApplicantOnBoardingFormInfo>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetOnboardingForms([FromQuery] int officeId, [FromRoute] int applicantId)
    {
        var response = await _service.SendAsync<GetApplicantOnBoardingFormsQuery, IEnumerable<ApplicantOnBoardingFormInfo>>(new() { OfficeId = officeId, ApplicantId = applicantId });

        return Ok(response);
    }

    /// <summary> 
    /// Save Form Response Id for Onboarding Form
    /// </summary>
    /// <param name="applicantId"></param>
    /// <param name="onBoardingFormId"></param>
    /// <param name="officeId"></param>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/generate_form_response/{onBoardingFormId}"),
     ProducesResponseType(typeof(FormDataResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> GenerateFormResponseId([FromRoute] int applicantId, [FromRoute] int onBoardingFormId, [FromQuery] int officeId)
    {
        var response = await _service.SendAsync<GenerateApplicantFormResponseIdCommand, FormDataResponse>(new() { ApplicantId = applicantId, OfficeId = officeId, OnBoardingFormId = onBoardingFormId });

        return Ok(response);
    }

    /// <summary>
    /// Retrieve Onboarding Forms Signature
    /// </summary>
    /// <param name="applicantId"></param>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpGet("{applicantId}/onboarding_forms_signature"),
     ProducesResponseType(typeof(OnBoardingFormSignatureInfo), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetOnBoardingFormsSignatureAsync([FromRoute] int applicantId)
    {
        var response = await _service.SendAsync<GetApplicantOnBoardingFormSignatureQuery, OnBoardingFormSignatureInfo>(new(applicantId));

        return Ok(response);
    }

    /// <summary>
    /// Save Applicant Onboarding Forms Signature
    /// </summary>
    /// <param name="applicantId"></param>
    /// <param name="onboardingFormSignature"></param>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpPut("{applicantId}/applicant_onboarding_form_signature"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveApplicantOnBoardingFormSignature([FromBody] SaveApplicantOnBoardingFormSignatureCommand saveApplicantFormSignatureCommand)
    {
        var response = await _service.SendAsync<SaveApplicantOnBoardingFormSignatureCommand, BaseResponse>(saveApplicantFormSignatureCommand);

        if (response.Id != 0)
        {
            await _service.SendAsync<SetApplicationSubmittedStatusCommand, BaseResponse>(new(saveApplicantFormSignatureCommand.ApplicantId));
        }

        return Ok(response);
    }
    /// <summary>
    /// Set Applicant Activity Status
    /// </summary>
    /// <param name="isActive"></param>
    /// <param name="applicantIds"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpPut("set-activity-status/{isActive}"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateApplicantActivityStatusAsync([FromRoute] bool isActive, [FromBody] int[] applicantIds)
    {
        UpdateApplicantActivityStatusCommand command = new(isActive, applicantIds);

        await _service.SendAsync(command);

        return Ok();
    }

    /// <summary>
    /// Save Applicant Application Language Preference
    /// </summary>
    /// <param name="applicantId"></param>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpPost("{applicantId}/update-language"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateApplicantLanguage([FromRoute] int applicantId, [FromQuery] int languageId)
    {
        var response = await _service.SendAsync<UpdateApplicantApplicationLanguageCommand, BaseResponse>(new() { ApplicantId = applicantId, LanguageId = languageId });

        return Ok(response);
    }
}
