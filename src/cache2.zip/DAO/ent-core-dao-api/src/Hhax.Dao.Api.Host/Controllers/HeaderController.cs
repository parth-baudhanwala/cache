﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Feature;
using Hhax.Dao.Application.Abstracts.Responses.Header;
using Hhax.Dao.Application.Queries.Feature;
using Hhax.Dao.Application.Queries.Header;

namespace Hhax.Dao.Api.Host.Controllers
{
    [Authorize,
     ApiVersion("1.0"),
     Route("api/v{version:apiVersion}/header"),
     ApiController]
    public class HeaderController : ControllerBase
    {
        private readonly IMediatorService _service;

        public HeaderController(IMediatorService service)
            => _service = service;

        [HttpGet("skin-info"),
        ProducesResponseType(typeof(SkinFeatureInfoResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSkinType()
        {
            var query = new GetSkinFeatureInfoQuery();

            var response = await _service.SendAsync<GetSkinFeatureInfoQuery, SkinFeatureInfoResponse>(query);

            return Ok(response);
        }

        [HttpGet("notifications"),
        ProducesResponseType(typeof(NotificationsDetailResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetUserNotifications()
        {
            var query = new GetNotificationsDetailQuery();

            var response = await _service.SendAsync<GetNotificationsDetailQuery, NotificationsDetailResponse>(query);

            return Ok(response);
        }

        [AllowAnonymous,
         HttpGet("application-form-skin-info/{officeId:int}"),
         ProducesResponseType(typeof(ApplicationFormSkinInfo), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetSkinType([FromRoute] int officeId)
        {
            var query = new GetApplicationFormSkinInfoQuery(officeId);

            var response = await _service.SendAsync<GetApplicationFormSkinInfoQuery, ApplicationFormSkinInfo>(query);

            return Ok(response);
        }
    }
}
