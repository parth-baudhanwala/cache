﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Compliance;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Host.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Hhax.Dao.Api.Host.Controllers;

[Authorize,
 ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/compliances"),
 ApiController]
public class CompliancesController : ControllerBase
{
    private readonly IMediatorService _service;
    private readonly IFilesUploadService _filesUploadService;

    public CompliancesController(IMediatorService service,
                                 IFilesUploadService filesUploadService)
    {
        _filesUploadService = filesUploadService;
        _service = service;
    }

    [HttpGet("get-file-link"),
     ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetFileLink([FromQuery] string fileKey)
        => Ok(await _filesUploadService.GetFileUrlAsync(fileKey));

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("i9/{applicantId:int}"),
     ProducesResponseType(typeof(ComplianceI9Requirement), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetI9Requirements([FromRoute] int applicantId)
    {
        var query = new GetI9RequirementsQuery(applicantId);

        var response = await _service.SendAsync<GetI9RequirementsQuery, ComplianceI9Requirement>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpPut("i9/{applicantId:int}"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SetupI9Requirements([FromRoute] int applicantId, [FromForm] ComplianceI9Requirement requirement)
    {
        IFormFileCollection? files = Request?.Form?.Files;

        if (files is not null && files.Any())
        {
            var filesSize = files.Sum(c => c.Length);
            var validationResponse = await _filesUploadService.ValidateTotalFileSizeLimitByProviderAsync(filesSize);

            if (validationResponse != null && !validationResponse.IsSaved) throw new ValidationException(validationResponse.ErrorMessage);

            requirement.ColumnABDocumentFileKey = await _filesUploadService.UploadDocumentAsync(ComplianceFileType.ColumnAB, files, applicantId, requirement.ColumnABDocumentId, null);
            requirement.ColumnCDocumentFileKey = await _filesUploadService.UploadDocumentAsync(ComplianceFileType.ColumnC, files, applicantId, requirement.ColumnCDocumentId, null);
            requirement.EverifyDocumentFileKey = await _filesUploadService.UploadDocumentAsync(ComplianceFileType.EverifyDocuments, files, applicantId);
        }

        requirement.ApplicantId = applicantId;

        var response = await _service.SendAsync<ComplianceI9Requirement, UpsertI9RequirementCommand, BaseResponse>(requirement);

        return Ok(response);
    }

    [HttpGet("i9/column-c-documents"),
     ProducesResponseType(typeof(IEnumerable<I9ColumnCDocument>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetI9ColumnCDocuments()
    {
        var query = new GetColumnCdDocumentsQuery();

        var response = await _service.SendAsync<GetColumnCdDocumentsQuery, IEnumerable<I9ColumnCDocument>>(query);

        return Ok(response);
    }

    [HttpGet("i9/column-ab-documents"),
     ProducesResponseType(typeof(IEnumerable<I9ColumnABDocument>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetI9ColumnABDocuments([FromQuery] GetColumnABDocumentsRequest request)
    {
        var query = new GetColumnAbDocumentsQuery(request.OfficeId);

        var response = await _service.SendAsync<GetColumnAbDocumentsQuery, IEnumerable<I9ColumnABDocument>>(query);

        return Ok(response);
    }

    [Authorize(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("background-check/{applicantId:int}"),
     ProducesResponseType(typeof(IEnumerable<ComplianceBackgroundCheck>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetBackgroundCheck([FromRoute] int applicantId)
    {
        var query = new GetApplicantComplianceBackgroundCheckQuery(applicantId);

        var response = await _service.SendAsync<GetApplicantComplianceBackgroundCheckQuery, IEnumerable<ComplianceBackgroundCheck>>(query);

        return Ok(response);
    }

    [Authorize(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpPut("background-check/{applicantId:int}"),
     ProducesResponseType(typeof(BaseRangeResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SetupBackgroundCheck([FromRoute] int applicantId, [FromForm] IEnumerable<ComplianceBackgroundCheck> data)
    {
        IFormFileCollection? files = Request?.Form?.Files;

        if (files is not null && files.Any())
        {
            var filesSize = files.Sum(c => c.Length);
            var validationResponse = await _filesUploadService.ValidateTotalFileSizeLimitByProviderAsync(filesSize);
            if (validationResponse != null && !validationResponse.IsSaved) throw new ValidationException(validationResponse.ErrorMessage);

            var cbItems = data.Where(x => !string.IsNullOrWhiteSpace(x.FileName));

            foreach (var item in cbItems)
            {
                item.FileKey = await _filesUploadService.UploadDocumentAsync(ComplianceFileType.BackgroundCheck, files, applicantId, fileName: item.FileName!);
            }
        }

        var command = new UpsertApplicationBackgroundChecksCommand(applicantId, data);

        var ids = await _service.SendAsync<UpsertApplicationBackgroundChecksCommand, IEnumerable<int>>(command);

        return Ok(new BaseRangeResponse(ids));
    }

    [Authorize(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpDelete("background-check/{applicantId:int}"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteBackgroundCheck([FromRoute] int applicantId, [FromForm] IEnumerable<int> ids)
    {
        var command = new DeleteApplicationBackgroundChecksCommand(applicantId, ids);

        await _service.SendAsync(command);

        return NoContent();
    }

    [HttpGet("background-check/possible-results"),
     ProducesResponseType(typeof(IEnumerable<BackgroundCheckResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> BackgroundCheckResultsAsync([FromQuery] GetBackgroundCheckResultsRequest request)
    {
        var query = new GetBackgroundCheckResultsQuery(request.OfficeId);

        var response = await _service.SendAsync<GetBackgroundCheckResultsQuery, IEnumerable<BackgroundCheckResponse>>(query);

        return Ok(response);
    }

    [HttpGet("training-schools/schools"),
     ProducesResponseType(typeof(IEnumerable<TrainingSchool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetTrainingSchools([FromQuery] GetTrainingSchoolRequest request)
    {
        var query = new GetTrainingSchoolsQuery(request.OfficeId);

        var response = await _service.SendAsync<GetTrainingSchoolsQuery, IEnumerable<TrainingSchool>>(query);

        return Ok(response);
    }

    // TODO: Delete after FE starts using GetSelfApplicantTrainingSchools
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("training-schools"),
     ProducesResponseType(typeof(PaginatationResponse<ComplianceTrainingSchool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantTrainingSchools([FromQuery] PaginationRequest<GetApplicantTrainingSchools> request)
    {
        var query = new GetApplicantComplianceTrainingSchoolQuery(request);

        var response = await _service.SendAsync<GetApplicantComplianceTrainingSchoolQuery, PaginatationResponse<ComplianceTrainingSchool>>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("training-schools/{applicantId:int}"),
     ProducesResponseType(typeof(PaginatationResponse<ComplianceTrainingSchool>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetSelfApplicantTrainingSchools([FromRoute] int applicantId, [FromQuery] PaginationRequest<GetApplicantTrainingSchools> request)
    {
        request.Filters = new() { ApplicantId = applicantId };

        var query = new GetApplicantComplianceTrainingSchoolQuery(request);

        var response = await _service.SendAsync<GetApplicantComplianceTrainingSchoolQuery, PaginatationResponse<ComplianceTrainingSchool>>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpPut("training-schools/{applicantId:int}"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveApplicantTrainingSchools([FromRoute] int applicantId, [FromForm] ComplianceTrainingSchool request)
    {
        IFormFileCollection? files = Request?.Form?.Files;

        if (files is not null)
        {
            var filesSize = files.Sum(c => c.Length);
            var validationResponse = await _filesUploadService.ValidateTotalFileSizeLimitByProviderAsync(filesSize);
            if (validationResponse != null && !validationResponse.IsSaved) throw new ValidationException(validationResponse.ErrorMessage);

            request.CertificateFileKey = await _filesUploadService.UploadDocumentAsync(ComplianceFileType.TrainingSchool, files, applicantId, documentTypeId: request.SchoolId);
        }

        request.ApplicantId = applicantId;

        var response = await _service.SendAsync<ComplianceTrainingSchool, UpsertApplicationTrainingSchoolCommand, BaseResponse>(request);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpDelete("training-schools/{applicantId:int}"),
     ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> DeleteApplicantTrainingSchools([FromRoute] int applicantId, [FromForm] int rowId)
    {
        var command = new DeleteApplicationComplianceTrainingSchoolCommand(applicantId, rowId);

        await _service.SendAsync(command);

        return Ok();
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("custom-fields/{applicantId:int}"),
     ProducesResponseType(typeof(ComplianceCustomFieldModel), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetCustomFields([FromRoute] int applicantId, [FromQuery] int officeId)
    {
        var query = new GetComplianceCustomFieldsQuery(applicantId, officeId);

        var response = await _service.SendAsync<GetComplianceCustomFieldsQuery, ComplianceCustomFieldModel>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     OnlyForApplicants,
     HttpPut("custom-fields/{applicantId:int}"),
     ProducesResponseType(typeof(BaseRangeResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveCustomFields([FromRoute] int applicantId, [FromBody] ComplianceCustomFieldModel customFieldModel)
    {
        var command = new UpsertApplicantComplianceCustomFieldsCommand(applicantId, customFieldModel.ComplianceCustomFields, customFieldModel.Signature);

        var response = await _service.SendAsync<UpsertApplicantComplianceCustomFieldsCommand, BaseRangeResponse>(command);

        return Ok(response);
    }
}
