﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.Settings;
using Hhax.Dao.Application.Commands.Settings;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Application.Queries.Settings;
using Hhax.Dao.Domain.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IO;

namespace Hhax.Dao.Api.Host.Controllers;

[Authorize(Policy = nameof(HhaxPolicies.ViewSettingsPolicy)), 
 ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/settings"),
 ApiController]
public class SettingsController : ControllerBase
{
    private readonly IMediatorService _service;
    
    private const string _type = "Logo";
    private const int _defaultWidth = 200;
    private const int _defaultHeigh = 44;

    public SettingsController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Uploads a agency logo image to AWS S3
    /// </summary>
    /// <param name="file"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.EditThemesPolicy)),
     HttpPost("agency-logo"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> UploadAgencyLogoAsync([FromForm] IFormFile file)
    {
        var response = string.Empty;
        
        using(var inputStream = file.OpenReadStream())
        {
            var recyclableMemoryStreamManager = new RecyclableMemoryStreamManager();
            
            using var memoryStream = recyclableMemoryStreamManager.GetStream();
            inputStream.CopyTo(memoryStream);
            memoryStream.Seek(0, SeekOrigin.Begin);

            var command = new UploadAgencyLogoCommand(_type, Path.GetFileNameWithoutExtension(file.FileName), memoryStream, _defaultWidth, _defaultHeigh);

            response = await _service.SendAsync<UploadAgencyLogoCommand, string>(command);
        }

        return Ok(response);
    }

    /// <summary>
    /// Save agency logo
    /// </summary>
    /// <param name="command"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.EditThemesPolicy)),
     HttpPut("agency-logo"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveAsync([FromBody] SaveAgencyLogoRequest request)
    {
        var response = await _service.SendAsync<SaveAgencyLogoRequest, SaveAgencyLogoCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Get agency notifications settings
    /// </summary>
    /// <returns></returns>
    [Authorize,
     HttpGet("notifications-settings"),
     ProducesResponseType(typeof(NotificationsSettingsResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetNotificationsSettings()
    {
        var response = await _service.SendAsync<GetNotificationsSettingsQuery, NotificationsSettingsResponse>(new());

        return Ok(response);
    }

    /// <summary>
    /// Set agency notifications settings
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.EditNotificationsPolicy)),
     HttpPut("notifications-settings"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SetNotificationsSettings([FromBody] SaveNotificationsSettingsCommand request)
    {
        var response = await _service.SendAsync<SaveNotificationsSettingsCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Retrieve global languages.
    /// </summary>
    /// <returns>List of global languages.</returns>
    [AllowAnonymous,
     HttpGet("global-languages"),
     ProducesResponseType(typeof(IEnumerable<GlobalLanguage>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetLanguagesAsync()
    {
        var response = await _service.SendAsync<GetGlobalLanguagesQuery, IEnumerable<GlobalLanguage>>(new());
        return Ok(response);
    }
}
