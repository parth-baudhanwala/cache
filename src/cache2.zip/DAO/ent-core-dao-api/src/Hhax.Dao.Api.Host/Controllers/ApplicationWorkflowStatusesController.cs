﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hhax.Dao.Api.Host.Controllers;

[Authorize(Policy = nameof(HhaxPolicies.ViewApplicationWorkflowPolicy)),
 ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/application-workflow-statuses"),
 ApiController]
public class ApplicationWorkflowStatusesController : ControllerBase
{
    private readonly IMediatorService _service;

    public ApplicationWorkflowStatusesController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Add Application Workflow Status
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.AddWorkflowStatusPolicy)),
     HttpPost,
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> AddApplicationWorkflowStatusAsync([FromBody] ApplicationWorkflowStatusRequest request)
    {
        var response = await _service.SendAsync<ApplicationWorkflowStatusRequest, AddApplicationWorkflowStatusCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Update Application Workflow Status
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.EditApplicationWorkflowPolicy)), 
     HttpPut("{applicationWorkflowStatusId}"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateApplicationWorkflowStatusAsync([FromRoute] int applicationWorkflowStatusId, [FromBody] ApplicationWorkflowStatusRequest request)
    {
        request.Id = applicationWorkflowStatusId;

        var response = await _service.SendAsync<ApplicationWorkflowStatusRequest, UpdateApplicationWorkflowStatusCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Get Application Workflow Status
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationWorkflowPolicy)), 
     HttpGet("{applicationWorkflowStatusId}"),
     ProducesResponseType(typeof(ApplicationWorkflowStatus), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicationWorkflowStatusAsync([FromRoute] int applicationWorkflowStatusId)
    {
        var query = new GetApplicationWorkflowStatusQuery(applicationWorkflowStatusId);

        var response = await _service.SendAsync<GetApplicationWorkflowStatusQuery, ApplicationWorkflowStatus>(query);

        return Ok(response);
    }

    /// <summary>
    /// Delete Application Workflow Status
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationWorkflowPolicy)),
     HttpDelete("{applicationWorkflowStatusId}"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteApplicationWorkflowStatusAsync([FromRoute] int applicationWorkflowStatusId)
    {
        var command = new DeleteApplicationWorkflowStatusCommand(applicationWorkflowStatusId);

        await _service.SendAsync(command);

        return NoContent();
    }

    /// <summary>
    /// Get Application Workflow Status
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationWorkflowPolicy)), 
     HttpGet,
     ProducesResponseType(typeof(PaginatationResponse<ApplicationWorkflowStatus>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicationWorkflowStatusesAsync([FromQuery] PaginationRequest<SearchApplicationWorkflowStatusRequest> request)
    {
        var query = new GetApplicationWorkflowStatusesQuery(request);

        var response = await _service.SendAsync<GetApplicationWorkflowStatusesQuery, PaginatationResponse<ApplicationWorkflowStatus>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get Application Workflow Status Colors
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationWorkflowPolicy)), 
     HttpGet("colors"),
     ProducesResponseType(typeof(IEnumerable<ApplicationWorkflowStatusBadgeColor>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetColorsAsync()
    {
        var query = new GetApplicationWorkflowStatusBadgeColorsQuery();

        var response = await _service.SendAsync<GetApplicationWorkflowStatusBadgeColorsQuery, IEnumerable<ApplicationWorkflowStatusBadgeColor>>(query);

        return Ok(response);
    }
}
