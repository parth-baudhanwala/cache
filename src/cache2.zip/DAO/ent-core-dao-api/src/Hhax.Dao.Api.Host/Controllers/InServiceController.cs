﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.InService;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.InService;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.InService;
using Hhax.Dao.Infrastructure.Host.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hhax.Dao.Api.Host.Controllers;

[Authorize,
 ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/inservice"),
 ApiController]
public class InServiceController : ControllerBase
{
    private readonly IMediatorService _service;

    public InServiceController(IMediatorService service)
    {
        _service = service;
    }

    [HttpGet("instructors"),
     ProducesResponseType(typeof(IEnumerable<InServiceInstructor>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetInServiceInstructors()
    {
        var query = new GetInServiceInstructorsQuery();

        var response = await _service.SendAsync<GetInServiceInstructorsQuery, IEnumerable<InServiceInstructor>>(query);

        return Ok(response);
    }

    [HttpGet("payrates/{disciplineId}"),
        ProducesResponseType(typeof(IEnumerable<InServicePayRate>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetPayCodes([FromRoute] short disciplineId)
    {
        var query = new GetPaycodesQuery(disciplineId);

        var response = await _service.SendAsync<GetPaycodesQuery, IEnumerable<InServicePayRate>>(query);

        return Ok(response);
    }

    [HttpGet("reasons"),
        ProducesResponseType(typeof(IEnumerable<InServiceNoShowReason>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetNoShowReasons()
    {
        var query = new GetInServiceNoShowReasonsQuery();

        var result = await _service.SendAsync<GetInServiceNoShowReasonsQuery, IEnumerable<InServiceNoShowReason>>(query);

        return Ok(result);
    }

    [HttpGet("topics/{officeId}"),
        ProducesResponseType(typeof(IEnumerable<InServiceTopic>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetTopics([FromRoute] int officeId)
    {
        var query = new GetTopicsQuery(officeId);

        var response = await _service.SendAsync<GetTopicsQuery, IEnumerable<InServiceTopic>>(query);

        return Ok(response);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/has-any"),
     ProducesResponseType(typeof(HasApplicantInServices), StatusCodes.Status200OK)]
    public async Task<IActionResult> HasApplicantInServices([FromRoute] int applicantId)
    {
        var query = new HasApplicantInServicesQuery(applicantId);

        var result = await _service.SendAsync<HasApplicantInServicesQuery, HasApplicantInServices>(query);

        return Ok(result);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}"),
     ProducesResponseType(typeof(PaginatationResponse<ApplicantInServiceTableItem>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantInServicesForTable([FromRoute] int applicantId, [FromQuery] PaginationRequest<GetApplicantInServices> request)
    {
        request.Filters = new GetApplicantInServices
        {
            ApplicantId = applicantId
        };
        var query = new GetApplicantInServicesQuery(request);

        var result = await _service.SendAsync<GetApplicantInServicesQuery, PaginatationResponse<ApplicantInServiceTableItem>>(query);

        return Ok(result);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpPost("{applicantId}"),
     OnlyForApplicants,
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> SaveInService([FromRoute] int applicantId, [FromBody] UpsertInServiceCommand command)
    {
        command.ApplicantId = applicantId;
        var result = await _service.SendAsync<UpsertInServiceCommand, BaseResponse>(command);
        return Ok(result);
    }

    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpDelete("{applicantId}/{inServiceId}"),
     OnlyForApplicants,
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteInServiceAsync([FromRoute] int applicantId, [FromRoute] int inServiceId)
    {
        var command = new DeleteInServiceCommand(applicantId, inServiceId);

        await _service.SendAsync(command);

        return NoContent();
    }
}
