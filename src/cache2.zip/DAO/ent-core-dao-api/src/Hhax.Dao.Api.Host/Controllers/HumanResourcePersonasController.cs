﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Office;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Domain.User;
using Hhax.Dao.Infrastructure.Host.Attributes;

namespace Hhax.Dao.Api.Host.Controllers;

[ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/human-resource-personas"),
 ApiController]
public class HumanResourcePersonasController : ControllerBase
{
    private readonly IMediatorService _service;

    public HumanResourcePersonasController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Get users
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewHRRepresentativesPolicy)),
     HttpGet("users"),
     ProducesResponseType(typeof(IEnumerable<UserInfo>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetUsersAsync()
    {
        var query = new GetUsersQuery();

        var response = await _service.SendAsync<GetUsersQuery, IEnumerable<UserInfo>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get statuses
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewHRRepresentativesPolicy)),
     HttpGet("statuses"),
     ProducesResponseType(typeof(IEnumerable<HumanResourcePersonaStatus>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetStatusesAsync()
    {
        var query = new GetHumanResourcePersonaStatusesQuery();

        var response = await _service.SendAsync<GetHumanResourcePersonaStatusesQuery, IEnumerable<HumanResourcePersonaStatus>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Add HR Persona
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.AddHRPolicy)),
     HttpPost,
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> AddHumanResourcePersonaAsync([FromBody] HumanResourcePersonaRequest request)
    {
        var response = await _service.SendAsync<HumanResourcePersonaRequest, AddHumanResourcePersonaCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Update HR Persona
    /// </summary>
    /// <param name="parameters"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.EditHRPolicy)),
     HttpPut("{humanResourcePersonaId}"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateHumanResourcePersonaAsync([FromRoute] int humanResourcePersonaId, [FromBody] HumanResourcePersonaRequest request)
    {
        request.Id = humanResourcePersonaId;

        var response = await _service.SendAsync<HumanResourcePersonaRequest, UpdateHumanResourcePersonaCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Get HR Personas as Pagination Response
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewHRRepresentativesPolicy)),
     HttpGet,
     ProducesResponseType(typeof(PaginatationResponse<HumanResourcePersona>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetHumanResourcePersonasAsync([FromQuery] PaginationRequest<SearchHumanResourcePersonaRequest> request)
    {
        var query = new GetHumanResourcePersonasQuery(request);

        var response = await _service.SendAsync<GetHumanResourcePersonasQuery, PaginatationResponse<HumanResourcePersona>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get HR Personas
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewHRRepresentativesPolicy)),
     HttpGet("list"),
     ProducesResponseType(typeof(IEnumerable<HumanResourcePersona>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetHumanResourcePersonasListAsync()
    {
        var request = new GetHumanResourcePersonasRequest();

        var response = await _service.SendAsync<GetHumanResourcePersonasRequest, IEnumerable<HumanResourcePersona>>(request);

        return Ok(response);
    }

    /// <summary>
    /// Get HR Persona
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewHRRepresentativesPolicy)),
     HttpGet("{humanResourcePersonaId}"),
     ProducesResponseType(typeof(HumanResourcePersona), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetHumanResourcePersonaAsync([FromRoute] int humanResourcePersonaId)
    {
        var query = new GetHumanResourcePersonaQuery(humanResourcePersonaId);

        var response = await _service.SendAsync<GetHumanResourcePersonaQuery, HumanResourcePersona>(query);

        return Ok(response);
    }

    /// <summary>
    /// Delete HR Persona
    /// </summary>
    [Authorize(Policy = nameof(HhaxPolicies.ViewHRRepresentativesPolicy)),
     HttpDelete("{humanResourcePersonaId}"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteHumanResourcePersonaAsync([FromRoute] int humanResourcePersonaId)
    {
        var command = new DeleteHumanResourcePersonaCommand(humanResourcePersonaId);

        await _service.SendAsync(command);

        return NoContent();
    }

    /// <summary>
    /// Assign applicant
    /// </summary>
    /// <param name="assignApplicantRequest"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.AssignHRUserPolicy)),
     AuthorizeAssignHR(),
     HttpPost("assign-applicant"),
     ProducesResponseType(typeof(BaseRangeResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> AssignApplicantAsync([FromForm] AssignApplicantRequest assignApplicantRequest)
    {
        var response = await _service.SendAsync<AssignApplicantRequest, AssignHumanResourcePersonaToApplicantCommand, BaseRangeResponse>(assignApplicantRequest);

        return Ok(response);
    }

    /// <summary>
    /// Get current user human resource persona
    /// </summary>
    /// <returns></returns>
    [Authorize,
     HttpGet("for-current-user"),
     ProducesResponseType(typeof(HumanResourcePersona), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetCurrentUserHumanResourcePersonaAsync()
    {
        var query = new GetHumanResourcePersonaForUserQuery();

        var response = await _service.SendAsync<GetHumanResourcePersonaForUserQuery, HumanResourcePersona>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get applicant human resource persona
    /// </summary>
    /// <param name="applicantId"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewHRRepresentativesPolicy)),
     HttpGet("for-applicant/{applicantId}"),
     ProducesResponseType(typeof(HumanResourcePersona), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantHumanResourcePersonaAsync([FromRoute] int applicantId)
    {
        var query = new GetHumanResourcePersonaForApplicantQuery(applicantId);

        var response = await _service.SendAsync<GetHumanResourcePersonaForApplicantQuery, HumanResourcePersona>(query);

        return Ok(response);
    }
}
