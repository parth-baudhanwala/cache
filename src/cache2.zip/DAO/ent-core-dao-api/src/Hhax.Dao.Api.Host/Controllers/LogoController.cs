﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Settings;
using Hhax.Dao.Domain.Settings;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hhax.Dao.Api.Host.Controllers;

[Authorize,
 ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/settings"),
 ApiController]
public class LogoController : ControllerBase
{
    private const string _type = "Logo";
    private readonly IMediatorService _service;

    public LogoController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Get agency logo
    /// </summary>
    /// <returns></returns>
    [Authorize,
     HttpGet("agency-logo"),
     ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAgencyLogoAsync()
    {
        var query = new GetAgencyLogoQuery { Type = _type };

        var response = await _service.SendAsync<GetAgencyLogoQuery, AgencyLogoInfo>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get agency logo anonymous
    /// </summary>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpGet("agency-logo/{officeId:int}"),
     ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAgencyLogoAsync([FromRoute] int officeId)
    {
        var query = new GetAgencyLogoQuery
        {
            OfficeId = officeId,
            Type = _type
        };

        var response = await _service.SendAsync<GetAgencyLogoQuery, AgencyLogoInfo>(query);

        return Ok(response);
    }
}
