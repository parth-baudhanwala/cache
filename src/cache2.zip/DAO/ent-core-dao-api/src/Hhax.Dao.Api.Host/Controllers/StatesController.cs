﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Globalization;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Domain.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hhax.Dao.Api.Host.Controllers;

[Authorize,
 ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/states"),
 ApiController]
public class StatesController : ControllerBase
{
    private readonly IMediatorService _service;

    public StatesController(IMediatorService service)
         => _service = service;

    /// <summary>
    /// Search states
    /// </summary>
    /// <param name="search"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet,
     ProducesResponseType(typeof(IEnumerable<State>), StatusCodes.Status200OK)]
    public async Task<IActionResult> SearchStatesAsync([FromQuery] SearchStatesRequest request)
    {
        var query = new SearchStatesQuery(request?.StateName!);

        var response = await _service.SendAsync<SearchStatesQuery, IEnumerable<State>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Search cities by zip code
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("cities/zipcodes"),
     ProducesResponseType(typeof(IEnumerable<City>), StatusCodes.Status200OK)]
    public async Task<IActionResult> SearchCitiesByZipCodeAsync([FromQuery] PaginationRequest<SearchCitiesByZipCodeRequest> request)
    {
        var query = new SearchCitiesByZipCodeQuery(request);

        var response = await _service.SendAsync<SearchCitiesByZipCodeQuery, IEnumerable<City>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Search cities by city name and state name
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("cities"),
     ProducesResponseType(typeof(IEnumerable<City>), StatusCodes.Status200OK)]
    public async Task<IActionResult> SearchCitiesAsync([FromQuery] PaginationRequest<SearchCitiesRequest> request)
    {
        var query = new SearchCitiesQuery(request);

        var response = await _service.SendAsync<SearchCitiesQuery, IEnumerable<City>>(query);

        return Ok(response);
    }
}
