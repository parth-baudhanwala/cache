﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Account;
using Hhax.Dao.Application.Abstracts.Requests.Permission;
using Hhax.Dao.Application.Abstracts.Responses.Account;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using Hhax.Dao.Application.Commands.Account;
using Hhax.Dao.Application.Queries.Account;
using Hhax.Identity.Api.Client.Abstracts.Models.Responses;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hhax.Dao.Api.Host.Controllers;

[Authorize,
 ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/accounts"),
 ApiController]
public class AccountsController : ControllerBase
{
    private readonly IMediatorService _service;

    public AccountsController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Get permissions
    /// </summary>
    /// <returns></returns>
    [HttpGet("permissions"),
     ProducesResponseType(typeof(PermissionsResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetPermissionsAsync()
    {
        var query = new GetPermissionsQuery();

        var response = await _service.SendAsync<GetPermissionsQuery, PermissionsResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Validate permissions
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [HttpPost("permissions/validate"),
     ProducesResponseType(typeof(ValidatePermissionsResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ValidatePermissionsAsync([FromBody] PermissionsRequest request)
    {
       var response = await _service.SendAsync<PermissionsRequest, ValidatePermissionsByIdsCommand, ValidatePermissionsResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Login applicant
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpPost("applicant/login"),
     ProducesResponseType(typeof(IEnumerable<ApplicantLoginResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> LoginApplicantAsync([FromBody] ApplicantLoginRequest request)
    {
        var response = await _service.SendAsync<ApplicantLoginRequest, ApplicantLoginQuery, ApplicantLoginResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Applicant refresh token
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpPost("applicant/refresh-token"),
     ProducesResponseType(typeof(TokenResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> ApplicantRefreshTokenAsync([FromBody] ApplicantRefreshTokenRequest request)
    {
        var response = await _service.SendAsync<ApplicantRefreshTokenRequest, ApplicantRefreshTokenQuery, TokenResponse>(request);

        return Ok(response);
    }
}
