﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using Hhax.Dao.Application.Abstracts.Responses.OnBoardingForm;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.OnBoardingForm;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Application;

namespace Hhax.Dao.Api.Host.Controllers;

[ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/application-forms"),
 ApiController]
public class ApplicationFormsController : ControllerBase
{
    private readonly IMediatorService _service;

    public ApplicationFormsController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Add application form
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.AddApplicationFormPolicy)),
     HttpPost,
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> AddApplicationFormAsync([FromBody] ApplicationFormRequest request)
    {
        var response = await _service.SendAsync<ApplicationFormRequest, AddApplicationFormCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Update application form
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.AddApplicationFormPolicy)),
     HttpPut("{applicationFormId}"),
     ProducesResponseType(typeof(BaseResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateApplicationFormAsync([FromRoute] int applicationFormId, [FromBody] ApplicationFormRequest request)
    {
        request.Id = applicationFormId;

        var response = await _service.SendAsync<ApplicationFormRequest, UpdateApplicationFormCommand, BaseResponse>(request);

        return Ok(response);
    }

    /// <summary>
    /// Get application form
    /// </summary>
    /// <param name="applicationFormId"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationFormPolicy)),
     HttpGet("{applicationFormId}"),
     ProducesResponseType(typeof(ApplicationForm), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicationFormAsync([FromRoute] int applicationFormId)
    {
        var query = new GetApplicationFormByIdQuery(applicationFormId);

        var response = await _service.SendAsync<GetApplicationFormByIdQuery, ApplicationForm>(query);

        return Ok(response);
    }

    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationFormPolicy)),
    HttpGet("custom-field-hasvalue/{formCustomFieldId}"),
    ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetFormCustomFieldHasValue([FromRoute] int formCustomFieldId)
    {
        var query = new GetFormCustomFieldHasValueQuery(formCustomFieldId);
        var response = await _service.SendAsync<GetFormCustomFieldHasValueQuery, BaseResponse>(query);
        return Ok(response.Id > 0);
    }

    /// <summary>
    /// Get application form by unique url id and office id
    /// </summary>
    /// <param name="uniqueUrlId"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("urls/{uniqueUrlId}/offices/{officeId}"),
     ProducesResponseType(typeof(ApplicationForm), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicationFormAsync([FromRoute] Guid uniqueUrlId, [FromRoute] int officeId)
    {
        var query = new GetApplicationFormByUniqueIdQuery(uniqueUrlId, officeId);

        var response = await _service.SendAsync<GetApplicationFormByUniqueIdQuery, ApplicationForm>(query);

        return Ok(response);
    }

    /// <summary>
    /// Delete application form
    /// </summary>
    /// <param name="applicationFormId"></param>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationFormPolicy)),
     HttpDelete("{applicationFormId}"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteApplicationFormAsync([FromRoute] int applicationFormId)
    {
        var command = new DeleteApplicationFormCommand(applicationFormId);

        await _service.SendAsync(command);

        return NoContent();
    }

    /// <summary>
    /// Get link for application form by office id
    /// </summary>
    /// <param name="officeId"></param>
    /// <returns></returns>
    [AllowAnonymous,
     HttpGet("link/{officeId}"),
     ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetLinkToApplicationFormByOfficeAsync([FromRoute] int officeId)
    {
        var query = new GetApplicationFormUrlQuery(officeId);

        var response = await _service.SendAsync<GetApplicationFormUrlQuery, string>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get compliances
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.AddApplicationFormPolicy)),
     HttpGet("compliances"),
     ProducesResponseType(typeof(CompliancesResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetCompliancesAsync([FromQuery] int? applicationFormId)
    {
        var query = new GetCompliancesQuery(applicationFormId);

        var response = await _service.SendAsync<GetCompliancesQuery, CompliancesResponse>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get applicant requirements of applicant form by unique url id
    /// </summary>
    /// <returns></returns>
    [HttpGet("applicant-requirements/{uniqueUrlId}"),
     ProducesResponseType(typeof(IEnumerable<ApplicationFormApplicantRequirement>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantRequirementsAsync([FromRoute] Guid uniqueUrlId)
    {
        var query = new GetApplicantRequirementsByUniqueIdQuery(uniqueUrlId);

        var response = await _service.SendAsync<GetApplicantRequirementsByUniqueIdQuery, IEnumerable<ApplicationFormApplicantRequirement>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get application forms
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationFormPolicy)),
     HttpGet,
     ProducesResponseType(typeof(PaginatationResponse<ApplicationFormInfo>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicatonFormsAsync([FromQuery] PaginationRequest<GetApplicationFormRequest> request)
    {
        var query = new GetApplicationFormsQuery(request);

        var response = await _service.SendAsync<GetApplicationFormsQuery, PaginatationResponse<ApplicationFormInfo>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get application form applicant sections
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationFormPolicy)),
     HttpGet("applicant-sections"),
     ProducesResponseType(typeof(IEnumerable<ApplicationFormApplicantSection>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicationFormApplicantSectionsAsync([FromQuery] GetApplicationFormApplicantSectionsRequest request)
    {
        var query = new GetApplicationFormApplicantSectionsQuery(request.OfficeIds!);

        var response = await _service.SendAsync<GetApplicationFormApplicantSectionsQuery, IEnumerable<ApplicationFormApplicantSection>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get application field types
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationFormPolicy)),
     HttpGet("application-field-type"),
     ProducesResponseType(typeof(IEnumerable<ApplicationFieldType>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicationFieldTypes()
    {
        GetApplicationFieldTypes query = new();
        var response = await _service.SendAsync<GetApplicationFieldTypes, IEnumerable<ApplicationFieldType>>(query);
        return Ok(response);
    }

   [Authorize(Policy = nameof(HhaxPolicies.ViewApplicationFormPolicy)),
    HttpPost("onboarding-forms"),
    ProducesResponseType(typeof(IEnumerable<OnBoardingFormResponse>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetOnBoardingForms([FromBody] GetOnBoardingFormsCommand query)
    {
        var response = await _service.SendAsync<GetOnBoardingFormsCommand, IEnumerable<OnBoardingFormResponse>>(query);
        return Ok(response);
    }
}
