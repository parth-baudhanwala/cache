﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Message;
using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Application.Commands.Message;
using Hhax.Dao.Domain.Message;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hhax.Dao.Api.Host.Controllers
{
    [ApiVersion("1.0"),
     Route("api/v{version:apiVersion}/messages"),
     ApiController]
    public class MessagesController : ControllerBase
    {
        private readonly IMediatorService _service;
        public MessagesController(IMediatorService service)
        {
            _service = service;
        }

        /// <summary>
        /// Send email
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
        HttpPost("send-email"),
        ProducesResponseType(typeof(SendMessagesResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> SendEmailAsync([FromForm] SendEmailRequest request)
        {
            var response = await _service.SendAsync<SendEmailRequest, SendEmailCommand, SendMessagesResponse>(request);

            return Ok(response);
        }

        /// <summary>
        /// Send sms
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
        HttpPost("send-sms"),
        ProducesResponseType(typeof(SendMessagesResponse), StatusCodes.Status200OK)]
        public async Task<IActionResult> SendSmsAsync([FromForm] SendSmsRequest request)
        {
            var response = await _service.SendAsync<SendSmsRequest, SendSmsCommand, SendMessagesResponse>(request);

            return Ok(response);
        }


        /// <summary>
        /// Get message templates
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
        HttpGet("templates"),
        ProducesResponseType(typeof(IEnumerable<MessageTemplate>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetMessageTemplates([FromQuery] GetTemplatesRequest request)
        {
            var response = await _service.SendAsync<GetTemplatesRequest, IEnumerable<MessageTemplate>> (request);

            return Ok(response);
        }
    }
}
