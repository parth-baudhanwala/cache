﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Host.Attributes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Hhax.Dao.Api.Host.Controllers;

[ApiVersion("1.0"),
 Route("api/v{version:apiVersion}/applicants"),
 ApiController]
public class ApplicantEligibilitiesController : ControllerBase
{
    private readonly IMediatorService _service;

    public ApplicantEligibilitiesController(IMediatorService service)
    {
        _service = service;
    }

    /// <summary>
    /// Get applicant eligibilities
    /// </summary>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/applicant-eligibilities"),
     ProducesResponseType(typeof(IEnumerable<ApplicantEligibility>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantEligibilitiesAsync([FromRoute] int applicantId)
    {
        var query = new GetApplicantEligibilitiesQuery(applicantId);

        var response = await _service.SendAsync<GetApplicantEligibilitiesQuery, IEnumerable<ApplicantEligibility>>(query);

        return Ok(response);
    }

    /// <summary>
    /// Check applicant eligibilities
    /// </summary>
    /// <returns></returns>
    [AuthorizeApplicant(nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpPost("{applicantId}/applicant-eligibilities"),
     ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> CheckApplicantEligibilityAsync([FromRoute] int applicantId)
    {
        var command = new CheckApplicantEligibilitiesCommand(applicantId);

        await _service.SendAsync(command);

        return NoContent();
    }

    /// <summary>
    /// Get applicant eligibilities for availability
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/applicant-availability-eligibilities"),
     ProducesResponseType(typeof(ApplicantEligibility), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantAvailabilityEligibilitiesAsync([FromRoute] int applicantId)
    {
        var query = new GetApplicantAvailabilityEligibilityQuery(applicantId);

        var response = await _service.SendAsync<GetApplicantAvailabilityEligibilityQuery, ApplicantEligibility>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get applicant eligibilities for availability
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/applicant-background-eligibilities"),
     ProducesResponseType(typeof(ApplicantEligibility), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantBackgroundEligibilitiesAsync([FromRoute] int applicantId)
    {
        var query = new GetApplicantBackgroundEligibilityQuery(applicantId);

        var response = await _service.SendAsync<GetApplicantBackgroundEligibilityQuery, ApplicantEligibility>(query);

        return Ok(response);
    }

    /// <summary>
    /// Get applicant eligibilities for training schools
    /// </summary>
    /// <returns></returns>
    [Authorize(Policy = nameof(HhaxPolicies.ViewApplicantsPolicy)),
     HttpGet("{applicantId}/applicant-training-schools-eligibilities"),
     ProducesResponseType(typeof(ApplicantEligibility), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetApplicantTrainingSchoolsEligibilitiesAsync([FromRoute] int applicantId)
    {
        var query = new GetApplicantTrainingSchoolsEligibilityQuery(applicantId);

        var response = await _service.SendAsync<GetApplicantTrainingSchoolsEligibilityQuery, ApplicantEligibility>(query);

        return Ok(response);
    }
}
