using Amazon.S3;
using AutoMapper.Extensions.ExpressionMapping;
using FluentValidation;
using FluentValidation.AspNetCore;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Profiles.Application;
using Hhax.Dao.Application.Validators.Application;
using Hhax.Dao.Infrastructure.Contexts;
using Hhax.Dao.Infrastructure.Host.Extensions;
using Hhax.Dao.Infrastructure.Host.Middlewares;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.OpenApi.Models;
using System.Reflection;
using System.Text.Json.Serialization;


const string redisSectionName = "Redis";
const string redisConnection = "RedisConnection";

const string identitySectionName = "Identity";
const string identityScopeConfigName = "Identity:Scopes";
const string scopeSectionName = "Scope";

const string applicationFormSectionName = "ApplicationForm";
const string settingsSectionName = "Settings";
const string hhaStoredProceduresSectionName = "HHAStoredProcedures";
const string storedProcConnectionStringsSectionName = "StoredProceduresConnectionStrings";
const string instanceName = "dao_api_";
const string daoApiPolicy = "_daoApiPolicy";

const string healthzPath = "/healthz";
const string healthzApiPath = "/api/healthz";
const string healthzReadyPath = "/healthz/ready";
const string healthzLivePath = "/healthz/live";
const string healthzServiceUrlParamName = "HealthCheck:ServiceUrl";

const string swaggerTitle = "HHAX DAO Api";
const string swaggerVersion = "v1";
const string swaggerUrl = "swagger/v1/swagger.json";
const string swaggerName = "HHAX DAO Api v1";
const string swaggerMediaType = "application/json";
const string swaggerAuthorizationName = "Authorization";
const string swaggerBearerFormat = "JWT";

const string awsS3SectionName = "AWSS3";
const string awsSecretNameEnvironmentVariable = "AWS_SECRET_NAME";
const string awsSecretArnEnvironmentVariable = "AWS_SECRET_ARN";

const string traceSource = "Information, ActivityTracing";

var builder = WebApplication.CreateBuilder(args);

// Configure Logging - Trace Source
builder.WebHost.ConfigureLogging(configureLogging =>
{
    configureLogging.Configure(options => options.ActivityTrackingOptions = ActivityTrackingOptions.TraceId | ActivityTrackingOptions.SpanId);
    configureLogging.AddTraceSource(traceSource);
});

// Use Kestrel
builder.WebHost.UseKestrel(options =>
{
    options.Limits.MaxRequestBodySize = long.MaxValue;
});

// Add services to the container
builder.Services.AddControllers(configure =>
{
    configure.Filters.Add(new ProducesAttribute(swaggerMediaType));
    configure.Filters.Add(new ProducesResponseTypeAttribute(typeof(ErrorInfo), StatusCodes.Status400BadRequest));
    configure.Filters.Add(new ProducesResponseTypeAttribute(StatusCodes.Status401Unauthorized));
    configure.Filters.Add(new ProducesResponseTypeAttribute(StatusCodes.Status403Forbidden));
    configure.Filters.Add(new ProducesResponseTypeAttribute(typeof(ErrorInfo), StatusCodes.Status404NotFound));
    configure.Filters.Add(new ProducesResponseTypeAttribute(typeof(ErrorInfo), StatusCodes.Status500InternalServerError));
}).AddJsonOptions(configure =>
{
    configure.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    configure.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

// Configure AWS Secrets Manager
if (!builder.Environment.IsDevelopment())
{
    string? awsSecretName = Environment.GetEnvironmentVariable(awsSecretNameEnvironmentVariable);
    string? awsSecretArn = Environment.GetEnvironmentVariable(awsSecretArnEnvironmentVariable);
    if (!string.IsNullOrEmpty(awsSecretName))
    {
        builder.Configuration.AddSecretsManager(configurator: options =>
        {
            // Replace __ tokens in the configuration key name
            options.KeyGenerator = (secret, name) => name.Replace("__", ":");
            options.PollingInterval = TimeSpan.FromMinutes(30);
            options.AcceptedSecretArns = awsSecretArn != null ? new List<string>() { awsSecretArn } : new();
            options.SecretFilter = entry => awsSecretArn != null || entry.Name.Contains(awsSecretName);

            // Remove the prefix "secretname:" and the code will be unified.
            options.KeyGenerator = (secret, name) => name.Replace($"{awsSecretName}:", string.Empty);
        });
    }
}

// Configure AWS S3
builder.Services.Configure<AwsS3Configuration>(builder.Configuration.GetSection(awsS3SectionName));
builder.Services.AddDefaultAWSOptions(builder.Configuration.GetAWSOptions());
builder.Services.AddAWSService<IAmazonS3>();

// Configure Application Form 
builder.Services.Configure<ApplicationFormConfguration>(builder.Configuration.GetSection(applicationFormSectionName));

// Configure Settings
builder.Services.Configure<SettingsConfiguration>(builder.Configuration.GetSection(settingsSectionName));

// Configure Stored Procedures
builder.Services.Configure<HhaStoredProceduresConfiguration>(builder.Configuration.GetSection(hhaStoredProceduresSectionName));
builder.Services.Configure<StoredProceduresConnectionStringsConfiguration>(builder.Configuration.GetSection(storedProcConnectionStringsSectionName));

// Configure Redis
builder.Services.Configure<RedisConfiguration>(builder.Configuration.GetSection(redisSectionName));
var redisConfiguration = builder.Configuration.GetSection(redisSectionName).Get<RedisConfiguration>()!;
builder.Services.AddStackExchangeRedisCache(options =>
{
    options.Configuration = builder.Configuration.GetConnectionString(redisConnection);
    options.InstanceName = instanceName;

    options.ConfigurationOptions = new StackExchange.Redis.ConfigurationOptions
    {
        AbortOnConnectFail = redisConfiguration.AbortOnConnectFail,
        Password = redisConfiguration.Password,
        AsyncTimeout = redisConfiguration.AsyncTimeout,
        ConnectTimeout = redisConfiguration.ConnectTimeout,
        SyncTimeout = redisConfiguration.SyncTimeout,
        ResponseTimeout = redisConfiguration.ResponseTimeout
    };

    options.ConfigurationOptions.EndPoints.Add(redisConfiguration.EndPoint);
});

// Configure Api Versioning
builder.Services.AddApiVersioning();

// Configure AutoMapper
builder.Services.AddAutoMapper(configure => configure.AddExpressionMapping(), Assembly.GetAssembly(typeof(ApplicantProfile)));

// Configure FluentValidation
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<ApplicantAddRequestValidator>();

// Configure MediatorR
builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(AddApplicationFormCommand).Assembly));

// Configure Behaviours
builder.Services.ConfigureBehaviours();

// Configure Cors
string[] origins = builder.Environment.IsDevelopment() ?
        new string[] { "http://localhost:4200", "https://localhost:4200", } :
        new string[] { "https://*.hhaexchange.com" };

builder.Services.AddCors(options => options.AddPolicy(daoApiPolicy, builder => builder.SetIsOriginAllowedToAllowWildcardSubdomains()
    .WithOrigins(origins)
    .AllowAnyMethod()
    .AllowAnyHeader()));

// Configure Identity
builder.Services.Configure<IdentityConfiguration>(builder.Configuration.GetSection(identitySectionName));
builder.Services.ConfigureIdentityApiClient(builder.Configuration);

// Configure Scope
builder.Services.Configure<ScopeConfiguration>(builder.Configuration.GetSection(scopeSectionName));

// Configure Authorization
builder.Services.ConfigureAuthorization(builder.Configuration[identityScopeConfigName]);

// Configure Authentication
builder.Services.ConfigureAuthentication(builder.Configuration);

// Configure repositories
builder.Services.ConfigureRepositories(builder.Configuration);

// Configure stores procedures managers
builder.Services.ConfigureStoredProceduresManagers(builder.Configuration);

// Configure services
builder.Services.ConfigureServices(builder);

// Configure clients
builder.Services.ConfigureClients();

// Configure Health Checks
builder.Services.AddHealthChecks()
                .AddDbContextCheck<DaoDbContext>()
                .AddUrlGroup(new Uri($"{builder.Configuration[healthzServiceUrlParamName]}{healthzApiPath}"));

// Configure Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(configure =>
{
    configure.SwaggerDoc(swaggerVersion, new OpenApiInfo
    {
        Title = swaggerTitle,
        Version = swaggerVersion
    });

    configure.AddSecurityDefinition(JwtBearerDefaults.AuthenticationScheme, new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Name = swaggerAuthorizationName,
        Type = SecuritySchemeType.Http,
        BearerFormat = swaggerBearerFormat,
        Scheme = JwtBearerDefaults.AuthenticationScheme
    });
    configure.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type=ReferenceType.SecurityScheme,
                    Id=JwtBearerDefaults.AuthenticationScheme
                }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
    app.UseDeveloperExceptionPage();
}

app.UseMiddleware<ExceptionMiddleware>();

app.MapHealthChecks(healthzPath);

app.MapHealthChecks(healthzReadyPath, new HealthCheckOptions
{
    Predicate = healthCheck => healthCheck.Tags.Contains("ready")
});

app.MapHealthChecks(healthzLivePath, new HealthCheckOptions
{
    Predicate = _ => false
});

app.Map(healthzApiPath, configuration => configuration.Use(async (context, next) =>
{
    await context.Response.WriteAsync(HealthStatus.Healthy.ToString());
    await next(context);
}));

app.UseHttpsRedirection();

app.UseRouting();

app.UseCors(daoApiPolicy);

app.UseAuthentication();

app.UseAuthorization();

app.UseEndpoints(configure => { });

app.UseSwagger(configure => configure.PreSerializeFilters
    .Add((swaggerDoc, httpRequest) => swaggerDoc.Servers = new List<OpenApiServer>
    {
        new OpenApiServer { Url = $"https://{httpRequest.Host.Value}"
    }
}));

app.UseSwaggerUI(configure => configure.SwaggerEndpoint($"/{swaggerUrl}", swaggerName));

app.MapControllers();

app.Run();
