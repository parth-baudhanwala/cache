﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Settings;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Settings;

public record SaveNotificationsSettingsHandler(IGenericRepository<VendorNotificationsSettingsEntity> NotificationsSettingsRepository,
                                               IMapper Mapper,
                                               IAuthenticationService AuthenticationService,
                                               ILogger<SaveNotificationsSettingsHandler> Logger)
    : IRequestHandler<SaveNotificationsSettingsCommand, BaseResponse>
{
    public async Task<BaseResponse> Handle(SaveNotificationsSettingsCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        int agencyId = AuthenticationService.GetAgencyId();
        VendorNotificationsSettingsEntity upsertEntity = Mapper.Map<VendorNotificationsSettingsEntity>(command);
        upsertEntity.VendorId = agencyId;

        int id = await NotificationsSettingsRepository.Upsert(upsertEntity, x => x.VendorId == upsertEntity.VendorId, requestEntity =>
        {
            requestEntity.IsNotifyApplicantNotLogged = upsertEntity.IsNotifyApplicantNotLogged;
            requestEntity.NotifyApplicantNotLoggedDays = upsertEntity.NotifyApplicantNotLoggedDays;
            requestEntity.IsNotifyHRStatusChanges = upsertEntity.IsNotifyHRStatusChanges;
            requestEntity.NotifyHRStatusNotChangedDays = upsertEntity.NotifyHRStatusNotChangedDays;
            requestEntity.IsNotifyHRStatusNotChanged = upsertEntity.IsNotifyHRStatusNotChanged;
            requestEntity.NotifyHRNotLoggedDays = upsertEntity.NotifyHRNotLoggedDays;
            requestEntity.IsNotifyHRNotLogged = upsertEntity.IsNotifyHRNotLogged;
            requestEntity.IsRepeatNotifyApplicantRequiredTrainingDue = upsertEntity.IsRepeatNotifyApplicantRequiredTrainingDue;
            requestEntity.NotifyApplicantRequiredTrainingDueDays = upsertEntity.NotifyApplicantRequiredTrainingDueDays;
            requestEntity.IsNotifyApplicantRequiredTrainingDue = upsertEntity.IsNotifyApplicantRequiredTrainingDue;
            requestEntity.NotifyApplicantRequiredInfoMissingDays = upsertEntity.NotifyApplicantRequiredInfoMissingDays;
            requestEntity.IsNotifyApplicantStatusChanges = upsertEntity.IsNotifyApplicantStatusChanges;
            requestEntity.IsNotifyApplicantRequiredInfoMissing = upsertEntity.IsNotifyApplicantRequiredInfoMissing;

            requestEntity.Updated = DateTime.UtcNow;

            return requestEntity;
        });

        Logger.LogInformation($"Notifications settings for the agency id: {agencyId} have been updated");

        return new() { Id = id };
    }
}
