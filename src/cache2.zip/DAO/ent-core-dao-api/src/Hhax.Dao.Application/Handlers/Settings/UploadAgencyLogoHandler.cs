﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Settings;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Settings;

public class UploadAgencyLogoHandler : IRequestHandler<UploadAgencyLogoCommand, string>
{
    private readonly AwsS3Configuration _awsS3Configuration;
    
    private readonly IAwsImageService _awsFileService;
    private readonly IAuthenticationService _authenticationService;

    private readonly ILogger<UploadAgencyLogoHandler> _logger;

    public UploadAgencyLogoHandler(
        IOptions<AwsS3Configuration> awsS3ConfigurationOptions,
        IAwsImageService awsFileService,
        IAuthenticationService authenticationService,
        ILogger<UploadAgencyLogoHandler> logger)
    {
        _awsS3Configuration = awsS3ConfigurationOptions.Value;
        
        _awsFileService = awsFileService;
        _authenticationService = authenticationService;

        _logger = logger;
    }

    public async Task<string> Handle(UploadAgencyLogoCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");
        
        var agencyId = _authenticationService.GetAgencyId();

        _logger.LogInformation("Upload logo image with Agency Id: {agencyId} and  Type: {type}", agencyId, request.Type);

        var key = $"agencies/{agencyId}/{request.Type}/{request.FileName}";

        await _awsFileService.UploadImageAsync(_awsS3Configuration.BucketName!, key, request.FileName, request.Stream, request.Width, request.Height);

        _logger.LogInformation("Image logo was uploaded with {agencyId} and {type}", agencyId, request.Type);

        var response = await _awsFileService.GetImageUrlAsync(_awsS3Configuration.BucketName!, $"{key}.webp");

        return response;
    }
}
