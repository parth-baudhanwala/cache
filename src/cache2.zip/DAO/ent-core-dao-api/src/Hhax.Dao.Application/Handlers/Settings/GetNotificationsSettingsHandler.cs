﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Settings;
using Hhax.Dao.Application.Queries.Settings;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Settings;

public record GetNotificationsSettingsHandler(IReadOnlyRepository<VendorNotificationsSettingsEntity> NotificationsSettingsRepository,
                                              IMapper Mapper,
                                              IAuthenticationService AuthenticationService,
                                              ILogger<GetNotificationsSettingsHandler> Logger)
    : IRequestHandler<GetNotificationsSettingsQuery, NotificationsSettingsResponse>
{
    public async Task<NotificationsSettingsResponse> Handle(GetNotificationsSettingsQuery request, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        var agencyId = AuthenticationService.GetAgencyId();

        VendorNotificationsSettingsEntity? settings = await NotificationsSettingsRepository.FirstOrDefaultAsync(x => x.VendorId == agencyId);

        if(settings is not null)
        {
            Logger.LogInformation($"Notifications settings retrieved for the agency id: {agencyId}");
            return Mapper.Map< NotificationsSettingsResponse>(settings);
        }

        Logger.LogInformation($"Notifications settings for the agency id: {agencyId} not found, default returned");

        return NotificationsSettingsResponse.Default;
    }
}
