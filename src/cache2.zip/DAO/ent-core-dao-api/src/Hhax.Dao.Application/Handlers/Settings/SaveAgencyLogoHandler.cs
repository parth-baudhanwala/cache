﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Settings;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Settings
{
    public class SaveAgencyLogoHandler : IRequestHandler<SaveAgencyLogoCommand, BaseResponse>
    {
        private readonly IAuthenticationService _authenticationService;
        
        private readonly IGenericRepository<VendorLogoEntity> _vendorLogoRepository;

        private readonly ILogger<SaveAgencyLogoHandler> _logger;
        
        public SaveAgencyLogoHandler(
            IAuthenticationService authenticationService,
            IGenericRepository<VendorLogoEntity> vendorLogoRepository,
            ILogger<SaveAgencyLogoHandler> logger)
        {
            _authenticationService = authenticationService;
            
            _vendorLogoRepository = vendorLogoRepository;

            _logger = logger;
        }

        public async Task<BaseResponse> Handle(SaveAgencyLogoCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(Handle)}.");
            
            var agencyId = _authenticationService.GetAgencyId();
            var userId = _authenticationService.GetUserId();

            var agencyLogo = (await _vendorLogoRepository.FindAsync(v => v.VendorId == agencyId)).FirstOrDefault();
            if(agencyLogo == null)
            {
                var entity = new VendorLogoEntity
                {
                    VendorId = agencyId,
                    LogoFileExtension = request.FileExtension,
                    LogoFileName = request.FileName,
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow,
                    CreatedBy = userId,
                    UpdatedBy = userId
                };
                await _vendorLogoRepository.AddAsync(entity);

                _logger.LogInformation("Vendor with Id: {agencyId} has updated logo successfully.", agencyId);
                return new BaseResponse { Id = entity.Id };
            }
            agencyLogo.Updated = DateTime.UtcNow;
            agencyLogo.UpdatedBy = userId;
            agencyLogo.LogoFileName = request.FileName;
            agencyLogo.LogoFileExtension = request.FileExtension;

            await _vendorLogoRepository.UpdateAsync(agencyLogo);

            _logger.LogInformation("Vendor with Id: {agencyId} has updated logo successfully.", agencyId);
            return new BaseResponse { Id = agencyLogo.Id };
        }
    }
}
