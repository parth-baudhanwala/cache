﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Handlers.Office;
using Hhax.Dao.Application.Queries.Settings;
using Hhax.Dao.Domain.Settings;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Settings;

public class GetAgencyLogoHandler : IRequestHandler<GetAgencyLogoQuery, AgencyLogoInfo>
{
    private readonly AwsS3Configuration _awsS3Configuration;

    private readonly IAwsImageService _awsFileService;
    private readonly IAuthenticationService _authenticationService;
    
    private readonly IReadOnlyRepository<VendorLogoEntity> _vendorLogoRepository;
    private readonly IReadOnlyRepository<OfficeInfoEntity> _officeInfoRepository;
    
    private readonly ILogger<GetOfficeImageUrlQueryHandler> _logger;

    public GetAgencyLogoHandler(
            IOptions<AwsS3Configuration> awsS3ConfigurationOptions,
            IAwsImageService awsFileService,
            IAuthenticationService authenticationService,
            IReadOnlyRepository<VendorLogoEntity> vendorLogoRepository,
            IReadOnlyRepository<OfficeInfoEntity> officeInfoRepository,
            ILogger<GetOfficeImageUrlQueryHandler> logger)
    {
        _awsS3Configuration = awsS3ConfigurationOptions.Value;
        
        _awsFileService = awsFileService;
        _authenticationService = authenticationService;
        
        _vendorLogoRepository = vendorLogoRepository;
        _officeInfoRepository = officeInfoRepository;

        _logger = logger;
    }

    public async Task<AgencyLogoInfo> Handle(GetAgencyLogoQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");
        
        var agencyId = 0;

        var response = new AgencyLogoInfo
        {
            LogoFileExtension = string.Empty,
            LogoFileName = string.Empty,
            LogoFileSize = 0,
            LogoUrl = string.Empty
        };

        if(request.OfficeId != null && request.OfficeId != 0)
        {
            var office = await _officeInfoRepository.FirstOrDefaultAsync(o => o.Id == request.OfficeId);
            if(office == null)
            {
                return response;
            }
            agencyId = office.VendorId;
        } else
        {
            agencyId = _authenticationService.GetAgencyId();
        }

        _logger.LogInformation("Get logo image url with {agencyId} and {type}", agencyId, request.Type);
        
        var agencyInfo = (await _vendorLogoRepository.FindAsync(x => x.VendorId == agencyId)).FirstOrDefault();
        if(agencyInfo == null || string.IsNullOrEmpty(agencyInfo.LogoFileName))
        {
            return response;
        }
        
        var key = $"agencies/{agencyId}/{request.Type}/{agencyInfo.LogoFileName}";
        var image = await _awsFileService.GetImageAsync(_awsS3Configuration.BucketName!, $"{key}.webp");
        if(image == null)
        {
            _logger.LogInformation("No logo found for {agencyId} and {type}", agencyId, request.Type);
            return response;
        }

        var size = image.Length;
        var url = await _awsFileService.GetImageUrlAsync(_awsS3Configuration.BucketName!, $"{key}.webp");
        
        response = new AgencyLogoInfo
        {
            LogoFileExtension = agencyInfo.LogoFileExtension,
            LogoFileName = agencyInfo.LogoFileName,
            LogoFileSize = size,
            LogoUrl = url
        };

        return response;
    }
}
