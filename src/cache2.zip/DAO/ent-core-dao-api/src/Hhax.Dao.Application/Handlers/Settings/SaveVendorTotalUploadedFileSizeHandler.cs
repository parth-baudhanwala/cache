﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Settings;
using Hhax.Dao.Application.Commands.Settings;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Settings
{
    public class SaveVendorTotalUploadedFileSizeHandler : IRequestHandler<SaveVendorTotalUploadedFileSizeRequest, VendorTotalUploadedFileSizeResponse>
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IGenericRepository<VendorLogoEntity> _vendorLogoRepository;
        private readonly IReadOnlyRepository<OfficeInfoEntity> _officeInfoRepository;
        private readonly IReadOnlyRepository<ApplicantEntity> _applicantEntityRepository;
        private readonly ILogger<SaveVendorTotalUploadedFileSizeHandler> _logger;

        public SaveVendorTotalUploadedFileSizeHandler(
            ILogger<SaveVendorTotalUploadedFileSizeHandler> logger,
            IServiceProvider serviceProvider)
        {
            _authenticationService = serviceProvider.GetService<IAuthenticationService>()!;
            _vendorLogoRepository = serviceProvider.GetService<IGenericRepository<VendorLogoEntity>>()!;
            _officeInfoRepository = serviceProvider.GetService<IReadOnlyRepository<OfficeInfoEntity>>()!;
            _applicantEntityRepository = serviceProvider.GetService<IReadOnlyRepository<ApplicantEntity>>()!;
            _logger = logger;
        }

        public async Task<VendorTotalUploadedFileSizeResponse> Handle(SaveVendorTotalUploadedFileSizeRequest request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(Handle)}.");

            long? currentTotalUploadedFileUsage = 0;
            var userId = _authenticationService.GetUserId();
            int vendorId = _authenticationService.GetAgencyId();
            if (vendorId == 0)
            {
                var applicantEntity = await _applicantEntityRepository.FirstOrDefaultAsync(c => c.Id == request.ApplicantId);
                if (applicantEntity == null)
                {
                    return new VendorTotalUploadedFileSizeResponse { TotalUploadedFileUsage = 0 };
                }

                var office = await _officeInfoRepository.FirstOrDefaultAsync(o => o.Id == applicantEntity.OfficeId);
                if (office == null)
                {
                    return new VendorTotalUploadedFileSizeResponse { TotalUploadedFileUsage = 0 };
                }
                vendorId = office.VendorId;
            }

            var vendorLogoEntity = await _vendorLogoRepository.FirstOrDefaultAsync(v => v.VendorId == vendorId);
            if (vendorLogoEntity == null)
            {
                vendorLogoEntity = new VendorLogoEntity
                {
                    VendorId = vendorId,
                    TotalUploadedFileUsage = request.TotalUploadedFileUsage,
                    Created = DateTime.UtcNow,
                    CreatedBy = userId
                };
                await _vendorLogoRepository.AddAsync(vendorLogoEntity);

                _logger.LogInformation("Vendor with Id: {vendorId} has updated total uploaded file usage successfully.", vendorId);
                return new VendorTotalUploadedFileSizeResponse { TotalUploadedFileUsage = vendorLogoEntity.TotalUploadedFileUsage };
            }

            vendorLogoEntity.Updated = DateTime.UtcNow;
            vendorLogoEntity.UpdatedBy = userId;
            currentTotalUploadedFileUsage = vendorLogoEntity.TotalUploadedFileUsage;

            if (currentTotalUploadedFileUsage is not null)
            {
                vendorLogoEntity.TotalUploadedFileUsage = currentTotalUploadedFileUsage + request.TotalUploadedFileUsage;
            }
            else
            {
                vendorLogoEntity.TotalUploadedFileUsage = request.TotalUploadedFileUsage;
            }

            await _vendorLogoRepository.UpdateAsync(vendorLogoEntity);

            _logger.LogInformation("Vendor with Id: {vendorId} has updated total uploaded file usage successfully.", vendorId);

            return new VendorTotalUploadedFileSizeResponse { TotalUploadedFileUsage = vendorLogoEntity.TotalUploadedFileUsage };
        }
    }
}
