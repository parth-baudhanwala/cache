﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.InService;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.InService;

public class GetTopicsHandler : IRequestHandler<GetTopicsQuery, IEnumerable<InServiceTopic>>
{
    private readonly IReadOnlyRepository<RefInServiceTopicEntity> _refInServiceTopicRepository;
    private readonly IReadOnlyRepository<ApplicationFormOfficeMappingEntity> _applicationFormOfficeMappingRepository;
    private readonly IReadOnlyRepository<ApplicationFormEntity> _applicationFormEntityRepository;
    private readonly IReadOnlyRepository<ApplicationFormApplicantRequirementEntity> _applicationFormApplicantRequirementRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly ILogger<GetTopicsHandler> _logger;
    private readonly IMapper _mapper;
    private const short _isActive = 1;

    public GetTopicsHandler(
        IReadOnlyRepository<RefInServiceTopicEntity> refInServiceTopicRepository,
        IReadOnlyRepository<ApplicationFormOfficeMappingEntity> applicationFormOfficeMappingRepository,
        IReadOnlyRepository<ApplicationFormEntity> applicationFormEntityRepository,
        IReadOnlyRepository<ApplicationFormApplicantRequirementEntity> applicationFormApplicantRequirementRepository,
        IAuthenticationService authenticationService,
        ILogger<GetTopicsHandler> logger,
        IMapper mapper)
    {
        _refInServiceTopicRepository = refInServiceTopicRepository;
        _applicationFormOfficeMappingRepository = applicationFormOfficeMappingRepository;
        _applicationFormEntityRepository = applicationFormEntityRepository;
        _applicationFormApplicantRequirementRepository = applicationFormApplicantRequirementRepository;
        _authenticationService = authenticationService;
        _logger = logger;
        _mapper = mapper;
    }

    public async Task<IEnumerable<InServiceTopic>> Handle(GetTopicsQuery request, CancellationToken cancellationToken)
    {
        int agencyId = _authenticationService.GetAgencyId();

        var mapping = await _applicationFormOfficeMappingRepository.FirstOrDefaultAsync(m => m.OfficeId == request.OfficeId);
        if(mapping == null)
        {
            return new List<InServiceTopic>();
        }

        var requirements = await _applicationFormApplicantRequirementRepository
            .FindAsync(r => r.ApplicationFormId == mapping.ApplicationFormId && r.ApplicantSectionId == (int)ApplicationFormApplicantSections.InServiceTopics);

        var filteredRequirements = requirements.Select(r => r.ApplicantFieldId);

        var refInServiceTopicsEntities =
            await _refInServiceTopicRepository.FindAsync(refInServiceTopic =>
                filteredRequirements.Contains(refInServiceTopic.Id));

        var result = refInServiceTopicsEntities.Select(t => new InServiceTopic { 
            Id = t.Id,
            Active = t.Active,
            TopicDescription = t.TopicDescription,
            IsShow = requirements.FirstOrDefault(r => r.ApplicantFieldId == t.Id).IsShow,
            IsRequire = requirements.FirstOrDefault(r => r.ApplicantFieldId == t.Id).IsRequire
        });
        return result;
    }
}
