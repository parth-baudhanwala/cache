﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.InService;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;

namespace Hhax.Dao.Application.Handlers.InService
{
    public class GetInServiceInstructorsHandler : IRequestHandler<GetInServiceInstructorsQuery, IEnumerable<InServiceInstructor>>
    {
        private readonly IReadOnlyRepository<InstructorEntity> _instructorEntityRepository;
        private readonly IAuthenticationService _authenticationService;
        private readonly IMapper _mapper;
        private const short _isActive = 1;

        public GetInServiceInstructorsHandler(
            IReadOnlyRepository<InstructorEntity> instructorEntityRepository,
            IAuthenticationService authenticationService,
            IMapper mapper)
        {
            _instructorEntityRepository = instructorEntityRepository;
            _authenticationService = authenticationService;
            _mapper = mapper;
        }

        public async Task<IEnumerable<InServiceInstructor>> Handle(GetInServiceInstructorsQuery request, CancellationToken cancellationToken)
        {
            var agencyId = _authenticationService.GetAgencyId();

            var instructors = await _instructorEntityRepository.FindAsync(i => i.CompanyId == agencyId && i.Active == _isActive);

            var mapped = _mapper.Map<List<InServiceInstructor>>(instructors); 
            
            return mapped.OrderBy(i => i.InstructorName);
        }
    }
}
