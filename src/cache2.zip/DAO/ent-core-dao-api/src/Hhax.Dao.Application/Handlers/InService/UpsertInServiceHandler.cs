﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.InService;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.InService;

public record UpsertInServiceHandler(IGenericRepository<ApplicantInServiceEntity> ApplicantInServiceRepository,
                                     IGenericRepository<InServiceTopicEntity> InServiceTopicEntityRepository,
                                     IAuthenticationService AuthenticationService,
                                     ILogger<UpsertInServiceHandler> Logger,
                                     IMapper Mapper,
                                     IMediator Mediator)
    : IRequestHandler<UpsertInServiceCommand, BaseResponse>
{
    public async Task<BaseResponse> Handle(UpsertInServiceCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        await Mediator.Send(new ValidateApplicantRequestDataCommand(command.ApplicantId, null, new[] { Mapper.Map<ApplicantInServiceTableItem>(command) }, ApplicantEligibilitySection.InService), cancellationToken);

        var userId = AuthenticationService.GetUserId();

        var entity = Mapper.Map<ApplicantInServiceEntity>(command);

        int success = await ApplicantInServiceRepository.Upsert(entity, x => x.Id == command.Id, requestedEntity =>
        {
            requestedEntity.Date = entity.Date;
            requestedEntity.StartTime = entity.StartTime;
            requestedEntity.EndTime = entity.EndTime;
            requestedEntity.InstructorId = entity.InstructorId;
            requestedEntity.DisciplineId = entity.DisciplineId;
            requestedEntity.PaycodeId = entity.PaycodeId;
            requestedEntity.Status = entity.Status;
            requestedEntity.NoShowReasonId = entity.NoShowReasonId;

            requestedEntity.Updated = DateTime.UtcNow;
            return requestedEntity;
        });
        
        var inServiceTopics = await InServiceTopicEntityRepository.FindAsync(t => t.InServiceId == entity.Id);

        await UpdateInServiceTopics(entity.Id, inServiceTopics, command);
        await UpdateApplicantEligibilities(command.ApplicantId, cancellationToken);

        Logger.LogInformation("In service session with Id: {Id} was created.", entity.Id);

        return new BaseResponse { Id = entity.Id };
    }

    private async Task UpdateInServiceTopics(
        int inServiceId, 
        IEnumerable<InServiceTopicEntity> inServiceTopicEntities, 
        UpsertInServiceCommand command)
    {
        foreach(var topic in inServiceTopicEntities)
        {
            if(!command.TopicIds.Any(t => t == topic.TopicId))
            {
                await InServiceTopicEntityRepository.RemoveAsync(topic);
            }
        }

        if(command.TopicIds != null)
        {
            foreach(var topicId in command.TopicIds)
            {
                if(!inServiceTopicEntities.Any(t => t.TopicId == topicId))
                {
                    var inServiceTopic = new InServiceTopicEntity
                    {
                        TopicId = topicId,
                        InServiceId = inServiceId
                    };
                    await InServiceTopicEntityRepository.AddAsync(inServiceTopic);
                }
            }
        }
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
