﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.InService;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;

namespace Hhax.Dao.Application.Handlers.InService;

public class GetPaycodesHandler : IRequestHandler<GetPaycodesQuery, IEnumerable<InServicePayRate>>
{
    private readonly IReadOnlyRepository<PayRateEntity> _payRateRepository;
    private readonly IReadOnlyRepository<DisciplineRateEntity> _disciplineRateRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IMapper _mapper;

    public GetPaycodesHandler(
        IReadOnlyRepository<PayRateEntity> payRateRepository,
        IReadOnlyRepository<DisciplineRateEntity> disciplineRateRepository,
        IAuthenticationService authenticationService,
        IMapper mapper)
    {
        _payRateRepository = payRateRepository;
        _disciplineRateRepository = disciplineRateRepository;
        _authenticationService = authenticationService;
        _mapper = mapper;
    }

    public async Task<IEnumerable<InServicePayRate>> Handle(GetPaycodesQuery request, CancellationToken cancellationToken)
    {
        var agencyId = _authenticationService.GetAgencyId();

        var paycodesByDiscipline = await _disciplineRateRepository.FindAsync(r => r.Discipline == request.DisciplineId && r.CompanyId == agencyId);
        if (paycodesByDiscipline.Any())
        {
            var paycodes = await _payRateRepository
            .FindAsync(p => paycodesByDiscipline.Select(r => r.PayRateId).Contains(p.Id));

            return _mapper.Map<List<InServicePayRate>>(paycodes);
        }

        return new List<InServicePayRate>();
    }
}
