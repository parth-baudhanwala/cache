﻿using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.InService;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Hhax.Dao.Application.Handlers.InService;

public class DeleteInServiceHandler : IRequestHandler<DeleteInServiceCommand, Unit>
{
    private readonly IGenericRepository<ApplicantInServiceEntity> _applicantInServiceRepository;
    private readonly ILogger<DeleteInServiceHandler> _logger;
    private readonly IMediator _mediator;

    public DeleteInServiceHandler(
        IGenericRepository<ApplicantInServiceEntity> applicantInServiceRepository,
        ILogger<DeleteInServiceHandler> logger,
        IMediator mediator)
    {
        _applicantInServiceRepository = applicantInServiceRepository;
        _logger = logger;
        _mediator = mediator;
    }

    public async Task<Unit> Handle(DeleteInServiceCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var entity = await _applicantInServiceRepository
            .FirstOrDefaultAsync(x => x.Id == request.InServiceId && x.ApplicantId == request.ApplicantId);
        if(entity != null)
        {
            await _applicantInServiceRepository.RemoveAsync(entity);
            await UpdateApplicantEligibilities(request.ApplicantId, cancellationToken);

            _logger.LogInformation("In-service with Id: {Id} was deleted.", entity.Id);
        }
        
        return Unit.Value;
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await _mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
