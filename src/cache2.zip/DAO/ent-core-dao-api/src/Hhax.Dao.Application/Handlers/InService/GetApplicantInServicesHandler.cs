﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Compliance;
using System.Threading.Tasks;

namespace Hhax.Dao.Application.Handlers.InService;

public class GetApplicantInServicesHandler : IRequestHandler<GetApplicantInServicesQuery, PaginatationResponse<ApplicantInServiceTableItem>>
{
    private readonly IReadOnlyRepository<ApplicantInServiceEntity> _applicantInServiceRepository;
    private readonly IReadOnlyRepository<InstructorEntity> _instructorRepository;
    private readonly IReadOnlyRepository<InserviceNoShowReasonEntity> _inserviceNoShowReasonRepository;
    private readonly IReadOnlyRepository<InServiceTopicEntity> _inServiceTopicRepository;
    private readonly IReadOnlyRepository<RefInServiceTopicEntity> _refInServiceTopicEntity;
    private readonly IReadOnlyRepository<DisciplineEntity> _disciplineRepository;

    public GetApplicantInServicesHandler(
        IReadOnlyRepository<ApplicantInServiceEntity> applicantInServiceRepository,
        IReadOnlyRepository<InstructorEntity> instructorRepository,
        IReadOnlyRepository<InserviceNoShowReasonEntity> inserviceNoShowReasonRepository,
        IReadOnlyRepository<InServiceTopicEntity> inServiceTopicRepository,
        IReadOnlyRepository<RefInServiceTopicEntity> refInServiceTopicEntity,
        IReadOnlyRepository<DisciplineEntity> disciplineRepository)
    {
        _applicantInServiceRepository = applicantInServiceRepository;
        _instructorRepository = instructorRepository;
        _inserviceNoShowReasonRepository = inserviceNoShowReasonRepository;
        _inServiceTopicRepository = inServiceTopicRepository;
        _refInServiceTopicEntity = refInServiceTopicEntity;
        _disciplineRepository = disciplineRepository;
    }

    public async Task<PaginatationResponse<ApplicantInServiceTableItem>> Handle(GetApplicantInServicesQuery request, CancellationToken cancellationToken)
    {
        var resultList = new List<ApplicantInServiceTableItem>();
        var filteredList = new List<ApplicantInServiceEntity>();
        var total = 0;

        var response = new PaginatationResponse<ApplicantInServiceTableItem>
        {
            Data = Enumerable.Empty<ApplicantInServiceTableItem>(),
            PageInfo = new PageInfo { TotalRecordCount = 0 }
        };

        if(request.Request.Filters is not null)
        {
            var rows = await _applicantInServiceRepository.FindAsync(s => s.ApplicantId == request.Request.Filters.ApplicantId);
            total = rows.Count();

            rows = rows.OrderByDescending(x => x.Id);

            if (request.Request.Page is not null)
                filteredList = rows.Skip((request.Request.Page.PageNumber - 1) * request.Request.Page.PageSize)
                                       .Take(request.Request.Page.PageSize)
                                       .ToList();
            else
                filteredList = rows.ToList();
        }
        
        foreach(var inService in filteredList)
        {
            var item = new ApplicantInServiceTableItem { 
                Id = inService.Id,
                ApplicantId = inService.ApplicantId,
                PaycodeId = inService.PaycodeId
            };

            item.Date = inService.Date.Value!;
            item.StartTime = inService.StartTime;
            item.EndTime = inService.EndTime;
            
            var instructor = await _instructorRepository.FirstOrDefaultAsync(i => i.Id == inService.InstructorId);
            if(instructor != null && instructor.InstructorName != null)
            {
                item.InstructorId = instructor.Id;
                item.Instructor = instructor.InstructorName;
            }

            if(inService.DisciplineId.HasValue)
            {
                var discipline = await _disciplineRepository.GetByIdAsync(inService.DisciplineId.Value);
                if (discipline != null)
                {
                    item.DisciplineId = discipline.Id;
                    item.Discipline = discipline.Name!;
                }
            }

            if(inService.Status.HasValue)
            {
                item.StatusId = inService.Status;
                item.Status = EnumsExtensions.GetValue((InServiceStatus)inService.Status.Value);
            }
            
            if(inService.NoShowReasonId != null)
            {
                var reason = await _inserviceNoShowReasonRepository.FirstOrDefaultAsync(r => r.Id == inService.NoShowReasonId);
                if(reason != null)
                {
                    item.ReasonId = reason.Id;
                    item.Reason = reason.Reason!;
                }
            }

            var topicIds = (await _inServiceTopicRepository.FindAsync(t => t.InServiceId == inService.Id)).Select(t => t.TopicId);
            var topics = await _refInServiceTopicEntity.FindAsync(t => topicIds.Contains(t.Id));

            if(topics != null)
            {
                item.TopicIds = topics.Select(t => t.Id).ToArray();
                item.Topic = string.Join(", ", topics.Select(t => t.TopicDescription));
            }

            resultList.Add(item);
        }

        response.Data = resultList;
        response.PageInfo.TotalRecordCount = total;

        return response;
    }
}
