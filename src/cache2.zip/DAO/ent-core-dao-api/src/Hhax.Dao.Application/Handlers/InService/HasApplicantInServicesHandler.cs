﻿using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hhax.Dao.Application.Handlers.InService;

public class HasApplicantInServicesHandler : IRequestHandler<HasApplicantInServicesQuery, HasApplicantInServices>
{
    private readonly IReadOnlyRepository<ApplicantInServiceEntity> _applicantInServiceRepository;

    public HasApplicantInServicesHandler(IReadOnlyRepository<ApplicantInServiceEntity> applicantInServiceRepository)
    {
        _applicantInServiceRepository = applicantInServiceRepository;
    }

    public async Task<HasApplicantInServices> Handle(HasApplicantInServicesQuery request, CancellationToken cancellationToken)
    {
        var inServiceExsists = await _applicantInServiceRepository.FirstOrDefaultAsync(s => s.ApplicantId == request.ApplicantId);
        return new HasApplicantInServices
        {
            ApplicationId = request.ApplicantId,
            HasInServices = inServiceExsists != null
        };
    }
}
