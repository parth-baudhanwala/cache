﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.InService;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;

namespace Hhax.Dao.Application.Handlers.InService;

public class GetInServiceNoShowReasonsHandler : IRequestHandler<GetInServiceNoShowReasonsQuery, IEnumerable<InServiceNoShowReason>>
{
    private readonly IReadOnlyRepository<InserviceNoShowReasonEntity> _inserviceNoShowReasonRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IMapper _mapper;

    public GetInServiceNoShowReasonsHandler(
        IReadOnlyRepository<InserviceNoShowReasonEntity> inserviceNoShowReasonRepository,
        IAuthenticationService authenticationService,
        IMapper mapper)
    {
        _inserviceNoShowReasonRepository = inserviceNoShowReasonRepository;
        _authenticationService = authenticationService;
        _mapper = mapper;
    }

    public async Task<IEnumerable<InServiceNoShowReason>> Handle(GetInServiceNoShowReasonsQuery request, CancellationToken cancellationToken)
    {
        var agencyId = _authenticationService.GetAgencyId();

        var reasons = await _inserviceNoShowReasonRepository.FindAsync(r => r.CompanyId == agencyId && r.Active);

        return _mapper.Map<List<InServiceNoShowReason>>(reasons); 
    }
}
