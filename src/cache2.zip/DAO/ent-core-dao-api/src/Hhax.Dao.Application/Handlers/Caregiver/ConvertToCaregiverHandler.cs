﻿using Hhax.Dao.Application.Abstracts.Caregiver;
using Hhax.Dao.Application.Abstracts.Interfaces.Caregiver;
using Hhax.Dao.Application.Abstracts.Responses.Caregiver;
using Hhax.Dao.Application.Commands.Caregiver;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Caregiver;

public record ConvertToCaregiverHandler(ICreateCaregiverRequestBuilder CreateCaregiverRequestBuilder,
                                        ICaregiverApiClient CaregiverAPIClient,
                                        ILogger<ConvertToCaregiverHandler> Logger)
    : IRequestHandler<ConvertToCaregiverCommand, CreateCaregiverResponse>
{
    public async Task<CreateCaregiverResponse> Handle(ConvertToCaregiverCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");
        CreateCaregiverRequest request = CreateCaregiverRequestBuilder.SetApplicant(command.ApplicantId)
                                                                      .WithProfile()
                                                                      .WithComplinaceI9()
                                                                      .WithCriminalBackgroundCheck()
                                                                      .WithTrainingSchools()
                                                                      .WithMedicalsAndOtherRequirement()
                                                                      .WithComplinaceCustomFields()
                                                                      .WithInService()
                                                                      .WithAvailability()
                                                                      .WithCustomFields()
                                                                      .WithOnBoardingForms()
                                                                      .CreateRequest();

        var caregiverResponse = await CaregiverAPIClient.ConvertApplicantToCaregiver(request).ConfigureAwait(false);
        Logger.LogInformation("Applicant is converted successfully into caregiver: {ApplicantId}", command.ApplicantId);
        return caregiverResponse;
    }
}
