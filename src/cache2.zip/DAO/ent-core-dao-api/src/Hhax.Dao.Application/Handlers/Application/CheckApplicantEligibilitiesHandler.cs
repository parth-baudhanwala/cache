﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Application;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.InService;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Application.Queries.MedicalsOther;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class CheckApplicantEligibilitiesHandler : IRequestHandler<CheckApplicantEligibilitiesCommand, Unit>
{
    private readonly IMediator _mediator;

    private readonly IReadOnlyRepository<ApplicantEntity> _applicantRepository;
    private readonly IReadOnlyRepository<AvailabilityDayEntity> _availabilityDayRepository;
    private readonly IReadOnlyRepository<ComplianceBackgroundCheckEntity> _complianceBackgroundCheckRepository;
    private readonly IReadOnlyRepository<ApplicationFormEntity> _applicationFormEntityRepository;
    private readonly IReadOnlyRepository<ComplianceTrainingSchoolEntity> _trainingSchoolRepository;

    private readonly IGenericRepository<ApplicantEligibilityEntity> _applicantEligibilityEntityRepository;

    private readonly IAuthenticationService _authenticationService;
    private readonly IApplicantProfileService _applicantProfileService;

    private readonly ILogger<CheckApplicantEligibilitiesHandler> _logger;

    public CheckApplicantEligibilitiesHandler(IMediator mediator,
                                              IReadOnlyRepository<ApplicantEntity> applicantEntityRepository,
                                              IReadOnlyRepository<AvailabilityDayEntity> availabilityDayRepository,
                                              IReadOnlyRepository<ComplianceBackgroundCheckEntity> complianceBackgroundCheckRepository,
                                              IReadOnlyRepository<ApplicationFormEntity> applicationFormEntityRepository,
                                              IReadOnlyRepository<ComplianceTrainingSchoolEntity> trainingSchoolRepository,
                                              IGenericRepository<ApplicantEligibilityEntity> applicantEligibilityEntityRepository,
                                              IAuthenticationService authenticationService,
                                              IApplicantProfileService applicantProfileService,
                                              ILogger<CheckApplicantEligibilitiesHandler> logger)
    {
        _mediator = mediator;

        _applicantRepository = applicantEntityRepository;
        _availabilityDayRepository = availabilityDayRepository;
        _complianceBackgroundCheckRepository = complianceBackgroundCheckRepository;
        _applicationFormEntityRepository = applicationFormEntityRepository;
        _trainingSchoolRepository = trainingSchoolRepository;

        _applicantEligibilityEntityRepository = applicantEligibilityEntityRepository;

        _authenticationService = authenticationService;
        _applicantProfileService = applicantProfileService;

        _logger = logger;
    }

    public async Task<Unit> Handle(CheckApplicantEligibilitiesCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Check Applicant Eligibility with Applicant Id: {applicantId}", request.ApplicantId);

        var userId = _authenticationService.GetUserId();

        // Get applicant by ApplicantId
        var applicantEntity = await _applicantRepository.FirstOrDefaultAsync(applicant => applicant.Id == request.ApplicantId, true);
        if (applicantEntity == null)
        {
            var message = $"Applicant with Id: {request.ApplicantId} not found.";
            throw new ApplicantNotFoundException(message);
        }

        // Get applicant requirements by OfficeId
        var getApplicantRequirementsByOfficeIdQuery = new GetApplicationFormApplicantRequirementsByOfficeIdQuery(applicantEntity.OfficeId);
        var applicantRequirements = await _mediator.Send(getApplicantRequirementsByOfficeIdQuery, cancellationToken);

        // Get application form by OfficeId
        var applicationFormEntity = await _applicationFormEntityRepository.FirstOrDefaultAsync(applicationForm => applicationForm.ApplicationFormOfficeMappings != null &&
                                                                                                                  applicationForm.ApplicationFormOfficeMappings.Any(f => f.OfficeId == applicantEntity.OfficeId));
        if (applicationFormEntity == null)
        {
            var message = $"{nameof(ApplicationFormEntity)} with OfficeId: {applicantEntity.OfficeId} not found.";

            _logger.LogError("Application Form with OfficeId: {applicationFormId} not found.", applicantEntity.OfficeId);
            throw new ApplicationFormNotFoundException(message);
        }

        // Validate applicant profile section
        await ValidateApplicantProfileSectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId);

        // Validate applicant I-9 section
        await ValidateApplicantI9SectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId, cancellationToken);

        // Validate applicant availability section
        await ValidateApplicantAvailabilitySectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId);

        // Validate applicant background check section
        await ValidateApplicantBackgroundCheckSectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId);

        // Validate applicant training schools section
        await ValidateApplicantTrainingSchoolsSectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId);

        // Validate applicant custom fields section
        await ValidateApplicantCustomFieldsSectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId, cancellationToken);

        // Validate applicant medical section
        await ValidateApplicantMedicalsSectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId, cancellationToken);

        // Validate applicant other documents section
        await ValidateApplicantOtherDocumentsSectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId, cancellationToken);

        // Validate applicant other documents section
        await ValidateApplicantInServiceSectionAsync(request, applicantEntity, applicantRequirements, applicationFormEntity, userId, cancellationToken);

        _logger.LogInformation("Applicant Eligibility with Applicant Id: {applicantId} was checked successfully.", request.ApplicantId);

        return Unit.Value;
    }

    /// <summary>
    /// Validate applicant profile section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    private async Task ValidateApplicantProfileSectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                            IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                            ApplicationFormEntity applicationFormEntity, int userId)
    {
        var applicantProfileSectionNotEligibleFields = _applicantProfileService.ValidateApplicantProfileSection(applicantEntity, applicantRequirements);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantProfileSectionNotEligibleFields.Any(), ApplicationFormApplicantSections.Demographics);
    }

    /// <summary>
    /// Validate applicant I-9 section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    private async Task ValidateApplicantI9SectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                       IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                       ApplicationFormEntity applicationFormEntity, int userId,
                                                       CancellationToken cancellationToken)
    {
        IEnumerable<I9ColumnABDocument> i9ColumnABDocuments = new List<I9ColumnABDocument>();
        try
        {
            var getColumnAbDocumentsQuery = new GetColumnAbDocumentsQuery(applicantEntity.OfficeId);
            i9ColumnABDocuments = await _mediator.Send(getColumnAbDocumentsQuery, cancellationToken);
        }
        catch (Exception exc)
        {
            _logger.LogError(exc.Message);
        }

        var getI9RequirementsQuery = new GetI9RequirementsQuery(applicantEntity.Id);
        var i9Requirement = await _mediator.Send(getI9RequirementsQuery, cancellationToken);

        var applicantI9SectionNotEligibileFields = _applicantProfileService.ValidateApplicantI9Section(i9ColumnABDocuments, i9Requirement, applicantRequirements, false, false);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantI9SectionNotEligibileFields.Any(),
                                          ApplicationFormApplicantSections.GeneralCompliance,
                                          ApplicationFormApplicantFields.I9);

    }

    /// <summary>
    /// Validate applicant availability section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    private async Task ValidateApplicantAvailabilitySectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                                 IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                                 ApplicationFormEntity applicationFormEntity, int userId)
    {
        var applicantAvailabilityDays = await _availabilityDayRepository.FindAsync(x => x.ApplicantId == request.ApplicantId, true);

        var applicantAvailabilityNotEligibleFields = _applicantProfileService.ValidateApplicantAvailabilitySection(applicantAvailabilityDays, applicantRequirements);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantAvailabilityNotEligibleFields.Any(),
                                          ApplicationFormApplicantSections.Availability);
    }

    /// <summary>
    /// Validate applicant background check section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    private async Task ValidateApplicantBackgroundCheckSectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                                    IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                                    ApplicationFormEntity applicationFormEntity, int userId)
    {
        var backgroundChecks = await _complianceBackgroundCheckRepository.FindAsync(x => x.ApplicantId == request.ApplicantId, true);

        var applicantBackgroundCheckNotEligibleFields = _applicantProfileService.ValidateApplicantBackgroundCheckSection(backgroundChecks, applicantRequirements);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantBackgroundCheckNotEligibleFields.Any(),
                                          ApplicationFormApplicantSections.GeneralCompliance,
                                          ApplicationFormApplicantFields.BackgroundCheck);
    }

    /// <summary>
    /// Validate applicant training schools section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    private async Task ValidateApplicantTrainingSchoolsSectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                                    IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                                    ApplicationFormEntity applicationFormEntity, int userId)
    {
        var applicanTrainingSchools = await _trainingSchoolRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);

        var applicantTrainingSchoolsNotEligibleFields = _applicantProfileService.ValidateApplicantTrainingSchoolsCheckSection(applicanTrainingSchools, applicantRequirements, false, false);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantTrainingSchoolsNotEligibleFields.Any(),
                                          ApplicationFormApplicantSections.GeneralCompliance,
                                          ApplicationFormApplicantFields.TrainingSchools);
    }

    /// <summary>
    /// Validate applicant custom fields section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    private async Task ValidateApplicantCustomFieldsSectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                                    IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                                    ApplicationFormEntity applicationFormEntity, int userId,
                                                                    CancellationToken cancellationToken)
    {

        var getComplianceCustomFieldsQuery = new GetComplianceCustomFieldsQuery(applicantEntity.Id, applicantEntity.OfficeId);
        var customFieldModel = await _mediator.Send(getComplianceCustomFieldsQuery, cancellationToken);

        var applicantOtherDocumentsNotEligibleFields = _applicantProfileService.ValidateApplicantCustomComplianceSection(customFieldModel.ComplianceCustomFields, applicantRequirements);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantOtherDocumentsNotEligibleFields.Any(),
                                          ApplicationFormApplicantSections.ComplianceFields);
    }

    /// <summary>
    /// Validate applicant medicals section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    private async Task ValidateApplicantMedicalsSectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                                    IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                                    ApplicationFormEntity applicationFormEntity, int userId,
                                                                    CancellationToken cancellationToken)
    {
        // Get applicant medicals by OfficeId
        var getMedicalsRequirementsQuery = new GetMedicalsRequirementsQuery(applicantEntity.Id, applicantEntity.OfficeId);
        var medicalsApplicantValues = await _mediator.Send(getMedicalsRequirementsQuery, cancellationToken);

        var applicantMedicalsNotEligibleFields = _applicantProfileService.ValidateApplicantMedicalsCheckSection(medicalsApplicantValues, applicantRequirements);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantMedicalsNotEligibleFields.Any(),
                                          ApplicationFormApplicantSections.MedicalsAndOtherDocuments,
                                          ApplicationFormApplicantFields.Medicals);
    }

    /// <summary>
    /// Validate applicant other documents section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    private async Task ValidateApplicantOtherDocumentsSectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                                    IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                                    ApplicationFormEntity applicationFormEntity, int userId,
                                                                    CancellationToken cancellationToken)
    {
        // Get applicant other documents by OfficeId
        var getOtherDocumentsRequirementsQuery = new GetOtherRequirementsQuery(applicantEntity.Id, applicantEntity.OfficeId);
        var otherDocumentsApplicantValues = await _mediator.Send(getOtherDocumentsRequirementsQuery, cancellationToken);

        var applicantOtherDocumentsNotEligibleFields = _applicantProfileService.ValidateApplicantOtherDocumentsCheckSection(otherDocumentsApplicantValues, applicantRequirements);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantOtherDocumentsNotEligibleFields.Any(),
                                          ApplicationFormApplicantSections.MedicalsAndOtherDocuments,
                                          ApplicationFormApplicantFields.OtherDocuments);
    }

    /// <summary>
    /// Validate applicant other documents section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <returns></returns>
    private async Task ValidateApplicantInServiceSectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                                    IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                                    ApplicationFormEntity applicationFormEntity, int userId,
                                                                    CancellationToken cancellationToken)
    {

        // Get applicant in-service values by Office Id
        var getTopicsQuery = new GetTopicsQuery(applicantEntity.OfficeId);
        var topicsValues = await _mediator.Send(getTopicsQuery, cancellationToken);

        // Get applicant services by Applicant Id
        var query = new PaginationRequest<GetApplicantInServices>()
        {
            Filters = new GetApplicantInServices
            {
                ApplicantId = applicantEntity.Id
            }
        };
        var getApplicantInServicesQuery = new GetApplicantInServicesQuery(query);
        var inServiceApplicantValues = await _mediator.Send(getApplicantInServicesQuery, cancellationToken);

        var applicantOtherDocumentsNotEligibleFields = _applicantProfileService.ValidateApplicantInServiceSection(inServiceApplicantValues?.Data!, topicsValues, applicantRequirements);
        await UpsertApplicantSectionAsync(request, applicantEntity, applicationFormEntity, userId,
                                          applicantOtherDocumentsNotEligibleFields.Any(),
                                          ApplicationFormApplicantSections.InServiceTopics);
    }

    /// <summary>
    /// Upsert applcant section
    /// </summary>
    /// <param name="request"></param>
    /// <param name="applicantEntity"></param>
    /// <param name="applicationFormEntity"></param>
    /// <param name="userId"></param>
    /// <param name="hasEligibleFields"></param>
    /// <param name="applicationFormApplicantSections"></param>
    /// <param name="applicationFormApplicantFields"></param>
    /// <returns></returns>
    private async Task UpsertApplicantSectionAsync(CheckApplicantEligibilitiesCommand request, ApplicantEntity applicantEntity,
                                                   ApplicationFormEntity applicationFormEntity, int userId, bool hasEligibleFields,
                                                   ApplicationFormApplicantSections applicationFormApplicantSections,
                                                   ApplicationFormApplicantFields? applicationFormApplicantFields = null)
    {
        var applicantEligibilityEntity = applicationFormApplicantFields.HasValue ? await _applicantEligibilityEntityRepository.FirstOrDefaultAsync(applicantEligibility => applicantEligibility.ApplicantId == request.ApplicantId &&
                                                                                                                                                                           applicantEligibility.ApplicantSectionId == (int)applicationFormApplicantSections &&
                                                                                                                                                                           applicantEligibility.ApplicantFieldId == (int?)applicationFormApplicantFields)
                                                                                 : await _applicantEligibilityEntityRepository.FirstOrDefaultAsync(applicantEligibility => applicantEligibility.ApplicantId == request.ApplicantId &&
                                                                                                                                                                           applicantEligibility.ApplicantSectionId == (int)applicationFormApplicantSections);


        if (applicantEligibilityEntity == null)
        {
            applicantEligibilityEntity = new ApplicantEligibilityEntity
            {
                ApplicantId = applicantEntity.Id,
                ApplicantEligibilityStatusId = hasEligibleFields ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                 : (int)ApplicantEligibilityStatuses.RequirementsCompleted,
                ApplicationFormId = applicationFormEntity.Id,
                IsVerified = true,
                ApplicantSectionId = (int)applicationFormApplicantSections,
                ApplicantFieldId = (int?)applicationFormApplicantFields,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow,
                CreatedBy = userId,
                UpdatedBy = userId
            };
            await _applicantEligibilityEntityRepository.AddAsync(applicantEligibilityEntity);
        }
        else
        {
            applicantEligibilityEntity.ApplicantId = applicantEntity.Id;
            applicantEligibilityEntity.ApplicantEligibilityStatusId = hasEligibleFields ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                        : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
            applicantEligibilityEntity.ApplicationFormId = applicationFormEntity.Id;
            applicantEligibilityEntity.ApplicantFieldId = (int?)applicationFormApplicantFields;
            applicantEligibilityEntity.IsVerified = true;
            applicantEligibilityEntity.ApplicantSectionId = (int)applicationFormApplicantSections;
            applicantEligibilityEntity.Updated = DateTime.UtcNow;
            applicantEligibilityEntity.UpdatedBy = userId;

            await _applicantEligibilityEntityRepository.UpdateAsync(applicantEligibilityEntity);
        }
    }
}
