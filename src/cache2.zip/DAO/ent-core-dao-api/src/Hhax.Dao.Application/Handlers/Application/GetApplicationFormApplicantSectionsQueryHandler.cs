﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormApplicantSectionsQueryHandler : IRequestHandler<GetApplicationFormApplicantSectionsQuery, IEnumerable<ApplicationFormApplicantSection>>
{
    private readonly ILookupService<ApplicationFormApplicantSection, ApplicationFormApplicantSectionEntity> _applicantSectionLookupService;
    private readonly IMediator _mediator;

    private readonly ILogger<GetApplicationFormApplicantSectionsQueryHandler> _logger;

    public GetApplicationFormApplicantSectionsQueryHandler(ILookupService<ApplicationFormApplicantSection, ApplicationFormApplicantSectionEntity> applicantSectionLookupService,
                                                           IMediator mediator,
                                                           ILogger<GetApplicationFormApplicantSectionsQueryHandler> logger)
    {
        _applicantSectionLookupService = applicantSectionLookupService;
        _mediator = mediator;

        _logger = logger;
    }

    public async Task<IEnumerable<ApplicationFormApplicantSection>> Handle(GetApplicationFormApplicantSectionsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var applicantSections = await _applicantSectionLookupService.FindAsync(x => x.IsActive && x.ApplicationFormApplicantFields!.All(x => x.IsActive), hasNavigationProperties: true);

        var response = new List<ApplicationFormApplicantSection>();

        foreach (var applicantSection in applicantSections)
        {
            applicantSection.ApplicationFormApplicantFields = applicantSection.ApplicationFormApplicantFields?.OrderBy(x => x.Order).ToArray();
            response.Add(applicantSection);
        }

        if (request.OfficeIds.Any())
        {
            var getApplicationFormComplianceApplicantSectionQuery = new GetApplicationFormComplianceApplicantSectionQuery(request.OfficeIds);
            await SetApplicationFormApplicantSectionAsync(getApplicationFormComplianceApplicantSectionQuery, ApplicationFormApplicantSections.ComplianceFields, response, cancellationToken);
        }

        var getApplicationFromInServiceApplicationSectionQuery = new GetApplicationFormInServiceTopicsApplicantSectionQuery();
        await SetApplicationFormApplicantSectionAsync(getApplicationFromInServiceApplicationSectionQuery, ApplicationFormApplicantSections.InServiceTopics, response, cancellationToken);

        var getApplicationFormMedicalsApplicantSectionQuery = new GetApplicationFormMedicalsApplicantSectionQuery(request.OfficeIds);
        await SetApplicationFormApplicantSectionAsync(getApplicationFormMedicalsApplicantSectionQuery, ApplicationFormApplicantSections.MedicalsAndOtherDocuments, response, cancellationToken);

        _logger.LogInformation("Handle were getting successfully.");

        return response.OrderBy(x => x.Order).ToArray();
    }

    private async Task SetApplicationFormApplicantSectionAsync<TRequest>(IRequest<TRequest> request, ApplicationFormApplicantSections applicationFormApplicantSections,
                                                                         List<ApplicationFormApplicantSection> applicationSections, CancellationToken cancellationToken) where TRequest : ApplicationFormApplicantSection
    {
        var applicantSection = await _mediator.Send(request, cancellationToken);
        var applicantSectionIndex = applicationSections.FindIndex(applicantSection => applicantSection.Id == (int)applicationFormApplicantSections);
        var applicantFields = applicationSections[applicantSectionIndex].ApplicationFormApplicantFields;

        if (applicantFields?.Any() == true && applicantSection.ApplicationFormApplicantFields?.Any() == true)
        {
            applicantSection.ApplicationFormApplicantFields = applicantSection.ApplicationFormApplicantFields?.Concat(applicantFields);
        }

        applicationSections[applicantSectionIndex] = applicantSection;
    }
}
