﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.MedicalsOther;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public record GetApplicantDataStatusHandler(IReadOnlyRepository<AvailabilityDayEntity> AvailabilityDaysRepository,
                                            IReadOnlyRepository<ComplianceCustomFieldApplicantValueEntity> ComplianceCustomFieldApplicantValueRepository,
                                            IReadOnlyRepository<ComplianceI9RequirementEntity> I9RequirementsRepository,
                                            IReadOnlyRepository<ComplianceTrainingSchoolEntity> ComplianceTrainingSchoolRepository,
                                            IReadOnlyRepository<MedicalsApplicantValueEntity> MedicalsApplicantValuesRepository,
                                            IReadOnlyRepository<OtherApplicantValueEntity> OtherApplicantValuesRepository,
                                            IReadOnlyRepository<ComplianceBackgroundCheckEntity> BackgroundCheckRepository,
                                            IMediatorService MediatorService,
                                            ILogger<GetApplicantDataStatusHandler> Logger)
    : IRequestHandler<GetApplicantDataStatusQuery, ApplicantDataStatus>
{
    const string MEDICALS_AND_OTHER_REQUIREMENTS_SECTION_NAME = "Medicals & Other Documents";
    const string MEDICALS_REQUIREMENTS_PREFIX = "Medical:";
    const string OTHER_REQUIREMENTS_PREFIX = "Other Compliance:";

    public async Task<ApplicantDataStatus> Handle(GetApplicantDataStatusQuery query, CancellationToken cancellationToken)
    {
        Logger.LogInformation("Get applicant data status with Id: {applicantId}.", query.ApplicantId);

        int availability = await AvailabilityDaysRepository.GetSingleColumnValue(x => x.ApplicantId == query.ApplicantId && (x.MaxVisits.HasValue || (x.TimeShifts != null && x.TimeShifts.Any(x => x.PreferenceId > 0))), y => y.Id);
        int complianceFields = await ComplianceCustomFieldApplicantValueRepository.GetSingleColumnValue(x => x.ApplicantId == query.ApplicantId && !string.IsNullOrWhiteSpace(x.Value), y => y.Id);
        int i9 = await I9RequirementsRepository.GetSingleColumnValue(x => x.ApplicantId == query.ApplicantId && x.ColumnABDocumentId.HasValue, y => y.Id);
        int trainingSchools = await ComplianceTrainingSchoolRepository.GetSingleColumnValue(x => x.ApplicantId == query.ApplicantId && x.SchoolId.HasValue, y => y.Id);
        int backgroundCheck = await BackgroundCheckRepository.GetSingleColumnValue(x => x.ApplicantId == query.ApplicantId, y => y.Id);

        bool hasMedicals = false;
        bool hasOtherRequirements = false;
        int[] medicals = Array.Empty<int>();
        int[] otherRequirements = Array.Empty<int>();

        var getAfsQuery = new GetApplicationFormApplicantSectionsQuery(new int?[] { query.OfficeId });

        var afsResponse = await MediatorService.SendAsync<GetApplicationFormApplicantSectionsQuery, IEnumerable<ApplicationFormApplicantSection>>(getAfsQuery);

        bool complianceHasMedicalsRequirementsRow = ComplainsHasMedicalsRows(afsResponse);
        bool complianceHasOtherRequirementsRow = ComplainsHasOtherRequirementsRows(afsResponse);

        if (complianceHasMedicalsRequirementsRow)
        {
            hasMedicals = (await MedicalsApplicantValuesRepository.FindAsync(x => x.ApplicantId == query.ApplicantId && (!string.IsNullOrWhiteSpace(x.Value) || x.PerformedDate.HasValue || !string.IsNullOrWhiteSpace(x.FileKey)))).Select(y => y.ComplianceExpItemId).Any();
            medicals = (await MediatorService.SendAsync<GetMedicalsRequirementsQuery, IEnumerable<MedicalsApplicantValue>>(new(query.ApplicantId, query.OfficeId))).Select(y => y.ComplianceExpItemId).ToArray();
        }

        if (complianceHasOtherRequirementsRow)
        {
            hasOtherRequirements = (await OtherApplicantValuesRepository.FindAsync(x => x.ApplicantId == query.ApplicantId && (!string.IsNullOrWhiteSpace(x.Value) || x.PerformedDate.HasValue || !string.IsNullOrWhiteSpace(x.FileKey)))).Select(y => y.ComplianceExpItemId).Any();
            otherRequirements = (await MediatorService.SendAsync<GetOtherRequirementsQuery, IEnumerable<OtherApplicantValue>>(new(query.ApplicantId, query.OfficeId))).Select(y => y.ComplianceExpItemId).ToArray();
        }

        ApplicantDataStatus result = new()
        {
            HasAvailabilityData = HasValue(availability),
            HasComplianceFieldsData = HasValue(complianceFields),
            HasI9Data = HasValue(i9),
            HasTrainingSchoolsData = HasValue(trainingSchools),
            HasBackgroundChecksData = HasValue(backgroundCheck),
            MedicalsRows = medicals,
            OtherRequirementsRows = otherRequirements,
            HasMedicalsData = hasMedicals,
            HasOtherRequirementsData = hasOtherRequirements,
            ComplianceHasMedicalsRequirementsRow = complianceHasMedicalsRequirementsRow,
            ComplianceHasOtherRequirementsRow = complianceHasOtherRequirementsRow
        };

        Logger.LogInformation("Applicant data status with Id: {applicantId} retrieved.", query.ApplicantId);

        return result;
    }

    private static bool HasValue(int value)
        => value > 0;

    private bool ComplainsHasMedicalsRows(IEnumerable<ApplicationFormApplicantSection> sections)
        => sections.FirstOrDefault(x => x.Name == MEDICALS_AND_OTHER_REQUIREMENTS_SECTION_NAME)
        ?.ApplicationFormApplicantFields
        ?.Any(x => x.Name!.StartsWith(MEDICALS_REQUIREMENTS_PREFIX)) ?? false;

    private bool ComplainsHasOtherRequirementsRows(IEnumerable<ApplicationFormApplicantSection> sections)
       => sections.FirstOrDefault(x => x.Name == MEDICALS_AND_OTHER_REQUIREMENTS_SECTION_NAME)
       ?.ApplicationFormApplicantFields
       ?.Any(x => x.Name!.StartsWith(OTHER_REQUIREMENTS_PREFIX)) ?? false;
}
