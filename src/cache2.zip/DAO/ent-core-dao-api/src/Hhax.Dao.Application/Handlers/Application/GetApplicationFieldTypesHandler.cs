﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public record GetApplicationFieldTypesHandler(ILookupService<ApplicationFieldType, ApplicationFieldTypeEntity> ApplicantFieldTypeLookup,
                                                IMapper Mapper,
                                                ILogger<GetApplicationFieldTypesHandler> Logger)
    : IRequestHandler<GetApplicationFieldTypes, IEnumerable<ApplicationFieldType>>
{
    public async Task<IEnumerable<ApplicationFieldType>> Handle(GetApplicationFieldTypes request, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(GetApplicationFieldTypesHandler)}.");
        var applicationFieldTypes = await ApplicantFieldTypeLookup.GetAllAsync();
        Logger.LogInformation("Handle were getting successfully.");
        return applicationFieldTypes;
    }
}
