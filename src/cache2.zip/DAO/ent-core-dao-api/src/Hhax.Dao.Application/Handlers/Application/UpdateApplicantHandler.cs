﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public record UpdateApplicantHandler(IAuthenticationService AuthenticationService,
                                     IGenericRepository<ApplicantEntity> ApplicantRepository,
                                     IMapper Mapper,
                                     ILogger<UpdateApplicantHandler> Logger,
                                     IMediator Mediator)
    : IRequestHandler<UpdateApplicantCommand, BaseResponse>
{
    public async Task<BaseResponse> Handle(UpdateApplicantCommand request, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");
        Logger.LogInformation("UpdateApplicantAsync with Id: {applicantId}.", request.Id);

        var applicantEntity = await ApplicantRepository.GetByIdAsync(request.Id, hasNavigationProperties: true);
        if (applicantEntity == null)
        {
            var message = $"{nameof(Applicant)} with Id: {request.Id} not found.";

            Logger.LogError("Applicant with Id: {applicantId} not found.", request.Id);
            throw new ApplicantNotFoundException(message);
        }

        var applicant = Mapper.Map<Applicant>(request);

        var updatedApplicantEntity = Mapper.Map<ApplicantEntity>(applicant);
        updatedApplicantEntity.ApplicationLanguageId = applicantEntity.ApplicationLanguageId;

        await Mediator.Send(new ValidateApplicantRequestDataCommand(request.Id, null, updatedApplicantEntity, ApplicantEligibilitySection.Profile), cancellationToken);

        await CheckDuplicationContactEmail(applicantEntity, updatedApplicantEntity);

        FillTechnicalFields(applicantEntity, updatedApplicantEntity);

        applicantEntity.ApplicantEmploymentTypeMappings = updatedApplicantEntity.ApplicantEmploymentTypeMappings;

        await ApplicantRepository.UpdateAsync(applicantEntity, updatedApplicantEntity);

        if (request.Signatures != null && request.Signatures.Any())
        {
            await Mediator.Send(new SaveApplicantSignatureCommand(applicantEntity.Id, request.Signatures), cancellationToken);
        }

        await UpdateApplicantEligibilities(applicantEntity.Id, cancellationToken);

        Logger.LogInformation("Applicant with Id: {applicantId} was updated.", request.Id);

        return new() { Id = request.Id };
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }

    private void FillTechnicalFields(ApplicantEntity oldApplicant, ApplicantEntity updatedApplicant)
    {
        if (oldApplicant.ApplicationWorkflowStatusId == updatedApplicant.ApplicationWorkflowStatusId)
        {
            updatedApplicant.ApplicationWorkflowStatusUpdated = oldApplicant.ApplicationWorkflowStatusUpdated;
        }
        else
        {
            updatedApplicant.ApplicationWorkflowStatusUpdated = DateTime.UtcNow;
        }

        updatedApplicant.AgencyId = AuthenticationService.GetAgencyId();
        updatedApplicant.Created = oldApplicant.Created;
        updatedApplicant.CreatedBy = oldApplicant.CreatedBy;
        updatedApplicant.UpdatedBy = AuthenticationService.GetUserId();
        updatedApplicant.LoginEmail = oldApplicant.LoginEmail;
        updatedApplicant.IsVerified = oldApplicant.IsVerified;
        updatedApplicant.IsActive = oldApplicant.IsActive;
        updatedApplicant.UserId = oldApplicant.UserId;
    }

    private async Task CheckDuplicationContactEmail(ApplicantEntity oldApplicant, ApplicantEntity updatedApplicant)
    {
        if (string.IsNullOrWhiteSpace(updatedApplicant.ContactEmail))
        {
            updatedApplicant.ContactEmail = null;
        }
        else
        {
            if (!updatedApplicant.ContactEmail.Equals(oldApplicant.ContactEmail))
            {
                var query = new ValidateContactEmailUniquenessQuery(updatedApplicant.ContactEmail!, updatedApplicant.Id);
                var response = await Mediator.Send(query);

                if (response.IsSuccess)
                {
                    return;
                }

                var message = $"Email {updatedApplicant.ContactEmail} is already busy.";
                Logger.LogError(message);
                throw new ApplicantInvalidException(message);
            }
        }
    }
}
