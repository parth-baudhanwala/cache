﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Contexts;
using Hhax.Dao.Common.Extensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Threading;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormUrlQueryHandler : IRequestHandler<GetApplicationFormUrlQuery, string>
{
    private readonly ApplicationFormConfguration _applicationFormConfguration;
    private readonly IDbContextFactory<DaoDbContext> _daoDbContextFactory;
    private readonly IDbContextFactory<HhaDbContext> _hhaDbContextFactory;
    private readonly IAuthenticationService _authenticationService;

    private readonly IGenericRepository<OfficeInfoEntity> _officeInfoRepository;
    private readonly IReadOnlyRepository<UserInfoEntity> _userInfoRepository;
    private readonly IReadOnlyRepository<VendorEntity> _vendorRepository;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormUrlQueryHandler> _logger;

    public GetApplicationFormUrlQueryHandler(IOptions<ApplicationFormConfguration> applicationFormConfigurationOptions,
                                             IDbContextFactory<DaoDbContext> daoDbContextFactory,
                                             IDbContextFactory<HhaDbContext> hhaDbContextFactory,
                                             IAuthenticationService authenticationService,
                                             IGenericRepository<OfficeInfoEntity> officeInfoRepository,
                                             IReadOnlyRepository<UserInfoEntity> userInfoRepository,
                                             IReadOnlyRepository<VendorEntity> vendorRepository,
                                             IMapper mapper,
                                             ILogger<GetApplicationFormUrlQueryHandler> logger)
    {
        _applicationFormConfguration = applicationFormConfigurationOptions.Value;
        _daoDbContextFactory = daoDbContextFactory;
        _hhaDbContextFactory = hhaDbContextFactory;
        _authenticationService = authenticationService;

        _officeInfoRepository = officeInfoRepository;
        _userInfoRepository = userInfoRepository;
        _vendorRepository = vendorRepository;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<string> Handle(GetApplicationFormUrlQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        if (string.IsNullOrEmpty(_applicationFormConfguration.Url))
        {
            var message = "Configuration of Application Form not found.";

            _logger.LogError(message);
            throw new ApplicationFormInvalidException(message);
        }

        VendorEntity vendor = await GetVendor(request.OfficeId);

        bool hasApplicationFormPermission = await HasApplicationFormPermission(vendor, HhaxPermissions.CanViewApplicationProcessManagement, cancellationToken);
        if (!hasApplicationFormPermission)
            throw new ForbiddenException($"Access to add Application Form for office {request.OfficeId} is denied");

        using var daoContext = await _daoDbContextFactory.CreateDbContextAsync(cancellationToken);
        var applicationFormEntity = await daoContext.ApplicationForms!.FirstOrDefaultAsync(x => x.ApplicationFormOfficeMappings != null &&
                                                                                             x.ApplicationFormOfficeMappings.Any(f => f.OfficeId == request.OfficeId), cancellationToken: cancellationToken);

        if (applicationFormEntity == null)
        {
            var message = $"{nameof(ApplicationFormEntity)} with OfficeId: {request.OfficeId} not found.";

            _logger.LogError("Application Form with OfficeId: {applicationFormId} not found.", request.OfficeId);
            throw new ApplicationFormNotFoundException(message);
        }

        _logger.LogInformation("Application Form Url with Office Id: {officeId} was getting successfully.", request.OfficeId);

        return string.Format(_applicationFormConfguration.Url, request.OfficeId, applicationFormEntity.UniqueUrlId);
    }

    private async Task<UserInfoEntity> GetUser(int? userId)
    {
        UserInfoEntity? user = await _userInfoRepository.FirstOrDefaultAsync(x => x.Id == userId);

        if (userId == null || user == null)
        {
            string message = $"User with Id: '{userId}' was not found in the DB.";
            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        return user;
    }

    private async Task<VendorEntity> GetVendor(int? officeId)
    {
        var office = await _officeInfoRepository.FirstOrDefaultAsync(x => x.Id == officeId);
        if (office == null)
        {
            string message = $"Office with Id: '{officeId}' was not found in the DB.";
            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        var vendorId = office.VendorId;
        VendorEntity? vendor = await _vendorRepository.FirstOrDefaultAsync(x => x.Id == vendorId);
        if (vendor == null)
        {
            string message = $"Vendor with Id: '{vendorId}' " +
                $"for office with Id: '{officeId}' was not found in the DB.";
            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        return vendor;
    }

    private async Task<bool> HasApplicationFormPermission(VendorEntity vendor, HhaxPermissions permission, CancellationToken cancellationToken)
    {
        using var hhaContext = await _hhaDbContextFactory.CreateDbContextAsync(cancellationToken);
        var vendorRight = await hhaContext.VendorRights!.FirstOrDefaultAsync(x => x.VendorId == vendor.Id &&
            x.RightId == (int)permission, cancellationToken: cancellationToken);

        return vendorRight != null;
    }
}