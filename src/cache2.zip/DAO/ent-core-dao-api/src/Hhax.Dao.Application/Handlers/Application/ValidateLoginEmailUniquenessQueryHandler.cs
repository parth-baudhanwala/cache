﻿using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Models.Requests;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Queries.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application
{
    public class ValidateLoginEmailUniquenessQueryHandler : IRequestHandler<ValidateLoginEmailUniquenessQuery, ValidationResponse>
    {
        private readonly IIdentityClient _identityClient;

        private readonly ILogger<ValidateContactEmailUniquenessQueryHandler> _logger;

        public ValidateLoginEmailUniquenessQueryHandler(IIdentityClient identityClient,
                                                        ILogger<ValidateContactEmailUniquenessQueryHandler> logger)
        {
            _identityClient = identityClient;

            _logger = logger;
        }

        public async Task<ValidationResponse> Handle(ValidateLoginEmailUniquenessQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation("ValidateLoginEmailUniqueness with 'Email' param: {email}.", request.Email);

            ValidationResponse response = new();

            if (string.IsNullOrWhiteSpace(request.Email))
            {
                response.IsSuccess = false;
                response.Message = "Login Email is empty. Please provide an email to validate.";
            }
            else
            {
                const string authorizationHeaderName = "Authorization";

                var headers = new Dictionary<string, string>();

                var token = await _identityClient.AccountsClient.GetTokenWithClientCredentialsAsync();
                headers.Add(authorizationHeaderName, $"Bearer {token.AccessToken}");

                var uniqueUserNameRequest = new UniqueUserNameRequest { UserName = request.Email };
                bool isUnique = await _identityClient.ValidationClient.IsUserNameUniqueAsync(uniqueUserNameRequest, headers);
                response.IsSuccess = isUnique;
                response.Message = response.IsSuccess ? string.Empty : "Login Email is not unique. It should be unique.";
            }

            _logger.LogInformation("Login Email was validated successfully.");

            return response;
        }
    }
}
