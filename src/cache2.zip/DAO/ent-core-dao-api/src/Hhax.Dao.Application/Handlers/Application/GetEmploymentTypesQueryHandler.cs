﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetEmploymentTypesQueryHandler : IRequestHandler<GetEmploymentTypesQuery, IEnumerable<EmploymentType>>
{
    private readonly ILookupService<EmploymentType, DisciplineEntity> _employmentTypesLookupService;
    private readonly ILogger<GetEmploymentTypesQueryHandler> _logger;

    public GetEmploymentTypesQueryHandler(ILookupService<EmploymentType, DisciplineEntity> employmentTypesLookupService,
                                          ILogger<GetEmploymentTypesQueryHandler> logger)
    {
        _employmentTypesLookupService = employmentTypesLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<EmploymentType>> Handle(GetEmploymentTypesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var response = await _employmentTypesLookupService.GetAllAsync();

        _logger.LogInformation("Handle was getting successfully.");

        return response;
    }
}
