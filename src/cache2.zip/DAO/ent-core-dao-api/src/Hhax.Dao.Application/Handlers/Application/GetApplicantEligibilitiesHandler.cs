﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Application;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.FormBuilder;
using Hhax.Dao.Application.Abstracts.Requests.FormBuilder;
using Hhax.Dao.Application.Abstracts.Requests.InService;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Application.Queries.MedicalsOther;
using Hhax.Dao.Application.Utilities;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Domain.InService;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantEligibilitiesHandler : IRequestHandler<GetApplicantEligibilitiesQuery, IEnumerable<ApplicantEligibility>>
{
    private readonly IMediator _mediator;

    private readonly IReadOnlyRepository<ApplicantEntity> _applicantRepository;
    private readonly IReadOnlyRepository<AvailabilityDayEntity> _availabilityDayRepository;
    private readonly IReadOnlyRepository<ComplianceBackgroundCheckEntity> _complianceBackgroundCheckRepository;
    private readonly IReadOnlyRepository<ComplianceTrainingSchoolEntity> _trainingSchoolRepository;
    private readonly IReadOnlyRepository<ApplicantEligibilityEntity> _applicantProfileEligibilityEntityRepository;

    private readonly IAuthenticationService _authenticationService;
    private readonly IApplicantProfileService _applicantProfileService;
    private readonly IFormBuilderApiClient _formBuilderApiClient;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicantEligibilitiesHandler> _logger;

    public GetApplicantEligibilitiesHandler(IMediator mediator,
                                            IReadOnlyRepository<ApplicantEntity> applicantRepository,
                                            IReadOnlyRepository<AvailabilityDayEntity> availabilityDayRepository,
                                            IReadOnlyRepository<ComplianceBackgroundCheckEntity> complianceBackgroundCheckRepository,
                                            IReadOnlyRepository<ComplianceTrainingSchoolEntity> trainingSchoolRepository,
                                            IReadOnlyRepository<ApplicantEligibilityEntity> applicantEligibilityEntityRepository,
                                            IAuthenticationService authenticationService,
                                            IApplicantProfileService applicantProfileService,
                                            IFormBuilderApiClient formBulderApiClient,
                                            IMapper mapper,
                                            ILogger<GetApplicantEligibilitiesHandler> logger)
    {
        _mediator = mediator;

        _applicantRepository = applicantRepository;
        _availabilityDayRepository = availabilityDayRepository;
        _complianceBackgroundCheckRepository = complianceBackgroundCheckRepository;
        _trainingSchoolRepository = trainingSchoolRepository;
        _applicantProfileEligibilityEntityRepository = applicantEligibilityEntityRepository;

        _authenticationService = authenticationService;
        _applicantProfileService = applicantProfileService;
        _formBuilderApiClient = formBulderApiClient;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<ApplicantEligibility>> Handle(GetApplicantEligibilitiesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Check Applicant Eligibility with Applicant Id: {applicantId}", request.ApplicantId);
        var userId = _authenticationService.GetUserId();

        // Get applicant by ApplicantId
        var applicantEntity = await _applicantRepository.FirstOrDefaultAsync(x => x.Id == request.ApplicantId, true);
        if (applicantEntity == null)
        {
            var message = $"Applicant with Id: {request.ApplicantId} not found.";
            throw new ApplicantNotFoundException(message);
        }

        // Get applicant requirements by OfficeId
        var getApplicantRequirementsByOfficeIdQuery = new GetApplicationFormApplicantRequirementsByOfficeIdQuery(applicantEntity.OfficeId);
        var applicantRequirements = await _mediator.Send(getApplicantRequirementsByOfficeIdQuery, cancellationToken);

        var entities = await _applicantProfileEligibilityEntityRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);

        IEnumerable<ApplicantEligibility> applicantEligibilities = _mapper.Map<IEnumerable<ApplicantEligibility>>(entities);

        //Get Applicant Signatures
        int[] sections =
        {
            (int)ApplicationFormApplicantSections.Demographics,
            (int)ApplicationFormApplicantSections.EmploymentInformation,
            (int)ApplicationFormApplicantSections.Address,
            (int)ApplicationFormApplicantSections.EmergencyContact,
            (int)ApplicationFormApplicantSections.NotificationPreferences,
            (int)ApplicationFormApplicantSections.Languages,
            (int)ApplicationFormApplicantSections.GeneralCompliance,
            (int)ApplicationFormApplicantSections.Availability,
            (int)ApplicationFormApplicantSections.ComplianceFields
        };

        GetApplicantSignatureCommand signatureCommand = new(applicantEntity.Id, 0, sections);
        var applicantsSignatures = await _mediator.Send(signatureCommand, cancellationToken);

        // Get applicant custom fields by OfficeId
        List<ApplicantCustomFieldInfo> applicantRequireCustomFields = new();

        HashSet<int> profileSections = new()
        {
            (int)ApplicationFormApplicantSections.Demographics,
            (int)ApplicationFormApplicantSections.Address,
            (int)ApplicationFormApplicantSections.EmergencyContact,
            (int)ApplicationFormApplicantSections.NotificationPreferences,
            (int)ApplicationFormApplicantSections.Languages,
            (int)ApplicationFormApplicantSections.EmploymentInformation
        };

        GetApplicantCustomFieldCommand command = new(applicantId: request.ApplicantId ?? 0, applicantEntity.OfficeId);
        var applicantCustomFields = await _mediator.Send(command, cancellationToken);
        if (applicantCustomFields.Any())
        {
            applicantRequireCustomFields = applicantCustomFields.Where(c => c.IsRequire && string.IsNullOrEmpty(c.Value)).ToList();
        }

        if (applicantEligibilities.Any())
        {
            string? signature;

            foreach (var applicantEligibility in applicantEligibilities)
            {
                switch (applicantEligibility.ApplicantSectionId)
                {
                    case (int)ApplicationFormApplicantSections.Demographics:
                        ValidateApplicantProfileSection(applicantEntity, applicantRequirements, applicantEligibility, applicantRequireCustomFields.Where(c => profileSections.Contains(c.ApplicantSectionId)), applicantsSignatures);
                        break;

                    case (int)ApplicationFormApplicantSections.Availability:
                        signature = applicantsSignatures?.FirstOrDefault(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.Availability)?.Value;
                        var applicantAvailabilityDays = await _availabilityDayRepository.FindAsync(x => x.ApplicantId == request.ApplicantId, true);
                        ValidateApplicantAvailabilitySection(signature, applicantAvailabilityDays, applicantRequirements, applicantEligibility, applicantRequireCustomFields.Where(c => c.ApplicantSectionId == (int)ApplicationFormApplicantSections.Availability));
                        break;

                    case (int)ApplicationFormApplicantSections.GeneralCompliance:
                        var generalComplienceSignature = applicantsSignatures?.Where(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.GeneralCompliance);
                        switch (applicantEligibility.ApplicantFieldId)
                        {
                            case (int)ApplicationFormApplicantFields.BackgroundCheck:
                                if (_authenticationService.IsCAPUser())
                                {
                                    applicantEligibility.NotEligibleFields = Enumerable.Empty<string>();
                                    break;
                                }
                                var backgroundChecks = await _complianceBackgroundCheckRepository.FindAsync(x => x.ApplicantId == request.ApplicantId, true);
                                ValidateBackgroundCheckSection(backgroundChecks, applicantRequirements, applicantEligibility);
                                break;

                            case (int)ApplicationFormApplicantFields.I9:
                                var i9ColumnABDocuments = await GetI9ColumnABDocuments(applicantEntity, cancellationToken);
                                var i9Requirement = await GetComplianceI9Requirement(applicantEntity, cancellationToken);
                                ValidateApplicantI9SectionAsync(i9ColumnABDocuments, i9Requirement, applicantRequirements, applicantEligibility);
                                break;

                            case (int)ApplicationFormApplicantFields.TrainingSchools:
                                var applicanTrainingSchools = await _trainingSchoolRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);
                                ValidateTrainingSchoolsCheckSection(applicanTrainingSchools, applicantRequirements, applicantEligibility, generalComplienceSignature);
                                break;
                        }
                        break;

                    case (int)ApplicationFormApplicantSections.ComplianceFields:
                        signature = applicantsSignatures?.FirstOrDefault(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.ComplianceFields)?.Value;
                        var customFieldsApplicantValues = await GetApplicantCustomFields(applicantEntity, cancellationToken);
                        ValidateApplicantComplianceCustomFieldSection(signature, customFieldsApplicantValues, applicantRequirements, applicantEligibility);
                        break;

                    case (int)ApplicationFormApplicantSections.MedicalsAndOtherDocuments:
                        switch (applicantEligibility.ApplicantFieldId)
                        {
                            case (int)ApplicationFormApplicantFields.Medicals:
                                var medicalsApplicantValues = await GetApplicantMedicals(applicantEntity, cancellationToken);
                                ValidateApplicantMedicalsSection(medicalsApplicantValues, applicantRequirements, applicantEligibility);
                                break;

                            case (int)ApplicationFormApplicantFields.OtherDocuments:
                                var otherDocumentsApplicantValues = await GetApplicantOtherDocuments(applicantEntity, cancellationToken);
                                ValidateApplicantOtherDocumentsSection(otherDocumentsApplicantValues, applicantRequirements, applicantEligibility);
                                break;

                        }
                        break;

                    case (int)ApplicationFormApplicantSections.InServiceTopics:
                        if (_authenticationService.IsCAPUser())
                        {
                            applicantEligibility.NotEligibleFields = Enumerable.Empty<string>();
                            break;
                        }
                        var topicsValues = await GetOfficeInServices(applicantEntity, cancellationToken);
                        var inServiceApplicantValues = await GetApplicantServices(applicantEntity, cancellationToken);
                        ValidateApplicantInServiceSection(inServiceApplicantValues, topicsValues, applicantRequirements, applicantEligibility);
                        break;

                }
            }
        }
        else
        {
            applicantEligibilities = GetDefaultApplicantEligibilities(request.ApplicantId, userId);
        }


        ApplicantEligibility onboardingFormsEligibility = GetDefaultApplicantEligibility(request.ApplicantId, userId, DateTime.UtcNow, DateTime.UtcNow, ApplicationFormApplicantSections.OnboardingForms);

        onboardingFormsEligibility.IsVerified = true;
        onboardingFormsEligibility.NotEligibleFields = await ValidateOnboardingFormCompletionStatuses(applicantEntity, cancellationToken);

        var eligibilities = applicantEligibilities.ToList();
        eligibilities.Add(onboardingFormsEligibility);
        applicantEligibilities = eligibilities;


        _logger.LogInformation("Applicant Eligibility with Applicant Id: {applicantId} was checked successfully.", request.ApplicantId);

        return applicantEligibilities;
    }

    private static IEnumerable<ApplicantEligibility> GetDefaultApplicantEligibilities(int? applicantId, int userId)
    {
        var created = DateTime.UtcNow;
        var updated = DateTime.UtcNow;

        var result = new List<ApplicantEligibility>
        {
            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.Demographics),

            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.GeneralCompliance, ApplicationFormApplicantFields.I9),

            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.GeneralCompliance, ApplicationFormApplicantFields.BackgroundCheck),

            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.Availability),

            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.GeneralCompliance, ApplicationFormApplicantFields.TrainingSchools),

            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.ComplianceFields),

            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.MedicalsAndOtherDocuments, ApplicationFormApplicantFields.Medicals),

            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.MedicalsAndOtherDocuments, ApplicationFormApplicantFields.OtherDocuments),

            GetDefaultApplicantEligibility(applicantId, userId, created, updated,
            ApplicationFormApplicantSections.InServiceTopics)
        };

        return result;
    }

    private static ApplicantEligibility GetDefaultApplicantEligibility(int? applicantId, int userId, DateTime created, DateTime updated,
        ApplicationFormApplicantSections section, ApplicationFormApplicantFields? field = null) =>
        new()
        {
            ApplicantId = applicantId,
            ApplicantEligibilityStatusId = (int)ApplicantEligibilityStatuses.NoInformation,
            ApplicantSectionId = (int)section,
            ApplicantFieldId = field != null ? (int)field : null,
            IsVerified = false,
            NotEligibleFields = new List<string>(),
            NotEligibleFieldsMessage = string.Empty,
            Created = created,
            CreatedBy = userId,
            Updated = updated,
            UpdatedBy = userId,
        };

    /// <summary>
    /// Validate applicant profile section
    /// </summary>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    /// <param name="applicantRequireCustomFields"></param>
    private void ValidateApplicantProfileSection(ApplicantEntity applicantEntity, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility, IEnumerable<ApplicantCustomFieldInfo> applicantRequireCustomFields, IEnumerable<Signature>? applicantSignatures)
    {
        var applicantSectionNotEligibleFields = _applicantProfileService.ValidateApplicantProfileSection(applicantEntity, applicantRequirements).ToList();

        if (applicantRequireCustomFields.Any())
        {
            applicantSectionNotEligibleFields = (List<string>)(!applicantSectionNotEligibleFields.Any() ? applicantRequireCustomFields.Select(c => c.FieldName ?? string.Empty).ToList()
                                                                                        : applicantSectionNotEligibleFields.Concat(applicantRequireCustomFields.Select(c => c.FieldName ?? string.Empty)));
        }

        if (_authenticationService.IsCAPUser() && SignatureUtility.CheckProfileSectionSignatures(applicantSignatures, applicantRequirements))
        {
            applicantSectionNotEligibleFields.Add("Signature");
        }

        var applicantSectionNotEligibleFieldsMessage = applicantSectionNotEligibleFields.Any() ? $"Not all required information is added, please fill in: {string.Join(", ", applicantSectionNotEligibleFields.ToList())}." : string.Empty;

        applicantEligibility.ApplicantEligibilityStatusId = applicantSectionNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                    : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = applicantSectionNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = applicantSectionNotEligibleFieldsMessage;
    }

    private async Task<IEnumerable<I9ColumnABDocument>> GetI9ColumnABDocuments(ApplicantEntity applicant, CancellationToken cancellationToken)
    {
        var getColumnAbDocumentsQuery = new GetColumnAbDocumentsQuery(applicant.OfficeId);
        return await _mediator.Send(getColumnAbDocumentsQuery, cancellationToken);
    }

    private async Task<ComplianceI9Requirement> GetComplianceI9Requirement(ApplicantEntity applicant, CancellationToken cancellationToken)
    {
        var getI9RequirementsQuery = new GetI9RequirementsQuery(applicant.Id);
        return await _mediator.Send(getI9RequirementsQuery, cancellationToken);
    }

    /// <summary>
    /// Validate applicant I9 section
    /// </summary>
    /// <param name="applicantEntity"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    /// <param name="cancellationToken"></param>
    /// <returns></returns>
    private void ValidateApplicantI9SectionAsync(IEnumerable<I9ColumnABDocument> i9ColumnABDocuments, ComplianceI9Requirement i9Requirement, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility)
    {
        bool skipVerificationField;
        bool skipEVerifyField = skipVerificationField = _authenticationService.IsCAPUser();

        var applicantI9SectionNotEligibleFields = _applicantProfileService.ValidateApplicantI9Section(i9ColumnABDocuments, i9Requirement, applicantRequirements, skipEVerifyField, skipVerificationField);
        var applicantI9SectionNotEligibleFieldsMessage = applicantI9SectionNotEligibleFields.Any() ? $"Not all required information is added, please fill in: {string.Join(", ", applicantI9SectionNotEligibleFields.Reverse())}." : string.Empty;

        applicantEligibility.ApplicantEligibilityStatusId = applicantI9SectionNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                      : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = applicantI9SectionNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = applicantI9SectionNotEligibleFieldsMessage;
    }

    /// <summary>
    /// Validate applicant availability section
    /// </summary>
    /// <param name="applicantAvailabilityDays"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    private void ValidateApplicantAvailabilitySection(string? signature, IEnumerable<AvailabilityDayEntity> applicantAvailabilityDays, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility, IEnumerable<ApplicantCustomFieldInfo> applicantRequireCustomFields)
    {
        var availabilitySectionNotEligibleFields = _applicantProfileService.ValidateApplicantAvailabilitySection(applicantAvailabilityDays, applicantRequirements).ToList();
        var availabilitySectionNotEligibleFieldsMessage = string.Empty;
        var availabilityNotEligibleFields = new List<string>();

        if (_authenticationService.IsCAPUser() && signature == null && SignatureUtility.CheckIsSignatureRequired(applicantRequirements, (int)ApplicationFormApplicantFields.AvailabilitySignature))
        {
            availabilityNotEligibleFields.Add("Signature");
        }

        if (availabilitySectionNotEligibleFields.Any() && !applicantRequireCustomFields.Any())
        {
            availabilitySectionNotEligibleFieldsMessage = $"Not all required information is added, please fill in at least one max visits number or at least one shift data.";
            availabilityNotEligibleFields = availabilitySectionNotEligibleFields.ToList();
        }
        else if (!availabilitySectionNotEligibleFields.Any() && applicantRequireCustomFields.Any())
        {
            availabilityNotEligibleFields.AddRange(applicantRequireCustomFields.Select(c => c.FieldName ?? string.Empty).ToList());
            availabilitySectionNotEligibleFieldsMessage = $"Not all required information is added, please fill in: {string.Join(", ", availabilityNotEligibleFields)}.";

        }
        else if (availabilitySectionNotEligibleFields.Any() && applicantRequireCustomFields.Any())
        {
            availabilityNotEligibleFields.AddRange(availabilitySectionNotEligibleFields.ToList());
            availabilityNotEligibleFields.AddRange(applicantRequireCustomFields.Select(c => c.FieldName ?? string.Empty).ToList());
            availabilitySectionNotEligibleFieldsMessage = $"Not all required information is added, please fill in at least one max visits number or at least one shift data & Custom fields: {string.Join(", ", applicantRequireCustomFields.Select(c => c.FieldName ?? string.Empty))}.";
        }
        else
        {
            availabilitySectionNotEligibleFieldsMessage = $"Not all required information is added, please fill in: {string.Join(", ", availabilityNotEligibleFields)}.";
        }

        applicantEligibility.ApplicantEligibilityStatusId = availabilityNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                   : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = availabilityNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = availabilitySectionNotEligibleFieldsMessage;
    }

    private async Task<IEnumerable<MedicalsApplicantValue>> GetApplicantMedicals(ApplicantEntity applicant, CancellationToken cancellationToken)
    {
        var getMedicalsRequirementsQuery = new GetMedicalsRequirementsQuery(applicant.Id, applicant.OfficeId);
        return await _mediator.Send(getMedicalsRequirementsQuery, cancellationToken);
    }

    /// <summary>
    /// Validate applicant medicals section
    /// </summary>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    private void ValidateApplicantMedicalsSection(IEnumerable<MedicalsApplicantValue> medicalsApplicantValues, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility)
    {
        var medicalsSectionNotEligibleFields = _applicantProfileService.ValidateApplicantMedicalsCheckSection(medicalsApplicantValues, applicantRequirements);

        var medicalsSectionNotEligibleFieldsMessage = medicalsSectionNotEligibleFields.Any() ? $"Not all required information is added, please fill in all required documents: {string.Join(", ", medicalsSectionNotEligibleFields.OrderBy(x => x))}." : string.Empty;


        applicantEligibility.ApplicantEligibilityStatusId = medicalsSectionNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                       : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = medicalsSectionNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = medicalsSectionNotEligibleFieldsMessage;
    }

    private async Task<IEnumerable<OtherApplicantValue>> GetApplicantOtherDocuments(ApplicantEntity applicant, CancellationToken cancellationToken)
    {
        var getOtherDocumentsRequirementsQuery = new GetOtherRequirementsQuery(applicant.Id, applicant.OfficeId);
        return await _mediator.Send(getOtherDocumentsRequirementsQuery, cancellationToken);
    }

    private async Task<IEnumerable<ComplianceCustomFieldApplicantValue>> GetApplicantCustomFields(ApplicantEntity applicant, CancellationToken cancellationToken)
    {
        var getComplianceCustomFieldsQuery = new GetComplianceCustomFieldsQuery(applicant.Id, applicant.OfficeId);
        return (await _mediator.Send(getComplianceCustomFieldsQuery, cancellationToken)).ComplianceCustomFields!;
    }

    private async Task<IEnumerable<InServiceTopic>> GetOfficeInServices(ApplicantEntity applicant, CancellationToken cancellationToken)
    {
        var getTopicsQuery = new GetTopicsQuery(applicant.OfficeId);
        return await _mediator.Send(getTopicsQuery, cancellationToken);
    }

    private async Task<IEnumerable<ApplicantInServiceTableItem>> GetApplicantServices(ApplicantEntity applicant, CancellationToken cancellationToken)
    {
        var query = new Abstracts.Requests.Common.PaginationRequest<Abstracts.Requests.InService.GetApplicantInServices>()
        {
            Filters = new GetApplicantInServices
            {
                ApplicantId = applicant.Id
            }
        };
        var getApplicantInServicesQuery = new GetApplicantInServicesQuery(query);
        var inServiceApplicantPaginationValue = await _mediator.Send(getApplicantInServicesQuery, cancellationToken);
        return inServiceApplicantPaginationValue.Data!;
    }

    /// <summary>
    /// Validate applicant custom fields section
    /// </summary>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    private void ValidateApplicantComplianceCustomFieldSection(string? signature, IEnumerable<ComplianceCustomFieldApplicantValue> customFieldsApplicantValues, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility)
    {
        var customFieldsSectionNotEligibleFields = _applicantProfileService.ValidateApplicantCustomComplianceSection(customFieldsApplicantValues, applicantRequirements).ToList();
        if (_authenticationService.IsCAPUser() && signature == null && SignatureUtility.CheckIsSignatureRequired(applicantRequirements, (int)ApplicationFormApplicantFields.ComplianceFieldSignature))
        {
            customFieldsSectionNotEligibleFields.Add("Signature");
        }
        var customFieldsSectionNotEligibleFieldsMessage = customFieldsSectionNotEligibleFields.Any() ? $"Not all required information is added, please fill in: {string.Join(", ", customFieldsSectionNotEligibleFields.OrderBy(x => x))}." : string.Empty;

        applicantEligibility.ApplicantEligibilityStatusId = customFieldsSectionNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                       : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = customFieldsSectionNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = customFieldsSectionNotEligibleFieldsMessage;
    }

    /// <summary>
    /// Validate applicant other documents section
    /// </summary>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    private void ValidateApplicantOtherDocumentsSection(IEnumerable<OtherApplicantValue> otherDocumentsApplicantValues, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility)
    {
        var otherDocumentsSectionNotEligibleFields = _applicantProfileService.ValidateApplicantOtherDocumentsCheckSection(otherDocumentsApplicantValues, applicantRequirements);
        var otherDocumentssSectionNotEligibleFieldsMessage = otherDocumentsSectionNotEligibleFields.Any() ? $"Not all required information is added, please fill in all required documents: {string.Join(", ", otherDocumentsSectionNotEligibleFields.OrderBy(x => x))}." : string.Empty;

        applicantEligibility.ApplicantEligibilityStatusId = otherDocumentsSectionNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                       : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = otherDocumentsSectionNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = otherDocumentssSectionNotEligibleFieldsMessage;
    }

    /// <summary>
    /// Validate applicant other documents section
    /// </summary>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    private void ValidateApplicantInServiceSection(IEnumerable<ApplicantInServiceTableItem> inServiceApplicantValues, IEnumerable<InServiceTopic> inServiceTopics, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility)
    {
        var inServiceSectionNotEligibleFields = _applicantProfileService.ValidateApplicantInServiceSection(inServiceApplicantValues, inServiceTopics, applicantRequirements);
        var inServiceSectionNotEligibleFieldsMessage = inServiceSectionNotEligibleFields.Any() ? $"Not all in-service information is added, please fill in all required topics: {string.Join(", ", inServiceSectionNotEligibleFields.OrderBy(x => x))}." : string.Empty;

        applicantEligibility.ApplicantEligibilityStatusId = inServiceSectionNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                       : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = inServiceSectionNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = inServiceSectionNotEligibleFieldsMessage;
    }

    /// <summary>
    /// Valdiate background check section
    /// </summary>
    /// <param name="backgroundChecks"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    private void ValidateBackgroundCheckSection(IEnumerable<ComplianceBackgroundCheckEntity> backgroundChecks, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility)
    {
        var backgroundCheckSectionNotEligibleFields = _applicantProfileService.ValidateApplicantBackgroundCheckSection(backgroundChecks, applicantRequirements);
        var backgroundCheckSectionNotEligibleFieldsMessage = backgroundCheckSectionNotEligibleFields.Any() ? $"Not all required information is added, please fill in at least one background check result." : string.Empty;

        applicantEligibility.ApplicantEligibilityStatusId = backgroundCheckSectionNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                          : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = backgroundCheckSectionNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = backgroundCheckSectionNotEligibleFieldsMessage;
    }

    /// <summary>
    /// Valdiate background check section
    /// </summary>
    /// <param name="trainingSchools"></param>
    /// <param name="applicantRequirements"></param>
    /// <param name="applicantEligibility"></param>
    private void ValidateTrainingSchoolsCheckSection(IEnumerable<ComplianceTrainingSchoolEntity> trainingSchools, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, ApplicantEligibility applicantEligibility, IEnumerable<Signature>? signature)
    {
        var trainingSchoolsCheckSectionNotEligibleFields = _applicantProfileService.ValidateApplicantTrainingSchoolsCheckSection(trainingSchools, applicantRequirements, false, false).ToList();
        var trainingSchoolsCheckSectionNotEligibleFieldsMessage = trainingSchoolsCheckSectionNotEligibleFields.Any() ?
            $"Not all required information is added, please fill in at least one training school record with verification and verification date." : string.Empty;

        if (_authenticationService.IsCAPUser() && string.IsNullOrEmpty(trainingSchoolsCheckSectionNotEligibleFieldsMessage)
               && SignatureUtility.CheckIsSignatureRequired(applicantRequirements, (int)ApplicationFormApplicantFields.GeneralComplianceSignature)
               && (signature == null || signature.Any(x => x.Value == null && trainingSchools.Any(y => y.Id == x.ReferenceId))))
        {
            trainingSchoolsCheckSectionNotEligibleFields.Add("Signature");
            trainingSchoolsCheckSectionNotEligibleFieldsMessage = $"Not all required information is added, please fill in: Signature.";
        }

        applicantEligibility.ApplicantEligibilityStatusId = trainingSchoolsCheckSectionNotEligibleFields.Any() ? (int)ApplicantEligibilityStatuses.NotEligibleRequirements
                                                                                                          : (int)ApplicantEligibilityStatuses.RequirementsCompleted;
        applicantEligibility.NotEligibleFields = trainingSchoolsCheckSectionNotEligibleFields;
        applicantEligibility.NotEligibleFieldsMessage = trainingSchoolsCheckSectionNotEligibleFieldsMessage;
    }

    private async Task<IEnumerable<string>> ValidateOnboardingFormCompletionStatuses(ApplicantEntity applicant, CancellationToken cancellationToken)
    {
        GetApplicantOnBoardingFormsQuery query = new()
        {
            ApplicantId = applicant.Id,
            OfficeId = applicant.OfficeId,
        };

        IEnumerable<ApplicantOnBoardingFormInfo> onboardingForms = await _mediator.Send(query, cancellationToken);

        if (!onboardingForms.Any())
        {
            return Enumerable.Empty<string>();
        }

        List<int> formResponseIds = onboardingForms
            .Where(form => form.FormResponseId != 0)
            .Select(form => form.FormResponseId)
            .ToList();

        if (formResponseIds.Any())
        {
            var response = await _formBuilderApiClient.GetMandatoryFieldStatusForBulkId(new FormCompletionStatusRequest(formResponseIds));

            IEnumerable<string> incompleteForms = response.FormsStaus?
                                                          .Where(formStatus => !formStatus.Result)
                                                          .Select(formStatus => formStatus.FormResponseRawId.ToString()) ?? Enumerable.Empty<string>();

            if (!incompleteForms.Any() && onboardingForms.Any(x => x.FormResponseId == 0))
            {
                return new List<string> { "0" };
            }
            return incompleteForms;
        }

        return new List<string> { "0" };
    }
}
