﻿using AutoMapper;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class DeleteApplicantHandler : IRequestHandler<DeleteApplicantCommand, Unit>
{
    private readonly IMediator _mediator;
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    
    private readonly IMapper _mapper;
    private readonly ILogger<DeleteApplicantHandler> _logger;

    public DeleteApplicantHandler(IMediator mediator,
                                  IGenericRepository<ApplicantEntity> applicantRepository,
                                  IMapper mapper,
                                  ILogger<DeleteApplicantHandler> logger)
    {
        _mediator = mediator;
        
        _applicantRepository = applicantRepository;

        _mapper = mapper;
        _logger = logger;
    }   

    public async Task<Unit> Handle(DeleteApplicantCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var getApplicantQuery = new GetApplicantQuery(request.ApplicantId);

        var applicant = await _mediator.Send(getApplicantQuery, cancellationToken);

        var applicantEntity = _mapper.Map<ApplicantEntity>(applicant);

        await _applicantRepository.RemoveAsync(applicantEntity);

        _logger.LogInformation("Applicant with Id: {Id} was created.", applicantEntity.Id);

        return Unit.Value;
    }
}
