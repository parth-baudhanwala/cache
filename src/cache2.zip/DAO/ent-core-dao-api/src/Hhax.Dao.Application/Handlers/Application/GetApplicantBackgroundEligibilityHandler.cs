﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Application;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantBackgroundEligibilityHandler : IRequestHandler<GetApplicantBackgroundEligibilityQuery, ApplicantEligibility>
{
    private readonly IMediator _mediator;

    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IReadOnlyRepository<ComplianceBackgroundCheckEntity> _complianceBackgroundCheckRepository;
    private readonly IGenericRepository<ApplicantEligibilityEntity> _applicantEligibilityEntityRepository;

    private readonly IAuthenticationService _authenticationService;
    private readonly IApplicantProfileService _applicantProfileService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicantBackgroundEligibilityHandler> _logger;

    public GetApplicantBackgroundEligibilityHandler(IMediator mediator,
                                                 IGenericRepository<ApplicantEntity> applicantRepository,
                                                 IReadOnlyRepository<ComplianceBackgroundCheckEntity> complianceBackgroundCheckRepository,
                                                 IGenericRepository<ApplicantEligibilityEntity> applicantEligibilityEntityRepository,
                                                 IAuthenticationService authenticationService,
                                                 IApplicantProfileService applicantProfileService,
                                                 IMapper mapper,
                                                 ILogger<GetApplicantBackgroundEligibilityHandler> logger)
    {
        _mediator = mediator;

        _applicantRepository = applicantRepository;
        _complianceBackgroundCheckRepository = complianceBackgroundCheckRepository;
        _applicantEligibilityEntityRepository = applicantEligibilityEntityRepository;

        _authenticationService = authenticationService;
        _applicantProfileService = applicantProfileService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicantEligibility> Handle(GetApplicantBackgroundEligibilityQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Check Applicant Background Eligibility with Applicant Id: {applicantId}", request.ApplicantId);

        // Get applicant by ApplicantId
        var applicantEntity = await _applicantRepository.FirstOrDefaultAsync(x => x.Id == request.ApplicantId);
        if (applicantEntity == null)
        {
            var message = $"Applicant with Id: {request.ApplicantId} not found.";
            throw new ApplicantNotFoundException(message);
        }

        // Get applicant requirements by OfficeId
        var getApplicantRequirementsByOfficeIdQuery = new GetApplicationFormApplicantRequirementsByOfficeIdQuery(applicantEntity.OfficeId);
        var applicantRequirements = await _mediator.Send(getApplicantRequirementsByOfficeIdQuery, cancellationToken);

        var applicantBackgroundEligibility = await _applicantEligibilityEntityRepository.FirstOrDefaultAsync(x => x.ApplicantId == request.ApplicantId &&
        x.ApplicantSectionId == (int)ApplicationFormApplicantSections.GeneralCompliance && x.ApplicantFieldId == (int)ApplicationFormApplicantFields.BackgroundCheck);

        var applicantEligibility = _mapper.Map<ApplicantEligibility>(applicantBackgroundEligibility);

        // Get Background Checks by ApplicantId
        var backgroundChecks = await _complianceBackgroundCheckRepository.FindAsync(x => x.ApplicantId == request.ApplicantId, true);

        if (applicantEligibility is not null)
        {
            var backgroundCheckSectionNotEligibleFields = _applicantProfileService.ValidateApplicantBackgroundCheckSection(backgroundChecks, applicantRequirements);
            var backgroundCheckSectionNotEligibleFieldsMessage = backgroundCheckSectionNotEligibleFields.Any() ? $"Not all required information is added, please fill in at least one background check result." : string.Empty;

            applicantEligibility.NotEligibleFields = backgroundCheckSectionNotEligibleFields;
            applicantEligibility.NotEligibleFieldsMessage = backgroundCheckSectionNotEligibleFieldsMessage;
        }
        else
        {
            var userId = _authenticationService.GetUserId();
            applicantEligibility =
                new ApplicantEligibility {
                    ApplicantId = request.ApplicantId,
                    ApplicantEligibilityStatusId = (int)ApplicantEligibilityStatuses.NoInformation,
                    ApplicantSectionId = (int)ApplicationFormApplicantSections.GeneralCompliance,
                    ApplicantFieldId = (int)ApplicationFormApplicantFields.BackgroundCheck,
                    IsVerified = false,
                    NotEligibleFields = new List<string>(),
                    NotEligibleFieldsMessage = string.Empty,
                    Created = DateTime.UtcNow,
                    CreatedBy = userId,
                    Updated = DateTime.UtcNow,
                    UpdatedBy = userId,
                };
        }

        _logger.LogInformation("Applicant Background Eligibility with Applicant Id: {applicantId} was checked successfully.", request.ApplicantId);

        return applicantEligibility;
    }
}