﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetPreferredContactMethodsQueryHandler : IRequestHandler<GetPreferredContactMethodsQuery, IEnumerable<ContactMethod>>
{
    private readonly ILookupService<ContactMethod, ContactMethodEntity> _contactMethodsLookupService;
    private readonly ILogger<GetPreferredContactMethodsQueryHandler> _logger;

    public GetPreferredContactMethodsQueryHandler(ILookupService<ContactMethod, ContactMethodEntity> contactMethodsLookupService,
                                                  ILogger<GetPreferredContactMethodsQueryHandler> logger)
    {
        _contactMethodsLookupService = contactMethodsLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<ContactMethod>> Handle(GetPreferredContactMethodsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var response = await _contactMethodsLookupService.GetAllAsync();

        _logger.LogInformation("Handle were getting successfully.");

        return response;
    }
}
