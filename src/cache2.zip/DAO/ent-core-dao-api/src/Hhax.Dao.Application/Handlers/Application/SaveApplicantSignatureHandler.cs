﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class SaveApplicantSignatureHandler : IRequestHandler<SaveApplicantSignatureCommand, BaseResponse>
{
    private readonly ILogger<GetApplicantCustomFieldHandler> _logger;
    private readonly IAuthenticationService _authenticationService;
    private readonly IGenericRepository<ApplicantSignatureEntity> _applicantSignatureRepository;

    public SaveApplicantSignatureHandler(ILogger<GetApplicantCustomFieldHandler> logger,
                                         IServiceProvider serviceProvider)
    {
        _logger = logger;
        _authenticationService = serviceProvider.GetService<IAuthenticationService>()!;
        _applicantSignatureRepository = serviceProvider.GetService<IGenericRepository<ApplicantSignatureEntity>>()!;
    }

    public async Task<BaseResponse> Handle(SaveApplicantSignatureCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        BaseResponse response = new();
        int userId = _authenticationService.GetUserId();

        var applicantSignatureEntities = (await _applicantSignatureRepository.FindAsync(x => x.ApplicantId == command.ApplicantId)).ToList();

        foreach (var signature in command.Signatures)
        {
            var applicantSignatureEntity = applicantSignatureEntities.FirstOrDefault(x => x.ApplicantSectionId == signature.ApplicantSectionId
                                                                                          && x.ReferenceId == signature.ReferenceId);

            if (applicantSignatureEntity != null)
            {
                if (applicantSignatureEntity.Value?.Equals(signature.Value) == true) continue;
                applicantSignatureEntity.Value = signature.Value;
                applicantSignatureEntity.TimeStamp = DateTime.UtcNow;
                applicantSignatureEntity.Updated = DateTime.UtcNow;
                applicantSignatureEntity.UpdatedBy = userId;
            }
            else
            {
                applicantSignatureEntity = new()
                {
                    Value = signature.Value,
                    TimeStamp = DateTime.UtcNow,
                    ApplicantId = command.ApplicantId,
                    ApplicantSectionId = signature.ApplicantSectionId,
                    ReferenceId = signature.ReferenceId,
                    Created = DateTime.UtcNow,
                    CreatedBy = userId
                };

                applicantSignatureEntities.Add(applicantSignatureEntity);
            }
        }

        response.Id = await _applicantSignatureRepository.AttachRangeAsync(applicantSignatureEntities);

        _logger.LogInformation("Applicant signatures were saved successfully for {ApplicantId}.", command.ApplicantId);

        return response;
    }
}
