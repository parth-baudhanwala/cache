﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using Hhax.Dao.Application.Abstracts.Constants;

namespace Hhax.Dao.Application.Handlers.Application;

public record GetApplicantStatusToEditHandler (IReadOnlyRepository<ApplicantEntity> ApplicantReadOnlyRepository,
                                               IReadOnlyRepository<ApplicationWorkflowStatusEntity> ApplicationWorkflowStatusReadOnlyRepository,
                                               IAuthenticationService AuthenticationService,
                                               ILogger<GetApplicantStatusToEditHandler> Logger,
                                               IMapper Mapper)
    : IRequestHandler<GetApplicantStatusToEditQuery, ApplicantStatusToEdit>
{
    public async Task<ApplicantStatusToEdit> Handle(GetApplicantStatusToEditQuery query, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"Get applicant with Id: {query.ApplicantId}.");

        var applicantEntity = await ApplicantReadOnlyRepository.FirstOrDefaultAsync(x => x.Id == query.ApplicantId);

        if (applicantEntity is null)
        {
            var message = $"Unable to find applicant. Applicant id: {query.ApplicantId}.";
            Logger.LogInformation(message);
            throw new EntityNotFoundException(message);
        }

        Logger.LogInformation($"Get applicant status with Id: {applicantEntity.ApplicationWorkflowStatusId}.");

        ApplicationWorkflowStatusEntity? applicantStatusEntity = await ApplicationWorkflowStatusReadOnlyRepository.FirstOrDefaultAsync(x => x.Id == applicantEntity.ApplicationWorkflowStatusId, true);

        if(applicantStatusEntity is null)
        {
            var message = $"Unable to find status. Status id: {applicantEntity.ApplicationWorkflowStatusId}.";
            Logger.LogInformation(message);
            throw new EntityNotFoundException(message);
        }

        if (applicantStatusEntity.Name == DefaultWorkflowStatusesConstants.ApplicationInProgressName)
        {
            Logger.LogInformation("Applicant status is Applicantion In Progress.");
            return new ApplicantStatusToEdit(true);
        }

        if (applicantStatusEntity.IsLastPossible == true)
        {
            Logger.LogInformation($"Status is last possible. Status id: {applicantEntity.ApplicationWorkflowStatusId}.");
            return new ApplicantStatusToEdit(false);
        }

        if (applicantStatusEntity.ApplicationWorkflowStatusMappings == null || applicantStatusEntity.ApplicationWorkflowStatusMappings.Count() == 0)
        {
            Logger.LogInformation($"Status has no next statuses. Status id: {applicantEntity.ApplicationWorkflowStatusId}.");
            return new ApplicantStatusToEdit(false);
        }

        var nextStatusesIds = applicantStatusEntity.ApplicationWorkflowStatusMappings.Select(x => x.NextApplicationWorkflowStatusId);
        int agencyId = AuthenticationService.GetAgencyId();
        var nextStatusesCount = await ApplicationWorkflowStatusReadOnlyRepository.CountAsync(x => nextStatusesIds.Contains(x.Id) && x.AgencyId == agencyId);

        Logger.LogInformation("Applicant status to edit was retrieved");

        return new ApplicantStatusToEdit(nextStatusesCount > 0);
    }
}
