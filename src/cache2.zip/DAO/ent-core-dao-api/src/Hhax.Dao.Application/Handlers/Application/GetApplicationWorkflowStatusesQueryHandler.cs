﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Abstracts.Requests;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationWorkflowStatusesQueryHandler : IRequestHandler<GetApplicationWorkflowStatusesQuery, PaginatationResponse<ApplicationWorkflowStatus>>
{
    private const string SORT_KEY_NAME = "name";

    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly IMediator _mediator;
    private readonly ILogger<GetApplicationWorkflowStatusesQueryHandler> _logger;

    public GetApplicationWorkflowStatusesQueryHandler(IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusRepository,
                                                      IMapper mapper,
                                                      IMediator mediator,
                                                      ILogger<GetApplicationWorkflowStatusesQueryHandler> logger,
                                                      IAuthenticationService authenticationService)
    {
        _applicationWorkflowStatusRepository = applicationWorkflowStatusRepository;
        _authenticationService = authenticationService;

        _mapper = mapper;
        _mediator = mediator;
        _logger = logger;
    }

    public async Task<PaginatationResponse<ApplicationWorkflowStatus>> Handle(GetApplicationWorkflowStatusesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        await InitializeApplicationWorkflowStatuses(cancellationToken);

        IEnumerable<ApplicationWorkflowStatusEntity> entities;

        SortRequest<ApplicationWorkflowStatusEntity> sortParameter = BuildSortParameter(request.Request.Sort);

        var agencyId = _authenticationService.GetAgencyId();

        List<Expression<Func<ApplicationWorkflowStatusEntity, bool>>> searchPredictants = BuildSearchPredicants(request.Request, agencyId);
        entities = await _applicationWorkflowStatusRepository.FindAsync(sortParameter, searchPredictants, hasNavigationProperties: true);

        var mappedIds = entities.Where(x => x.ApplicationWorkflowStatusMappings != null && x.ApplicationWorkflowStatusMappings.Count > 0)
                                .Select(x => x.ApplicationWorkflowStatusMappings)
                                .SelectMany(selector: x => x!.Select(n => n.NextApplicationWorkflowStatusId))
                                .Distinct();

        IEnumerable<ApplicationWorkflowStatusEntity> mappedEntities = request.Request?.Page != null
            ? await _applicationWorkflowStatusRepository.FindAsync(x => mappedIds.Contains(x.Id), request.Request.Page!.PageNumber, request.Request.Page!.PageSize, hasNavigationProperties: true)
            : await _applicationWorkflowStatusRepository.FindAsync(x => mappedIds.Contains(x.Id), hasNavigationProperties: true);

        var total = await _applicationWorkflowStatusRepository.CountAsync();

        List<ApplicationWorkflowStatus> applicationWorkflowStatuses = new();

        foreach (var entity in entities)
        {
            var applicationWorkflowStatus = _mapper.Map<ApplicationWorkflowStatus>(entity);
            if (entity.ApplicationWorkflowStatusMappings != null && entity.ApplicationWorkflowStatusMappings.Count > 0)
            {
                List<ApplicationWorkflowStatus> nextApplicationWorkflowStatuses = new();
                foreach (var nextStatusMapping in entity.ApplicationWorkflowStatusMappings)
                {
                    var nextStatus = mappedEntities.Where(m =>m.AgencyId == agencyId && m.Id == nextStatusMapping.NextApplicationWorkflowStatusId).FirstOrDefault();
                    if (nextStatus != null)
                        nextApplicationWorkflowStatuses.Add(new ApplicationWorkflowStatus
                        {
                            Id = nextStatus.Id,
                            Name = nextStatus.Name,
                            Description = nextStatus.Description,
                            IsDefaultStatus = nextStatus.IsDefaultStatus,
                            IsCustomizable = nextStatus.IsCustomizable,
                            IsLastPossible = nextStatus.IsLastPossible,
                            ColorId = nextStatus.ColorId,
                            IsActive = true,
                            Updated = nextStatus.Updated,
                            UpdatedBy = nextStatus.UpdatedBy,
                            Created = nextStatus.Created,
                            CreatedBy = nextStatus.CreatedBy
                        });
                }
                applicationWorkflowStatus.NextApplicationWorkflowStatuses = nextApplicationWorkflowStatuses;
            }
            applicationWorkflowStatuses.Add(applicationWorkflowStatus);
        }

        var firstApplicationWorkflowStatus = applicationWorkflowStatuses.FirstOrDefault(x => x.Priority == (int)ApplicationWorkflowStatusPriority.Initial && x.IsCustomizable == false);
        if (firstApplicationWorkflowStatus != null)
        {
            applicationWorkflowStatuses.Remove(firstApplicationWorkflowStatus);
            applicationWorkflowStatuses.Insert(0, firstApplicationWorkflowStatus);
        }

        var lastApplicationWorkflowStatus = applicationWorkflowStatuses.FirstOrDefault(x => x.Priority == (int)ApplicationWorkflowStatusPriority.Last && x.IsCustomizable == false);
        if (lastApplicationWorkflowStatus != null)
        {
            applicationWorkflowStatuses.Remove(lastApplicationWorkflowStatus);
            applicationWorkflowStatuses.Add(lastApplicationWorkflowStatus);
        }

        var response = new PaginatationResponse<ApplicationWorkflowStatus>
        {
            Data = applicationWorkflowStatuses,
            PageInfo = new PageInfo { TotalRecordCount = total }
        };

        _logger.LogInformation("Application Workflow Statuses were getting successfully.");

        return response;
    }

    private static SortRequest<ApplicationWorkflowStatusEntity> BuildSortParameter(Sort? sort) => sort?.Item switch
    {
        SORT_KEY_NAME => new(x => x.Name!, sort.Direction == SortDirection.Asc),
        _ => new(x => x.Id, true),
    };

    private static List<Expression<Func<ApplicationWorkflowStatusEntity, bool>>> BuildSearchPredicants(PaginationRequest<SearchApplicationWorkflowStatusRequest> parameters, int agencyId)
    {
        List<Expression<Func<ApplicationWorkflowStatusEntity, bool>>> list = new() {
            x => x.AgencyId == agencyId
        };

        if (!string.IsNullOrWhiteSpace(parameters!.Filters?.Name))
        {
            list.Add(x => !string.IsNullOrWhiteSpace(x.Name) && EF.Functions.ILike(x.Name, $"%{parameters.Filters.Name}%"));
        }

        return list;
    }

    private async Task InitializeApplicationWorkflowStatuses(CancellationToken cancellationToken)
    {
        var initializeApplicationWorkflowStatusesCommand = new InitializeApplicationWorkflowStatusesCommand();
        await _mediator.Send(initializeApplicationWorkflowStatusesCommand, cancellationToken);
    }
}
