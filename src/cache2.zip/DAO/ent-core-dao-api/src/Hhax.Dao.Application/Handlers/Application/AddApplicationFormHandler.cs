﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class AddApplicationFormHandler : IRequestHandler<AddApplicationFormCommand, BaseResponse>
{
    private readonly IMediator _mediator;
    private readonly IAuthenticationService _authenticationService;
    private readonly IGenericRepository<ApplicationFormEntity> _applicationFormRepository;
    private readonly IGenericRepository<ApplicationFormCustomFieldEntity> _customFieldRepository;
    private readonly IGenericRepository<ApplicationOnBoardingFormsEntity> _onBoardingFormsRepository;
    private readonly IGenericRepository<ApplicationOnBoardingFormMappingEntity> _onBoardingFormMappingRepository;
    private readonly IMapper _mapper;
    private readonly ILogger<AddApplicationFormHandler> _logger;

    public AddApplicationFormHandler(IMediator mediator,
                                     IAuthenticationService authenticationService,
                                     IServiceProvider serviceProvider,
                                     IMapper mapper,
                                     ILogger<AddApplicationFormHandler> logger)
    {
        _mediator = mediator;
        _authenticationService = authenticationService;
        _applicationFormRepository = serviceProvider.GetService<IGenericRepository<ApplicationFormEntity>>()!;
        _customFieldRepository = serviceProvider.GetService<IGenericRepository<ApplicationFormCustomFieldEntity>>()!;
        _onBoardingFormsRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationOnBoardingFormsEntity>>();
        _onBoardingFormMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationOnBoardingFormMappingEntity>>();
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<BaseResponse> Handle(AddApplicationFormCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");
        request.CreatedBy = _authenticationService.GetUserId();
        request.UpdatedBy = _authenticationService.GetUserId();
        int agencyId = _authenticationService.GetAgencyId();
        var applicationForm = _mapper.Map<ApplicationForm>(request);
        var entity = _mapper.Map<ApplicationFormEntity>(applicationForm);
        entity.AgencyId = agencyId;

        await _applicationFormRepository.AddAsync(entity);
        await UpdateApplicantEligibilities(entity.Id, cancellationToken);
        await InitializeApplicationWorkflowStatuses(cancellationToken);

        if (applicationForm.ApplicationFormCustomFields != null && entity.Id > 0)
        {
            await AddAplicationCustomFields(entity.Id, applicationForm.ApplicationFormCustomFields);
        }

        if (applicationForm.ApplicationOnBoardingForms != null && entity.Id > 0)
        {
            await AddApplicationOnBoardingForms(entity.Id, applicationForm.ApplicationOnBoardingForms);
        }

        var response = new BaseResponse { Id = entity.Id };
        _logger.LogInformation("Application Form with Id: {Id} was added successfully.", response.Id);
        return response;
    }

    private async Task UpdateApplicantEligibilities(int applicationFormId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicationFormIdCommand(applicationFormId, false);
        await _mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }

    private async Task InitializeApplicationWorkflowStatuses(CancellationToken cancellationToken)
    {
        var initializeApplicationWorkflowStatusesCommand = new InitializeApplicationWorkflowStatusesCommand();
        await _mediator.Send(initializeApplicationWorkflowStatusesCommand, cancellationToken);
    }

    private async Task AddAplicationCustomFields(int applicationFormId, IEnumerable<ApplicationFormCustomFieldInfo> applicationFormCustomFieldInfo)
    {
        var applicationFormCustomFields = _mapper.Map<IEnumerable<ApplicationFormCustomFieldEntity>>(applicationFormCustomFieldInfo);
        int userId = _authenticationService.GetUserId();
        int providerId = _authenticationService.GetAgencyId();

        foreach (var customField in applicationFormCustomFields)
        {
            customField.ApplicationFormId = applicationFormId;
            customField.Created = DateTime.UtcNow;
            customField.CreatedBy = userId;
            customField.Id = 0;
            customField.IsActive = true;
            customField.ProviderId = providerId;

            if (customField.ApplicationCustomFieldValueMappings != null && customField.ApplicationCustomFieldValueMappings.Any())
            {
                foreach (var customFieldMapping in customField.ApplicationCustomFieldValueMappings)
                {
                    customFieldMapping.ApplicationFormId = applicationFormId;
                    customFieldMapping.Created = DateTime.UtcNow;
                    customFieldMapping.CreatedBy = userId;
                    customFieldMapping.Id = 0;
                    customFieldMapping.IsActive = true;
                }
            }
        }

        await _customFieldRepository.AddRangeAsync(applicationFormCustomFields);
    }

    private async Task AddApplicationOnBoardingForms(int applicationFormId, IEnumerable<ApplicationOnBoardingFormInfo> applicationOnBoardingForms)
    {
        int userId = _authenticationService.GetUserId();
        int providerId = _authenticationService.GetAgencyId();

        var formIds = applicationOnBoardingForms.Select(x => x.OnBoardingFormId).ToArray();

        ApplicationOnBoardingFormMappingEntity? onBoardingFormMapping;
        List<ApplicationOnBoardingFormMappingEntity> newOnBoardingFormMappingEntities = new();

        var onBoardingFormsEntities = (await _onBoardingFormsRepository.FindAsync(x => formIds.Contains(x.OnBoardingFormId))).ToList();

        foreach (var form in applicationOnBoardingForms)
        {
            onBoardingFormMapping = new()
            {
                Id = 0,
                ApplicationOnBoardingFormId = onBoardingFormsEntities.Find(x => x.OnBoardingFormId == form.OnBoardingFormId && x.Version == form.Version)?.Id ?? 0,
                ApplicationFormId = applicationFormId,
                IsShow = form.IsShow,
                IsActive = form.IsActive,
                CreatedBy = userId,
                Created = DateTime.UtcNow
            };

            if (onBoardingFormMapping.ApplicationOnBoardingFormId == 0)
            {
                onBoardingFormMapping.ApplicationOnBoardingForms = new()
                {
                    Id = 0,
                    OnBoardingFormId = form.OnBoardingFormId,
                    Name = form.Name,
                    Category = form.Category,
                    Description = form.Description,
                    Version = form.Version,
                    IsActive = true,
                    ProviderId = providerId,
                    CreatedBy = userId,
                    Created = DateTime.UtcNow
                };
            }

            newOnBoardingFormMappingEntities.Add(onBoardingFormMapping);
        }

        await _onBoardingFormMappingRepository.AddRangeAsync(newOnBoardingFormMappingEntities);
    }
}
