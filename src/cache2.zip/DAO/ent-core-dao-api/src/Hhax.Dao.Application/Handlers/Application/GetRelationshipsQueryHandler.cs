﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Common.Extensions;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetRelationshipsQueryHandler : IRequestHandler<GetRelationshipsQuery, IEnumerable<Relationship>>
{
    private readonly IReadOnlyRepository<OfficeInfoEntity> _officeInfoEntityRepository;
    private readonly ILookupService<Relationship, GenericReferenceEntity> _relationshipsLookupService;
    private readonly ILogger<GetRelationshipsQueryHandler> _logger;

    public GetRelationshipsQueryHandler(ILookupService<Relationship, GenericReferenceEntity> relationshipsLookupService,
                                        ILogger<GetRelationshipsQueryHandler> logger,
                                        IReadOnlyRepository<OfficeInfoEntity> officeInfoEntityRepository)
    {
        _officeInfoEntityRepository = officeInfoEntityRepository;
        _relationshipsLookupService = relationshipsLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<Relationship>> Handle(GetRelationshipsQuery query, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        string relationshipType = ReferenceType.EmergencyContactRelationship.GetDisplayName();

        var office = await _officeInfoEntityRepository.GetByIdAsync(query.OfficeId);

        if (office is not null)
        {
            var response = await _relationshipsLookupService.FindAsync(relationship => relationship.CompanyId.HasValue &&
                                                                                   relationship.CompanyId.Value == office.VendorId &&
                                                                                   relationship.IsActive &&
                                                                                   relationship.Type == relationshipType);

            _logger.LogInformation("Relationships were getting successfully.");

            return response;
        }

        _logger.LogInformation("Relationships not found.");

        return Enumerable.Empty<Relationship>();
    }
}
