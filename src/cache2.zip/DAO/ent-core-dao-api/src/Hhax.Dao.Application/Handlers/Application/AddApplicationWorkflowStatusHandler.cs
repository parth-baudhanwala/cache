﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class AddApplicationWorkflowStatusHandler : IRequestHandler<AddApplicationWorkflowStatusCommand, BaseResponse>
{
    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<AddApplicationWorkflowStatusHandler> _logger;
    
    public AddApplicationWorkflowStatusHandler(IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusRepository,
                                               IAuthenticationService authenticationService,
                                               IMapper mapper,
                                               ILogger<AddApplicationWorkflowStatusHandler> logger)
    {
        _authenticationService = authenticationService;
        _applicationWorkflowStatusRepository = applicationWorkflowStatusRepository;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<BaseResponse> Handle(AddApplicationWorkflowStatusCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var userId = _authenticationService.GetUserId();
        var agencyId = _authenticationService.GetAgencyId();
        
        request.AgencyId = agencyId;
        request.UserId = userId;

        request.CreatedBy = userId;
        request.UpdatedBy = userId;

        var applicationWorkflowStatus = _mapper.Map<ApplicationWorkflowStatus>(request);

        var entity = _mapper.Map<ApplicationWorkflowStatusEntity>(applicationWorkflowStatus);

        entity.IsCustomizable = true;
        entity.IsLastPossible = false;
        entity.IsLastStatus = entity.ApplicationWorkflowStatusMappings is null || 
            entity.ApplicationWorkflowStatusMappings.Count() == 0;
        entity.Priority = (int)ApplicationWorkflowStatusPriority.None;

        await _applicationWorkflowStatusRepository.AddAsync(entity);

        var response = new BaseResponse { Id = entity.Id };

        _logger.LogInformation("ApplicationWorkflowStatus were adding successfully.");

        return response;
    }
}
