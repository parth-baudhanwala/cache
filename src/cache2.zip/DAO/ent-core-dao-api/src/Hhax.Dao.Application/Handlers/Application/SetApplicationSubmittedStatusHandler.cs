﻿using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Notification;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class SetApplicationSubmittedStatusHandler : IRequestHandler<SetApplicationSubmittedStatusCommand, BaseResponse>
{
    private readonly IAuthenticationService _authenticationService;
    private readonly IMailNotificationService _mailNotificationService;
    private readonly IConfiguration _configuration;

    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;
    private readonly IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> _applicantHumanResourcePersonaMappingRepository;
    private readonly IReadOnlyRepository<HumanResourcePersonaEntity> _humanResourcePersonaRepository;
    private readonly IReadOnlyRepository<UserInfoEntity> _userInfoEntityRepository;
    private readonly IReadOnlyRepository<VendorNotificationsSettingsEntity> _notificationsSettingsRepository;

    private readonly ILogger<SetApplicationSubmittedStatusHandler> _logger;

    public SetApplicationSubmittedStatusHandler(IAuthenticationService authenticationService,
                                        IMailNotificationService mailNotificationService,
                                        IConfiguration configuration,
                                        IGenericRepository<ApplicantEntity> applicantRepository,
                                        IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusRepository,
                                        IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> applicantHumanResourcePersonaMappingRepository,
                                        IReadOnlyRepository<HumanResourcePersonaEntity> humanResourcePersonaRepository,
                                        IReadOnlyRepository<UserInfoEntity> userInfoEntityRepository,
                                        IReadOnlyRepository<VendorNotificationsSettingsEntity> notificationsSettingsRepository,
                                        ILogger<SetApplicationSubmittedStatusHandler> logger)
    {
        _authenticationService = authenticationService;
        _mailNotificationService = mailNotificationService;
        _configuration = configuration;
        _applicantRepository = applicantRepository;
        _applicationWorkflowStatusRepository = applicationWorkflowStatusRepository;
        _applicantHumanResourcePersonaMappingRepository = applicantHumanResourcePersonaMappingRepository;
        _humanResourcePersonaRepository = humanResourcePersonaRepository;
        _userInfoEntityRepository = userInfoEntityRepository;
        _notificationsSettingsRepository = notificationsSettingsRepository;

        _logger = logger;
    }

    public async Task<BaseResponse> Handle(SetApplicationSubmittedStatusCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Update Applicant workflow status with Id: {applicantId}.", command.ApplicantId);

        string? domain = _configuration["HealthCheck:ServiceUrl"];

        int agencyId = _authenticationService.GetAgencyId();

        var applicant = await _applicantRepository.FirstOrDefaultAsync(x => x.Id == command.ApplicantId);

        if (applicant == null)
        {
            _logger.LogError($"{nameof(Applicant)} with Id: {command.ApplicantId} not found.");
            throw new ApplicantNotFoundException($"{nameof(Applicant)} with Id: {command.ApplicantId} not found.");
        }

        var applicationSubmittedStatus = await _applicationWorkflowStatusRepository.FirstOrDefaultAsync(
        x => x.AgencyId == agencyId &&
        x.IsDefaultStatus == true &&
        x.IsCustomizable == DefaultWorkflowStatusesConstants.ApplicationSubmittedIsCustomizable &&
        x.Name == DefaultWorkflowStatusesConstants.ApplicationSubmittedName);

        applicant.ApplicationWorkflowStatusId = applicationSubmittedStatus!.Id;
        applicant.ApplicationWorkflowStatusUpdated = DateTime.UtcNow;
        applicant.Updated = DateTime.UtcNow;
        applicant.UpdatedBy = command.ApplicantId;

        await _applicantRepository.UpdateAsync(applicant);

        var humanResourcePersonaMappings = await _applicantHumanResourcePersonaMappingRepository.FindAsync(x => x.ApplicantId == command.ApplicantId);

        if (humanResourcePersonaMappings.Any())
        {
            int humanResourcePersonaId = humanResourcePersonaMappings.OrderByDescending(x => x.Created).First().HumanResourcePersonaId;
            await SendNotification(applicant,
            applicationSubmittedStatus.Name!,
              "#fff1d2", "1px solid #fdb81e",
            humanResourcePersonaId, domain);
        }

        _logger.LogInformation("Applicant with Id: {applicantId} was updated.", command.ApplicantId);

        return new() { Id = command.ApplicantId };
    }

    private async Task SendNotification(ApplicantEntity applicant,
       string statusName, string statusBackgroundColor, string statusBorderColor,
       int humanResourcePersonaId, string? domain)
    {
        VendorNotificationsSettingsEntity? settings = await _notificationsSettingsRepository.FirstOrDefaultAsync(x => x.VendorId == applicant.AgencyId);

        if (settings is not null && settings.IsNotifyHRStatusChanges)
        {
            var humanResourcePersona = await _humanResourcePersonaRepository.FirstOrDefaultAsync(x => x.Id == humanResourcePersonaId);

            var humanResourcePersonaUser = await _userInfoEntityRepository.FirstOrDefaultAsync(x => x.Id == humanResourcePersona!.UserId);

            var statusChangedNotificationData = new StatusChangedNotificationData()
            {
                HumanResourcePersonaName = humanResourcePersona!.Name!,
                ApplicantId = applicant.Id,
                ApplicantFirstName = applicant.FirstName!,
                ApplicantLastName = applicant.LastName!,
                Domain = domain,
                StatusName = statusName,
                StatusBackgroundColor = statusBackgroundColor,
                StatusBorderColor = statusBorderColor,
                StatusUpdated = applicant.Updated!.Value
            };

            await _mailNotificationService.SendStatusChangedEmailAsync(statusChangedNotificationData, humanResourcePersonaUser!.EMail!);
        }
    }
}
