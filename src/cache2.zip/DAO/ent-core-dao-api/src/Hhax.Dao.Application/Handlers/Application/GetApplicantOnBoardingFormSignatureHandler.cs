﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantOnBoardingFormSignatureHandler : IRequestHandler<GetApplicantOnBoardingFormSignatureQuery, OnBoardingFormSignatureInfo>
{
    private readonly ILogger<GetApplicantOnBoardingFormSignatureHandler> _logger;
    private readonly IFilesUploadService _filesUploadService;
    private readonly IReadOnlyRepository<ApplicantOnBoardingFormSignatureEntity> _applicantOnBoardingFormSignatureRepository;

    public GetApplicantOnBoardingFormSignatureHandler(ILogger<GetApplicantOnBoardingFormSignatureHandler> logger, IServiceProvider serviceProvider)
    {
        _logger = logger;
        _filesUploadService = serviceProvider.GetRequiredService<IFilesUploadService>();
        _applicantOnBoardingFormSignatureRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<ApplicantOnBoardingFormSignatureEntity>>();
    }

    public async Task<OnBoardingFormSignatureInfo> Handle(GetApplicantOnBoardingFormSignatureQuery query, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        OnBoardingFormSignatureInfo applicantSignatureInfo = new();

        var onboardingFormSignature = await _applicantOnBoardingFormSignatureRepository.FirstOrDefaultAsync(x => x.ApplicantId == query.ApplicantId);

        if (onboardingFormSignature == null) return applicantSignatureInfo;

        if (onboardingFormSignature.IsSignatureDrawn && !string.IsNullOrWhiteSpace(onboardingFormSignature.SignatureFileKey))
        {
            byte[] imageBytes = await _filesUploadService.GetDocumentAsync(onboardingFormSignature.SignatureFileKey);
            applicantSignatureInfo.Signature = Convert.ToBase64String(imageBytes);
        }
        else
        {
            applicantSignatureInfo.Signature = onboardingFormSignature.SignatureText;
        }

        applicantSignatureInfo.IsSignatureDrawn = onboardingFormSignature.IsSignatureDrawn;
        applicantSignatureInfo.SignatureDate = onboardingFormSignature.SignatureDate;

        _logger.LogInformation("Applicant signature was fetched successfully for {ApplicantId}.", query.ApplicantId);

        return applicantSignatureInfo;
    }
}
