﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormComplianceApplicantSectionQueryHandler : IRequestHandler<GetApplicationFormComplianceApplicantSectionQuery, ApplicationFormApplicantSection>
{
    private readonly IDbContextFactory<HhaDbContext> _hhaDbContextFactory;
    private readonly IGenericRepository<ApplicationFormApplicantSectionEntity> _applicationFormApplicantSectionRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormComplianceApplicantSectionQueryHandler> _logger;

    public GetApplicationFormComplianceApplicantSectionQueryHandler(IDbContextFactory<HhaDbContext> hhaDbContextFactory,
                                                                    IGenericRepository<ApplicationFormApplicantSectionEntity> applicationFormApplicantSectionRepository,
                                                                    IAuthenticationService authenticationService,
                                                                    IMapper mapper,
                                                                    ILogger<GetApplicationFormComplianceApplicantSectionQueryHandler> logger)
    {
        _hhaDbContextFactory = hhaDbContextFactory;
        _applicationFormApplicantSectionRepository = applicationFormApplicantSectionRepository;

        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicationFormApplicantSection> Handle(GetApplicationFormComplianceApplicantSectionQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var userId = _authenticationService.GetUserId();
        var agencyId = _authenticationService.GetAgencyId();

        ApplicationFormApplicantSection response;

        var documentsAndComplianceSectionEntity = await _applicationFormApplicantSectionRepository.FirstOrDefaultAsync(applicantSection => applicantSection.Id == (int)ApplicationFormApplicantSections.ComplianceFields);
        if (documentsAndComplianceSectionEntity == null)
        {
            const string message = "Documents & Compliance section not found.";

            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        documentsAndComplianceSectionEntity.CreatedBy = userId;
        documentsAndComplianceSectionEntity.UpdatedBy = userId;

        using (var context = await _hhaDbContextFactory.CreateDbContextAsync(cancellationToken))
        {
            var complianceSetupEntities = await (from complianceSetup in context.ComplianceSetups!

                                                 join complianceSetupOffice in context.ComplianceSetupOffices! on complianceSetup.Id equals complianceSetupOffice.ComplianceSetupId

                                                 where request.OfficeIds.Contains(complianceSetupOffice.OfficeId) &&
                                                       complianceSetup.Status == ComplianceSetupStatuses.Active &&
                                                       complianceSetup.ProviderId == agencyId

                                                 select complianceSetup).ToArrayAsync(cancellationToken: cancellationToken);

            response = _mapper.Map<ApplicationFormApplicantSection>(documentsAndComplianceSectionEntity);

            if (complianceSetupEntities.Any())
            {
                var maxPublishVersion = complianceSetupEntities.Max(complianceSetupEntity => complianceSetupEntity.PublishVersion);

                var complianceSetupEntity = complianceSetupEntities.FirstOrDefault(complianceSetupEntity => complianceSetupEntity.PublishVersion == maxPublishVersion);

                var complianceCustomFieldEntities = await context.ComplianceCustomFields!.Where(complianceCustomField => complianceCustomField.ComplianceSetupId == complianceSetupEntity!.Id &&
                                                                                                                         complianceCustomField.Status == ComplianceCustomFieldStatuses.Active &&
                                                                                                                         complianceCustomField.ProviderId == agencyId).ToArrayAsync(cancellationToken: cancellationToken);
                response.ComplianceSetupName = complianceSetupEntity?.ComplianceSetupName;

                response.ApplicationFormApplicantFields = complianceCustomFieldEntities.Select(applicationFormApplicantField => new ApplicationFormApplicantField
                {
                    Id = applicationFormApplicantField.ComplianceFieldId ?? throw new NullValueException("Compliance Custom Field Id should not be null."),
                    Name = applicationFormApplicantField.CustomFieldLabel,
                    ApplicantSectionId = (int)ApplicationFormApplicantSections.ComplianceFields,
                    DefaultIsRequire = false,
                    DefaultIsShow = false,
                    IsActive = applicationFormApplicantField.Status.HasValue && applicationFormApplicantField.Status.Value.ToString() == ComplianceCustomFieldStatuses.Active.ToString(),
                    IsRequireEnabled = true,
                    IsShowEnabled = true,
                    Created = DateTime.UtcNow,
                    CreatedBy = userId,
                    Updated = DateTime.UtcNow,
                    UpdatedBy = userId
                }).ToArray();
            }
        }

        _logger.LogInformation("Application Form Compliance Applicant Section with Id: {Id} was getting successfully.", response.Id);

        return response;
    }
}
