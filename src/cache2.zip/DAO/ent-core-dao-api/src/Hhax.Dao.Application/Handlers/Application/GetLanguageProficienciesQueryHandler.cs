﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetLanguageProficienciesQueryHandler : IRequestHandler<GetLanguageProficienciesQuery, IEnumerable<LanguageProficiency>>
{
    private readonly ILookupService<LanguageProficiency, LanguageProficiencyEntity> _languageProficiencyLookupService;
    private readonly ILogger<GetLanguageProficienciesQueryHandler> _logger;

    public GetLanguageProficienciesQueryHandler(ILookupService<LanguageProficiency, LanguageProficiencyEntity> languageProficiencyLookupService,
                                                ILogger<GetLanguageProficienciesQueryHandler> logger)
    {
        _languageProficiencyLookupService = languageProficiencyLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<LanguageProficiency>> Handle(GetLanguageProficienciesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var response = await _languageProficiencyLookupService.GetAllAsync();

        _logger.LogInformation("Handle was getting successfully.");

        return response;
    }
}
