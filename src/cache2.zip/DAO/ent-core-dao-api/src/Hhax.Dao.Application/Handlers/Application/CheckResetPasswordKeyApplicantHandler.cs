﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application
{
    public class CheckResetPasswordKeyApplicantHandler : IRequestHandler<CheckResetPasswordKeyApplicantQuery, CheckResetPasswordKeyApplicantResponse>
    {
        private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
        private readonly IResetPasswordService _resetPasswordService;
        private readonly ILogger<CheckResetPasswordKeyApplicantHandler> _logger;

        public CheckResetPasswordKeyApplicantHandler(
            IGenericRepository<ApplicantEntity> applicantRepository,
            IResetPasswordService resetPasswordService,
            ILogger<CheckResetPasswordKeyApplicantHandler> logger) 
        { 
            _applicantRepository = applicantRepository;
            _resetPasswordService = resetPasswordService;
            _logger = logger;
        }

        public async Task<CheckResetPasswordKeyApplicantResponse> Handle(CheckResetPasswordKeyApplicantQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Starting checking reset password key " +
                $"for applicant with Id: '{request.ApplicantId}'.");

            if (request.ApplicantId == null)
                throw new ArgumentNullException(nameof(request.ApplicantId));
            if (request.Key == null)
                throw new ArgumentNullException(nameof(request.Key));

            int applicantId = request.ApplicantId!.Value;
            ApplicantEntity applicant = await _applicantRepository.GetByIdAsync(applicantId);

            if (applicant == null)
            {
                var message = $"Applicant with Id: '{applicantId}' not found.";

                _logger.LogError(message);
                throw new EntityNotFoundException(message);
            }

            CheckResetPasswordKeyApplicantResponse result = new();

            bool response = await _resetPasswordService.VerifуKeyAsync(applicantId, request.Key);
            result.IsValid = response;

            if (response)
            {
                result.Email = applicant.LoginEmail;

                if (!applicant.IsVerified)
                {
                    applicant.IsVerified = true;
                    await _applicantRepository.UpdateAsync(applicant);
                }
            }

            _logger.LogInformation($"Reset password key " +
                $"for applicant with Id: '{applicantId}' was checked.");

            return result;
        }
    }
}
