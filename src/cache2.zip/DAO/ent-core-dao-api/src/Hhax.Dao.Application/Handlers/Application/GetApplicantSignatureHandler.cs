﻿using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantSignatureHandler : IRequestHandler<GetApplicantSignatureCommand, IEnumerable<Signature>>
{
    private readonly ILogger<GetApplicantCustomFieldHandler> _logger;
    private readonly IReadOnlyRepository<ApplicantSignatureEntity> _applicantSignatureRepository;

    public GetApplicantSignatureHandler(ILogger<GetApplicantCustomFieldHandler> logger,
                                        IServiceProvider serviceProvider)
    {
        _logger = logger;
        _applicantSignatureRepository = serviceProvider.GetService<IReadOnlyRepository<ApplicantSignatureEntity>>()!;
    }

    public async Task<IEnumerable<Signature>> Handle(GetApplicantSignatureCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var applicantSignatures = (await _applicantSignatureRepository
                                            .FindAsync(x => x.ApplicantId == command.ApplicantId
                                                            && command.ApplicantSectionIds.Contains(x.ApplicantSectionId)
                                                            && (command.ReferenceId == 0 || x.ReferenceId == command.ReferenceId)))
                                            .Select(x => new Signature
                                            {
                                                Value = x.Value,
                                                TimeStamp = x.TimeStamp,
                                                ApplicantSectionId = x.ApplicantSectionId,
                                                ReferenceId = x.ReferenceId
                                            });

        _logger.LogInformation("Applicant signatures were fetched successfully for {ApplicantId}.", command.ApplicantId);

        return applicantSignatures;
    }
}
