﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantForUserQueryHandler : IRequestHandler<GetApplicantForUserQuery, Applicant?>
{
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IMediatorService _mediator;
    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicantForUserQueryHandler> _logger;

    public GetApplicantForUserQueryHandler(IGenericRepository<ApplicantEntity> applicantRepository,
                                           IAuthenticationService authenticationService,
                                           IMediatorService mediator,
                                           IMapper mapper,
                                           ILogger<GetApplicantForUserQueryHandler> logger)
    {
        _applicantRepository = applicantRepository;
        _authenticationService = authenticationService;
        _mediator = mediator;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<Applicant?> Handle(GetApplicantForUserQuery request, CancellationToken cancellationToken)
    {
        var userId = _authenticationService.GetUserId();

        _logger.LogInformation("GetApplicantionForUserAsync with Id: {userId}.", userId);

        var applicant = await _applicantRepository.FirstOrDefaultAsync(x => x.UserId == userId, hasNavigationProperties: true);
        if (applicant == null)
        {
            const string message = "Applicant for current user not found";
            throw new EntityNotFoundException(message);
        }

        var response = _mapper.Map<Applicant>(applicant);

        int[] applicantSectionIds = new int[6]
        {
            (int)ApplicationFormApplicantSections.Demographics,
            (int)ApplicationFormApplicantSections.Address,
            (int)ApplicationFormApplicantSections.EmergencyContact,
            (int)ApplicationFormApplicantSections.NotificationPreferences,
            (int)ApplicationFormApplicantSections.Languages,
            (int)ApplicationFormApplicantSections.EmploymentInformation
        };

        GetApplicantSignatureCommand signatureCommand = new(applicant.Id, 0, applicantSectionIds);

        response.Signatures = await _mediator.SendAsync<GetApplicantSignatureCommand, IEnumerable<Signature>>(signatureCommand);

        _logger.LogInformation("Applicant for user with Id: {userId} was getting successfully.", userId);

        return response;
    }
}
