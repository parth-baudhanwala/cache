﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class UpdateApplicationWorkflowStatusHandler : IRequestHandler<UpdateApplicationWorkflowStatusCommand, BaseResponse>
{
    private readonly ILookupService<ApplicationWorkflowStatusBadgeColor, ApplicationWorkflowStatusBadgeColorEntity> _applicationWorkflowStatusBadgeColorsLookupService;
    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;
    private readonly IAuthenticationService _authenticationService;
    
    private readonly ILogger<UpdateApplicationWorkflowStatusHandler> _logger;

    public UpdateApplicationWorkflowStatusHandler(ILookupService<ApplicationWorkflowStatusBadgeColor, ApplicationWorkflowStatusBadgeColorEntity> applicationWorkflowStatusBadgeColorsLookupService,
                                                  IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusRepository,
                                                  IAuthenticationService authenticationService,
                                                  ILogger<UpdateApplicationWorkflowStatusHandler> logger)
    {
        _applicationWorkflowStatusBadgeColorsLookupService = applicationWorkflowStatusBadgeColorsLookupService;
        _applicationWorkflowStatusRepository = applicationWorkflowStatusRepository;

        _authenticationService = authenticationService;

        _logger = logger;
    }

    public async Task<BaseResponse> Handle(UpdateApplicationWorkflowStatusCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        CheckEditableStatusIsNotExistAmongNextStatuses(request);

        var userId = _authenticationService.GetUserId();

        var applicationWorkflowStatus = await _applicationWorkflowStatusRepository.GetByIdAsync(request.Id, hasNavigationProperties: true);
        if (applicationWorkflowStatus == null)
        {
            var message = $"{nameof(ApplicationWorkflowStatus)} with Id: {request.Id} not found.";

            _logger.LogError(message);
            throw new ApplicationFormNotFoundException(message);
        }

        if (applicationWorkflowStatus.IsCustomizable == true)
        {
            applicationWorkflowStatus.Name = request.Name;
            applicationWorkflowStatus.ColorId = request.ColorId;
        }

        applicationWorkflowStatus.Description = request.Description;
        applicationWorkflowStatus.IsInterviewPossible = request.IsInterviewPossible;

        applicationWorkflowStatus.Updated = DateTime.UtcNow;
        applicationWorkflowStatus.UpdatedBy = userId;

        if (applicationWorkflowStatus.IsLastPossible != true)
        {
            UpdateApplicationWorkflowStatusMappings(applicationWorkflowStatus, request, userId);
        }

        applicationWorkflowStatus.IsLastStatus = applicationWorkflowStatus.ApplicationWorkflowStatusMappings is null || 
            applicationWorkflowStatus.ApplicationWorkflowStatusMappings.Count == 0;

        await _applicationWorkflowStatusRepository.UpdateAsync(applicationWorkflowStatus);

        var response = new BaseResponse { Id = applicationWorkflowStatus.Id };

        _logger.LogInformation("Application Workflow Status was updated successfully.");

        return response;
    }

    private static void UpdateApplicationWorkflowStatusMappings(ApplicationWorkflowStatusEntity applicationWorkflowStatus, UpdateApplicationWorkflowStatusCommand request, int userId)
    {
        List<ApplicationWorkflowStatusMappingEntity> appplicationWorkflowStatusMappings = new();

        if (applicationWorkflowStatus.ApplicationWorkflowStatusMappings != null)
        {
            appplicationWorkflowStatusMappings = applicationWorkflowStatus.ApplicationWorkflowStatusMappings!.ToList();
            foreach (var mapping in appplicationWorkflowStatusMappings)
            {
                if (request.NextApplicationWorkflowStatusIds == null || !request.NextApplicationWorkflowStatusIds.Any(x => x == mapping.NextApplicationWorkflowStatusId))
                {
                    applicationWorkflowStatus.ApplicationWorkflowStatusMappings!.Remove(mapping);
                }
            }
        }

        if (request.NextApplicationWorkflowStatusIds != null)
        {
            appplicationWorkflowStatusMappings = new();

            foreach (var nextApplicationWorkflowStatusId in request?.NextApplicationWorkflowStatusIds!)
            {
                if (!appplicationWorkflowStatusMappings.Any(x => x.NextApplicationWorkflowStatusId == nextApplicationWorkflowStatusId))
                {
                    var applicationWorkflowStatusMapping = new ApplicationWorkflowStatusMappingEntity
                    {
                        NextApplicationWorkflowStatusId = nextApplicationWorkflowStatusId,
                        ApplicationWorkflowStatusId = applicationWorkflowStatus.Id,
                        Created = DateTime.UtcNow,
                        CreatedBy = userId,
                        Updated = DateTime.UtcNow,
                        UpdatedBy = userId
                    };
                    appplicationWorkflowStatusMappings.Add(applicationWorkflowStatusMapping);
                }
            }
            applicationWorkflowStatus.ApplicationWorkflowStatusMappings = appplicationWorkflowStatusMappings;
        }
    }

    private void CheckEditableStatusIsNotExistAmongNextStatuses(UpdateApplicationWorkflowStatusCommand request)
    {
        var nextWorkflowStatuses = request.NextApplicationWorkflowStatusIds;

        if (nextWorkflowStatuses != null && Array.Exists(nextWorkflowStatuses, element => element == request.Id))
        {
            var message = $"The {request.Name} status that is being edited has been added to the Next Status list. This is not allowed, as it will lead to a loop.";

            _logger.LogError(message);
            throw new ApplicationWorkflowStatusException(message);
        }
    }
}
