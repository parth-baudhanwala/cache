﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.MailVerification;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class VerifyApplicantMailQueryHandler : IRequestHandler<VerifyApplicantMailQuery, MailVerificationResponse>
{
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly ILogger<VerifyApplicantMailQueryHandler> _logger;
    private readonly IMailVerificationService _mailVerifiactionService;

    public VerifyApplicantMailQueryHandler(ILogger<VerifyApplicantMailQueryHandler> logger,
                                           IMailVerificationService mailVerifiactionService,
                                           IGenericRepository<ApplicantEntity> applicantRepository)
    {
        _applicantRepository = applicantRepository;
        _logger = logger;
        _mailVerifiactionService = mailVerifiactionService;
    }

    public async Task<MailVerificationResponse> Handle(VerifyApplicantMailQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"Verify Mail key for Applicant with id: {request.ApplicantId}.");

        var targetApplicant = await _applicantRepository.GetByIdAsync(request.ApplicantId);

        if (targetApplicant == null)
        {
            var message = $"{nameof(Applicant)} with Id: {request.ApplicantId} not found.";

            _logger.LogError("Applicant with Id: {applicantId} not found.", request.ApplicantId);
            throw new EntityNotFoundException(message);
        }
        else
        {
            if (targetApplicant.IsVerified) 
                return new MailVerificationResponse 
                { 
                    Status = MailVerificationStatus.AlreadyVerified 
                };
            var response = await _mailVerifiactionService.VerifуKeyAsync(request.ApplicantId, request.Key);
            if (response)
            {
                targetApplicant.IsVerified = true;
                await _applicantRepository.UpdateAsync(targetApplicant);
                return new MailVerificationResponse
                {
                    Status = MailVerificationStatus.Verified
                };
            }
            else
                return new MailVerificationResponse
                {
                    Status = MailVerificationStatus.NotFound,
                    Name = targetApplicant.FirstName,
                    Mail = targetApplicant.LoginEmail
                };
        }
    }
}