﻿using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class UpdateVerifyStatusApplicantEligibilitiesByApplicantIdHandler : IRequestHandler<UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand, Unit>
{
    private readonly IGenericRepository<ApplicantEligibilityEntity> _applicantEligibilityRepository;

    private readonly ILogger<UpdateVerifyStatusApplicantEligibilitiesByApplicantIdHandler> _logger;

    public UpdateVerifyStatusApplicantEligibilitiesByApplicantIdHandler(IGenericRepository<ApplicantEligibilityEntity> applicantEligibilityRepository,
                                                                        ILogger<UpdateVerifyStatusApplicantEligibilitiesByApplicantIdHandler> logger)
    {
        _applicantEligibilityRepository = applicantEligibilityRepository;

        _logger = logger;
    }

    public async Task<Unit> Handle(UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Update Verify Status of Applicant Eligibilities with Status: {isVerify} and Applicant Id: {applicantId}.", request.IsVerified, request.ApplicantId);

        var applicantEligibilities = await _applicantEligibilityRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);

        foreach (var applicantEligibility in applicantEligibilities)
        {
            applicantEligibility.IsVerified = request.IsVerified;
        }

        await _applicantEligibilityRepository.UpdateRangeAsync(applicantEligibilities);

        _logger.LogInformation($"Status of Applicant Eligibilities was updated successfully.");

        return Unit.Value;
    }
}
