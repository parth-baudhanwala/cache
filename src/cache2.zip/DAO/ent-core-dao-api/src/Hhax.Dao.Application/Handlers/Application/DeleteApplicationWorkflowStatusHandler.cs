﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class DeleteApplicationWorkflowStatusHandler : IRequestHandler<DeleteApplicationWorkflowStatusCommand, Unit>
{
    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;
    private readonly IGenericRepository<ApplicationWorkflowStatusMappingEntity> _applicationWorkflowStatusMappingRepository;
    private readonly ILogger<DeleteApplicationWorkflowStatusHandler> _logger;

    public DeleteApplicationWorkflowStatusHandler(IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatustRepository,
                                        IGenericRepository<ApplicationWorkflowStatusMappingEntity> applicationWorkflowStatusMappingRepository,
                                        ILogger<DeleteApplicationWorkflowStatusHandler> logger)
    {
        _applicationWorkflowStatusRepository = applicationWorkflowStatustRepository;
        _applicationWorkflowStatusMappingRepository = applicationWorkflowStatusMappingRepository;
        _logger = logger;
    }

    public async Task<Unit> Handle(DeleteApplicationWorkflowStatusCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var applicationWorkflowStatusEntity = await _applicationWorkflowStatusRepository.FirstOrDefaultAsync(x => x.Id == request.ApplicationFormId);

        if (applicationWorkflowStatusEntity == null)
        {
            var message = $"{nameof(ApplicationWorkflowStatusEntity)} with Id: {request.ApplicationFormId} not found.";

            _logger.LogError("Applicant Workflow Status with Id: {applicantId} not found.", request.ApplicationFormId);
            throw new EntityNotFoundException(message);
        }

        if (applicationWorkflowStatusEntity.IsCustomizable != false)
        {
            await _applicationWorkflowStatusRepository.RemoveAsync(applicationWorkflowStatusEntity!);
            _logger.LogInformation("Applicant Workflow Status with Id: {Id} was deleted.", request.ApplicationFormId);

            await RemoveMappings(applicationWorkflowStatusEntity.Id);
            _logger.LogInformation("Mappings for Applicant Workflow Status with Id: {Id} was deleted.", request.ApplicationFormId);
        }

        return Unit.Value;
    }

    private async Task RemoveMappings(int applicationWorkflowStatusId)
    {
        var mappingsToRemove = await _applicationWorkflowStatusMappingRepository.FindAsync(x => x.NextApplicationWorkflowStatusId == applicationWorkflowStatusId);
        var statusesToEditIds = mappingsToRemove.Select(x => x.ApplicationWorkflowStatusId).ToList();
        await _applicationWorkflowStatusMappingRepository.RemoveRangeAsync(mappingsToRemove);
        var statusesToEdit = await _applicationWorkflowStatusRepository.FindAsync(x => statusesToEditIds.Contains(x.Id));

        foreach(var statusToEdit in statusesToEdit)
            statusToEdit.IsLastStatus = statusToEdit.ApplicationWorkflowStatusMappings is null ||
            statusToEdit.ApplicationWorkflowStatusMappings.Count() == 0;
    }
}
