﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormInServiceTopicsApplicantSectionQueryHandler : IRequestHandler<GetApplicationFormInServiceTopicsApplicantSectionQuery, ApplicationFormApplicantSection>
{
    private readonly IGenericRepository<ApplicationFormApplicantSectionEntity> _applicationFormApplicantSectionRepository;
    private readonly IReadOnlyRepository<RefInServiceTopicEntity> _refInServiceTopicRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormInServiceTopicsApplicantSectionQueryHandler> _logger;

    public GetApplicationFormInServiceTopicsApplicantSectionQueryHandler(IGenericRepository<ApplicationFormApplicantSectionEntity> applicationFormApplicantSectionRepository,
                                                                    IReadOnlyRepository<RefInServiceTopicEntity> refInServiceTopicRepository,
                                                                    IAuthenticationService authenticationService,
                                                                    IMapper mapper,
                                                                    ILogger<GetApplicationFormInServiceTopicsApplicantSectionQueryHandler> logger)
    {
        _applicationFormApplicantSectionRepository = applicationFormApplicantSectionRepository;
        _refInServiceTopicRepository = refInServiceTopicRepository;

        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicationFormApplicantSection> Handle(GetApplicationFormInServiceTopicsApplicantSectionQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        const int activeValue = 1;

        int userId = _authenticationService.GetUserId();
        int agencyId = _authenticationService.GetAgencyId();

        ApplicationFormApplicantSectionEntity? inServiceSectionEntity = await _applicationFormApplicantSectionRepository.FirstOrDefaultAsync(applicantSection => applicantSection.Id == (int)ApplicationFormApplicantSections.InServiceTopics);
        if (inServiceSectionEntity == null)
        {
            const string message = "InServiceTopics section not found.";

            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        inServiceSectionEntity.CreatedBy = userId;
        inServiceSectionEntity.UpdatedBy = userId;

        ApplicationFormApplicantSection response = _mapper.Map<ApplicationFormApplicantSection>(inServiceSectionEntity);

        IEnumerable<RefInServiceTopicEntity> refInServiceTopicsEntities =
            await _refInServiceTopicRepository.FindAsync(refInServiceTopic =>
                refInServiceTopic.CompanyId == agencyId && refInServiceTopic.Active == activeValue);

        response.ApplicationFormApplicantFields = refInServiceTopicsEntities.Select(applicationFormApplicantField => new ApplicationFormApplicantField
        {
            Id = applicationFormApplicantField.Id,
            Name = applicationFormApplicantField.TopicDescription,
            ApplicantSectionId = (int)ApplicationFormApplicantSections.InServiceTopics,
            DefaultIsRequire = false,
            DefaultIsShow = false,
            IsActive = true,
            IsRequireEnabled = true,
            IsShowEnabled = true,
            Created = DateTime.UtcNow,
            CreatedBy = userId,
            Updated = DateTime.UtcNow,
            UpdatedBy = userId
        }).OrderBy(field => field.Name).ToArray();

        _logger.LogInformation("Application Form In-Service Topics Applicant Section with Id: {Id} was getting successfully.", response.Id);

        return response;
    }
}
