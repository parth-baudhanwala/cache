﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationWorkflowStatusQueryHandler : IRequestHandler<GetApplicationWorkflowStatusQuery, ApplicationWorkflowStatus>
{
    private readonly IAuthenticationService _authenticationService;

    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationWorkflowStatusQueryHandler> _logger;

    public GetApplicationWorkflowStatusQueryHandler(IAuthenticationService authenticationService,
                                                    IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusRepository,
                                                    IMapper mapper,
                                                    ILogger<GetApplicationWorkflowStatusQueryHandler> logger)
    {
        _authenticationService = authenticationService;
        _applicationWorkflowStatusRepository = applicationWorkflowStatusRepository;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicationWorkflowStatus> Handle(GetApplicationWorkflowStatusQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Get Application Workflow Status with Id: {applicationWorkflowStatusId}.", request.ApplicationWorkflowStatusId);

        var applicationWorkflowStatus = await _applicationWorkflowStatusRepository.GetByIdAsync(request.ApplicationWorkflowStatusId, hasNavigationProperties: true);
        if (applicationWorkflowStatus == null)
        {
            var message = $"{nameof(ApplicationWorkflowStatus)} with Id: {request.ApplicationWorkflowStatusId} not found.";

            _logger.LogError(message);
            throw new ApplicationFormNotFoundException(message);
        }

        var result = _mapper.Map<ApplicationWorkflowStatus>(applicationWorkflowStatus);

        var nextApplicationWorkflowStatuses = new List<ApplicationWorkflowStatus>();

        if (applicationWorkflowStatus.ApplicationWorkflowStatusMappings != null)
        {
            var agencyId = _authenticationService.GetAgencyId();
            foreach (var applicationWorkflowStatusMapping in applicationWorkflowStatus.ApplicationWorkflowStatusMappings)
            {
                var nextApplicationWorkflowStatus = await _applicationWorkflowStatusRepository.GetByIdAsync(applicationWorkflowStatusMapping.NextApplicationWorkflowStatusId, hasNavigationProperties: true);
                if (nextApplicationWorkflowStatus != null &&  nextApplicationWorkflowStatus.AgencyId == agencyId)
                {
                    nextApplicationWorkflowStatuses.Add(
                    new ApplicationWorkflowStatus
                    {
                        ColorId = nextApplicationWorkflowStatus.ColorId,
                        Name = nextApplicationWorkflowStatus.Name,
                        IsLastPossible = nextApplicationWorkflowStatus.IsLastPossible,
                        Id = nextApplicationWorkflowStatus.Id,
                        Updated = nextApplicationWorkflowStatus.Updated,
                        UpdatedBy = nextApplicationWorkflowStatus.UpdatedBy,
                        Created = nextApplicationWorkflowStatus.Created,
                        CreatedBy = nextApplicationWorkflowStatus.CreatedBy,
                        IsActive = true
                    });
                }
            }
        }

        result.NextApplicationWorkflowStatuses = nextApplicationWorkflowStatuses;

        _logger.LogInformation("Application Workflow Status with Id: {applicationWorkflowStatusId} was getting successfully.", request.ApplicationWorkflowStatusId);

        return result;
    }
}
