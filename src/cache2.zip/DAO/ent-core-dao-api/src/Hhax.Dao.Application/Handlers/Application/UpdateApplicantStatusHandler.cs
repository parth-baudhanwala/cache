﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Notification;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class UpdateApplicantStatusHandler : IRequestHandler<UpdateApplicantStatusCommand, BaseResponse>
{
    private readonly IAuthenticationService _authenticationService;
    private readonly IMailNotificationService _mailNotificationService;

    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;
    private readonly IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> _applicantHumanResourcePersonaMappingRepository;
    private readonly IReadOnlyRepository<HumanResourcePersonaEntity> _humanResourcePersonaRepository;
    private readonly IReadOnlyRepository<UserInfoEntity> _userInfoEntityRepository;
    private readonly IReadOnlyRepository<VendorNotificationsSettingsEntity> _notificationsSettingsRepository;

    private readonly ILogger<UpdateApplicantStatusHandler> _logger;

    public UpdateApplicantStatusHandler(IAuthenticationService authenticationService,
                                        IMailNotificationService mailNotificationService,
                                        IGenericRepository<ApplicantEntity> applicantRepository,
                                        IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusRepository,
                                        IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> applicantHumanResourcePersonaMappingRepository,
                                        IReadOnlyRepository<HumanResourcePersonaEntity> humanResourcePersonaRepository,
                                        IReadOnlyRepository<UserInfoEntity> userInfoEntityRepository,
                                        IReadOnlyRepository<VendorNotificationsSettingsEntity> notificationsSettingsRepository,
                                        ILogger<UpdateApplicantStatusHandler> logger)
    {
        _authenticationService = authenticationService;
        _mailNotificationService = mailNotificationService;

        _applicantRepository = applicantRepository;
        _applicationWorkflowStatusRepository = applicationWorkflowStatusRepository;
        _applicantHumanResourcePersonaMappingRepository = applicantHumanResourcePersonaMappingRepository;
        _humanResourcePersonaRepository = humanResourcePersonaRepository;
        _userInfoEntityRepository = userInfoEntityRepository;
        _notificationsSettingsRepository = notificationsSettingsRepository;

        _logger = logger;
    }

    public async Task<BaseResponse> Handle(UpdateApplicantStatusCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("UpdateApplicantAsync with Id: {applicantId}.", request.ApplicantId);

        var targetApplicant = await _applicantRepository.GetQuery().Include(s => s.ApplicationWorkflowStatus!)
                                                                   .ThenInclude(i => i.ApplicationWorkflowStatusMappings)
                                                                   .FirstOrDefaultAsync(x => x.Id == request.ApplicantId, cancellationToken: cancellationToken);
        if (targetApplicant == null)
        {
            var message = $"{nameof(Applicant)} with Id: {request.ApplicantId} not found.";

            _logger.LogError(message);
            throw new ApplicantNotFoundException(message);
        }

        var nextApplicationWorkflowStatus = await _applicationWorkflowStatusRepository.FirstOrDefaultAsync(x => x.Id == request.StatusId);
        if (nextApplicationWorkflowStatus is null)
        {
            var message = $"Status with Id: {request.StatusId} not found.";

            _logger.LogError(message);
            throw new ApplicantInvalidException(message);
        }

        var humanResourcePersonaMappings = await _applicantHumanResourcePersonaMappingRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);
        if (!humanResourcePersonaMappings.Any())
        {
            var message = "HR Representative was not assigned to Applicant.";

            _logger.LogError(message);
            throw new ApplicantInvalidException(message);
        }
        int humanResourcePersonaId = humanResourcePersonaMappings.OrderByDescending(x => x.Created).First().HumanResourcePersonaId;

        if (targetApplicant.ApplicationWorkflowStatus?.ApplicationWorkflowStatusMappings?.Any(x => x.NextApplicationWorkflowStatusId == request.StatusId) is null)
        {
            var message = "It is not allowed to change the status to proposed.";

            _logger.LogError(message);
            throw new ApplicantInvalidException(message);
        }

        if (request.GlobalCaregiverId is not null && request.GlobalCaregiverId != Guid.Empty)
        {
            targetApplicant.GlobalCaregiverId = request.GlobalCaregiverId;
            targetApplicant.IsActive = false;
        }

        targetApplicant.ApplicationWorkflowStatusId = request.StatusId;
        targetApplicant.ApplicationWorkflowStatusUpdated = DateTime.UtcNow;
        targetApplicant.Updated = DateTime.UtcNow;
        targetApplicant.UpdatedBy = _authenticationService.GetUserId();

        await _applicantRepository.UpdateAsync(targetApplicant);
        await SendNotification(targetApplicant,
            nextApplicationWorkflowStatus.Name!, request.StatusBackgroundColor!, request.StatusBorderColor!,
            humanResourcePersonaId, request.Domain!);

        _logger.LogInformation("Applicant with Id: {applicantId} was updated.", request.ApplicantId);

        return new() { Id = request.ApplicantId };
    }

    private async Task SendNotification(ApplicantEntity applicant, 
        string statusName, string statusBackgroundColor, string statusBorderColor, 
        int humanResourcePersonaId, string domain)
    {
        VendorNotificationsSettingsEntity? settings = await _notificationsSettingsRepository.FirstOrDefaultAsync(x => x.VendorId == applicant.AgencyId);

        if (settings is not null && settings.IsNotifyHRStatusChanges)
        {
            var humanResourcePersona = await _humanResourcePersonaRepository.FirstOrDefaultAsync(x => x.Id == humanResourcePersonaId);

            var humanResourcePersonaUser = await _userInfoEntityRepository.FirstOrDefaultAsync(x => x.Id == humanResourcePersona!.UserId);

            var statusChangedNotificationData = new StatusChangedNotificationData()
            {
                HumanResourcePersonaName = humanResourcePersona!.Name!,
                ApplicantId = applicant.Id,
                ApplicantFirstName = applicant.FirstName!,
                ApplicantLastName = applicant.LastName!,
                Domain = domain,
                StatusName = statusName,
                StatusBackgroundColor = statusBackgroundColor,
                StatusBorderColor = statusBorderColor,
                StatusUpdated = applicant.Updated!.Value
            };

            await _mailNotificationService.SendStatusChangedEmailAsync(statusChangedNotificationData, humanResourcePersonaUser!.EMail!);
        }
    }
}
