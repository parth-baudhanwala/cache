﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantRequirementsByUniqueIdHandler : IRequestHandler<GetApplicantRequirementsByUniqueIdQuery, IEnumerable<ApplicationFormApplicantRequirement>>
{
    private readonly IDbContextFactory<DaoDbContext> _daoDbContextFactory;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormByIdQueryHandler> _logger;

    public GetApplicantRequirementsByUniqueIdHandler(IDbContextFactory<DaoDbContext> daoDbContextFactory,
                                                     IMapper mapper,
                                                     ILogger<GetApplicationFormByIdQueryHandler> logger)
    {
        _daoDbContextFactory = daoDbContextFactory;
        
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<ApplicationFormApplicantRequirement>> Handle(GetApplicantRequirementsByUniqueIdQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        IEnumerable<ApplicationFormApplicantRequirement> response = new List<ApplicationFormApplicantRequirement>();

        using (var context = await _daoDbContextFactory.CreateDbContextAsync(cancellationToken))
        {
            var applicationFormEntity = await context.ApplicationForms!.FirstOrDefaultAsync(x => x.UniqueUrlId == request.UniqueUrlId, cancellationToken: cancellationToken);
            if (applicationFormEntity == null)
            {
                var message = $"{nameof(ApplicationForm)} with Unique Url Id: {request.UniqueUrlId} not found.";

                _logger.LogError("Application Form with Unique Url Id: {uniqueUrlId} not found.", request.UniqueUrlId);
                throw new ApplicationFormNotFoundException(message);
            }

            _logger.LogInformation("Applicant Requirements were getting successfully.");

            response = _mapper.Map<IEnumerable<ApplicationFormApplicantRequirement>>(applicationFormEntity!.ApplicationFormApplicantRequirements);
        }

        return response;
    }
}
