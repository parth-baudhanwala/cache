﻿using AutoMapper;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormApplicantRequirementsByOfficeIdQueryHandler : IRequestHandler<GetApplicationFormApplicantRequirementsByOfficeIdQuery, IEnumerable<ApplicationFormApplicantRequirement>>
{
    private readonly IDbContextFactory<DaoDbContext> _daoDbContextFactory;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormApplicantRequirementsByOfficeIdQueryHandler> _logger;

    public GetApplicationFormApplicantRequirementsByOfficeIdQueryHandler(IDbContextFactory<DaoDbContext> daoDbContextFactory,
                                                                         IMapper mapper,
                                                                         ILogger<GetApplicationFormApplicantRequirementsByOfficeIdQueryHandler> logger)
    {
        _daoDbContextFactory = daoDbContextFactory;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<ApplicationFormApplicantRequirement>> Handle(GetApplicationFormApplicantRequirementsByOfficeIdQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        IEnumerable<ApplicationFormApplicantRequirement> response = new List<ApplicationFormApplicantRequirement>();

        using (var context = await _daoDbContextFactory.CreateDbContextAsync(cancellationToken))
        {
            var applicationFormApplicantRequirementEntities = await context.ApplicationForms!.Include(x => x.ApplicationFormApplicantRequirements)
                                                                                             .Include(x => x.ApplicationFormOfficeMappings)
                                                                                             .Where(x => x.ApplicationFormOfficeMappings!.Any(x => x.OfficeId == request.OfficeId))
                                                                                             .ToArrayAsync(cancellationToken: cancellationToken);

            if (applicationFormApplicantRequirementEntities != null && applicationFormApplicantRequirementEntities.Any())
            {
                var applicationForm = applicationFormApplicantRequirementEntities.FirstOrDefault();
                if (applicationForm != null)
                {
                    response = _mapper.Map<IEnumerable<ApplicationFormApplicantRequirement>>(applicationForm!.ApplicationFormApplicantRequirements);
                }
            }
        }

        _logger.LogInformation("Applicant Requirements were getting successfully.");

        return response;
    }
}
