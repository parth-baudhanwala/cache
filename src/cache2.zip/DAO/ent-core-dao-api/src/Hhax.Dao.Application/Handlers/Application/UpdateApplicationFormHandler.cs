﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class UpdateApplicationFormHandler : IRequestHandler<UpdateApplicationFormCommand, BaseResponse>
{
    private readonly IMediator _mediator;
    private readonly IAuthenticationService _authenticationService;
    private readonly IGenericRepository<ApplicationFormEntity> _applicationFormRepository;
    private readonly IGenericRepository<ApplicationFormCustomFieldEntity> _customFieldRepository;
    private readonly IGenericRepository<ApplicationCustomFieldValueMappingEntity> _customFieldMappingRepository;
    private readonly IGenericRepository<ApplicationOnBoardingFormsEntity> _onboardingFormsRepository;
    private readonly IGenericRepository<ApplicationOnBoardingFormMappingEntity> _onboardingFormMappingRepository;
    private readonly IGenericRepository<ApplicantOnBoardingFormsEntity> _applicantOnBoardingFormsRepository;
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IMapper _mapper;
    private readonly ILogger<UpdateApplicationFormHandler> _logger;

    public UpdateApplicationFormHandler(IMediator mediator,
                                        IAuthenticationService authenticationService,
                                        IServiceProvider serviceProvider,
                                        IMapper mapper,
                                        ILogger<UpdateApplicationFormHandler> logger)
    {
        _mediator = mediator;
        _authenticationService = authenticationService;
        _applicationFormRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationFormEntity>>();
        _customFieldRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationFormCustomFieldEntity>>();
        _customFieldMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationCustomFieldValueMappingEntity>>();
        _onboardingFormsRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationOnBoardingFormsEntity>>();
        _onboardingFormMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationOnBoardingFormMappingEntity>>();
        _applicantOnBoardingFormsRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicantOnBoardingFormsEntity>>();
        _applicantRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicantEntity>>();
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<BaseResponse> Handle(UpdateApplicationFormCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");
        var entity = await _applicationFormRepository.GetByIdAsync(request.Id, hasNavigationProperties: true);

        if (entity == null)
        {
            var message = $"{nameof(ApplicationForm)} with Id: {request.Id} not found.";

            _logger.LogError("Application Form with Id: {applicationFormId} not found.", request.Id);
            throw new ApplicationFormNotFoundException(message);
        }

        entity.Name = request.Name;
        entity.ComplianceSetupId = request.ComplianceSetupId;
        entity.IsActive = request.IsActive;
        entity.Updated = DateTime.UtcNow;
        entity.UpdatedBy = _authenticationService.GetUserId();

        UpdateOfficeMappings(entity, request);
        UpdateApplicantRequirements(entity, request);
        await UpdateApplicantEligibilities(entity.Id, cancellationToken);
        await _applicationFormRepository.UpdateAsync(entity);

        if (request.ApplicationFormCustomFields != null && request.ApplicationFormCustomFields.Any())
        {
            await UpsertAplicationCustomFields(entity.Id, request.ApplicationFormCustomFields);
        }

        if (request.ApplicationOnBoardingForms != null && request.ApplicationOnBoardingForms.Any())
        {
            await UpsertApplicationOnboardingForms(entity.Id, request.OfficeIds, request.ApplicationOnBoardingForms);
        }

        var result = new BaseResponse { Id = entity.Id };
        _logger.LogInformation("Application Form with Id: {applicationFormId} was updated successfully.", request.Id);
        return result;
    }

    private async Task UpdateApplicantEligibilities(int applicationFormId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicationFormIdCommand(applicationFormId, false);
        await _mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }

    private void UpdateOfficeMappings(ApplicationFormEntity applicationForm, UpdateApplicationFormCommand request)
    {
        // Remove office setup mappings
        var applicationFormOfficeMappings = applicationForm.ApplicationFormOfficeMappings!.ToList();
        foreach (var mapping in applicationFormOfficeMappings)
        {
            if (!request.OfficeIds!.Any(x => x == mapping.OfficeId))
            {
                applicationForm.ApplicationFormOfficeMappings!.Remove(mapping);
            }
        }

        if (request.OfficeIds != null)
        {
            // Add office setup mappings
            applicationFormOfficeMappings = applicationForm.ApplicationFormOfficeMappings!.ToList();
            foreach (var officeId in request.OfficeIds!)
            {
                if (!applicationFormOfficeMappings.Exists(x => x.OfficeId == officeId))
                {
                    var officeSetupMapping = new ApplicationFormOfficeMappingEntity
                    {
                        OfficeId = officeId,
                        ApplicationFormId = applicationForm.Id,
                        Created = DateTime.UtcNow,
                        CreatedBy = _authenticationService.GetUserId(),
                        Updated = DateTime.UtcNow,
                        UpdatedBy = _authenticationService.GetUserId()
                    };
                    applicationForm.ApplicationFormOfficeMappings!.Add(officeSetupMapping);
                }
            }
        }
    }

    private void UpdateApplicantRequirements(ApplicationFormEntity applicationForm, UpdateApplicationFormCommand request)
    {
        // Remove applicant requirements
        var applicantRequirementIds = request.ApplicationFormApplicantRequirements!.Select(x => new { x.ApplicantFieldId, x.ApplicantSectionId }).ToArray();

        var applicantRequirements = applicationForm.ApplicationFormApplicantRequirements!.ToList();
        foreach (var applicantRequirement in applicantRequirements)
        {
            if (!Array.Exists(applicantRequirementIds, x => x.ApplicantFieldId == applicantRequirement.ApplicantFieldId && x.ApplicantSectionId == applicantRequirement.ApplicantSectionId))
            {
                applicationForm.ApplicationFormApplicantRequirements!.Remove(applicantRequirement);
            }
        }

        if (request.ApplicationFormApplicantRequirements != null)
        {
            // Add applicant requirements
            applicantRequirements = applicationForm.ApplicationFormApplicantRequirements!.ToList();
            foreach (var applicantRequirement in request.ApplicationFormApplicantRequirements!)
            {
                if (!applicantRequirements.Exists(x => x.ApplicantFieldId == applicantRequirement.ApplicantFieldId && x.ApplicantSectionId == applicantRequirement.ApplicantSectionId))
                {
                    var applicantRequirementEntity = _mapper.Map<ApplicationFormApplicantRequirementEntity>(applicantRequirement);

                    applicantRequirementEntity.Created = DateTime.UtcNow;
                    applicantRequirementEntity.CreatedBy = _authenticationService.GetUserId();
                    applicantRequirementEntity.Updated = DateTime.UtcNow;
                    applicantRequirementEntity.UpdatedBy = _authenticationService.GetUserId();

                    applicationForm.ApplicationFormApplicantRequirements!.Add(applicantRequirementEntity);
                }
                else
                {
                    var targetApplicantRequirementEntity = _mapper.Map<ApplicationFormApplicantRequirement>(applicantRequirement);

                    var applicantRequirementEntity = applicantRequirements.Find(x => x.ApplicantFieldId == applicantRequirement.ApplicantFieldId && x.ApplicantSectionId == applicantRequirement.ApplicantSectionId);
                    if (applicantRequirementEntity != null)
                    {
                        applicantRequirementEntity.IsShow = targetApplicantRequirementEntity.IsShow;
                        applicantRequirementEntity.IsRequire = targetApplicantRequirementEntity.IsRequire;
                        applicantRequirementEntity.ApplicantFieldId = targetApplicantRequirementEntity.ApplicantFieldId;
                        applicantRequirementEntity.ApplicantSectionId = targetApplicantRequirementEntity.ApplicantSectionId;
                        applicantRequirementEntity.Created = DateTime.UtcNow;
                        applicantRequirementEntity.CreatedBy = _authenticationService.GetUserId();
                        applicantRequirementEntity.Updated = DateTime.UtcNow;
                        applicantRequirementEntity.UpdatedBy = _authenticationService.GetUserId();
                    }
                }
            }
        }
    }

    private async Task UpsertAplicationCustomFields(int applicationFormId, IEnumerable<ApplicationFormCustomFieldInfo> applicationFormCustomFieldInfo)
    {
        var applicationFormCustomFields = _mapper.Map<IEnumerable<ApplicationFormCustomFieldEntity>>(applicationFormCustomFieldInfo);
        int userId = _authenticationService.GetUserId();
        int providerId = _authenticationService.GetAgencyId();

        var applicationFormCustomFieldEntities = (await _customFieldRepository.FindAsync(x => x.ApplicationFormId == applicationFormId)).ToList();
        var applicationCustomFieldValueMappingEntities = (await _customFieldMappingRepository.FindAsync(x => x.ApplicationFormId == applicationFormId)).ToList();

        foreach (var customField in applicationFormCustomFields)
        {
            var existCustomField = applicationFormCustomFieldEntities.Find(x => x.Id == customField.Id ||
                                                                            (x.ApplicationFormId == applicationFormId
                                                                               && x.FieldName == customField.FieldName
                                                                               && x.FieldTypeId == customField.FieldTypeId
                                                                               && x.ApplicantSectionId == customField.ApplicantSectionId
                                                                               && x.ProviderId == providerId));

            if (existCustomField != null)
            {
                existCustomField.ApplicantSectionId = customField.ApplicantSectionId;
                existCustomField.CanUploadFile = customField.CanUploadFile;
                existCustomField.FieldName = customField.FieldName;
                existCustomField.FieldTypeId = customField.FieldTypeId;
                existCustomField.IsActive = customField.IsActive;
                existCustomField.IsRequire = customField.IsRequire;
                existCustomField.IsShow = customField.IsShow;
                existCustomField.Updated = DateTime.UtcNow;
                existCustomField.UpdatedBy = userId;

                if (customField.ApplicationCustomFieldValueMappings != null && customField.ApplicationCustomFieldValueMappings.Any())
                {
                    foreach (var customFieldMapping in customField.ApplicationCustomFieldValueMappings)
                    {
                        var existCustomFieldMapping = applicationCustomFieldValueMappingEntities.Find(x => x.Id == customFieldMapping.Id ||
                                                                                (x.ApplicationFormId == applicationFormId
                                                                                   && x.FormCustomFieldId == existCustomField.Id
                                                                                   && x.Value == customFieldMapping.Value));

                        if (existCustomFieldMapping != null)
                        {
                            existCustomFieldMapping.IsActive = customFieldMapping.IsActive;
                            existCustomFieldMapping.Updated = DateTime.UtcNow;
                            existCustomFieldMapping.UpdatedBy = userId;
                            existCustomFieldMapping.Value = customFieldMapping.Value;
                        }
                        else
                        {
                            customFieldMapping.ApplicationFormId = applicationFormId;
                            customFieldMapping.Created = DateTime.UtcNow;
                            customFieldMapping.CreatedBy = userId;
                            customFieldMapping.FormCustomFieldId = existCustomField.Id;
                            customFieldMapping.Id = 0;
                            applicationCustomFieldValueMappingEntities.Add(customFieldMapping);
                        }
                    }
                }
            }
            else
            {
                customField.ApplicationFormId = applicationFormId;
                customField.Created = DateTime.UtcNow;
                customField.CreatedBy = userId;
                customField.Id = 0;
                customField.IsActive = true;
                customField.ProviderId = providerId;

                if (customField.ApplicationCustomFieldValueMappings != null && customField.ApplicationCustomFieldValueMappings.Any())
                {
                    foreach (var customFieldMapping in customField.ApplicationCustomFieldValueMappings)
                    {
                        customFieldMapping.ApplicationFormId = applicationFormId;
                        customFieldMapping.Created = DateTime.UtcNow;
                        customFieldMapping.CreatedBy = userId;
                        customFieldMapping.Id = 0;
                        customFieldMapping.IsActive = true;
                    }
                }

                applicationFormCustomFieldEntities.Add(customField);
            }
        }

        await _customFieldRepository.AttachRangeAsync(applicationFormCustomFieldEntities);
        await _customFieldMappingRepository.AttachRangeAsync(applicationCustomFieldValueMappingEntities);
    }

    private async Task UpsertApplicationOnboardingForms(int applicationFormId, IEnumerable<int>? officeIds, IEnumerable<ApplicationOnBoardingFormInfo> applicationOnBoardingForms)
    {
        int userId = _authenticationService.GetUserId();
        int providerId = _authenticationService.GetAgencyId();

        var formIds = applicationOnBoardingForms.Select(x => x.OnBoardingFormId).ToArray();

        ApplicationOnBoardingFormMappingEntity? onBoardingFormMapping;
        List<ApplicationOnBoardingFormMappingEntity> upsertOnBoardingFormMappingEntities = new();
        List<int> applicationOnBoardingFormIds = new();

        var onBoardingFormsEntities = (await _onboardingFormsRepository.FindAsync(x => formIds.Contains(x.OnBoardingFormId))).ToList();
        var onBoardingFormMappingEntities = _onboardingFormMappingRepository.GetQuery().Include(x => x.ApplicationOnBoardingForms).Where(x => x.ApplicationFormId == applicationFormId && x.ApplicationOnBoardingForms!.ProviderId == providerId).ToList();

        foreach (var form in applicationOnBoardingForms)
        {
            onBoardingFormMapping = onBoardingFormMappingEntities.Find(x => x.ApplicationOnBoardingForms!.OnBoardingFormId == form.OnBoardingFormId && x.ApplicationOnBoardingForms!.Version == form.Version);

            if (onBoardingFormMapping != null)
            {
                onBoardingFormMapping.IsShow = form.IsShow;
                onBoardingFormMapping.IsActive = form.IsActive;
                onBoardingFormMapping.UpdatedBy = userId;
                onBoardingFormMapping.Updated = DateTime.UtcNow;

                if (!onBoardingFormMapping.IsActive)
                {
                    applicationOnBoardingFormIds.Add(onBoardingFormMapping.ApplicationOnBoardingFormId);
                }
            }
            else
            {
                onBoardingFormMapping = new()
                {
                    Id = 0,
                    ApplicationOnBoardingFormId = onBoardingFormsEntities.Find(x => x.OnBoardingFormId == form.OnBoardingFormId && x.Version == form.Version)?.Id ?? 0,
                    ApplicationFormId = applicationFormId,
                    IsShow = form.IsShow,
                    IsActive = form.IsActive,
                    CreatedBy = userId,
                    Created = DateTime.UtcNow
                };

                if (onBoardingFormMapping.ApplicationOnBoardingFormId == 0)
                {
                    onBoardingFormMapping.ApplicationOnBoardingForms = new()
                    {
                        Id = 0,
                        OnBoardingFormId = form.OnBoardingFormId,
                        Name = form.Name,
                        Category = form.Category,
                        Description = form.Description,
                        LanguageId = form.LanguageId,
                        Version = form.Version,
                        IsActive = true,
                        ProviderId = providerId,
                        CreatedBy = userId,
                        Created = DateTime.UtcNow
                    };
                }
            }

            upsertOnBoardingFormMappingEntities.Add(onBoardingFormMapping);
        }

        if (officeIds != null && officeIds.Any() && applicationOnBoardingFormIds.Any())
        {
            await UpdateApplicantOnboardingForms(officeIds, applicationOnBoardingFormIds);
        }

        await _onboardingFormMappingRepository.AttachRangeAsync(upsertOnBoardingFormMappingEntities);
    }

    private async Task UpdateApplicantOnboardingForms(IEnumerable<int> officeIds, List<int> applicationOnBoardingFormIds)
    {
        int userId = _authenticationService.GetUserId();

        var applicantIds = _applicantRepository.GetQuery()
                           .Where(x => officeIds.Contains(x.OfficeId) &&
                                       x.ApplicationWorkflowStatus!.Name == DefaultWorkflowStatusesConstants.ApplicationInProgressName)
                           .Select(x => x.Id).ToArray();

        if (applicantIds.Length == 0) return;

        await _applicantOnBoardingFormsRepository.GetQuery()
              .Where(x => applicantIds.Contains(x.ApplicantId) && applicationOnBoardingFormIds.Contains(x.ApplicationOnBoardingFormId))
              .ExecuteUpdateAsync(x => x.SetProperty(y => y.FormResponseId, y => 0)
                                        .SetProperty(y => y.IsActive, y => false)
                                        .SetProperty(y => y.UpdatedBy, y => userId)
                                        .SetProperty(y => y.Updated, y => DateTime.UtcNow));
    }
}
