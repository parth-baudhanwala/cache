﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Abstracts.Requests;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;

namespace Hhax.Dao.Application.Handlers.Application;

public class SearchApplicantsQueryHandler : IRequestHandler<SearchApplicantsQuery, PaginatationResponse<Applicant>>
{
    private const string _sortKeyName = "applicantName";
    private const string _sortKeyLocation = "location";
    private const string _sortKeyUpdated = "updated";
    private const string _sortKeyCreated = "created";
    private const string _sortKeyHrName = "humanResourcePersonaName";

    private readonly IAuthenticationService _authenticationService;

    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusesRepository;
    private readonly IGenericRepository<ApplicationWorkflowStatusMappingEntity> _applicationWorkflowStatusMappingsRepository;
    private readonly IGenericRepository<HumanResourcePersonaEntity> _humanResourcePersonaRepository;
    private readonly IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> _applicantHumanResourcePersonaMappingRepository;
    private readonly IGenericRepository<HumanResourcePersonaEntity> _hrPersonaRepository;

    private readonly IMapper _mapper;
    private readonly ILogger<SearchApplicantsQueryHandler> _logger;

    public SearchApplicantsQueryHandler(IAuthenticationService authenticationService,
                                        IGenericRepository<ApplicantEntity> applicantRepository,
                                        IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusesRepository,
                                        IGenericRepository<ApplicationWorkflowStatusMappingEntity> applicationWorkflowStatusMappingsRepository,
                                        IGenericRepository<HumanResourcePersonaEntity> humanResourcePersonaRepository,
                                        IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> applicantHumanResourcePersonaMappingRepository,
                                        IGenericRepository<HumanResourcePersonaEntity> hrPersonaRepository,
                                        IMapper mapper,
                                        ILogger<SearchApplicantsQueryHandler> logger)
    {
        _applicantRepository = applicantRepository;
        _applicationWorkflowStatusesRepository = applicationWorkflowStatusesRepository;
        _applicationWorkflowStatusMappingsRepository = applicationWorkflowStatusMappingsRepository;
        _humanResourcePersonaRepository = humanResourcePersonaRepository;
        _applicantHumanResourcePersonaMappingRepository = applicantHumanResourcePersonaMappingRepository;
        _hrPersonaRepository = hrPersonaRepository;

        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<PaginatationResponse<Applicant>> Handle(SearchApplicantsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("SearchApplicantsAsync with 'Search' params: {applicantName}.", request.Request.Filters?.ApplicantName);

        var applicants = await FetchApplicants(request);

        applicants = await FilterByHRRepresentative(request.Request, applicants);

        var mappedApplicants = _mapper.Map<IEnumerable<Applicant>>(applicants);

        await PopulateHumanResourcePersonaAsync(mappedApplicants);

        var filteredApplicants = FilterAndSortApplicants(request, mappedApplicants);

        await PopulateNextWorkflowStatuses(filteredApplicants, cancellationToken);

        PopulateMissingRequirements(filteredApplicants);

        var response = new PaginatationResponse<Applicant>
        {
            Data = filteredApplicants,
            PageInfo = new PageInfo { TotalRecordCount = applicants.Count() }
        };

        _logger.LogInformation("Applicants was getting successfully.");

        return response;
    }

    private static IEnumerable<Applicant> FilterAndSortApplicants(SearchApplicantsQuery request, IEnumerable<Applicant> applicants)
    {
        if (request.Request.Sort is not null && request.Request.Sort.Item == _sortKeyHrName)
        {
            applicants = request.Request.Sort.Direction == SortDirection.Asc ? applicants.OrderBy(x => x.HumanResourcePersonaName).ToArray()
                                                                                   : applicants.OrderByDescending(x => x.HumanResourcePersonaName).ToArray();
        }

        applicants = applicants.Skip((request.Request.Page!.PageNumber - 1) * request.Request.Page.PageSize)
                                           .Take(request.Request.Page.PageSize)
                                           .ToArray();
        return applicants;
    }

    private async Task<IEnumerable<ApplicantEntity>> FetchApplicants(SearchApplicantsQuery request)
    {
        var sortParameter = BuildSortParameter(request.Request.Sort);
        var searchPredicates = BuildSearchPredicates(request.Request);

        return await _applicantRepository.FindAsync(sortParameter, searchPredicates, hasNavigationProperties: true);
    }

    private async Task PopulateNextWorkflowStatuses(IEnumerable<Applicant> applicants, CancellationToken cancellationToken)
    {
        var applicantsIds = applicants.Select(applicant => applicant.Id);

        var workflowStatuses = await (from applicant in _applicantRepository.GetQuery()
                                      from workflowStatusMappings in _applicationWorkflowStatusMappingsRepository.GetQuery()
                                      .Where(mapping => mapping.ApplicationWorkflowStatusId == applicant.ApplicationWorkflowStatusId)

                                      from workflowStatus in _applicationWorkflowStatusesRepository.GetQuery()
                                      .Where(status => status.Id == workflowStatusMappings.NextApplicationWorkflowStatusId)

                                      where applicantsIds.Contains(applicant.Id)

                                      select new
                                      {
                                          ApplicantId = applicant.Id,
                                          applicationWorkflowStatus = new ApplicationWorkflowStatus
                                          {
                                              ColorId = workflowStatus.ColorId,
                                              Name = workflowStatus.Name,
                                              Description = workflowStatus.Description,
                                              IsCustomizable = workflowStatus.IsCustomizable,
                                              IsLastPossible = workflowStatus.IsLastPossible,
                                              IsDefaultStatus = workflowStatus.IsDefaultStatus,
                                              Id = workflowStatus.Id,
                                              Updated = workflowStatus.Updated,
                                              UpdatedBy = workflowStatus.UpdatedBy,
                                              Created = workflowStatus.Created,
                                              CreatedBy = workflowStatus.CreatedBy
                                          }
                                      })
                                      .Distinct()
                                      .ToListAsync(cancellationToken);

        applicants.ToList().ForEach(applicant =>
        {
            if (applicant.ApplicationWorkflowStatus != null)
            {
                var nextApplicationWorkflowStatuses = workflowStatuses
                .Where(item => item.ApplicantId == applicant.Id && item.applicationWorkflowStatus is not null)
                .Select(item => item.applicationWorkflowStatus);

                applicant.ApplicationWorkflowStatus.NextApplicationWorkflowStatuses = nextApplicationWorkflowStatuses;
            }
        });
    }

    private async Task PopulateHumanResourcePersonaAsync(IEnumerable<Applicant> applicants)
    {
        var applicantIds = applicants.Select(x => x.Id).Distinct().ToArray();
        var mappings = await _applicantHumanResourcePersonaMappingRepository.FindAsync(x => applicantIds.Contains(x.ApplicantId));

        var hrIds = mappings.Select(x => x.HumanResourcePersonaId).Distinct().ToArray();
        var humanResourcePersonas = await _humanResourcePersonaRepository.FindAsync(x => hrIds.Contains(x.Id));

        foreach (var applicant in applicants)
        {
            if (mappings.Any() && humanResourcePersonas.Any())
            {
                var recent = mappings.OrderByDescending(x => x.Created).FirstOrDefault(x => x.ApplicantId == applicant.Id);
                if (recent != null)
                {
                    var hrPersona = humanResourcePersonas.FirstOrDefault(x => x.Id == recent.HumanResourcePersonaId);
                    if (hrPersona != null)
                    {
                        applicant.HumanResourcePersonaName = hrPersona.Name;
                        applicant.HumanResourcePersonaUserId = hrPersona.UserId;
                        applicant.IsMineHumanResourcePersona = hrPersona.UserId == _authenticationService.GetUserId();
                    }
                }
            }
        }
    }

    private static void PopulateMissingRequirements(IEnumerable<Applicant>? applicants)
    {
        if (applicants is null)
        {
            return;
        }

        foreach (var applicant in applicants)
        {
            applicant.MissingComplianceRequirements = new List<string>();

            for (int i = 1; i < (applicant.Id % 2 == 0 ? 6 : 4); i++)
            {
                applicant.MissingComplianceRequirements = applicant.MissingComplianceRequirements!.Append($"Missing req {i}");
            }
        }
    }

    private static SortRequest<ApplicantEntity> BuildSortParameter(Sort? sort) => sort?.Item switch
    {
        _sortKeyName => new(x => x.FirstName!, sort.Direction == SortDirection.Asc),
        _sortKeyLocation => new(x => x.City!, sort.Direction == SortDirection.Asc),
        _sortKeyUpdated => new(x => x.Updated!, sort.Direction == SortDirection.Asc),
        _sortKeyCreated => new(x => x.Created!, sort.Direction == SortDirection.Asc),
        _ => new(x => x.Created!, false),
    };

    private List<Expression<Func<ApplicantEntity, bool>>> BuildSearchPredicates(PaginationRequest<SearchApplicantsRequest> request)
    {
        List<Expression<Func<ApplicantEntity, bool>>> expressions = new();

        int agencyId = _authenticationService.GetAgencyId();

        expressions.Add(x => x.AgencyId == agencyId);

        SearchByApplicationDateFrom(request, expressions);

        SearchByApplicationDateTo(request, expressions);

        SearchByApplicantName(request, expressions);

        SearchByApplicantsLocation(request, expressions);

        SearchByLanguage(request, expressions);

        SearchByDisciplines(request, expressions);

        SearchByOffices(request, expressions);

        SearchByStatus(request, expressions);

        return expressions;
    }

    private static void SearchByApplicationDateFrom(PaginationRequest<SearchApplicantsRequest> request, List<Expression<Func<ApplicantEntity, bool>>> expressions)
    {
        if (!string.IsNullOrEmpty(request!.Filters?.ApplicationDateFrom))
        {
            var applicationDateFrom = DateTime.SpecifyKind(Convert.ToDateTime(request!.Filters?.ApplicationDateFrom), DateTimeKind.Utc);
            expressions.Add(x => x.Created!.Value.Date >= applicationDateFrom.Date);
        }
    }

    private static void SearchByApplicationDateTo(PaginationRequest<SearchApplicantsRequest> request, List<Expression<Func<ApplicantEntity, bool>>> expressions)
    {
        if (!string.IsNullOrEmpty(request!.Filters?.ApplicationDateTo))
        {
            var applicationDateTo = DateTime.SpecifyKind(Convert.ToDateTime(request!.Filters?.ApplicationDateTo), DateTimeKind.Utc);
            expressions.Add(x => x.Created!.Value.Date <= applicationDateTo.Date);
        }
    }

    private static void SearchByApplicantName(PaginationRequest<SearchApplicantsRequest> request, List<Expression<Func<ApplicantEntity, bool>>> expressions)
    {
        if (!string.IsNullOrWhiteSpace(request!.Filters?.ApplicantName))
        {
            expressions.Add(x => (!string.IsNullOrWhiteSpace(x.FirstName) && EF.Functions.ILike(x.FirstName, $"%{request.Filters.ApplicantName}%")) ||
                             (!string.IsNullOrWhiteSpace(x.LastName) && EF.Functions.ILike(x.LastName, $"%{request.Filters.ApplicantName}%")) ||
                             EF.Functions.ILike(x.FirstName + " " + x.LastName, $"{request.Filters.ApplicantName}%"));
        }
    }

    private static void SearchByApplicantsLocation(PaginationRequest<SearchApplicantsRequest> request, List<Expression<Func<ApplicantEntity, bool>>> expressions)
    {
        if (!string.IsNullOrWhiteSpace(request!.Filters?.Location))
        {
            expressions.Add(x => (!string.IsNullOrWhiteSpace(x.City) && EF.Functions.ILike(x.City, $"%{request.Filters.Location}%")) ||
                 (!string.IsNullOrWhiteSpace(x.State) && EF.Functions.ILike(x.State, $"%{request.Filters.Location}%")) ||
                 EF.Functions.ILike(x.City + ", " + x.State, $"{request.Filters.Location}%"));
        }
    }

    private static void SearchByLanguage(PaginationRequest<SearchApplicantsRequest> request, List<Expression<Func<ApplicantEntity, bool>>> expressions)
    {
        if (!string.IsNullOrWhiteSpace(request!.Filters?.Language))
        {
            IEnumerable<int> langs = from i in request!.Filters?.Language.Split(',') select int.Parse(i);
            expressions.Add(x =>
            x.PrimaryLanguageId.HasValue && langs.Contains(x.PrimaryLanguageId.Value) ||
            x.SecondaryLanguageId.HasValue && langs.Contains(x.SecondaryLanguageId.Value) ||
            x.ThirdLanguageId.HasValue && langs.Contains(x.ThirdLanguageId.Value) ||
            x.FourthLanguageId.HasValue && langs.Contains(x.FourthLanguageId.Value));
        }
    }

    private static void SearchByDisciplines(PaginationRequest<SearchApplicantsRequest> request, List<Expression<Func<ApplicantEntity, bool>>> expressions)
    {
        if (!string.IsNullOrWhiteSpace(request!.Filters?.Disciplines))
        {
            IEnumerable<int> disciplines = from i in request!.Filters?.Disciplines.Split(',') select int.Parse(i);
            expressions.Add(x => x.ApplicantEmploymentTypeMappings!.Any(x => disciplines.Contains(x.EmploymentTypeId)));
        }
    }

    private static void SearchByOffices(PaginationRequest<SearchApplicantsRequest> request, List<Expression<Func<ApplicantEntity, bool>>> expressions)
    {
        if (!string.IsNullOrWhiteSpace(request!.Filters?.Offices))
        {
            IEnumerable<int> offices = from i in request!.Filters?.Offices.Split(',') select int.Parse(i);
            expressions.Add(x => offices.Any(y => y == x.OfficeId));
        }
    }

    private static void SearchByStatus(PaginationRequest<SearchApplicantsRequest> request, List<Expression<Func<ApplicantEntity, bool>>> expressions)
    {
        if (request.Filters != null)
        {
            expressions.Add(x => x.IsActive == request.Filters.ShowActive);
        }
    }

    private async Task<IEnumerable<ApplicantEntity>> FilterByHRRepresentative(PaginationRequest<SearchApplicantsRequest> request, IEnumerable<ApplicantEntity> applicants)
    {
        var userId = _authenticationService.GetUserId();
        var hrPersona = await _hrPersonaRepository.FirstOrDefaultAsync(x => x.UserId == userId);

        var toMeOnly = request.Filters?.ToMeOnly ?? false;

        if (toMeOnly)
        {
            if (hrPersona == null)
            {
                return Enumerable.Empty<ApplicantEntity>();
            }

            return applicants.Where(x => x.ApplicantHumanResourcePersonaMappings?
                             .OrderByDescending(a => a.Created)
                             .FirstOrDefault()?.HumanResourcePersonaId == hrPersona.Id);
        }

        if (!string.IsNullOrEmpty(request.Filters?.AssignedHRRepresentatives))
        {
            IEnumerable<int> hrPersonas = request.Filters.AssignedHRRepresentatives.Split(',').Select(x => int.Parse(x));

            var lastAssignedHrs = applicants.Select(x => new
            {
                x.Id,
                LastAssignedHrId = x.ApplicantHumanResourcePersonaMappings?.OrderByDescending(h => h.Created).FirstOrDefault()?.HumanResourcePersonaId
            });

            var filteredApplicantsIds = lastAssignedHrs
                .Where(x => x.LastAssignedHrId.HasValue && hrPersonas.Contains(x.LastAssignedHrId.Value))
                .Select(x => x.Id);
            applicants = applicants.Where(x => filteredApplicantsIds.Contains(x.Id));
            return applicants;
        }
        return applicants;
    }
}
