﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Models.Requests;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Application;

public record AddApplicantHandler(IMediator Mediator,
                                  IGenericRepository<ApplicantEntity> ApplicantRepository,
                                  IMailVerificationService MailVerificationService,
                                  IGenericRepository<OfficeInfoEntity> OfficeInfoRepository,
                                  IAuthenticationService AuthenticationService,
                                  IIdentityClient IdentityClient,
                                  IOptions<IdentityConfiguration> IdentityConfigurationOptions,
                                  IMapper Mapper,
                                  ILogger<AddApplicantHandler> Logger)
    : IRequestHandler<AddApplicantCommand, BaseResponse>
{
    private IdentityConfiguration IdentityConfiguration { get => IdentityConfigurationOptions.Value; }

    public async Task<BaseResponse> Handle(AddApplicantCommand request, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        var office = await OfficeInfoRepository.FirstOrDefaultAsync(x => x.Id == request.OfficeId);
        var vendorId = office!.VendorId;

        request.IsVerified = !MailVerificationService.IsVerificationEnabled();
        request.IsActive = true;

        var getInitialApplicationWorkflowStatusQuery = new GetInitialApplicationWorkflowStatusQuery(vendorId);

        var initialApplicationWorkflowStatus = await Mediator.Send(getInitialApplicationWorkflowStatusQuery, cancellationToken);
        if (initialApplicationWorkflowStatus == null)
        {
            var message = $"Couldn't find single initial {typeof(ApplicationWorkflowStatus)}.";

            Logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        request.ApplicationWorkflowStatusId = initialApplicationWorkflowStatus.Id;

        var applicant = Mapper.Map<Applicant>(request);

        var entity = Mapper.Map<ApplicantEntity>(applicant);

        entity.AgencyId = vendorId;

        await Mediator.Send(new ValidateApplicantRequestDataCommand(entity.Id, request.OfficeId, entity, ApplicantEligibilitySection.Profile), cancellationToken);

        int userId = await AddUserIdentityAsync(request, vendorId);
        entity.UserId = userId;

        entity.CreatedBy = userId;
        entity.UpdatedBy = userId;

        await ApplicantRepository.AddAsync(entity);

        await UpdateApplicantEligibilities(entity.Id, cancellationToken);

        if (request.Signatures != null && request.Signatures.Any())
        {
            await Mediator.Send(new SaveApplicantSignatureCommand(entity.Id, request.Signatures), cancellationToken);
        }

        var response = new BaseResponse { Id = entity!.Id };

        if (!string.IsNullOrEmpty(entity.LoginEmail) && !string.IsNullOrEmpty(request.Domain))
        {
            await MailVerificationService.SendEmailAsync(entity!.Id, entity!.FirstName!, entity.LoginEmail, request.Domain);
        }

        Logger.LogInformation("Applicant with Id: {Id} was created.", response.Id);

        return response;
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }

    private async Task<int> AddUserIdentityAsync(AddApplicantCommand request, int vendorId)
    {
        const string authorizationHeaderName = "Authorization";

        var headers = new Dictionary<string, string>();

        var token = await IdentityClient.AccountsClient.GetTokenWithClientCredentialsAsync(
            IdentityConfiguration.ApplicantClientId, IdentityConfiguration.ApplicantClientSecret,
            IdentityConfiguration.ApplicantScopes);
        headers.Add(authorizationHeaderName, $"Bearer {token.AccessToken}");

        var email = request.LoginEmail!;
        var uniqueUserNameRequest = new UniqueUserNameRequest { UserName = email };
        var isUserNameUnique = await IdentityClient.ValidationClient.IsUserNameUniqueAsync(uniqueUserNameRequest, headers);

        if (!isUserNameUnique)
        {
            var message = $"The {nameof(email)} is not unique in HHA.";

            throw new ApplicantInvalidException(message);
        }

        var addApplicantRequest = new AddApplicantRequest
        {
            UserName = email,
            Email = email,
            Password = request.Password!,
            FirstName = request.FirstName!,
            LastName = request.LastName!,
            VendorId = vendorId
        };

        return await IdentityClient.ApplicantsClient.AddApplicantAsync(addApplicantRequest, headers);
    }
}
