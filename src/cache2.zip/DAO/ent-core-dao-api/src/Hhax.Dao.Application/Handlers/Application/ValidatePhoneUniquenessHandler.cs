﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;

namespace Hhax.Dao.Application.Handlers.Application;

public class ValidatePhoneUniquenessHandler : IRequestHandler<ValidatePhoneUniquenessQuery, ValidationResponse>
{
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly ILogger<ValidatePhoneUniquenessHandler> _logger;

    public ValidatePhoneUniquenessHandler(IGenericRepository<ApplicantEntity> applicantRepository,
                                          ILogger<ValidatePhoneUniquenessHandler> logger)
    {
        _applicantRepository = applicantRepository;
        _logger = logger;
    }

    public async Task<ValidationResponse> Handle(ValidatePhoneUniquenessQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("ValidatePhoneUniqueness with 'Phone' param: {phone}.", request.Phone);

        ValidationResponse response = new();

        if (string.IsNullOrWhiteSpace(request.Phone))
        {
            response.Message = "Phone number is empty. Please provide a phone to validate.";
        }
        else
        {
            var entity = await _applicantRepository.FirstOrDefaultAsync(GetConditions(request));
            response.IsSuccess = entity is null;
            response.Message = response.IsSuccess ? string.Empty : "Phone number is not unique. It should be unique.";
        }

        _logger.LogInformation("Phone number was validating successfully.");

        return response;
    }

    private static Expression<Func<ApplicantEntity, bool>> GetConditions(ValidatePhoneUniquenessQuery request)
    {
        if (request.Id.HasValue)
            return x => x.TextMessagePhone == request.Phone && x.Id != request.Id;

        return x => x.TextMessagePhone == request.Phone;
    }
}
