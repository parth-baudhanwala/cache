﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Globalization;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetCountriesQueryHandler : IRequestHandler<GetCountriesQuery, IEnumerable<Country>>
{
    private readonly ILookupService<Country, CountryEntity> _countriesLookupService;
    private readonly ILogger<GetCountriesQueryHandler> _logger;

    public GetCountriesQueryHandler(ILookupService<Country, CountryEntity> countriesLookupService,
                                    ILogger<GetCountriesQueryHandler> logger)
    {
        _countriesLookupService = countriesLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<Country>> Handle(GetCountriesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var respone = await _countriesLookupService.GetAllAsync();

        _logger.LogInformation("Handle were getting successfully.");

        return respone;
    }
}
