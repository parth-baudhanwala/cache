﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetMaritalStatusesQueryHandler : IRequestHandler<GetMaritalStatusesQuery, IEnumerable<MaritalStatus>>
{
    private readonly ILookupService<MaritalStatus, MaritalStatusEntity> _maritalStatusesLookupService;
    private readonly ILogger<GetMaritalStatusesQueryHandler> _logger;

    public GetMaritalStatusesQueryHandler(ILookupService<MaritalStatus, MaritalStatusEntity> maritalStatusesLookupService,
                                          ILogger<GetMaritalStatusesQueryHandler> logger)
    {
        _maritalStatusesLookupService = maritalStatusesLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<MaritalStatus>> Handle(GetMaritalStatusesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var response = await _maritalStatusesLookupService.GetAllAsync();
        
        _logger.LogInformation("Marital Statuses was getting successfully.");

        return response;
    }
}
