﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Interfaces.Clients;
using Hhax.Identity.Api.Client.Abstracts.Models.Requests;
using Hhax.Identity.Api.Client.Abstracts.Models.Responses;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application
{
    public class ResetPasswordApplicantHandler : IRequestHandler<ResetPasswordApplicantQuery, ResetPasswordApplicantResponse>
    {
        private const string _theSamePasswordIdentityError = "Old password and new password should not be the same";
        private const string _invalidPasswordIdentityError = "Password must be eight to 64 characters";

        private readonly IReadOnlyRepository<ApplicantEntity> _applicantRepository;
        private readonly IUsersClient _usersClient;
        private readonly IIdentityClient _identityClient;
        private readonly IResetPasswordService _resetPasswordService;
        private readonly ILogger<ResetPasswordApplicantHandler> _logger;

        public ResetPasswordApplicantHandler(IReadOnlyRepository<ApplicantEntity> applicantRepository, IUsersClient usersClient,
            IResetPasswordService resetPasswordService, IIdentityClient identityClient,
            ILogger<ResetPasswordApplicantHandler> logger) 
        { 
            _applicantRepository = applicantRepository;
            _usersClient = usersClient;
            _identityClient = identityClient;
            _resetPasswordService = resetPasswordService;
            _logger = logger;
        }

        public async Task<ResetPasswordApplicantResponse> Handle(ResetPasswordApplicantQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Reseting password for applicant with id: {request.ApplicantId}.");

            ResetPasswordApplicantResponse result = new();

            ApplicantEntity applicant = await _applicantRepository.GetByIdAsync(request.ApplicantId!.Value);

            if (applicant == null || applicant.UserId == null)
            {
                string message = $"Applicant with Id: '{request.ApplicantId}' not found.";

                _logger.LogError(message);
                throw new EntityNotFoundException(message);
            }
            else
            {
                bool response = await _resetPasswordService.VerifуKeyAsync(request.ApplicantId!.Value, request.Key!);

                if (response)
                {
                    result.IsValid = true;
                    int userId = applicant.UserId.Value;

                    ChangePasswordResponse passwordResponse = await ResetPasswordIdentity(userId, request.Password!);

                    if (passwordResponse.IsValid)
                    {
                        result.IsSuccessful = true;
                        await _resetPasswordService.InvalidateKeyAsync(applicant.Id, request.Key!);

                        _logger.LogInformation($"Reseting password for applicant with id: '{request.ApplicantId}' was successful.");
                    }
                    else
                    {
                        if (passwordResponse.ValidationMessage!.Contains(_theSamePasswordIdentityError))
                            result.IsTheSamePassword = true;
                        if (passwordResponse.ValidationMessage!.Contains(_invalidPasswordIdentityError))
                            result.IsPasswordInvalid = true;

                        _logger.LogError($"Setting new password for applicant with Id: '{applicant.Id}' was " +
                            $"unsuccessful and returned errors: '{passwordResponse.ValidationMessage}'");
                    }
                }
                else
                {
                    _logger.LogInformation($"Verifying applicant's (with Id: '{applicant.Id}') key for reseting password was unsuccessful - key not found");
                }      
            }

            return result;
        }

        private async Task<ChangePasswordResponse> ResetPasswordIdentity(int userId, string password)
        {
            const string authorizationHeaderName = "Authorization";

            var headers = new Dictionary<string, string>();

            var token = await _identityClient.AccountsClient.GetTokenWithClientCredentialsAsync();
            headers.Add(authorizationHeaderName, $"Bearer {token.AccessToken}");

            ChangePasswordResponse passwordResponse = await _usersClient.ChangePasswordAsync
                (new ChangePasswordRequest() { UserId = userId, NewPassword = password, ShouldCheckCurrentPassword = false }, headers, catchError: false);

            return passwordResponse;
        } 
    }
}
