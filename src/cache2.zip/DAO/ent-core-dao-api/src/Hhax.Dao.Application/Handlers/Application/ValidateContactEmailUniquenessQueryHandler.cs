﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;

namespace Hhax.Dao.Application.Handlers.Application;

public class ValidateContactEmailUniquenessQueryHandler : IRequestHandler<ValidateContactEmailUniquenessQuery, ValidationResponse>
{
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly ILogger<ValidateContactEmailUniquenessQueryHandler> _logger;

    public ValidateContactEmailUniquenessQueryHandler(IGenericRepository<ApplicantEntity> applicantRepository, 
                                                      ILogger<ValidateContactEmailUniquenessQueryHandler> logger)
    {
        _applicantRepository = applicantRepository;
        _logger = logger;
    }

    public async Task<ValidationResponse> Handle(ValidateContactEmailUniquenessQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("ValidateContactEmailUniqueness with 'Email' param: {email}, {id}.", request.Email, request.Id);

        ValidationResponse response = new();

        if (string.IsNullOrWhiteSpace(request.Email))
        {
            response.IsSuccess = false;
            response.Message = "Contact Email is empty. Please provide an email to validate.";
        }
        else
        {
            var entity = await _applicantRepository.FirstOrDefaultAsync(GetConditions(request));
            response.IsSuccess = entity == default(ApplicantEntity);
            response.Message = response.IsSuccess ? string.Empty : "Contact Email is not unique. It should be unique.";
        }

        _logger.LogInformation("Contact Email was validated successfully.");

        return response;
    }

    private static Expression<Func<ApplicantEntity, bool>> GetConditions(ValidateContactEmailUniquenessQuery request)
    {
        if (request.Id.HasValue)
            return x => x.ContactEmail == request.Email && x.Id != request.Id;

        return x => x.ContactEmail == request.Email;
    }
}
