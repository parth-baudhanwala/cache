﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormByUniqueIdQueryHandler : IRequestHandler<GetApplicationFormByUniqueIdQuery, ApplicationForm>
{
    private readonly IDbContextFactory<HhaDbContext> _hhaDbContextFactory;
    private readonly IDbContextFactory<DaoDbContext> _daoDbContextFactory;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormByIdQueryHandler> _logger;

    public GetApplicationFormByUniqueIdQueryHandler(IDbContextFactory<HhaDbContext> hhaDbContextFactory,
                                                    IDbContextFactory<DaoDbContext> daoDbContextFactory,
                                                    IMapper mapper,
                                                    ILogger<GetApplicationFormByIdQueryHandler> logger)
    {
        _daoDbContextFactory = daoDbContextFactory;
        _hhaDbContextFactory = hhaDbContextFactory;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicationForm> Handle(GetApplicationFormByUniqueIdQuery request, CancellationToken cancellationToken)
    {
        var officesNames = string.Empty;

        var applicationFormEntity = await GetApplicationFormAsync(request, cancellationToken);

        var officeIds = applicationFormEntity.ApplicationFormOfficeMappings!.Select(x => x.OfficeId).ToArray();

        IEnumerable<ApplicationFormOffice> applicationFormOffices;

        using (var context = await _hhaDbContextFactory.CreateDbContextAsync(cancellationToken))
        {
            var applicationFormOfficesRaw = await (from officeInfo in context.Offices
                                                   join complianceOfficeSetup in context.ComplianceSetupOffices! on officeInfo.Id equals complianceOfficeSetup.OfficeId
                                                   join complianceSetup in context.ComplianceSetups! on complianceOfficeSetup.ComplianceSetupId equals complianceSetup.Id
                                                   join officeLevel in context.OfficeLevels! on officeInfo.OfficeLevelId equals officeLevel.Id
                                                   where officeIds.Contains(officeInfo.Id) && 
                                                         complianceSetup.Status == ComplianceSetupStatuses.Active && 
                                                         officeInfo.Id == request.OfficeId
                                                   select new
                                                   {
                                                       officeInfo.Id,
                                                       officeInfo.OfficeName,
                                                       officeLevel.OfficeLevelName,
                                                       complianceSetupId = complianceOfficeSetup.Id,
                                                       complianceSetup.ComplianceSetupName,
                                                       complianceSetup.PublishVersion
                                                   }).ToArrayAsync(cancellationToken);

            //Select max publish version for each office
            applicationFormOffices = applicationFormOfficesRaw.GroupBy(x => x.Id, (_, x) => x.OrderByDescending(x => x.PublishVersion).First())
                                                              .Select(x => new ApplicationFormOffice(x.Id, x.OfficeName, x.OfficeLevelName, x.complianceSetupId, x.ComplianceSetupName))
                                                              .ToArray();

            officesNames = string.Join(", ", applicationFormOffices.Select(x => x.Name).ToArray());
        }

        var applicationFormApplicantRequirements = _mapper.Map<IEnumerable<ApplicationFormApplicantRequirement>>(applicationFormEntity.ApplicationFormApplicantRequirements);

        var result = new ApplicationForm(applicationFormEntity.Id, applicationFormEntity.Name, officeIds,
                                         officesNames, applicationFormEntity.UniqueUrlId, applicationFormEntity.IsActive,
                                         applicationFormEntity.ComplianceSetupId, applicationFormOffices, applicationFormApplicantRequirements, applicationFormEntity.Created, applicationFormEntity.CreatedBy,
                                         applicationFormEntity.Updated, applicationFormEntity.UpdatedBy);

        _logger.LogInformation("Application Form with Id: {applicationFormId} was getting successfully.", result.Id);

        return result;
    }

    private async Task<ApplicationFormEntity> GetApplicationFormAsync(GetApplicationFormByUniqueIdQuery request, CancellationToken cancellationToken)
    {
        ApplicationFormEntity? applicationFormEntity;

        using var context = await _daoDbContextFactory.CreateDbContextAsync(cancellationToken);
        applicationFormEntity = await context.ApplicationForms!.Include(x => x.ApplicationFormOfficeMappings)
                                                               .Include(x => x.ApplicationFormApplicantRequirements)
                                                               .FirstOrDefaultAsync(x => x.UniqueUrlId == request.UniqueUrlId &&
                                                                                         x.ApplicationFormOfficeMappings!.Any(x => x.OfficeId == request.OfficeId), cancellationToken: cancellationToken);
        if (applicationFormEntity == null)
        {
            var message = $"{nameof(applicationFormEntity)} with Id: {applicationFormEntity?.Id} not found.";

            _logger.LogError("Application Form with Id: {applicationFormId} not found.", applicationFormEntity?.Id);
            throw new ApplicationFormNotFoundException(message);
        }

        return applicationFormEntity;
    }
}
