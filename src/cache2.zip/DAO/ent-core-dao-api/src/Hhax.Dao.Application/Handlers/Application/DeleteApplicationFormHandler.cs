﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class DeleteApplicationFormHandler : IRequestHandler<DeleteApplicationFormCommand, Unit>
{
    private readonly IGenericRepository<ApplicationFormEntity> _applicationFormRepository;
    private readonly IGenericRepository<ApplicationFormApplicantRequirementEntity> _applicantRequirementRepository;
    private readonly IGenericRepository<ApplicationFormCustomFieldEntity> _customFieldRepository;
    private readonly IGenericRepository<ApplicationOnBoardingFormMappingEntity> _onBoardingFormMappingRepository;
    private readonly ILogger<DeleteApplicationFormHandler> _logger;
    private readonly IAuthenticationService _authenticationService;

    public DeleteApplicationFormHandler(IServiceProvider serviceProvider,
                                        ILogger<DeleteApplicationFormHandler> logger,
                                        IAuthenticationService authenticationService)
    {
        _applicationFormRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationFormEntity>>();
        _applicantRequirementRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationFormApplicantRequirementEntity>>();
        _customFieldRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationFormCustomFieldEntity>>();
        _onBoardingFormMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationOnBoardingFormMappingEntity>>();
        _authenticationService = authenticationService;
        _logger = logger;
    }

    public async Task<Unit> Handle(DeleteApplicationFormCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        int agencyId = _authenticationService.GetAgencyId();

        var applicantRequirementEntities = await _applicantRequirementRepository.FindAsync(x => x.ApplicationFormId == request.ApplicationFormId);

        if (applicantRequirementEntities.Any())
        {
            await _applicantRequirementRepository.RemoveRangeAsync(applicantRequirementEntities);
        }

        var applicationFormEntity = await _applicationFormRepository.FirstOrDefaultAsync(x => x.AgencyId == agencyId && x.Id == request.ApplicationFormId);

        if (applicationFormEntity == null)
        {
            var message = $"{nameof(ApplicationFormEntity)} with Id: {request.ApplicationFormId} not found.";

            _logger.LogError("Application Form with Id: {ApplicationFormId} not found.", request.ApplicationFormId);
            throw new ApplicantNotFoundException(message);
        }

        await _applicationFormRepository.RemoveAsync(applicationFormEntity);

        var customFieldEntities = _customFieldRepository.GetQuery()
                                    .Include(x => x.ApplicationCustomFieldValueMappings!
                                                    .Where(x => x.ApplicationFormId == request.ApplicationFormId))
                                    .Where(x => x.ApplicationFormId == request.ApplicationFormId).AsEnumerable();

        if (customFieldEntities.Any())
        {
            await _customFieldRepository.RemoveRangeAsync(customFieldEntities);
        }

        var onBoardingFormMappingEntities = await _onBoardingFormMappingRepository.FindAsync(x => x.ApplicationFormId == request.ApplicationFormId);

        if (onBoardingFormMappingEntities.Any())
        {
            await _onBoardingFormMappingRepository.RemoveRangeAsync(onBoardingFormMappingEntities);
        }

        _logger.LogInformation("Application Form with Id: {Id} was created.", request.ApplicationFormId);

        return Unit.Value;
    }
}
