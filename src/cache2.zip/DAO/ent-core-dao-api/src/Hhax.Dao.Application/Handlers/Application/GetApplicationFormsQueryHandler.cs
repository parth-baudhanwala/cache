﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Extensions;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Requests;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormsQueryHandler : IRequestHandler<GetApplicationFormsQuery, PaginatationResponse<ApplicationFormInfo>>
{
    private readonly IDbContextFactory<DaoDbContext> _daoDbContextFactory;
    private readonly IDbContextFactory<HhaDbContext> _hhaDbContextFactory;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormByIdQueryHandler> _logger;

    public GetApplicationFormsQueryHandler(IDbContextFactory<DaoDbContext> daoDbContextFactory,
                                           IDbContextFactory<HhaDbContext> hhaDbContextFactory,
                                           IMapper mapper,
                                           ILogger<GetApplicationFormByIdQueryHandler> logger,
                                           IAuthenticationService authenticationService)
    {
        _daoDbContextFactory = daoDbContextFactory;
        _hhaDbContextFactory = hhaDbContextFactory;

        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<PaginatationResponse<ApplicationFormInfo>> Handle(GetApplicationFormsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var offices = Enumerable.Empty<OfficeInfoEntity>();
        var applicationForms = new List<ApplicationFormInfo>();
        var applicationFormEntities = Enumerable.Empty<ApplicationFormEntity>();

        var officesNames = string.Empty;
        var officesIds = Enumerable.Empty<int>();

        var total = 0;

        const string nameSortKey = "name";
        const string officesSortKey = "offices";
        const string updatedSortKey = "updated";
        const string isActiveSortKey = "isActive";

        var filterSetupName = request?.Request?.Filters?.SetupName?.ToLower();
        var filterOffices = request?.Request?.Filters?.Offices.ParseInts();
        var filterIsActiveStatus = GetStatusFilter(request?.Request?.Filters?.StatusId);

        int agencyId = _authenticationService.GetAgencyId();

        var sortRequest = request.Request.Sort?.Item == nameSortKey ? new SortRequest<ApplicationFormEntity>(applicationForm => applicationForm.Name!, request.Request.Sort.Direction == Abstracts.Enums.SortDirection.Asc) :
                          request.Request.Sort?.Item == updatedSortKey ? new SortRequest<ApplicationFormEntity>(applicationForm => applicationForm.Updated!, request.Request.Sort.Direction == Abstracts.Enums.SortDirection.Asc) :
                          request.Request.Sort?.Item == isActiveSortKey ? new SortRequest<ApplicationFormEntity>(applicationForm => applicationForm.IsActive!, request.Request.Sort.Direction == Abstracts.Enums.SortDirection.Asc) :
                          new SortRequest<ApplicationFormEntity>(applicationForm => applicationForm.Name!, true);

        using (var context = await _daoDbContextFactory.CreateDbContextAsync(cancellationToken))
        {
            var query = context.ApplicationForms!.Include(applicationForm => applicationForm.ApplicationFormApplicantRequirements)
                                                 .Include(applicationForm => applicationForm.ApplicationFormOfficeMappings)
                                                 .Where(x => x.AgencyId == agencyId)
                                                 .Where(x => filterSetupName == null || x.Name!.ToLower().Contains(filterSetupName))
                                                 .Where(x => filterOffices == null || x.ApplicationFormOfficeMappings!.Any(y => filterOffices.Contains(y.OfficeId)))
                                                 .Where(x => filterIsActiveStatus == null || x.IsActive == filterIsActiveStatus)
                                                 .AsQueryable();

            applicationFormEntities = sortRequest.IsAscOrdering ? await query.OrderBy(sortRequest.SortPredicant)
                                                                             .ToArrayAsync(cancellationToken: cancellationToken)
                                                                : await query.OrderByDescending(sortRequest.SortPredicant)
                                                                             .ToArrayAsync(cancellationToken: cancellationToken);

            total = applicationFormEntities.Count();

            officesIds = applicationFormEntities.SelectMany(applicationForm => applicationForm.ApplicationFormOfficeMappings!)
                                                .Select(applicationFormOfficeMapping => applicationFormOfficeMapping.OfficeId)
                                                .ToArray();
        }

        using (var context = await _hhaDbContextFactory.CreateDbContextAsync(cancellationToken))
        {
            offices = context.Offices!.Where(office => officesIds!.Contains(office.Id))
                                      .ToArray();
        }

        foreach (var applicationFormEntity in applicationFormEntities)
        {
            var officeIds = applicationFormEntity.ApplicationFormOfficeMappings?.Select(applicationFormOfficeMapping => applicationFormOfficeMapping.OfficeId)
                                                                                .ToArray();

            var officeNames = string.Join(", ", offices.Where(office => officeIds!.Contains(office.Id))
                                                                                  .Select(office => office.OfficeName)
                                                                                  .ToArray());

            applicationForms.Add(new ApplicationFormInfo(applicationFormEntity.Id, applicationFormEntity.Name, applicationFormEntity.IsActive, officeNames, officeIds, applicationFormEntity.UniqueUrlId, 
                                                         applicationFormEntity.Created, applicationFormEntity.CreatedBy, applicationFormEntity.Updated, applicationFormEntity.UpdatedBy ));
        }

        if (request.Request.Sort?.Item == officesSortKey)
        {
            applicationForms = request.Request.Sort.Direction == Abstracts.Enums.SortDirection.Asc ? applicationForms.OrderBy(applicationForm => applicationForm.Offices)
                                                                                                                     .ToList()
                                                                                                   : applicationForms.OrderByDescending(applicationForm => applicationForm.Offices)
                                                                                                                     .ToList();
        }

        applicationForms = applicationForms.Skip((request.Request.Page!.PageNumber - 1) * request.Request.Page.PageSize)
                                           .Take(request.Request.Page.PageSize)
                                           .ToList();

        var response = new PaginatationResponse<ApplicationFormInfo>
        {
            Data = applicationForms,
            PageInfo = new PageInfo
            {
                TotalRecordCount = total
            }
        };

        _logger.LogInformation("Application Forms were getting successfully.");

        return response;
    }

    private bool? GetStatusFilter(int? statusId)
    {
        switch (statusId)
        {
            case (int)ActiveStatus.Active:
                return true;
            case (int)ActiveStatus.Inactive:
                return false;
            default:
            case (int)ActiveStatus.None:
                return null;
        }
    }
}
