﻿using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;
using Microsoft.Extensions.DependencyInjection;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetFormCustomFieldHasValueHandler : IRequestHandler<GetFormCustomFieldHasValueQuery, BaseResponse>
{
    private readonly IGenericRepository<ApplicantCustomFieldEntity> _applicantCustomFieldRepository;

    public GetFormCustomFieldHasValueHandler(IServiceProvider serviceProvider)
    {
        _applicantCustomFieldRepository = serviceProvider.GetService<IGenericRepository<ApplicantCustomFieldEntity>>()!;
    }

    public async Task<BaseResponse> Handle(GetFormCustomFieldHasValueQuery request, CancellationToken cancellationToken)
    {
        BaseResponse response = new() { Id = 0 };

        var result = await _applicantCustomFieldRepository.FirstOrDefaultAsync(x => x.FormCustomFieldId == request.FormCustomFieldId
                                                                                && (!string.IsNullOrEmpty(x.Value) || !string.IsNullOrEmpty(x.FileKey)));

        if (result == null)
        {
            return response;
        }

        response.Id = 1;
        return response;
    }
}
