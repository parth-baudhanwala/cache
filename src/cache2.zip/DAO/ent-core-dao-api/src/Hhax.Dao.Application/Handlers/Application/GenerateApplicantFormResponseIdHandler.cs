﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.FormBuilder;
using Hhax.Dao.Application.Abstracts.Requests.FormBuilder;
using Hhax.Dao.Application.Abstracts.Responses.FormBuilder;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GenerateApplicantFormResponseIdHandler : IRequestHandler<GenerateApplicantFormResponseIdCommand, FormDataResponse>
{
    private readonly ILogger<GenerateApplicantFormResponseIdHandler> _logger;
    private readonly IAuthenticationService _authenticationService;
    private readonly IFormBuilderApiClient _formBuilderApiClient;
    private readonly IGenericRepository<ApplicantOnBoardingFormsEntity> _applicantOnBoardingFormsRepository;
    private readonly IGenericRepository<ApplicationOnBoardingFormMappingEntity> _onboardingFormMappingRepository;
    private readonly IReadOnlyRepository<ApplicationFormOfficeMappingEntity> _applicationFormOfficeMappingRepository;

    public GenerateApplicantFormResponseIdHandler(ILogger<GenerateApplicantFormResponseIdHandler> logger,
                                              IServiceProvider serviceProvider)
    {
        _logger = logger;
        _authenticationService = serviceProvider.GetRequiredService<IAuthenticationService>();
        _formBuilderApiClient = serviceProvider.GetRequiredService<IFormBuilderApiClient>();
        _applicationFormOfficeMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationFormOfficeMappingEntity>>();
        _onboardingFormMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationOnBoardingFormMappingEntity>>();
        _applicantOnBoardingFormsRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicantOnBoardingFormsEntity>>();
    }


    public async Task<FormDataResponse> Handle(GenerateApplicantFormResponseIdCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        int userId = _authenticationService.GetUserId();

        int applicationFormId = (await _applicationFormOfficeMappingRepository.FirstOrDefaultAsync(x => x.OfficeId == command.OfficeId))?.ApplicationFormId ?? 0;

        if (applicationFormId == 0)
        {
            return new FormDataResponse();
        }

        var onBoardingFormMapping = await _onboardingFormMappingRepository.GetQuery().Include(x => x.ApplicationOnBoardingForms).FirstOrDefaultAsync(x => x.ApplicationFormId == applicationFormId && x.ApplicationOnBoardingForms!.OnBoardingFormId == command.OnBoardingFormId && x.IsActive && x.IsShow);

        if (onBoardingFormMapping == null)
        {
            return new FormDataResponse();
        }

        var request = new FormDataRequest(command.ApplicantId, command.OnBoardingFormId, userId);

        var response = await _formBuilderApiClient.GetFormResponseData(request).ConfigureAwait(false);

        if (response.FormResponseRawId == null)
            return response;

        ApplicantOnBoardingFormsEntity applicantOnBoardingFormsEntity = new()
        {
            ApplicantId = command.ApplicantId,
            FormResponseId = response.FormResponseRawId.Value,
            ApplicationOnBoardingFormId = onBoardingFormMapping.ApplicationOnBoardingFormId,
            IsActive = true,
            Created = DateTime.UtcNow,
            CreatedBy = userId
        };

        await _applicantOnBoardingFormsRepository.Upsert(applicantOnBoardingFormsEntity,
                            x => x.ApplicantId == command.ApplicantId &&
                            x.IsActive &&
                            x.ApplicationOnBoardingFormId == onBoardingFormMapping.ApplicationOnBoardingFormId,
                            upsertEntity =>
                            {
                                upsertEntity.FormResponseId = response.FormResponseRawId.Value;
                                upsertEntity.Updated = DateTime.UtcNow;
                                upsertEntity.UpdatedBy = userId;

                                return upsertEntity;
                            });

        _logger.LogInformation("Applicant Form Response ID was saved successfully for {ApplicantId}.", command.ApplicantId);

        return response;
    }
}
