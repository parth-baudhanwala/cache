﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormByIdQueryHandler : IRequestHandler<GetApplicationFormByIdQuery, ApplicationForm>
{
    private readonly IDbContextFactory<DaoDbContext> _daoDbContextFactory;
    private readonly IReadOnlyRepository<OfficeInfoEntity> _officeInfoReadOnlyRepositoryRepository;
    private readonly IReadOnlyRepository<OfficeLevelEntity> _officeLevelReadOnlyRepositoryRepository;
    private readonly IReadOnlyRepository<ComplianceSetupOfficeEntity> _complianceOfficeSetupReadOnlyRepositoryRepository;
    private readonly IReadOnlyRepository<ComplianceSetupEntity> _complianceSetupReadOnlyRepository;
    private readonly IReadOnlyRepository<ApplicantEntity> _applicantReadOnlyRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IMediatorService _mediatorService;
    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormByIdQueryHandler> _logger;

    public GetApplicationFormByIdQueryHandler(IDbContextFactory<DaoDbContext> daoDbContextFactory,
                                              IServiceProvider serviceProvider,
                                              IMediatorService mediatorService,
                                              IMapper mapper,
                                              ILogger<GetApplicationFormByIdQueryHandler> logger,
                                              IAuthenticationService authenticationService)
    {
        _daoDbContextFactory = daoDbContextFactory;

        _officeInfoReadOnlyRepositoryRepository = serviceProvider.GetService<IReadOnlyRepository<OfficeInfoEntity>>()!;
        _officeLevelReadOnlyRepositoryRepository = serviceProvider.GetService<IReadOnlyRepository<OfficeLevelEntity>>()!;
        _complianceOfficeSetupReadOnlyRepositoryRepository = serviceProvider.GetService<IReadOnlyRepository<ComplianceSetupOfficeEntity>>()!;
        _complianceSetupReadOnlyRepository = serviceProvider.GetService<IReadOnlyRepository<ComplianceSetupEntity>>()!;
        _applicantReadOnlyRepository = serviceProvider.GetService<IReadOnlyRepository<ApplicantEntity>>()!;

        _authenticationService = authenticationService;
        _mediatorService = mediatorService;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicationForm> Handle(GetApplicationFormByIdQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        string officesNames = string.Empty;
        var applicationFormCustomFieldsTask = GetApplicationFormCustomFields(request, cancellationToken);
        var applicationFormEntity = await GetApplicationFormAsync(request, cancellationToken);
        int[] officeIds = applicationFormEntity.ApplicationFormOfficeMappings!.Select(x => x.OfficeId).ToArray();

        var applicationFormOfficesRaw = await (from officeInfo in _officeInfoReadOnlyRepositoryRepository.GetQuery()
                                               join complianceOfficeSetup in _complianceOfficeSetupReadOnlyRepositoryRepository.GetQuery() on officeInfo.Id equals complianceOfficeSetup.OfficeId
                                               join complianceSetup in _complianceSetupReadOnlyRepository.GetQuery() on complianceOfficeSetup
                                                   .ComplianceSetupId equals complianceSetup.Id
                                               join officeLevel in _officeLevelReadOnlyRepositoryRepository.GetQuery() on officeInfo.OfficeLevelId
                                                   equals officeLevel.Id

                                               where officeIds.Contains(officeInfo.Id) &&
                                                     complianceSetup.Status == ComplianceSetupStatuses.Active &&
                                                     officeInfo.VendorId == _authenticationService.GetAgencyId()

                                               select new
                                               {
                                                   officeInfo.Id,
                                                   officeInfo.OfficeName,
                                                   officeLevel.OfficeLevelName,
                                                   complianceSetupId = complianceSetup.Id,
                                                   complianceSetup.ComplianceSetupName,
                                                   complianceSetup.PublishVersion
                                               }).ToListAsync(cancellationToken);

        //Select max publish version for each office
        List<ApplicationFormOffice> applicationFormOffices = applicationFormOfficesRaw.GroupBy(x => x.Id,
                (_, g) => g.OrderByDescending(e => e.PublishVersion).First())
            .Select(x => new ApplicationFormOffice(x.Id, x.OfficeName, x.OfficeLevelName, x.complianceSetupId, x.ComplianceSetupName)).ToList();

        await SetHaveApplicantInProgressForApplicationFormOffices(applicationFormOffices);

        officesNames = string.Join(", ", applicationFormOffices.Select(x => x.Name).ToArray());

        IEnumerable<ApplicationFormApplicantRequirement>? applicationFormApplicantRequirements = _mapper.Map<IEnumerable<ApplicationFormApplicantRequirement>>(applicationFormEntity.ApplicationFormApplicantRequirements);

        var result = new ApplicationForm(applicationFormEntity.Id, applicationFormEntity.Name, officeIds,
                                         officesNames, applicationFormEntity.UniqueUrlId, applicationFormEntity.IsActive, applicationFormEntity.ComplianceSetupId,
                                         applicationFormOffices, applicationFormApplicantRequirements, applicationFormEntity.Created, applicationFormEntity.CreatedBy,
                                         applicationFormEntity.Updated, applicationFormEntity.UpdatedBy)
        {
            ApplicationFormCustomFields = await applicationFormCustomFieldsTask,
            ApplicationOnBoardingForms = await _mediatorService.SendAsync<GetApplicationOnBoardingFormsQuery, IEnumerable<ApplicationOnBoardingFormInfo>>(new() { ApplicationFormId = request.ApplicationFormId })
        };

        _logger.LogInformation("Application Form with Id: {applicationFormId} was getting successfully.", request.ApplicationFormId);

        return result;
    }

    private async Task<ApplicationFormEntity> GetApplicationFormAsync(GetApplicationFormByIdQuery request, CancellationToken cancellationToken)
    {
        ApplicationFormEntity? applicationFormEntity;

        int agencyId = _authenticationService.GetAgencyId();

        using var context = await _daoDbContextFactory.CreateDbContextAsync(cancellationToken);
        applicationFormEntity = await context.ApplicationForms!.Include(x => x.ApplicationFormOfficeMappings)
                                                               .Include(x => x.ApplicationFormApplicantRequirements)
                                                               .FirstOrDefaultAsync(x => x.AgencyId == agencyId && x.Id == request.ApplicationFormId, cancellationToken: cancellationToken);
        if (applicationFormEntity == null)
        {
            var message = $"{nameof(applicationFormEntity)} with Id: {request.ApplicationFormId} not found.";

            _logger.LogError("Application Form with Id: {applicationFormId} not found.", request.ApplicationFormId);
            throw new ApplicationFormNotFoundException(message);
        }

        return applicationFormEntity;
    }

    private async Task<List<ApplicationFormCustomFieldInfo>> GetApplicationFormCustomFields(GetApplicationFormByIdQuery request, CancellationToken cancellationToken)
    {
        List<ApplicationFormCustomFieldEntity> customFields;
        int providerId = _authenticationService.GetAgencyId();

        var context = await _daoDbContextFactory.CreateDbContextAsync(cancellationToken);
        customFields = context.ApplicationFormCustomFields!.AsNoTracking()
                                .Where(x => x.ApplicationFormId == request.ApplicationFormId
                                            && x.ProviderId == providerId
                                            && x.IsActive)
                                .Select(x => new ApplicationFormCustomFieldEntity
                                {
                                    ApplicantSectionId = x.ApplicantSectionId,
                                    ApplicationCustomFieldValueMappings = x.ApplicationCustomFieldValueMappings!.Where(x => x.IsActive).OrderBy(c => c.Id).ToList(),
                                    CanUploadFile = x.CanUploadFile,
                                    FieldName = x.FieldName,
                                    FieldTypeId = x.FieldTypeId,
                                    Id = x.Id,
                                    IsActive = x.IsActive,
                                    IsRequire = x.IsRequire,
                                    IsShow = x.IsShow,
                                }).ToList();

        var applicationFormCustomFields = _mapper.Map<List<ApplicationFormCustomFieldInfo>>(customFields);

        return applicationFormCustomFields;
    }

    private async Task SetHaveApplicantInProgressForApplicationFormOffices(List<ApplicationFormOffice> applicationFormOffices)
    {
        foreach (var applicationFormOffice in applicationFormOffices)
        {
            applicationFormOffice.HaveApplicantInProgress = (await _applicantReadOnlyRepository
                .FindAsync(applicant => applicant.ApplicationWorkflowStatus != null
                                        && applicant.ApplicationWorkflowStatus.IsLastPossible != true
                                        && applicant.OfficeId == applicationFormOffice.OfficeId
                                        && applicant.AgencyId == _authenticationService.GetAgencyId())).Any();
        }
    }
}
