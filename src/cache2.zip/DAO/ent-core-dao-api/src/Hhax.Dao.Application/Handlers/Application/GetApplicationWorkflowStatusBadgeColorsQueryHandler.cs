﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationWorkflowStatusBadgeColorsQueryHandler : IRequestHandler<GetApplicationWorkflowStatusBadgeColorsQuery, IEnumerable<ApplicationWorkflowStatusBadgeColor>>
{
    private readonly ILookupService<ApplicationWorkflowStatusBadgeColor, ApplicationWorkflowStatusBadgeColorEntity> _applicationWorkflowStatusBadgeColorsLookupService;
    private readonly ILogger<GetApplicationWorkflowStatusBadgeColorsQueryHandler> _logger;

    public GetApplicationWorkflowStatusBadgeColorsQueryHandler(ILookupService<ApplicationWorkflowStatusBadgeColor, ApplicationWorkflowStatusBadgeColorEntity> applicationWorkflowStatusBadgeColorsLookupService,
                                                               ILogger<GetApplicationWorkflowStatusBadgeColorsQueryHandler> logger)
    {
        _applicationWorkflowStatusBadgeColorsLookupService = applicationWorkflowStatusBadgeColorsLookupService;
        _logger = logger;
    }   

    public async Task<IEnumerable<ApplicationWorkflowStatusBadgeColor>> Handle(GetApplicationWorkflowStatusBadgeColorsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var response = await _applicationWorkflowStatusBadgeColorsLookupService.GetAllAsync();

        _logger.LogInformation("Application Workflow Status Badge Colors were getting successfully.");

        return response;
    }
}
