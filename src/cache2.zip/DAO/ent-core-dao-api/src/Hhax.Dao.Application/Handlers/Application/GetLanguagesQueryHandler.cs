﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetLanguagesQueryHandler : IRequestHandler<GetLanguagesQuery, IEnumerable<Language>>
{
    private readonly ILookupService<Language, LanguageEntity> _languagesLookupService;
    private readonly ILogger<GetLanguagesQueryHandler> _logger;

    public GetLanguagesQueryHandler(ILookupService<Language, LanguageEntity> languagesLookupService,
                                    ILogger<GetLanguagesQueryHandler> logger)
    {
        _languagesLookupService = languagesLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<Language>> Handle(GetLanguagesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var response = await _languagesLookupService.GetAllAsync();

        _logger.LogInformation("Handle was getting successfully.");

        return response;
    }
}
