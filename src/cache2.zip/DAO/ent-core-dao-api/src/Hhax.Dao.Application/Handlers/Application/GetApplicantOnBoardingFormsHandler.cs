﻿using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantOnBoardingFormsHandler : IRequestHandler<GetApplicantOnBoardingFormsQuery, IEnumerable<ApplicantOnBoardingFormInfo>>
{
    private readonly ILogger<GetApplicantOnBoardingFormsHandler> _logger;
    private readonly IReadOnlyRepository<ApplicationOnBoardingFormMappingEntity> _applicationOnBoardingFormMappingRepository;
    private readonly IReadOnlyRepository<ApplicationFormOfficeMappingEntity> _applicationFormOfficeMappingRepository;
    private readonly IReadOnlyRepository<ApplicantOnBoardingFormsEntity> _applicantOnBoardingFormsRepository;
    private readonly IReadOnlyRepository<ApplicantEntity> _applicantRepository;


    public GetApplicantOnBoardingFormsHandler(ILogger<GetApplicantOnBoardingFormsHandler> logger,
                                              IServiceProvider serviceProvider)
    {
        _logger = logger;
        _applicationOnBoardingFormMappingRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<ApplicationOnBoardingFormMappingEntity>>();
        _applicationFormOfficeMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationFormOfficeMappingEntity>>();
        _applicantOnBoardingFormsRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicantOnBoardingFormsEntity>>();
        _applicantRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicantEntity>>();
    }

    public async Task<IEnumerable<ApplicantOnBoardingFormInfo>> Handle(GetApplicantOnBoardingFormsQuery query, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        if (query.ApplicantId <= 0 || query.OfficeId <= 0)
        {
            return Enumerable.Empty<ApplicantOnBoardingFormInfo>();
        }

        int applicantLanguageId = (await _applicantRepository.FirstOrDefaultAsync(x => x.Id == query.ApplicantId))?.ApplicationLanguageId ?? 1;

        int applicationFormId = (await _applicationFormOfficeMappingRepository.FirstOrDefaultAsync(x => x.OfficeId == query.OfficeId))?.ApplicationFormId ?? 0;

        if (applicationFormId <= 0)
        {
            return Enumerable.Empty<ApplicantOnBoardingFormInfo>();
        }

        var onBoardingForms = await _applicationOnBoardingFormMappingRepository.GetQuery().AsNoTracking()
                                        .Include(x => x.ApplicationOnBoardingForms)
                                        .Where(x => x.ApplicationFormId == applicationFormId
                                                    && x.ApplicationOnBoardingForms!.LanguageId == applicantLanguageId
                                                    && x.IsShow
                                                    && x.IsActive)
                                        .GroupJoin(_applicantOnBoardingFormsRepository.GetQuery().AsNoTracking()
                                                   .Where(form => form.ApplicantId == query.ApplicantId),
                                                    mapping => mapping.ApplicationOnBoardingFormId,
                                                    form => form.ApplicationOnBoardingFormId,
                                                    (mapping, forms) => new { mapping, forms })
                                        .SelectMany(x => x.forms.DefaultIfEmpty(),
                                                    (x, form) => new ApplicantOnBoardingFormInfo
                                                    {
                                                        Id = x.mapping.Id,
                                                        OnBoardingFormId = x.mapping.ApplicationOnBoardingForms!.OnBoardingFormId,
                                                        Name = x.mapping.ApplicationOnBoardingForms!.Name,
                                                        IsActive = x.mapping.ApplicationOnBoardingForms!.IsActive,
                                                        FormResponseId = form != null ? form.FormResponseId : 0,
                                                        ApplicantId = form != null ? form.ApplicantId : 0
                                                    }).ToListAsync(cancellationToken: cancellationToken);

        _logger.LogInformation("Application onboarding forms were retrieved successfully for Applicant with application form id {ApplicationFormId} and applicant id {ApplicantId}", applicationFormId, query.ApplicantId);

        return onBoardingForms;
    }
}
