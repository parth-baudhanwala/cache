﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class InitializeApplicationWorkflowStatusesHandler : IRequestHandler<InitializeApplicationWorkflowStatusesCommand, Unit>
{
    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly ILogger<AddApplicationWorkflowStatusHandler> _logger;
    
    public InitializeApplicationWorkflowStatusesHandler(IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusRepository,
                                               IAuthenticationService authenticationService,
                                               ILogger<AddApplicationWorkflowStatusHandler> logger)
    {
        _authenticationService = authenticationService;
        _applicationWorkflowStatusRepository = applicationWorkflowStatusRepository;
        _logger = logger;
    }

    public async Task<Unit> Handle(InitializeApplicationWorkflowStatusesCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var agencyId = _authenticationService.GetAgencyId();

        var applicationInProgressStatus = await _applicationWorkflowStatusRepository.FirstOrDefaultAsync(
            x => x.AgencyId == agencyId &&
            x.IsDefaultStatus == true &&
            x.IsCustomizable == DefaultWorkflowStatusesConstants.ApplicationInProgressIsCustomizable &&
            x.Name == DefaultWorkflowStatusesConstants.ApplicationInProgressName);

        if (applicationInProgressStatus == null)
        {
            await _applicationWorkflowStatusRepository.AddAsync(new ApplicationWorkflowStatusEntity()
            {
                AgencyId = agencyId,
                IsDefaultStatus = true,
                Name = DefaultWorkflowStatusesConstants.ApplicationInProgressName,
                ColorId = DefaultWorkflowStatusesConstants.ApplicationInProgressColorId,
                Priority = DefaultWorkflowStatusesConstants.ApplicationInProgressPriority,
                IsCustomizable = DefaultWorkflowStatusesConstants.ApplicationInProgressIsCustomizable,
                IsLastPossible = DefaultWorkflowStatusesConstants.ApplicationInProgressIsLastPossible,
                Created = DateTime.UtcNow
            });
        }

        var applicationSubmittedStatus = await _applicationWorkflowStatusRepository.FirstOrDefaultAsync(
            x => x.AgencyId == agencyId &&
            x.IsDefaultStatus == true &&
            x.IsCustomizable == DefaultWorkflowStatusesConstants.ApplicationSubmittedIsCustomizable && 
            x.Name == DefaultWorkflowStatusesConstants.ApplicationSubmittedName);

        if (applicationSubmittedStatus == null)
        {
            await _applicationWorkflowStatusRepository.AddAsync(new ApplicationWorkflowStatusEntity()
            {
                AgencyId = agencyId,
                IsDefaultStatus = true,
                Name = DefaultWorkflowStatusesConstants.ApplicationSubmittedName,
                ColorId = DefaultWorkflowStatusesConstants.ApplicationSubmittedColorId,
                Priority = DefaultWorkflowStatusesConstants.ApplicationSubmittedPriority,
                IsCustomizable = DefaultWorkflowStatusesConstants.ApplicationSubmittedIsCustomizable,
                IsLastPossible = DefaultWorkflowStatusesConstants.ApplicationSubmittedIsLastPossible,
                Created = DateTime.UtcNow
            });
        }
        else if (applicationSubmittedStatus.Priority != DefaultWorkflowStatusesConstants.ApplicationSubmittedPriority)
        {
            applicationSubmittedStatus.Priority = DefaultWorkflowStatusesConstants.ApplicationSubmittedPriority;
            applicationSubmittedStatus.Updated = DateTime.UtcNow;
            applicationSubmittedStatus.UpdatedBy = agencyId;
            await _applicationWorkflowStatusRepository.UpdateAsync(applicationSubmittedStatus);
        }

        var convertedToCaregiverStatus = await _applicationWorkflowStatusRepository.FirstOrDefaultAsync(
            x => x.AgencyId == agencyId &&
            x.IsDefaultStatus == true &&
            x.IsCustomizable == DefaultWorkflowStatusesConstants.ConvertedToCaregiverIsCustomizable &&
            x.Name == DefaultWorkflowStatusesConstants.ConvertedToCaregiverName);

        if (convertedToCaregiverStatus == null)
        {
            await _applicationWorkflowStatusRepository.AddAsync(new ApplicationWorkflowStatusEntity()
            {
                AgencyId = agencyId,
                IsDefaultStatus = true,
                Name = DefaultWorkflowStatusesConstants.ConvertedToCaregiverName,
                ColorId = DefaultWorkflowStatusesConstants.ConvertedToCaregiverColorId,
                Priority = DefaultWorkflowStatusesConstants.ConvertedToCaregiverPriority,
                IsCustomizable = DefaultWorkflowStatusesConstants.ConvertedToCaregiverIsCustomizable,
                IsLastPossible = DefaultWorkflowStatusesConstants.ConvertedToCaregiverIsLastPossible,
                Created = DateTime.UtcNow
            });
        }
        else if (convertedToCaregiverStatus.Priority != DefaultWorkflowStatusesConstants.ConvertedToCaregiverPriority)
        {
            convertedToCaregiverStatus.Priority = DefaultWorkflowStatusesConstants.ConvertedToCaregiverPriority;
            convertedToCaregiverStatus.Updated = DateTime.UtcNow;
            convertedToCaregiverStatus.UpdatedBy = agencyId;
            await _applicationWorkflowStatusRepository.UpdateAsync(convertedToCaregiverStatus);
        }

        _logger.LogInformation("Default ApplicationWorkflowStatuses were added successfully.");

        return Unit.Value;
    }
}
