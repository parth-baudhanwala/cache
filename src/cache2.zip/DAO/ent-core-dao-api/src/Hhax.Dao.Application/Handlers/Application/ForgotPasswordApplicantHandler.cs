﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application
{
    public class ForgotPasswordApplicantHandler : IRequestHandler<ForgotPasswordApplicantQuery, ForgotPasswordApplicantResponse>
    {
        private readonly IResetPasswordService _resetPasswordService;
        private readonly IReadOnlyRepository<ApplicantEntity> _applicantEntityRepository;
        private readonly IReadOnlyRepository<UserInfoEntity> _userInfoEntityRepository;
        private readonly IHhaStoredProceduresManager _hhaStoredProceduresManager;
        private readonly ILogger<ForgotPasswordApplicantHandler> _logger;

        public ForgotPasswordApplicantHandler(IResetPasswordService resetPasswordService,
            IReadOnlyRepository<ApplicantEntity> applicantEntityRepository,
            IReadOnlyRepository<UserInfoEntity> userInfoEntityRepository,
            IHhaStoredProceduresManager hhaStoredProceduresManager, 
            ILogger<ForgotPasswordApplicantHandler> logger)
        {
            _resetPasswordService = resetPasswordService;
            _applicantEntityRepository = applicantEntityRepository;
            _userInfoEntityRepository = userInfoEntityRepository;
            _hhaStoredProceduresManager = hhaStoredProceduresManager;
            _logger = logger;
        }

        public async Task<ForgotPasswordApplicantResponse> Handle(ForgotPasswordApplicantQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Started Forgot Password flow for applicant with email: '{request.Email}'.");

            ApplicantEntity? applicantDao = await _applicantEntityRepository.FirstOrDefaultAsync(applicant => applicant.LoginEmail == request.Email);
            UserInfoEntity? applicantHha = await _userInfoEntityRepository.FirstOrDefaultAsync(user => user.UserName == request.Email);

            ForgotPasswordApplicantResponse result = new();

            if (applicantDao != null && applicantHha != null)
            {
                int maxLoginAttempts = await _hhaStoredProceduresManager.GetMaxLoginAttempts();
                if (applicantHha.LoginAttempt == maxLoginAttempts)
                    result.IsLocked = true;
                if (!applicantHha.IsActive)
                    result.IsInactive = true;

                if (!result.IsInactive && !result.IsLocked)
                {
                    _logger.LogInformation($"Applicant with email: '{request.Email}' was found, unlocked and active. " +
                        $"Sending Forgot Password to the applicant.");

                    await _resetPasswordService.SendEmailAsync(applicantDao.Id, applicantDao.FirstName!, applicantDao.LoginEmail!, request.Domain!);

                    _logger.LogInformation($"Forgot Password email was sent to applicant with email: '{request.Email}'.");
                }
                else
                    _logger.LogInformation($"The Forgot Password email was not sent to applicant with email: '{request.Email}', " +
                        $"because applicant was locked or inactive. Locked: '{result.IsLocked}'. Inactive: '{result.IsInactive}'.");
            }
            else
                _logger.LogInformation($"Applicant not found with email: '{request.Email}'.");

            return result;
        }
    }
}
