﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationFormMedicalsApplicantSectionQueryHandler : IRequestHandler<GetApplicationFormMedicalsApplicantSectionQuery, ApplicationFormApplicantSection>
{
    private readonly IDbContextFactory<HhaDbContext> _hhaDbContextFactory;
    private readonly IGenericRepository<ApplicationFormApplicantSectionEntity> _applicationFormApplicantSectionRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicationFormMedicalsApplicantSectionQueryHandler> _logger;

    public GetApplicationFormMedicalsApplicantSectionQueryHandler(IDbContextFactory<HhaDbContext> hhaDbContextFactory,
                                                                  IGenericRepository<ApplicationFormApplicantSectionEntity> applicationFormApplicantSectionRepository,
                                                                  IAuthenticationService authenticationService,
                                                                  IMapper mapper,
                                                                  ILogger<GetApplicationFormMedicalsApplicantSectionQueryHandler> logger)
    {
        _hhaDbContextFactory = hhaDbContextFactory;

        _applicationFormApplicantSectionRepository = applicationFormApplicantSectionRepository;
        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicationFormApplicantSection> Handle(GetApplicationFormMedicalsApplicantSectionQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var userId = _authenticationService.GetUserId();

        ApplicationFormApplicantSection response;

        var medicalsSectionEntity = await _applicationFormApplicantSectionRepository.FirstOrDefaultAsync(applicantSection => applicantSection.Id == (int)ApplicationFormApplicantSections.MedicalsAndOtherDocuments);
        if (medicalsSectionEntity == null)
        {
            const string message = "Medicals & Other Documents section not found.";

            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        medicalsSectionEntity.CreatedBy = userId;
        medicalsSectionEntity.UpdatedBy = userId;

        response = _mapper.Map<ApplicationFormApplicantSection>(medicalsSectionEntity);

        await EnrichApplicationFormApplicantFieldsAsync(response, request, cancellationToken);

        _logger.LogInformation("Application Form Compliance Applicant Section with Id: {Id} was getting successfully.", response.Id);

        return response;
    }

    private async Task EnrichApplicationFormApplicantFieldsAsync(ApplicationFormApplicantSection applicationFormApplicantSection, GetApplicationFormMedicalsApplicantSectionQuery request, CancellationToken cancellationToken)
    {
        var agencyId = _authenticationService.GetAgencyId();
        var userId = _authenticationService.GetUserId();

        using var context = await _hhaDbContextFactory.CreateDbContextAsync(cancellationToken);
        var complianceSetupEntities = await (from complianceSetup in context.ComplianceSetups!

                                             join complianceSetupOffice in context.ComplianceSetupOffices! on complianceSetup.Id equals complianceSetupOffice.ComplianceSetupId

                                             where request.OfficeIds.Contains(complianceSetupOffice.OfficeId) &&
                                                   complianceSetup.Status == ComplianceSetupStatuses.Active &&
                                                   complianceSetup.ProviderId == agencyId

                                             select complianceSetup).ToArrayAsync(cancellationToken: cancellationToken);

        if (complianceSetupEntities.Any())
        {
            var maxPublishVersion = complianceSetupEntities.Max(complianceSetupEntity => complianceSetupEntity.PublishVersion);

            var complianceSetupEntity = complianceSetupEntities.FirstOrDefault(complianceSetupEntity => complianceSetupEntity.PublishVersion == maxPublishVersion);

            var complianceExpItems = await context.ComplianceExpItems!.Where(complianceExpItem => complianceExpItem.ComplianceSetupId == complianceSetupEntity!.Id &&
                                                                                                  complianceExpItem.Status == ComplianceExpItemStatuses.Active &&
                                                                                                  complianceExpItem.ProviderId == agencyId).ToArrayAsync(cancellationToken: cancellationToken);
            applicationFormApplicantSection.ComplianceSetupName = complianceSetupEntity?.ComplianceSetupName;

            applicationFormApplicantSection.ApplicationFormApplicantFields = complianceExpItems.Select(complianceExpItem => new ApplicationFormApplicantField
            {
                Id = complianceExpItem.ExpirationItemId ?? throw new NullValueException("Compliance Expiration Item Id should not be null."),
                Name = $"{complianceExpItem.ExpirationItemType}: {complianceExpItem.ExpirationItem}",
                ApplicantSectionId = (int)ApplicationFormApplicantSections.MedicalsAndOtherDocuments,
                DefaultIsRequire = false,
                DefaultIsShow = false,
                IsActive = complianceExpItem.Status.HasValue && complianceExpItem.Status.Value.ToString() == ComplianceExpItemStatuses.Active.ToString(),
                IsRequireEnabled = true,
                IsShowEnabled = true,
                Created = DateTime.UtcNow,
                CreatedBy = userId,
                Updated = DateTime.UtcNow,
                UpdatedBy = userId
            }).ToArray();
        }
    }
}
