﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantQueryHandler : IRequestHandler<GetApplicantQuery, Applicant>
{
    private readonly IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> _applicantHumanResourcePersonaMappingRepository;
    private readonly IGenericRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;
    private readonly IGenericRepository<HumanResourcePersonaEntity> _humanResourcePersonaRepository;
    private readonly IDbContextFactory<DaoDbContext> _dbContextFactory;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly IMediatorService _mediator;
    private readonly ILogger<GetApplicantQueryHandler> _logger;

    public GetApplicantQueryHandler(IDbContextFactory<DaoDbContext> dbContextFactory,
                                    IAuthenticationService authenticationService,
                                    IGenericRepository<HumanResourcePersonaEntity> humanResourcePersonaRepository,
                                    IGenericRepository<ApplicationWorkflowStatusEntity> applicationWorkflowStatusRepository,
                                    IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> applicantHumanResourcePersonaMappingRepository,
                                    IMapper mapper,
                                    IMediatorService mediator,
                                    ILogger<GetApplicantQueryHandler> logger)
    {
        _dbContextFactory = dbContextFactory;

        _authenticationService = authenticationService;
        _humanResourcePersonaRepository = humanResourcePersonaRepository;
        _applicationWorkflowStatusRepository = applicationWorkflowStatusRepository;
        _applicantHumanResourcePersonaMappingRepository = applicantHumanResourcePersonaMappingRepository;

        _mapper = mapper;
        _mediator = mediator;
        _logger = logger;
    }

    public async Task<Applicant> Handle(GetApplicantQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("GetApplicantAsync with Id: {applicantId}.", request.ApplicantId);

        int agencyId = _authenticationService.GetAgencyId();
        bool isSupportUser = _authenticationService.IsSupportUser();

        using var context = await _dbContextFactory.CreateDbContextAsync(cancellationToken);
        var applicantEntity = await context.Applicants!.Include(x => x.ApplicantEmploymentTypeMappings)
                                                       .Include(x => x.ApplicationWorkflowStatus)
                                                       .ThenInclude(x => x!.ApplicationWorkflowStatusMappings)
                                                       .Include(x => x.ApplicantNotes)
                                                       .Include(x => x.MaritalStatus)
                                                       .Include(x => x.ApplicantHumanResourcePersonaMappings!)
                                                       .ThenInclude(x => x.HumanResourcePersona)
                                                       .FirstOrDefaultAsync(x => x.Id == request.ApplicantId &&
                                                                                 x.AgencyId == agencyId, cancellationToken: cancellationToken);
        if (applicantEntity == null)
        {
            var message = $"{nameof(Applicant)} with Id: {request.ApplicantId} not found.";

            _logger.LogError("Applicant with Id: {applicantId} not found.", request.ApplicantId);
            throw new EntityNotFoundException(message);
        }

        var applicant = _mapper.Map<Applicant>(applicantEntity);

        if (isSupportUser)
        {
            applicant.DateOfBirth = ApplyMask(applicant.DateOfBirth, Constants.DateMask);
            applicant.SocialSecurityNumber = ApplyMask(applicant.SocialSecurityNumber, Constants.SsnMask);
            applicant.PrimaryStreet = ApplyMask(applicant.PrimaryStreet, Constants.DigitMask);
            applicant.SecondaryStreet = ApplyMask(applicant.SecondaryStreet, Constants.DigitMask);
        }

        int[] applicantSectionIds = new int[6]
        {
            (int)ApplicationFormApplicantSections.Demographics,
            (int)ApplicationFormApplicantSections.Address,
            (int)ApplicationFormApplicantSections.EmergencyContact,
            (int)ApplicationFormApplicantSections.NotificationPreferences,
            (int)ApplicationFormApplicantSections.Languages,
            (int)ApplicationFormApplicantSections.EmploymentInformation
        };

        GetApplicantSignatureCommand signatureCommand = new(applicant.Id, 0, applicantSectionIds);

        applicant.Signatures = await _mediator.SendAsync<GetApplicantSignatureCommand, IEnumerable<Signature>>(signatureCommand);

        var mappings = await _applicantHumanResourcePersonaMappingRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);
        if (mappings.Any())
        {
            var recent = mappings.OrderByDescending(x => x.Created).First();

            var hrPersona = await _humanResourcePersonaRepository.GetByIdAsync(recent.HumanResourcePersonaId);

            applicant.HumanResourcePersonaName = hrPersona?.Name;
            applicant.HumanResourcePersonaUserId = hrPersona?.Id;
            applicant.IsMineHumanResourcePersona = hrPersona?.UserId == _authenticationService.GetUserId();
        }

        if (applicant.ApplicationWorkflowStatus != null)
        {
            var nextApplicationWorkflowStatuses = new List<ApplicationWorkflowStatus>();
            if (applicant.ApplicationWorkflowStatus.ApplicationWorkflowStatusMappings != null)
            {
                var applicationWorkflowStatusMappingsIds = applicant.ApplicationWorkflowStatus.ApplicationWorkflowStatusMappings.Select(x => x.NextApplicationWorkflowStatusId).ToArray();
                var statuses = _applicationWorkflowStatusRepository.GetQuery().Where(x => applicationWorkflowStatusMappingsIds.Contains(x.Id)).ToArray();
                foreach (var applicationWorkflowStatusMappingsId in applicationWorkflowStatusMappingsIds)
                {
                    var nextApplicationWorkflowStatus = statuses.FirstOrDefault(x => x.Id == applicationWorkflowStatusMappingsId);
                    if (nextApplicationWorkflowStatus != null && nextApplicationWorkflowStatus.AgencyId == agencyId)
                    {
                        nextApplicationWorkflowStatuses.Add(
                            new ApplicationWorkflowStatus
                            {
                                ColorId = nextApplicationWorkflowStatus.ColorId,
                                Name = nextApplicationWorkflowStatus.Name,
                                Description = nextApplicationWorkflowStatus.Description,
                                IsInterviewPossible = nextApplicationWorkflowStatus.IsInterviewPossible,
                                IsLastPossible = nextApplicationWorkflowStatus.IsLastPossible,
                                IsDefaultStatus = nextApplicationWorkflowStatus.IsDefaultStatus,
                                Id = nextApplicationWorkflowStatus.Id,
                                Updated = nextApplicationWorkflowStatus.Updated,
                                UpdatedBy = nextApplicationWorkflowStatus.UpdatedBy,
                                Created = nextApplicationWorkflowStatus.Created,
                                CreatedBy = nextApplicationWorkflowStatus.CreatedBy,
                                IsActive = true
                            });
                    }
                }
            }
            applicant.ApplicationWorkflowStatus.NextApplicationWorkflowStatuses = nextApplicationWorkflowStatuses;
        }

        _logger.LogInformation("Applicant with Id: {applicantId} was getting successfully.", request.ApplicantId);

        return applicant;
    }

    private static string? ApplyMask(string? value, string mask)
    {
        return !string.IsNullOrEmpty(value) ? mask : value;
    }
}
