﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetReferralSourcesQueryHandler : IRequestHandler<GetReferralSourcesQuery, IEnumerable<ReferralSource>>
{
    private readonly IReadOnlyRepository<OfficeInfoEntity> _officeInfoEntityRepository;
    private readonly ILookupService<ReferralSource, ReasonEntity> _referalSourcesLookupService;
    private readonly ILogger<GetReferralSourcesQueryHandler> _logger;

    public GetReferralSourcesQueryHandler(ILookupService<ReferralSource, ReasonEntity> referalSourcesLookupService,
                                          ILogger<GetReferralSourcesQueryHandler> logger,
                                          IReadOnlyRepository<OfficeInfoEntity> officeInfoEntityRepository)
    {
        _officeInfoEntityRepository = officeInfoEntityRepository;
        _referalSourcesLookupService = referalSourcesLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<ReferralSource>> Handle(GetReferralSourcesQuery query, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        const char companyType = 'V';
        const string reasonType = "Caregiver Referral Source";

        var office = await _officeInfoEntityRepository.GetByIdAsync(query.OfficeId);

        if(office is not null)
        {
            var response = await _referalSourcesLookupService.FindAsync(x => x.CompanyType == companyType &&
                                                                         x.Type == reasonType &&
                                                                         x.OfficeId == query.OfficeId &&
                                                                         x.CompanyId == office.VendorId &&
                                                                         x.IsActive);

            _logger.LogInformation("Referral Sources was getting successfully.");

            return response;
        }

        _logger.LogInformation("Referral Sources not found.");

        return Enumerable.Empty<ReferralSource>();
    }
}
