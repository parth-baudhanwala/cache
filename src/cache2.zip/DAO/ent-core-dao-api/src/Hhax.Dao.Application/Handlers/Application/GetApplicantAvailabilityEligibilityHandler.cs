﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Application;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantAvailabilityEligibilityHandler : IRequestHandler<GetApplicantAvailabilityEligibilityQuery, ApplicantEligibility>
{
    private readonly IMediator _mediator;

    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IGenericRepository<AvailabilityDayEntity> _availabilityDayRepository;
    private readonly IGenericRepository<ApplicantEligibilityEntity> _applicantEligibilityEntityRepository;

    private readonly IAuthenticationService _authenticationService;
    private readonly IApplicantProfileService _applicantProfileService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicantAvailabilityEligibilityHandler> _logger;

    public GetApplicantAvailabilityEligibilityHandler(IMediator mediator,
                                                 IGenericRepository<ApplicantEntity> applicantRepository,
                                                 IGenericRepository<AvailabilityDayEntity> availabilityDayRepository,
                                                 IGenericRepository<ApplicantEligibilityEntity> applicantEligibilityEntityRepository,
                                                 IAuthenticationService authenticationService,
                                                 IApplicantProfileService applicantProfileService,
                                                 IMapper mapper,
                                                 ILogger<GetApplicantAvailabilityEligibilityHandler> logger)
    {
        _mediator = mediator;

        _applicantRepository = applicantRepository;
        _availabilityDayRepository = availabilityDayRepository;
        _applicantEligibilityEntityRepository = applicantEligibilityEntityRepository;

        _authenticationService = authenticationService;
        _applicantProfileService = applicantProfileService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicantEligibility> Handle(GetApplicantAvailabilityEligibilityQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Check Applicant Availability Eligibility with Applicant Id: {applicantId}", request.ApplicantId);

        // Get applicant by ApplicantId
        var applicantEntity = await _applicantRepository.FirstOrDefaultAsync(x => x.Id == request.ApplicantId);
        if (applicantEntity == null)
        {
            var message = $"Applicant with Id: {request.ApplicantId} not found.";
            throw new ApplicantNotFoundException(message);
        }

        // Get applicant requirements by OfficeId
        var getApplicantRequirementsByOfficeIdQuery = new GetApplicationFormApplicantRequirementsByOfficeIdQuery(applicantEntity.OfficeId);
        var applicantRequirements = await _mediator.Send(getApplicantRequirementsByOfficeIdQuery, cancellationToken);

        var applicantAvailabilityEligibility = await _applicantEligibilityEntityRepository.FirstOrDefaultAsync(x => x.ApplicantId == request.ApplicantId &&
        x.ApplicantSectionId == (int)ApplicationFormApplicantSections.Availability);

        var applicantEligibilitiy = _mapper.Map<ApplicantEligibility>(applicantAvailabilityEligibility);

        // Get Availability Days form by ApplicantId
        var applicantAvailabilityDays = await _availabilityDayRepository.FindAsync(x => x.ApplicantId == request.ApplicantId, true);

        if (applicantEligibilitiy is not null)
        {
            var availabilitySectionNotEligibleFields = _applicantProfileService.ValidateApplicantAvailabilitySection(applicantAvailabilityDays, applicantRequirements);
            var availabilitySectionNotEligibleFieldsMessage = availabilitySectionNotEligibleFields.Any() ? $"Not all required information is added, please fill in at least one " +
                $"max visits number or at least one shift data." : string.Empty;

            applicantEligibilitiy.NotEligibleFields = availabilitySectionNotEligibleFields;
            applicantEligibilitiy.NotEligibleFieldsMessage = availabilitySectionNotEligibleFieldsMessage;
        }
        else
        {
            var userId = _authenticationService.GetUserId();
            applicantEligibilitiy =
                new ApplicantEligibility
                {
                    ApplicantId = request.ApplicantId,
                    ApplicantEligibilityStatusId = (int)ApplicantEligibilityStatuses.NoInformation,
                    ApplicantSectionId = (int)ApplicationFormApplicantSections.Availability,
                    IsVerified = false,
                    NotEligibleFields = new List<string>(),
                    NotEligibleFieldsMessage = string.Empty,
                    Created = DateTime.UtcNow,
                    CreatedBy = userId,
                    Updated = DateTime.UtcNow,
                    UpdatedBy = userId,
                };
        }

        _logger.LogInformation("Applicant Availability Eligibility with Applicant Id: {applicantId} was checked successfully.", request.ApplicantId);

        return applicantEligibilitiy;
    }
}