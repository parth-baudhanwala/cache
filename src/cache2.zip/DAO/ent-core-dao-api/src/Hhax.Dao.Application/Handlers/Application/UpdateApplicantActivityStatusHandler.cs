﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class UpdateApplicantActivityStatusHandler : IRequestHandler<UpdateApplicantActivityStatusCommand, Unit>
{
    private readonly IAuthenticationService _authenticationService;
    private readonly ILogger<UpdateApplicantActivityStatusHandler> _logger;
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;

    public UpdateApplicantActivityStatusHandler(IAuthenticationService authenticationService,
                                                ILogger<UpdateApplicantActivityStatusHandler> logger,
                                                IGenericRepository<ApplicantEntity> applicantRepository)
    {
        _authenticationService = authenticationService;
        _logger = logger;
        _applicantRepository = applicantRepository;
    }

    public async Task<Unit> Handle(UpdateApplicantActivityStatusCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        int userId = _authenticationService.GetUserId();

        await _applicantRepository.GetQuery()
                                  .Where(x => command.ApplicantIds.Contains(x.Id) && x.IsActive != command.IsActive)
                                  .ExecuteUpdateAsync(x => x.SetProperty(y => y.IsActive, y => command.IsActive)
                                                            .SetProperty(y => y.UpdatedBy, y => userId)
                                                            .SetProperty(y => y.Updated, y => DateTime.UtcNow), cancellationToken: cancellationToken);

        _logger.LogInformation("Activity of applicant(s) updated successfully.");

        return Unit.Value;
    }
}
