﻿using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetInitialApplicationWorkflowStatusQueryHandler : IRequestHandler<GetInitialApplicationWorkflowStatusQuery, ApplicationWorkflowStatus?>
{
    private readonly ILookupService<ApplicationWorkflowStatus, ApplicationWorkflowStatusEntity> _applicationWorkflowStatusLookupService;
    private readonly ILogger<GetInitialApplicationWorkflowStatusQueryHandler> _logger;
    private readonly IAuthenticationService _authenticationService;

    public GetInitialApplicationWorkflowStatusQueryHandler(ILookupService<ApplicationWorkflowStatus, ApplicationWorkflowStatusEntity> applicationWorkflowStatusLookupService,
                                                           ILogger<GetInitialApplicationWorkflowStatusQueryHandler> logger,
                                                           IAuthenticationService authenticationService)
    {
        _applicationWorkflowStatusLookupService = applicationWorkflowStatusLookupService;
        _logger = logger;
        _authenticationService = authenticationService;
    }

    public async Task<ApplicationWorkflowStatus?> Handle(GetInitialApplicationWorkflowStatusQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var initialStatuses = await _applicationWorkflowStatusLookupService.FindAsync(x => 
        x.Name == DefaultWorkflowStatusesConstants.ApplicationInProgressName && 
        x.AgencyId == request.VendorId &&
        x.IsDefaultStatus == true);

        ApplicationWorkflowStatus? response = null;

        // we need to check that there is only one initial status in the DB,
        // otherwise - it is an error
        if (initialStatuses != null && initialStatuses.Count() == 1)
        {
            response = initialStatuses.FirstOrDefault();
        }

        _logger.LogInformation("Handle was getting successfully.");

        return response;
    }
}
