﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Utilities;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class SaveApplicantOnBoardingFormSignatureHandler : IRequestHandler<SaveApplicantOnBoardingFormSignatureCommand, BaseResponse>
{
    private readonly ILogger<GetApplicantOnBoardingFormSignatureHandler> _logger;
    private readonly IFilesUploadService _filesUploadService;
    private readonly IAuthenticationService _authenticationService;
    private readonly IGenericRepository<ApplicantOnBoardingFormSignatureEntity> _applicantOnBoardingFormSignatureRepository;

    public SaveApplicantOnBoardingFormSignatureHandler(ILogger<GetApplicantOnBoardingFormSignatureHandler> logger, IServiceProvider serviceProvider)
    {
        _logger = logger;
        _filesUploadService = serviceProvider.GetRequiredService<IFilesUploadService>();
        _authenticationService = serviceProvider.GetRequiredService<IAuthenticationService>();
        _applicantOnBoardingFormSignatureRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicantOnBoardingFormSignatureEntity>>();
    }

    public async Task<BaseResponse> Handle(SaveApplicantOnBoardingFormSignatureCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        int userId = _authenticationService.GetUserId();
        BaseResponse response = new();
        List<string> fileKeys = new();
        long fileSize = 0;

        ApplicantOnBoardingFormSignatureEntity onboarsingFormSignatureEntity = new()
        {
            ApplicantId = command.ApplicantId,
            IsSignatureDrawn = command.IsSignatureDrawn,
            SignatureDate = command.SignatureDate,
            Created = DateTime.UtcNow,
            CreatedBy = userId
        };

        if (command.IsSignatureDrawn && command.IsClearOldSignature && !string.IsNullOrWhiteSpace(command.Signature))
        {
            IFormFile signatureFile = FileUtility.ConvertStringToFile(command.Signature);

            onboarsingFormSignatureEntity.SignatureFileKey = $"applicant/{command.ApplicantId}/applicant-onboarding-signature/{HhaxUtility.GetDateFolderPrefix()}/{command.ApplicantId}_signature.jpeg";
            onboarsingFormSignatureEntity.SignatureFileSize = (int)signatureFile.Length;

            await _filesUploadService.UploadDocumentAsync(signatureFile, onboarsingFormSignatureEntity.SignatureFileKey, command.ApplicantId);
        }
        else
        {
            onboarsingFormSignatureEntity.SignatureText = command.Signature;
        }

        response.Id = await _applicantOnBoardingFormSignatureRepository.Upsert(onboarsingFormSignatureEntity, x => x.ApplicantId == command.ApplicantId, upsertEntity =>
        {
            if (command.IsClearOldSignature
                && !string.IsNullOrWhiteSpace(upsertEntity.SignatureFileKey)
                && upsertEntity.SignatureFileSize != null
                && !upsertEntity.SignatureFileKey.Equals(onboarsingFormSignatureEntity.SignatureFileKey))
            {
                fileKeys.Add(upsertEntity.SignatureFileKey);
                fileSize = upsertEntity.SignatureFileSize.Value;
            }

            upsertEntity.IsSignatureDrawn = onboarsingFormSignatureEntity.IsSignatureDrawn;
            upsertEntity.SignatureText = onboarsingFormSignatureEntity.SignatureText;
            upsertEntity.SignatureFileKey = onboarsingFormSignatureEntity.SignatureFileKey;
            upsertEntity.SignatureFileSize = onboarsingFormSignatureEntity.SignatureFileSize;
            upsertEntity.SignatureDate = onboarsingFormSignatureEntity.SignatureDate;
            upsertEntity.Updated = DateTime.UtcNow;
            upsertEntity.UpdatedBy = userId;

            return upsertEntity;
        });

        if (fileKeys.Any())
        {
            await _filesUploadService.DeleteDocumentsAsync(fileKeys, fileSize, command.ApplicantId);
        }

        _logger.LogInformation("Applicant signature was saved successfully for {ApplicantId}.", command.ApplicantId);

        return response;
    }
}
