﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Application;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantTrainingSchoolsEligibilityHandler : IRequestHandler<GetApplicantTrainingSchoolsEligibilityQuery, ApplicantEligibility>
{
    private readonly IMediator _mediator;

    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IReadOnlyRepository<ComplianceTrainingSchoolEntity> _trainingSchoolRepository;
    private readonly IGenericRepository<ApplicantEligibilityEntity> _applicantEligibilityEntityRepository;

    private readonly IAuthenticationService _authenticationService;
    private readonly IApplicantProfileService _applicantProfileService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicantTrainingSchoolsEligibilityHandler> _logger;

    public GetApplicantTrainingSchoolsEligibilityHandler(IMediator mediator,
                                                 IGenericRepository<ApplicantEntity> applicantRepository,
                                                 IReadOnlyRepository<ComplianceTrainingSchoolEntity> trainingSchoolRepository,
                                                 IGenericRepository<ApplicantEligibilityEntity> applicantEligibilityEntityRepository,
                                                 IAuthenticationService authenticationService,
                                                 IApplicantProfileService applicantProfileService,
                                                 IMapper mapper,
                                                 ILogger<GetApplicantTrainingSchoolsEligibilityHandler> logger)
    {
        _mediator = mediator;

        _applicantRepository = applicantRepository;
        _trainingSchoolRepository = trainingSchoolRepository;
        _applicantEligibilityEntityRepository = applicantEligibilityEntityRepository;

        _authenticationService = authenticationService;
        _applicantProfileService = applicantProfileService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ApplicantEligibility> Handle(GetApplicantTrainingSchoolsEligibilityQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Check Applicant Training Schools Eligibility with Applicant Id: {applicantId}", request.ApplicantId);

        // Get applicant by ApplicantId
        var applicantEntity = await _applicantRepository.FirstOrDefaultAsync(x => x.Id == request.ApplicantId);
        if (applicantEntity == null)
        {
            var message = $"Applicant with Id: {request.ApplicantId} not found.";
            throw new ApplicantNotFoundException(message);
        }

        // Get applicant requirements by OfficeId
        var getApplicantRequirementsByOfficeIdQuery = new GetApplicationFormApplicantRequirementsByOfficeIdQuery(applicantEntity.OfficeId);
        var applicantRequirements = await _mediator.Send(getApplicantRequirementsByOfficeIdQuery, cancellationToken);

        var applicantTrainingSchoolsEligibility = await _applicantEligibilityEntityRepository.FirstOrDefaultAsync(x => x.ApplicantId == request.ApplicantId &&
        x.ApplicantSectionId == (int)ApplicationFormApplicantSections.GeneralCompliance && x.ApplicantFieldId == (int)ApplicationFormApplicantFields.TrainingSchools);

        var applicantEligibility = _mapper.Map<ApplicantEligibility>(applicantTrainingSchoolsEligibility);

        // Get Training Schools by ApplicantId
        var applicanTrainingSchools = await _trainingSchoolRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);

        if (applicantEligibility is not null)
        {
            var trainingSchoolsSectionNotEligibleFields = _applicantProfileService.ValidateApplicantTrainingSchoolsCheckSection(applicanTrainingSchools, applicantRequirements, false, false);
            var trainingSchoolsSectionNotEligibleFieldsMessage = trainingSchoolsSectionNotEligibleFields.Any() ?
                $"Not all required information is added, please fill in at least one training school record with verification and verification date." : string.Empty;

            applicantEligibility.NotEligibleFields = trainingSchoolsSectionNotEligibleFields;
            applicantEligibility.NotEligibleFieldsMessage = trainingSchoolsSectionNotEligibleFieldsMessage;
        }
        else
        {
            var userId = _authenticationService.GetUserId();
            applicantEligibility =
                new ApplicantEligibility {
                    ApplicantId = request.ApplicantId,
                    ApplicantEligibilityStatusId = (int)ApplicantEligibilityStatuses.NoInformation,
                    ApplicantSectionId = (int)ApplicationFormApplicantSections.GeneralCompliance,
                    ApplicantFieldId = (int)ApplicationFormApplicantFields.TrainingSchools,
                    IsVerified = false,
                    NotEligibleFields = new List<string>(),
                    NotEligibleFieldsMessage = string.Empty,
                    Created = DateTime.UtcNow,
                    CreatedBy = userId,
                    Updated = DateTime.UtcNow,
                    UpdatedBy = userId,
                };
        }

        _logger.LogInformation("Applicant Training Schools Eligibility with Applicant Id: {applicantId} was checked successfully.", request.ApplicantId);

        return applicantEligibility;
    }
}