﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Common.Constants;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetHumanResourcePersonasHandler : IRequestHandler<GetHumanResourcePersonasRequest, IEnumerable<HumanResourcePersona>>
{
    private readonly IReadOnlyRepository<UserInfoEntity> _userRepository;
    private readonly IReadOnlyRepository<HumanResourcePersonaEntity> _hrPersonaRepository;
    private readonly IReadOnlyRepository<HumanResourcePersonaStatusEntity> _humanResourcePersonaStatusRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IMapper _mapper;

    public GetHumanResourcePersonasHandler(
        IReadOnlyRepository<UserInfoEntity> userRepository,
        IReadOnlyRepository<HumanResourcePersonaEntity> hrPersonaRepository,
        IReadOnlyRepository<HumanResourcePersonaStatusEntity> humanResourcePersonaStatusRepository,
        IAuthenticationService authenticationService,
        IMapper mapper)
    {
        _userRepository = userRepository;
        _hrPersonaRepository = hrPersonaRepository;
        _humanResourcePersonaStatusRepository = humanResourcePersonaStatusRepository;
        _authenticationService = authenticationService;
        _mapper = mapper;
    }

    public async Task<IEnumerable<HumanResourcePersona>> Handle(GetHumanResourcePersonasRequest request, CancellationToken cancellationToken)
    {
        int agencyId = _authenticationService.GetAgencyId();

        var activeStatus = await _humanResourcePersonaStatusRepository.FirstOrDefaultAsync(x => x.Name == StatusConstants.ACTIVE);

        var hrPersonaEntities = await _hrPersonaRepository.FindAsync(x => x.AgencyId == agencyId && x.StatusId == activeStatus.Id);

        var hrPersonas = _mapper.Map<IEnumerable<HumanResourcePersona>>(hrPersonaEntities);

        var userIds = hrPersonas.Select(x => x.UserId).Distinct().ToArray();
        var users = await _userRepository.FindAsync(x => x.IsActive && userIds.Contains(x.Id));

        foreach (var hrPersona in hrPersonas)
        {
            var user = users.FirstOrDefault(x => x.Id == hrPersona.UserId);
            if (user is not null)
            {
                hrPersona.UserName = user.UserName;
                hrPersona.FirstName = user.FirstName;
                hrPersona.LastName = user.LastName;
            }
        }
        return hrPersonas;
    }
}
