﻿using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class UpdateApplicantApplicationLanguageHandler : IRequestHandler<UpdateApplicantApplicationLanguageCommand, BaseResponse>
{
    private readonly ILogger<UpdateApplicantApplicationLanguageHandler> _logger;
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IGenericRepository<ApplicantOnBoardingFormsEntity> _applicantOnBoardingFormsRepository;
    private readonly IReadOnlyRepository<ApplicationOnBoardingFormMappingEntity> _applicationOnBoardingFormMappingRepository;

    public UpdateApplicantApplicationLanguageHandler(ILogger<UpdateApplicantApplicationLanguageHandler> logger, IAuthenticationService authenticationService, IServiceProvider serviceProvider)
    {
        _logger = logger;
        _authenticationService = authenticationService;
        _applicantRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicantEntity>>();
        _applicantOnBoardingFormsRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicantOnBoardingFormsEntity>>();
        _applicationOnBoardingFormMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationOnBoardingFormMappingEntity>>();
    }

    public async Task<BaseResponse> Handle(UpdateApplicantApplicationLanguageCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        int userId = _authenticationService.GetUserId();

        var applicant = await _applicantRepository.GetQuery()
                                                  .Include(x => x.ApplicationWorkflowStatus)
                                                  .Where(x => x.ApplicationWorkflowStatus!.Name != DefaultWorkflowStatusesConstants.ApplicationSubmittedName 
                                                           && x.ApplicationWorkflowStatus.Name != DefaultWorkflowStatusesConstants.ConvertedToCaregiverName)
                                                  .FirstOrDefaultAsync(x => x.Id == command.ApplicantId);

        BaseResponse response = new();

        if (applicant is null || command.LanguageId <= 0 || applicant.ApplicationLanguageId == command.LanguageId)
        {
            return response;
        }

        var formsToDelete = await _applicantOnBoardingFormsRepository.GetQuery()
                   .Join(_applicationOnBoardingFormMappingRepository.GetQuery().Include(x => x.ApplicationOnBoardingForms),
                            aof => aof.ApplicationOnBoardingFormId,
                            aofm => aofm.ApplicationOnBoardingFormId,
                            (aof, aofm) => new { ApplicantOnboardingForm = aof, ApplicationOnboardingFormMapping = aofm })
                   .Where(x => x.ApplicantOnboardingForm.ApplicantId == applicant.Id && x.ApplicationOnboardingFormMapping.ApplicationOnBoardingForms!.LanguageId == applicant.ApplicationLanguageId)
                   .Select(x => x.ApplicantOnboardingForm)
                   .ToListAsync(cancellationToken);

        await _applicantOnBoardingFormsRepository.RemoveRangeAsync(formsToDelete);

        _logger.LogInformation("Entries Applicant FormResponseId was deleted successfully for applicant {ApplicantId}.", applicant!.Id);

        applicant.ApplicationLanguageId = command.LanguageId;
        applicant.Updated = DateTime.UtcNow;
        applicant.UpdatedBy = userId;

        response.Id = await _applicantRepository.UpdateAsync(applicant);

        _logger.LogInformation("Applicant Language Id was saved successfully for applicant {ApplicantId}.", applicant.Id);

        return response;
    }
}
