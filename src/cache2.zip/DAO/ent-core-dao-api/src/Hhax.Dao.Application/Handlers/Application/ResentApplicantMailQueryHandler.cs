﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.MailVerification;
using Hhax.Dao.Application.Queries.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class ResentApplicantMailQueryHandler : IRequestHandler<ResentApplicantMailQuery, MailVerificationResponse>
{
    private readonly IMailVerificationService _mailVerifiactionService;

    private readonly ILogger<ResentApplicantMailQueryHandler> _logger;
    
    public ResentApplicantMailQueryHandler(IMailVerificationService mailVerifiactionService,
                                           ILogger<ResentApplicantMailQueryHandler> logger)
    {
        _mailVerifiactionService = mailVerifiactionService;
        
        _logger = logger;
    }
    
    public async Task<MailVerificationResponse> Handle(ResentApplicantMailQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Resent Mail for Applicant with id: {request.ApplicantId}.", request.ApplicantId);
        
        await _mailVerifiactionService.SendEmailAsync(request.ApplicantId, request.Name!, request.Email, request.Domain);

        _logger.LogInformation("Resent Mail for Applicant with id: {request.ApplicantId}.", request.ApplicantId);

        var response = new MailVerificationResponse { Status = MailVerificationStatus.KeySent };

        return response;
    }
}