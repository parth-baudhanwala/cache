﻿using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicationOnBoardingFormsHandler : IRequestHandler<GetApplicationOnBoardingFormsQuery, IEnumerable<ApplicationOnBoardingFormInfo>>
{
    private readonly ILogger<GetApplicationOnBoardingFormsHandler> _logger;
    private readonly IReadOnlyRepository<ApplicationOnBoardingFormMappingEntity> _applicationOnBoardingFormMappingRepository;
    private readonly IReadOnlyRepository<ApplicationFormOfficeMappingEntity> _applicationFormOfficeMappingRepository;


    public GetApplicationOnBoardingFormsHandler(ILogger<GetApplicationOnBoardingFormsHandler> logger,
                                                IServiceProvider serviceProvider)
    {
        _logger = logger;
        _applicationOnBoardingFormMappingRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<ApplicationOnBoardingFormMappingEntity>>();
        _applicationFormOfficeMappingRepository = serviceProvider.GetRequiredService<IGenericRepository<ApplicationFormOfficeMappingEntity>>();
    }

    public async Task<IEnumerable<ApplicationOnBoardingFormInfo>> Handle(GetApplicationOnBoardingFormsQuery query, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        if (query.ApplicationFormId <= 0)
        {
            return Enumerable.Empty<ApplicationOnBoardingFormInfo>();
        }

        var onBoardingForms = await Task.FromResult(_applicationOnBoardingFormMappingRepository.GetQuery().AsNoTracking()
                                        .Where(x => x.ApplicationFormId == query.ApplicationFormId
                                                    && x.IsActive)
                                        .Select(x => new ApplicationOnBoardingFormInfo
                                        {
                                            Id = x.Id,
                                            OnBoardingFormId = x.ApplicationOnBoardingForms!.OnBoardingFormId,
                                            Name = x.ApplicationOnBoardingForms.Name,
                                            Category = x.ApplicationOnBoardingForms.Category,
                                            Description = x.ApplicationOnBoardingForms.Description,
                                            LanguageId = x.ApplicationOnBoardingForms.LanguageId,
                                            Version = x.ApplicationOnBoardingForms.Version,
                                            IsShow = x.IsShow,
                                            IsActive = x.IsActive
                                        }).AsEnumerable());

        _logger.LogInformation("Application onboarding forms were retrieved successfully for {ApplicationFormId}", query.ApplicationFormId);

        return onBoardingForms;
    }
}
