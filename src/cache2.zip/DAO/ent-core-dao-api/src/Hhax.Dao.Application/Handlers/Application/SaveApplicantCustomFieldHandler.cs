﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.Settings;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Settings;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class SaveApplicantCustomFieldHandler : IRequestHandler<SaveApplicantCustomFieldCommand, BaseResponse>
{
    private readonly ILogger<GetApplicantCustomFieldHandler> _logger;
    private readonly IAuthenticationService _authenticationService;
    private readonly IFilesUploadService _filesUploadService;
    private readonly IGenericRepository<ApplicantCustomFieldEntity> _applicantCustomFieldRepository;
    private readonly IGenericRepository<ApplicantEntity> _applicantRepository;
    private readonly IMediatorService _mediator;

    public SaveApplicantCustomFieldHandler(ILogger<GetApplicantCustomFieldHandler> logger, IMediatorService mediator, IServiceProvider serviceProvider)
    {
        _logger = logger;
        _authenticationService = serviceProvider.GetService<IAuthenticationService>()!;
        _filesUploadService = serviceProvider.GetService<IFilesUploadService>()!;
        _applicantCustomFieldRepository = serviceProvider.GetService<IGenericRepository<ApplicantCustomFieldEntity>>()!;
        _applicantRepository = serviceProvider.GetService<IGenericRepository<ApplicantEntity>>()!;
        _mediator = mediator;
    }

    public async Task<BaseResponse> Handle(SaveApplicantCustomFieldCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        BaseResponse response = new();
        List<Task> fileTasks = new();
        List<string> fileKeys = new();
        long totalFileSize = 0;
        int userId = _authenticationService.GetUserId();

        bool isApplicantExist = await _applicantRepository.GetQuery().AnyAsync(x => x.Id == command.ApplicantId, cancellationToken: cancellationToken);

        if (!isApplicantExist) throw new NullValueException("Applicant Id is not found.");

        var applicantCustomFieldEntities = (await _applicantCustomFieldRepository.FindAsync(x => x.ApplicantId == command.ApplicantId && x.IsActive)).ToList();

        foreach (var field in command.ApplicantCustomFields)
        {
            var applicantCustomFieldEntity = applicantCustomFieldEntities.Find(x => x.FormCustomFieldId == field.FormCustomFieldId);

            if (applicantCustomFieldEntity != null)
            {
                applicantCustomFieldEntity.Value = field.Value;
                applicantCustomFieldEntity.Updated = DateTime.UtcNow;
                applicantCustomFieldEntity.UpdatedBy = userId;
            }
            else
            {
                applicantCustomFieldEntity = new()
                {
                    ApplicantId = command.ApplicantId,
                    IsActive = true,
                    FormCustomFieldId = field.FormCustomFieldId,
                    Value = field.Value,
                    Created = DateTime.UtcNow,
                    CreatedBy = userId
                };

                applicantCustomFieldEntities.Add(applicantCustomFieldEntity);
            }

            if (field.IsFileDeleted)
            {
                var fileName = applicantCustomFieldEntity.FileKey?.Split("/").LastOrDefault();
                if (fileName is not null
                    && !fileName.Equals(field.File?.FileName)
                    && applicantCustomFieldEntity.FileSize != field.FileSize)
                {
                    fileKeys.Add(applicantCustomFieldEntity.FileKey!);
                    totalFileSize += applicantCustomFieldEntity.FileSize;
                    applicantCustomFieldEntity.FileSize = 0;
                    applicantCustomFieldEntity.FileKey = null;
                }
            }

            if (field.File != null)
            {
                applicantCustomFieldEntity.FileSize = field.FileSize;
                applicantCustomFieldEntity.FileKey = $"applicant/{command.ApplicantId}/applicant-custom-fields/{GetDateFolderPrefix()}/{field.FormCustomFieldId}/{field.File.FileName}";
                var fileUploadTask = _filesUploadService.UploadDocumentAsync(field.File, applicantCustomFieldEntity.FileKey);
                fileTasks.Add(fileUploadTask);
            }
        }

        if (fileKeys.Any())
        {
            Task fileDeleteTask = _filesUploadService.DeleteDocumentsAsync(fileKeys);
            fileTasks.Add(fileDeleteTask);
        }

        await Task.WhenAll(fileTasks);
        response.Id = await _applicantCustomFieldRepository.AttachRangeAsync(applicantCustomFieldEntities);

        totalFileSize = command.ApplicantCustomFields.Sum(c => c.FileSize) - totalFileSize;
        SaveVendorTotalUploadedFileSizeRequest request = new() { ApplicantId = command.ApplicantId, TotalUploadedFileUsage = totalFileSize };
        await _mediator.SendAsync<SaveVendorTotalUploadedFileSizeRequest, VendorTotalUploadedFileSizeResponse>(request);

        _logger.LogInformation("Applicant custom fields were saved successfully for {ApplicantId}.", command.ApplicantId);

        return response;
    }

    private static string GetDateFolderPrefix()
        => $"{DateTime.UtcNow.Year}/{DateTime.UtcNow.Month}/{DateTime.UtcNow.Day}";
}
