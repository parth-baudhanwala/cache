﻿using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public class GetApplicantCustomFieldHandler : IRequestHandler<GetApplicantCustomFieldCommand, IEnumerable<ApplicantCustomFieldInfo>>
{
    private readonly ILogger<GetApplicantCustomFieldHandler> _logger;
    private readonly IGenericRepository<ApplicationFormOfficeMappingEntity> _applicationFormOfficeMappingRepository;
    private readonly IGenericRepository<ApplicationFormCustomFieldEntity> _customFieldRepository;
    private readonly IGenericRepository<ApplicantCustomFieldEntity> _applicantCustomFieldRepository;

    public GetApplicantCustomFieldHandler(ILogger<GetApplicantCustomFieldHandler> logger,
                                          IServiceProvider serviceProvider)
    {
        _logger = logger;
        _applicationFormOfficeMappingRepository = serviceProvider.GetService<IGenericRepository<ApplicationFormOfficeMappingEntity>>()!;
        _customFieldRepository = serviceProvider.GetService<IGenericRepository<ApplicationFormCustomFieldEntity>>()!;
        _applicantCustomFieldRepository = serviceProvider.GetService<IGenericRepository<ApplicantCustomFieldEntity>>()!;
    }

    public async Task<IEnumerable<ApplicantCustomFieldInfo>> Handle(GetApplicantCustomFieldCommand command, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        int applicationFormId = (await _applicationFormOfficeMappingRepository.FirstOrDefaultAsync(x => x.OfficeId == command.OfficeId))?.ApplicationFormId ?? 0;

        if (applicationFormId == 0)
        {
            return Enumerable.Empty<ApplicantCustomFieldInfo>();
        }

        var applicantCustomFields = await _applicantCustomFieldRepository.FindAsync(x => x.ApplicantId == command.ApplicantId && x.IsActive);

        var applicationFormCustomFields = _customFieldRepository.GetQuery()
                                                .Where(x => x.ApplicationFormId == applicationFormId
                                                            && x.IsActive)
                                                .Select(x => new ApplicationFormCustomFieldEntity
                                                {
                                                    Id = x.Id,
                                                    ApplicantSectionId = x.ApplicantSectionId,
                                                    CanUploadFile = x.CanUploadFile,
                                                    FieldName = x.FieldName,
                                                    FieldTypeId = x.FieldTypeId,
                                                    IsRequire = x.IsRequire,
                                                    IsShow = x.IsShow,
                                                    ApplicationCustomFieldValueMappings = x.ApplicationCustomFieldValueMappings!.Where(x => x.IsActive).ToList()
                                                }).AsEnumerable();

        var applicantCustomFieldsInfo = MapData(applicationFormCustomFields, applicantCustomFields);

        _logger.LogInformation("Applicant custom fields were retrieved successfully for {ApplicantId}.", command.ApplicantId);

        return applicantCustomFieldsInfo;
    }

    private static IEnumerable<ApplicantCustomFieldInfo> MapData(IEnumerable<ApplicationFormCustomFieldEntity> applicationFormCustomFields, IEnumerable<ApplicantCustomFieldEntity> applicantCustomFields)
    {
        ApplicantCustomFieldEntity? applicantCustomField;

        foreach (var formCustomField in applicationFormCustomFields)
        {
            applicantCustomField = applicantCustomFields.FirstOrDefault(x => x.FormCustomFieldId == formCustomField.Id);
            ApplicantCustomFieldInfo applicantCustomFieldInfo = new()
            {
                ApplicantSectionId = formCustomField.ApplicantSectionId,
                CanUploadFile = formCustomField.CanUploadFile,
                FieldName = formCustomField.FieldName,
                FieldTypeId = formCustomField.FieldTypeId,
                FileKey = applicantCustomField?.FileKey,
                FileSize = applicantCustomField?.FileSize ?? 0,
                FormCustomFieldId = formCustomField.Id,
                Id = applicantCustomField?.Id ?? 0,
                IsRequire = formCustomField.IsRequire,
                IsShow = formCustomField.IsShow,
                Value = applicantCustomField?.Value
            };

            if (formCustomField.ApplicationCustomFieldValueMappings?.Any() == true)
            {
                applicantCustomFieldInfo.ApplicantCustomFieldValueMappings = PopulateMappingValues(formCustomField.ApplicationCustomFieldValueMappings, applicantCustomField?.Value);
            }

            yield return applicantCustomFieldInfo;
        }
    }

    private static IEnumerable<ApplicantCustomFieldValueMappingInfo> PopulateMappingValues(IEnumerable<ApplicationCustomFieldValueMappingEntity> applicationCustomFieldValueMappings, string? value)
    {
        string[]? values = null;

        if (!string.IsNullOrEmpty(value))
        {
            values = value.Split(",").Select(x => x.Trim()).ToArray();
        }

        foreach (var applicationCustomFieldValue in applicationCustomFieldValueMappings)
        {
            ApplicantCustomFieldValueMappingInfo applicantCustomFieldValue = new()
            {
                Id = applicationCustomFieldValue.Id,
                Value = applicationCustomFieldValue.Value,
                IsSelected = values?.Any(x => x == applicationCustomFieldValue.Value) ?? false
            };

            yield return applicantCustomFieldValue;
        }
    }
}
