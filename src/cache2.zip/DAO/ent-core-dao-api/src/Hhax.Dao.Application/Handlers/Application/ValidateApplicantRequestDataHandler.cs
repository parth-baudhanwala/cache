﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Application;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Application;

public record ValidateApplicantRequestDataHandler(IReadOnlyRepository<ApplicantEntity> ApplicantReadonlyRepository,
                                                  IReadOnlyRepository<ComplianceTrainingSchoolEntity> TrainingSchoolsReadonlyRepository,
                                                  IReadOnlyRepository<MedicalsApplicantValueEntity> MedicalsReadOnlyRepository,
                                                  IReadOnlyRepository<OtherApplicantValueEntity> OtherRequirementsReadOnlyRepository,
                                                  IReadOnlyRepository<ComplianceI9RequirementEntity> I9RequirementsReadonlyRepository,
                                                  IReadOnlyRepository<ComplianceBackgroundCheckEntity> BackgroundCheckReadonlyRepository,
                                                  IAuthenticationService AuthenticationService,
                                                  IMediator Mediator,
                                                  IApplicantProfileService ApplicantProfileService,
                                                  IMapper Mapper,
                                                  ILogger<ValidateApplicantRequestDataHandler> Logger)
     : IRequestHandler<ValidateApplicantRequestDataCommand, Unit>
{
    public async Task<Unit> Handle(ValidateApplicantRequestDataCommand command, CancellationToken cancellationToken)
    {
        int officeId = command.OfficeId ?? await ApplicantReadonlyRepository.GetSingleColumnValue(x => x.Id == command.ApplicantId, y => y.OfficeId);

        GetApplicationFormApplicantRequirementsByOfficeIdQuery getApplicantRequirementsByOfficeIdQuery = new(officeId);
        IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements = await Mediator.Send(getApplicantRequirementsByOfficeIdQuery, cancellationToken);

        return command.Section switch
        {
            ApplicantEligibilitySection.I9 => await I9SectionValidation(command, applicantRequirements, officeId, cancellationToken),
            ApplicantEligibilitySection.Profile => ProfileValidation(command, applicantRequirements),
            ApplicantEligibilitySection.BackgroundCheck => await BackgroundCheckValidation(command, applicantRequirements),
            ApplicantEligibilitySection.TrainingSchools => await TraininigSchoolsValidation(command, applicantRequirements),
            ApplicantEligibilitySection.Availability => AvailabilityValidation(command, applicantRequirements),
            ApplicantEligibilitySection.ComplianceFields => ComplianceFieldsValidation(command, applicantRequirements),
            ApplicantEligibilitySection.MedicalsRequirements => await MedicalsRequirementsValidation(command, applicantRequirements),
            ApplicantEligibilitySection.OtherRequirements => await OtherRequirementsValidation(command, applicantRequirements),
            _ => Unit.Value
        };
    }

    private async Task<Unit> I9SectionValidation(ValidateApplicantRequestDataCommand command,
                                                 IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                 int officeId,
                                                 CancellationToken cancellationToken)
    {
        GetColumnAbDocumentsQuery getColumnAbDocumentsQuery = new(officeId);
        IEnumerable<I9ColumnABDocument> i9ColumnABDocuments = await Mediator.Send(getColumnAbDocumentsQuery, cancellationToken);

        ComplianceI9Requirement requirements = Mapper.Map<ComplianceI9Requirement>((UpsertI9RequirementCommand)command.RequestData);

        ComplianceI9RequirementEntity? applicantI9Requiremnts = await I9RequirementsReadonlyRepository.FirstOrDefaultAsync(x => x.ApplicantId == command.ApplicantId);

        if (applicantI9Requiremnts is not null)
        {
            if (requirements.ColumnABDocumentId.HasValue &&
            string.IsNullOrWhiteSpace(requirements.ColumnABDocumentFileKey) &&
            requirements.ColumnABDocumentId == applicantI9Requiremnts.ColumnABDocumentId)
                requirements.ColumnABDocumentFileKey = applicantI9Requiremnts.ColumnABDocumentFileKey;

            if (requirements.ColumnCDocumentId.HasValue &&
                string.IsNullOrWhiteSpace(requirements.ColumnCDocumentFileKey) &&
                requirements.ColumnCDocumentId == applicantI9Requiremnts.ColumnCDocumentId)
                requirements.ColumnCDocumentFileKey = applicantI9Requiremnts.ColumnCDocumentFileKey;
        }

        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantI9Section(i9ColumnABDocuments,
                                                           requirements,
                                                           applicantRequirements,
                                                           true,
                                                           true);

        return Unit.Value;
    }

    private Unit ProfileValidation(ValidateApplicantRequestDataCommand command,
                                   IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantProfileSection((ApplicantEntity)command.RequestData,
                                                                applicantRequirements);

        return Unit.Value;
    }

    private async Task<Unit> BackgroundCheckValidation(ValidateApplicantRequestDataCommand command,
                                           IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var backgroundData = (IEnumerable<ComplianceBackgroundCheckEntity>)command.RequestData;

        foreach (var item in backgroundData)
            if(item.Id > 0 && string.IsNullOrWhiteSpace(item.FileKey))
                item.FileKey = await BackgroundCheckReadonlyRepository.GetSingleColumnValue(x => x.Id == item.Id, y => y.FileKey);

        

        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantBackgroundCheckSection(backgroundData,
                                                                        applicantRequirements);

        return Unit.Value;
    }

    private async Task<Unit> TraininigSchoolsValidation(ValidateApplicantRequestDataCommand command,
                                                        IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var trainingSchoolsData = (IEnumerable<ComplianceTrainingSchoolEntity>)command.RequestData;

        ComplianceTrainingSchoolEntity? school = trainingSchoolsData.FirstOrDefault();

        if(school is not null && string.IsNullOrWhiteSpace(school.CertificateFileKey))
        {
            school.CertificateFileKey = await TrainingSchoolsReadonlyRepository.GetSingleColumnValue(x => x.Id == school.Id,
                                                                                                     y => y.CertificateFileKey);
        }

        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantTrainingSchoolsCheckSection(trainingSchoolsData,
                                                                             applicantRequirements,
                                                                             true,
                                                                             true);

        return Unit.Value;
    }

    private Unit AvailabilityValidation(ValidateApplicantRequestDataCommand command,
                                        IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantAvailabilitySection((IEnumerable<AvailabilityDayEntity>)command.RequestData, 
                                                                     applicantRequirements);

        return Unit.Value;
    }

    private Unit ComplianceFieldsValidation(ValidateApplicantRequestDataCommand command,
                                            IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantCustomComplianceSection((IEnumerable<ComplianceCustomFieldApplicantValue>)command.RequestData, 
                                                                         applicantRequirements);

        return Unit.Value;
    }

    private async Task<Unit> MedicalsRequirementsValidation(ValidateApplicantRequestDataCommand command,
                                                IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var medicalsData = (IEnumerable<MedicalsApplicantValue>)command.RequestData;

        MedicalsApplicantValue? medical = medicalsData.FirstOrDefault();

        if(medical is not null && string.IsNullOrWhiteSpace(medical.FileKey))
        {
            int? medicalId = medical.ComplianceExpItemId;
            medical.FileKey = medicalId.HasValue ? await MedicalsReadOnlyRepository.GetSingleColumnValue(x => x.ApplicantId == command.ApplicantId && x.ComplianceExpItemId == medicalId,
                                                                                                         y => y.FileKey) : null;
        }

        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantMedicalsCheckSection(medicalsData,
                                                                      applicantRequirements);

        return Unit.Value;
    }

    private async Task<Unit> OtherRequirementsValidation(ValidateApplicantRequestDataCommand command,
                                             IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var othersData = (IEnumerable<OtherApplicantValue>)command.RequestData;

        OtherApplicantValue? other = othersData.FirstOrDefault();

        if(other is not null && string.IsNullOrWhiteSpace(other.FileKey))
        {
            int? otherId = othersData.FirstOrDefault()?.ComplianceExpItemId;
            other.FileKey = otherId.HasValue ? await OtherRequirementsReadOnlyRepository.GetSingleColumnValue(x => x.ApplicantId == command.ApplicantId && x.ComplianceExpItemId == otherId,
                                                                                                                y => y.FileKey) : null;
        }

        

        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantOtherDocumentsCheckSection(othersData,
                                                                            applicantRequirements);

        return Unit.Value;
    }

    private async Task<Unit> InServiceValidation(ValidateApplicantRequestDataCommand command,
                                                 IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                 int officeId,
                                                 CancellationToken cancellationToken)
    {
        var topicsValues = await Mediator.Send(new GetTopicsQuery(officeId), cancellationToken);

        ApplicantProfileService.ThrowExceptionIfNotValid()
                               .ValidateApplicantInServiceSection((IEnumerable<ApplicantInServiceTableItem>)command.RequestData,
                                                                  topicsValues,
                                                                  applicantRequirements);

        return Unit.Value;
    }
}
