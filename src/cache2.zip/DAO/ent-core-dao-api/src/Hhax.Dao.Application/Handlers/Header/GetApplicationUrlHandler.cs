﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Feature;
using Hhax.Dao.Infrastructure.Abstracts.Entities.AppServer;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Feature
{
    public class GetApplicationUrlHandler : IRequestHandler<GetApplicationUrlQuery, Dictionary<int, string?>>
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IReadOnlyRepository<AppServerDetailsEntity> _appServerDetailsRepository;
        private readonly IReadOnlyRepository<AppServersEntity> _appServerRepository;
        private readonly ILogger<GetApplicationUrlHandler> _logger;

        public GetApplicationUrlHandler(IAuthenticationService authenticationService,
                                        IReadOnlyRepository<AppServerDetailsEntity> appServerDetailsRepository,
                                        IReadOnlyRepository<AppServersEntity> appServerRepository,
                                        ILogger<GetApplicationUrlHandler> logger)
        {
            _authenticationService = authenticationService;
            _appServerDetailsRepository = appServerDetailsRepository;
            _appServerRepository = appServerRepository;
            _logger = logger;
        }

        public async Task<Dictionary<int, string?>> Handle(GetApplicationUrlQuery request, CancellationToken cancellationToken)
        {
            int currentUserId = _authenticationService.GetUserId();

            _logger.LogInformation("Getting URLs for user with Id: '{currentUserId}'.", currentUserId);

            var urlDictionary = await _appServerDetailsRepository.GetQuery()
                                                  .Where(x => request.AppVersionIDs.Contains(x.AppVersionID!.Value)
                                                              && x.Version == request.Version
                                                              && x.MinorVersion == request.MinorVersion
                                                              && !string.IsNullOrWhiteSpace(x.URL))
                                                  .ToDictionaryAsync(x => x.AppVersionID!.Value, y => y.URL, cancellationToken: cancellationToken);

            var otherAppVersionIDs = request.AppVersionIDs.Where(x => !urlDictionary.ContainsKey(x) || string.IsNullOrWhiteSpace(urlDictionary[x]));

            if (otherAppVersionIDs.Any())
            {
                var otherUrlDictionary = await _appServerRepository.GetQuery()
                                                 .Where(x => otherAppVersionIDs.Contains(x.AppVersionID!.Value))
                                                 .ToDictionaryAsync(x => x.AppVersionID!.Value, y => y.RCUrl ?? y.Url, cancellationToken: cancellationToken);

                urlDictionary = urlDictionary.Concat(otherUrlDictionary).ToDictionary(x => x.Key, y => y.Value);
            }

            _logger.LogInformation("URLs were retrieved for user with Id: '{currentUserId}'.", currentUserId);

            return urlDictionary;
        }
    }
}
