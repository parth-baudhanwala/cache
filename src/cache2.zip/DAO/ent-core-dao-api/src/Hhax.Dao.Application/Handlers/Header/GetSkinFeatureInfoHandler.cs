﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Feature;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using Hhax.Dao.Application.Queries.Feature;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Feature
{
    public class GetSkinFeatureInfoHandler : IRequestHandler<GetSkinFeatureInfoQuery, SkinFeatureInfoResponse>
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IMediatorService _mediatorService;

        private readonly IReadOnlyRepository<UserInfoEntity> _userInfoRepository;
        private readonly IReadOnlyRepository<VendorEntity> _vendorRepository;
        private readonly IReadOnlyRepository<StateAreaCodeEntity> _stateAreaCodeRepository;

        private readonly SettingsConfiguration _settings;

        private readonly IHhaStoredProceduresManager _storedProceduresManager;

        private readonly ILogger<GetSkinFeatureInfoHandler> _logger;

        public GetSkinFeatureInfoHandler(IAuthenticationService authenticationService,
                                         IMediatorService mediatorService,
                                         IReadOnlyRepository<UserInfoEntity> userInfoRepository,
                                         IReadOnlyRepository<VendorEntity> vendorRepository,
                                         IReadOnlyRepository<StateAreaCodeEntity> stateAreaCodeRepository,
                                         IOptions<SettingsConfiguration> settings,
                                         IHhaStoredProceduresManager storedProceduresManager,
                                         ILogger<GetSkinFeatureInfoHandler> logger)
        {
            _authenticationService = authenticationService;
            _mediatorService = mediatorService;

            _userInfoRepository = userInfoRepository;
            _vendorRepository = vendorRepository;
            _stateAreaCodeRepository = stateAreaCodeRepository;

            _settings = settings.Value;

            _storedProceduresManager = storedProceduresManager;

            _logger = logger;
        }

        public async Task<SkinFeatureInfoResponse> Handle(GetSkinFeatureInfoQuery request, CancellationToken cancellationToken)
        {
            int currentUserId = _authenticationService.GetUserId();

            _logger.LogInformation($"Getting skin feature info for user with Id: '{currentUserId}'.");

            UserInfoEntity user = await GetUser(currentUserId);
            VendorEntity vendor = await GetVendor(currentUserId);
            string stateName = await GetStateName(vendor.State);

            FeatureResponse feature = await _mediatorService.SendAsync<GetFeatureQuery, FeatureResponse>(new());

            int[] appVersionIDs = new int[4]
            {
                _settings.ENTMainAppVersionID,
                _settings.ENTPAPIAppVersionID,
                _settings.MobileChatAppVersionID,
                _settings.FormBuilderAppVersionID
            };

            GetApplicationUrlQuery getApplicationUrlQuery = new(appVersionIDs)
            {
                ProviderId = vendor.Id,
                Version = vendor.ProviderVersion!.Value,
                MinorVersion = vendor.ProviderMinorVersion!.Value
            };

            var urls = await _mediatorService.SendAsync<GetApplicationUrlQuery, Dictionary<int, string?>>(getApplicationUrlQuery);

            bool hasMobileChatPermission = await HasMobileChatPermission(user, vendor, currentUserId);

            var response = new SkinFeatureInfoResponse()
            {
                ProviderId = vendor.Id,
                ProviderName = vendor.Name,
                StateCode = vendor.State,
                State = stateName,
                Version = vendor.ProviderVersion,
                MinorVersion = vendor.ProviderMinorVersion,
                ENTUrl = urls[_settings.ENTMainAppVersionID],
                ENTPApiUrl = urls[_settings.ENTPAPIAppVersionID],
                MobileChatURL = urls[_settings.MobileChatAppVersionID],
                FormBuilderUrl = urls[_settings.FormBuilderAppVersionID],
                HasAccessToMobileChat = hasMobileChatPermission,
                IsNewSkin = feature.IsNewSkin,
                IsTexasRedirection = feature.IsTexasRedirection,
                IsTexasEnterpriseFree= feature.IsTexasEnterpriseFree
            };

            _logger.LogInformation($"Skin feature info was retrieved for user with Id: '{currentUserId}'.");

            return response;
        }

        private async Task<UserInfoEntity> GetUser(int currentUserId)
        {
            UserInfoEntity? user = await _userInfoRepository.FirstOrDefaultAsync(x => x.Id == currentUserId);
            if (user == null)
            {
                string message = $"User with Id: '{currentUserId}' was not found in the DB.";
                _logger.LogError(message);
                throw new EntityNotFoundException(message);
            }

            return user;
        }

        private async Task<VendorEntity> GetVendor(int currentUserId)
        {
            int currentUserVendorId = _authenticationService.GetAgencyId();

            VendorEntity? vendor = await _vendorRepository.FirstOrDefaultAsync(x => x.Id == currentUserVendorId);
            if (vendor == null)
            {
                string message = $"Vendor with Id: '{currentUserVendorId}' in the token " +
                    $"for user with Id: '{currentUserId}' was not found in the DB.";
                _logger.LogError(message);
                throw new EntityNotFoundException(message);
            }

            return vendor;
        }

        private async Task<string> GetStateName(string? stateCode)
        {
            if (string.IsNullOrEmpty(stateCode)) return string.Empty;

            var state = await _stateAreaCodeRepository.FirstOrDefaultAsync(x => x.StateCode == stateCode);

            return state?.StateName ?? string.Empty;
        }

        private async Task<bool> HasMobileChatPermission(UserInfoEntity user, VendorEntity vendor, int currentUserId)
        {
            string? mobileChatPermissionName = _settings.MobileChatPermission;

            if (string.IsNullOrWhiteSpace(mobileChatPermissionName))
            {
                throw new NullValueException(nameof(mobileChatPermissionName));
            }

            var menuItems = new string[]
            {
                mobileChatPermissionName
            };

            PermissionSPResponse permissionResult = await _storedProceduresManager
                .CheckAccess(currentUserId, menuItems, user.UserType, vendor.ProviderVersion, vendor.ProviderMinorVersion);

            if (permissionResult.AvailiablePermissions.Contains(mobileChatPermissionName))
            {
                return await _storedProceduresManager.CheckCaregiverChatAccess(currentUserId);
            }

            return false;
        }
    }
}
