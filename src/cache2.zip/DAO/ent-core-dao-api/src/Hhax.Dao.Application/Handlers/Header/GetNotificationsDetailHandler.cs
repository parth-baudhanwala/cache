﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Header;
using Hhax.Dao.Application.Queries.Header;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Feature
{
    public class GetNotificationsDetailHandler : IRequestHandler<GetNotificationsDetailQuery, NotificationsDetailResponse>
    {
        private readonly IAuthenticationService _authenticationService;

        private readonly IReadOnlyRepository<UserInfoEntity> _userInfoRepository;
        private readonly IReadOnlyRepository<VendorEntity> _vendorRepository;

        private readonly IHhaStoredProceduresManager _storedProceduresManager;

        private readonly IMapper _mapper;
        private readonly ILogger<GetNotificationsDetailHandler> _logger;

        public GetNotificationsDetailHandler(IAuthenticationService authenticationService, IReadOnlyRepository<UserInfoEntity> userInfoRepository,
            IReadOnlyRepository<VendorEntity> vendorRepository, IHhaStoredProceduresManager storedProceduresManager,
            IMapper mapper, ILogger<GetNotificationsDetailHandler> logger)
        {
            _authenticationService = authenticationService;

            _userInfoRepository = userInfoRepository;
            _vendorRepository = vendorRepository;

            _storedProceduresManager = storedProceduresManager;

            _mapper = mapper;
            _logger = logger;
        }

        public async Task<NotificationsDetailResponse> Handle(GetNotificationsDetailQuery request, CancellationToken cancellationToken)
        {
            int currentUserId = _authenticationService.GetUserId();

            _logger.LogInformation($"Getting notifications details for user with Id: '{currentUserId}'.");

            UserInfoEntity user = await GetUser(currentUserId);
            VendorEntity vendor = await GetVendor(currentUserId);

            NotificationsDetailSPResponse spResult =
                await _storedProceduresManager.GetUserNotificationsCountAll(currentUserId, vendor.Id, user.UserType, vendor.ProviderVersion, vendor.ProviderMinorVersion);

            NotificationsDetailResponse result = _mapper.Map<NotificationsDetailResponse>(spResult);

            _logger.LogInformation($"Notifications details for user with Id: '{currentUserId}' were successfully retrieved.");

            return result;
        }
        private async Task<UserInfoEntity> GetUser(int currentUserId)
        {
            UserInfoEntity? user = await _userInfoRepository.FirstOrDefaultAsync(x => x.Id == currentUserId);
            if (user == null)
            {
                string message = $"User with Id: '{currentUserId}' was not found in the DB.";
                _logger.LogError(message);
                throw new EntityNotFoundException(message);
            }

            return user;
        }

        private async Task<VendorEntity> GetVendor(int currentUserId)
        {
            int currentUserVendorId = _authenticationService.GetAgencyId();

            VendorEntity? vendor = await _vendorRepository.FirstOrDefaultAsync(x => x.Id == currentUserVendorId);
            if (vendor == null)
            {
                string message = $"Vendor with Id: '{currentUserVendorId}' in the token " +
                    $"for user with Id: '{currentUserId}' was not found in the DB.";
                _logger.LogError(message);
                throw new EntityNotFoundException(message);
            }

            return vendor;
        }
    }
}
