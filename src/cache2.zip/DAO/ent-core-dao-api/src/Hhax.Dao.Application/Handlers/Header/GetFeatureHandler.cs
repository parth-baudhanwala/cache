﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Feature;
using Hhax.Dao.Application.Queries.Feature;
using Hhax.Dao.Common.Extensions;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Feature;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Feature
{
    public class GetFeatureHandler : IRequestHandler<GetFeatureQuery, FeatureResponse>
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly IReadOnlyRepository<FeatureEntity> _featureRepository;
        private readonly IReadOnlyRepository<VendorFeatureEntity> _vendorfeatureRepository;
        private readonly IReadOnlyRepository<ProviderTagDetailEntity> _providerTagDetailRepository;

        private readonly ILogger<GetFeatureHandler> _logger;

        public GetFeatureHandler(IServiceProvider serviceProvider,
                                  ILogger<GetFeatureHandler> logger)
        {
            _authenticationService = serviceProvider.GetService<IAuthenticationService>()!;
            _featureRepository = serviceProvider.GetService<IReadOnlyRepository<FeatureEntity>>()!;
            _vendorfeatureRepository = serviceProvider.GetService<IReadOnlyRepository<VendorFeatureEntity>>()!;
            _providerTagDetailRepository = serviceProvider.GetService<IReadOnlyRepository<ProviderTagDetailEntity>>()!;
            _logger = logger;
        }

        public async Task<FeatureResponse> Handle(GetFeatureQuery request, CancellationToken cancellationToken)
        {
            int userId = _authenticationService.GetUserId();
            int providerId = request.ProviderId ?? _authenticationService.GetAgencyId();

            _logger.LogInformation("Getting header type and for user with Id: '{userId}'.", userId);

            FeatureEntity? newSkinFeature = await _featureRepository
                                    .FirstOrDefaultAsync(x => x.FeatureName == SkinFeatureType.NewSkin.GetDisplayName());

            if (newSkinFeature == null)
            {
                string message = "New skin feature was not found in the DB.";
                _logger.LogError("{message}", message);
                throw new EntityNotFoundException(message);
            }

            VendorFeatureEntity? newSkinForCurrentUserFeature = await _vendorfeatureRepository
                                    .FirstOrDefaultAsync(x => x.VendorId == providerId && x.FeatureId == newSkinFeature.Id);

            var tags = _providerTagDetailRepository.GetQuery()
                                .Where(x => x.ProviderId == providerId
                                            && x.ProviderTag!.ProviderTagType == ProviderTagType.Region.ToString()
                                            && x.ProviderTag!.ProviderTagType == x.ProviderTagType)
                                .Select(x => x.ProviderTag!.ProviderTagName ?? string.Empty);

          
           

            bool texasTag = tags.Any(x => x.StartsWith("TX_SPS") || x.StartsWith("TX_MCO"));
            bool nonTexasTag = tags.Any(x => !x.StartsWith("TX_SPS") && !x.StartsWith("TX_MCO"));
            bool texasEnterpriseFree = false;
            if (texasTag)
            {
                var txFree = _providerTagDetailRepository.GetQuery()
                              .Where(x => x.ProviderId == providerId
                                          && x.ProviderTag!.ProviderTagType == ProviderTagType.Platform.ToString()
                                          && x.ProviderTag!.ProviderTagType == x.ProviderTagType)
                              .Select(x => x.ProviderTag!.ProviderTagName ?? string.Empty);
                texasEnterpriseFree = txFree.Any(x => x.StartsWith("Enterprise-Free"));

            }
            _logger.LogInformation("Header type was retrieved for user with Id: '{userId}'.", userId);

            return new FeatureResponse()
            {
                IsNewSkin = newSkinForCurrentUserFeature != null,
                IsTexasRedirection = texasTag && !nonTexasTag, 
                IsTexasEnterpriseFree  = texasEnterpriseFree
            };
        }
    }
}
