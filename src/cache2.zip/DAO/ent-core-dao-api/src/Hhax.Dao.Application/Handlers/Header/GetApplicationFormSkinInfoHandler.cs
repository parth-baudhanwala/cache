﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Feature;
using Hhax.Dao.Application.Abstracts.Responses.Header;
using Hhax.Dao.Application.Queries.Feature;
using Hhax.Dao.Application.Queries.Header;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Header;

public class GetApplicationFormSkinInfoHandler : IRequestHandler<GetApplicationFormSkinInfoQuery, ApplicationFormSkinInfo>
{
    private readonly IMediatorService _mediatorService;
    private readonly IReadOnlyRepository<OfficeInfoEntity> _officeInfoRepository;
    private readonly IReadOnlyRepository<VendorEntity> _vendorRepository;
    private readonly ILogger<GetApplicationFormSkinInfoHandler> _logger;

    public GetApplicationFormSkinInfoHandler(IMediatorService mediatorService,
                                             IReadOnlyRepository<OfficeInfoEntity> officeInfoRepository,
                                             IReadOnlyRepository<VendorEntity> vendorRepository,
                                             ILogger<GetApplicationFormSkinInfoHandler> logger)
    {
        _mediatorService = mediatorService;
        _officeInfoRepository = officeInfoRepository;
        _vendorRepository = vendorRepository;
        _logger = logger;
    }

    public async Task<ApplicationFormSkinInfo> Handle(GetApplicationFormSkinInfoQuery request, CancellationToken cancellationToken)
    {
        VendorEntity vendor = await GetVendor(request.OfficeId);

        GetFeatureQuery featureQuery = new()
        {
            ProviderId = vendor.Id
        };

        FeatureResponse feature = await _mediatorService.SendAsync<GetFeatureQuery, FeatureResponse>(featureQuery);

        ApplicationFormSkinInfo applicationFormSkinInfo = new()
        {
            ProviderId = vendor.Id,
            ProviderName = vendor.Name,
            Version = vendor.ProviderVersion,
            MinorVersion = vendor.ProviderMinorVersion,
            IsNewSkin = feature.IsNewSkin,
            IsTexasRedirection = feature.IsTexasRedirection,
            IsTexasEnterpriseFree= feature.IsTexasEnterpriseFree
            
        };

        return applicationFormSkinInfo;
    }

    private async Task<VendorEntity> GetVendor(int officeId)
    {
        var office = await _officeInfoRepository.GetByIdAsync(officeId);

        if (office == null)
        {
            string message = $"Office with Id: '{officeId}' was not found in the database.";
            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        VendorEntity? vendor = await _vendorRepository.GetByIdAsync(office.VendorId);

        if (vendor == null)
        {
            string message = $"Vendor with Id: '{office.VendorId}' for office with Id: '{officeId}' was not found in the database.";
            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        return vendor;
    }
}
