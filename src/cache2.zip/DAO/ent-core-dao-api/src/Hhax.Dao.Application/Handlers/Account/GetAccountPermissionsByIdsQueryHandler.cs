﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using Hhax.Dao.Application.Queries.Account;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Account;

public class GetAccountPermissionsByIdsQueryHandler : IRequestHandler<GetAccountPermissionsByIdsQuery, PermissionsResponse>
{
    private readonly IMediator _mediator;
    private readonly IAuthenticationService _authenticationService;

    private readonly ILogger<GetAccountPermissionsByIdsQueryHandler> _logger;

    public GetAccountPermissionsByIdsQueryHandler(IMediator mediator,
                                                  IAuthenticationService authenticationService,
                                                  ILogger<GetAccountPermissionsByIdsQueryHandler> logger)
    {
        _mediator = mediator;
        _authenticationService = authenticationService;

        _logger = logger;
    }

    public async Task<PermissionsResponse> Handle(GetAccountPermissionsByIdsQuery request, CancellationToken cancellationToken)
    {
        var userId = _authenticationService.GetUserId();

        _logger.LogInformation("Handle with params: UserId={int userId}", userId);

        var hhaxPermissions = Enum.GetValues(typeof(HhaxPermissions))
                                  .Cast<HhaxPermissions>()
                                  .Select(hhaxPermission => (int)hhaxPermission)
                                  .ToArray();

        var query = new GetPermissionsByIdsQuery(userId, hhaxPermissions);

        var permissions = await _mediator.Send(query, cancellationToken);

        var response = new PermissionsResponse
        {
            Permissions = permissions.Select(permission => (HhaxPermissions)permission).ToArray()
        };

        _logger.LogInformation("Handle with params: UserId={userId} was called successfully.", userId);

        return response;
    }
}
