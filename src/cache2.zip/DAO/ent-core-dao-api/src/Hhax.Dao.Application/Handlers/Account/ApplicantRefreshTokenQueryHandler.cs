﻿using Hhax.Dao.Application.Queries.Account;
using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Models.Responses;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Account
{
    public class ApplicantRefreshTokenQueryHandler : IRequestHandler<ApplicantRefreshTokenQuery, TokenResponse>
    {
        private readonly IIdentityClient _identityClient;
        private readonly ILogger<ApplicantRefreshTokenQueryHandler> _logger;

        public ApplicantRefreshTokenQueryHandler(ILogger<ApplicantRefreshTokenQueryHandler> logger, IIdentityClient identityClient)
        {
            _logger = logger;
            _identityClient = identityClient;
        }

        public async Task<TokenResponse> Handle(ApplicantRefreshTokenQuery request,
            CancellationToken cancellationToken)
        {
            TokenResponse tokenResponse = new();

            try
            {
                tokenResponse =
                   await _identityClient.AccountsClient.GetTokenWithRefreshTokenAsync(request.RefreshToken!);

                if (tokenResponse.AccessToken == null)
                {
                    _logger.LogInformation(
                        "Identity refresh token process failed for applicant. Refresh token is not valid or expired");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Unable to receive token response from Identity service for applicant");
                return tokenResponse;
            }

            return tokenResponse;
        }
    }
}