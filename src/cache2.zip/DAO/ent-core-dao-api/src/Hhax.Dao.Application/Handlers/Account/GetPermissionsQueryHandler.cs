﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using Hhax.Dao.Application.Queries.Account;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Account;

public class GetPermissionsQueryHandler : IRequestHandler<GetPermissionsQuery, PermissionsResponse>
{
    private readonly IMediator _mediator;
    private readonly IAuthenticationService _authenticationService;

    private readonly ILogger<GetPermissionsQueryHandler> _logger;

    public GetPermissionsQueryHandler(IMediator mediator,
                                      IAuthenticationService authenticationService,
                                      ILogger<GetPermissionsQueryHandler> logger)
    {
        _mediator = mediator;
        _authenticationService = authenticationService;

        _logger = logger;
    }

    public async Task<PermissionsResponse> Handle(GetPermissionsQuery request, CancellationToken cancellationToken)
    {
        var userId = _authenticationService.GetUserId();

        _logger.LogInformation("Handle with params: UserId={int userId}", userId);

        var query = new GetPermissionsByNamesQuery(userId, EnumsExtensions.GetValuesByType(HhaxPermissions.CanViewApplicationProcessManagement));

        var permissions = await _mediator.Send(query, cancellationToken);

        var response = new PermissionsResponse
        {
            Permissions = permissions.Select(permission => EnumsExtensions.GetEnum<HhaxPermissions>(permission)).ToArray()
        };

        _logger.LogInformation("Handle was called successfully.");

        return response;
    }
}
