﻿using Hhax.Dao.Application.Queries.Account;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Account;

public class GetPermissionsByNamesQueryHandler : IRequestHandler<GetPermissionsByNamesQuery, IEnumerable<string>>
{
    private readonly IDbContextFactory<HhaDbContext> _dbContextFactory;
    
    private readonly ILogger<GetPermissionsByNamesQueryHandler> _logger;

    public GetPermissionsByNamesQueryHandler(IDbContextFactory<HhaDbContext> dbContextFactory, 
                                             ILogger<GetPermissionsByNamesQueryHandler> logger)
    {
        _dbContextFactory = dbContextFactory;
     
        _logger = logger;
    }

    public async Task<IEnumerable<string>> Handle(GetPermissionsByNamesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("GetPermissionsAsync with params: UserId={userId}", request.UserId);

        using var context = await _dbContextFactory.CreateDbContextAsync(cancellationToken);
        var query = (from roleMenuPermissionMapping in context.RoleMenuPermissionMappings

                     join menuPermission in context.MenuPermissions! on roleMenuPermissionMapping.MenuId equals menuPermission.Id

                     join officeRoleMapping in context.OfficeRoleMappings! on roleMenuPermissionMapping.OfficeRoleId equals officeRoleMapping.Id

                     join roleMapping in context.RoleMappings! on officeRoleMapping.RoleId equals roleMapping.RoleId

                     join userRoleMapping in context.UserRoleMappings! on roleMapping.RoleId equals userRoleMapping.RoleId

                     join user in context.Users! on userRoleMapping.UserName equals user.UserName

                     where request.Permissions!.Contains(menuPermission.Name) && user.Id == request.UserId

                     select menuPermission.Name).Distinct().AsQueryable();

        var response = await query.ToArrayAsync(cancellationToken: cancellationToken);

        _logger.LogInformation("GetPermissionsAsync with params: UserId={userId} was called successfully.", request.UserId);

        return response;
    }
}
