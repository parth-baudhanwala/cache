﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using Hhax.Dao.Application.Commands.Account;
using Hhax.Dao.Application.Queries.Account;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Account;

public class ValidatePermissionsHandler : IRequestHandler<ValidatePermissionsCommand, ValidatePermissionsResponse>
{
    private readonly IMediator _mediator;
    private readonly IAuthenticationService _authenticationService;

    private readonly ILogger<ValidatePermissionsHandler> _logger;

    public ValidatePermissionsHandler(IMediator mediator,
                                      IAuthenticationService authenticationService,
                                      ILogger<ValidatePermissionsHandler> logger)
    {
        _mediator = mediator;
        _authenticationService = authenticationService;

        _logger = logger;
    }

    public async Task<ValidatePermissionsResponse> Handle(ValidatePermissionsCommand request, CancellationToken cancellationToken)
    {
        var userId = _authenticationService.GetUserId();

        _logger.LogInformation("Handle with params: UserId={userId}", userId);

        var query = new GetPermissionsByNamesQuery(userId, request.Permissions!.Select(permission => EnumsExtensions.GetValue(permission)).ToArray());

        var permissions = await _mediator.Send(query, cancellationToken);

        var hhaxPermissions = permissions.Select(permission => EnumsExtensions.GetEnum<HhaxPermissions>(permission)).ToArray();

        var response = new ValidatePermissionsResponse
        {
            IsAccessDenied = !request.Permissions!.All(permission => hhaxPermissions.Any(hhaxPermission => hhaxPermission == permission))
        };

        _logger.LogInformation("Handle with params: UserId={userId} was called successfully.", userId);

        return response;
    }
}
