﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Account;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Account;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Models.Responses;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Account;

public class LoginApplicantQueryHandler : IRequestHandler<ApplicantLoginQuery, ApplicantLoginResponse>
{
    private readonly IReadOnlyRepository<ApplicantEntity> _applicantRepository;
    private readonly IIdentityClient _identityClient;
    private readonly ILogger<LoginApplicantQueryHandler> _logger;
    private readonly IMediatorService _mediatorService;

    public LoginApplicantQueryHandler(ILogger<LoginApplicantQueryHandler> logger,
                                      IReadOnlyRepository<ApplicantEntity> applicantRepository,
                                      IIdentityClient identityClient,
                                      IMediatorService mediatorService)
    {
        _logger = logger;
        _applicantRepository = applicantRepository;
        _identityClient = identityClient;
        _mediatorService = mediatorService;
    }

    public async Task<ApplicantLoginResponse> Handle(ApplicantLoginQuery request, CancellationToken cancellationToken)
    {
        ApplicantLoginResponse result = new();

        ApplicantEntity? user = await _applicantRepository
                                .FirstOrDefaultAsync(x => x.LoginEmail!.ToLower() == request.Email!.ToLower());

        if (user == null)
        {
            _logger.LogInformation("No applicant found with provided email: [{email}]", request.Email);
            result.IsInvalid = true;
            return result;
        }

        if (!user.IsActive || !user.IsVerified)
        {
            _logger.LogInformation("Applicant with provided email is inactive or not verified: [{email}]", request.Email);
            result.IsLocked = true;
            return result;
        }

        try
        {
            ResourceOwnerTokenResponse identityLoginResult =
                await _identityClient.AccountsClient.GetTokenWithResourceOwnerPasswordAsync(request.Email!,
                    request.Password!);

            if (identityLoginResult.AccessToken == null)
            {
                _logger.LogInformation(
                    "Identity authorization failed for applicant with Id: [{userID}] with error: [{error}]",
                    user.Id, identityLoginResult.ErrorDescription);

                result.IsLocked = identityLoginResult.IsLocked;
                if (!result.IsLocked)
                {
                    result.IsInvalid = true;
                }
            }
            else
            {
                result.AccessToken = identityLoginResult.AccessToken;
                result.RefreshToken = identityLoginResult.RefreshToken;
                result.DbSession = identityLoginResult.DBSession;

                if (request.ApplicationLanguageId > 0 && request.ApplicationLanguageId != user.ApplicationLanguageId)
                {
                    UpdateApplicantApplicationLanguageCommand command = new()
                    {
                        ApplicantId = user.Id,
                        LanguageId = request.ApplicationLanguageId
                    };

                    await _mediatorService.SendAsync<UpdateApplicantApplicationLanguageCommand, BaseResponse>(command);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Unable to receive token response from Identity service for applicant with Id: [{userId}] ",
                user.Id);
            result.IsLocked = true;
            return result;
        }

        return result;
    }
}
