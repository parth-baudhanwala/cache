﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public record GetBackgroundCheckResultsQueryHandler(ILookupService<ComplianceSetupOffice, ComplianceSetupOfficeEntity> ComplianceSetupOfficeLookups,
                                                     IAuthenticationService AuthenticationService,
                                                     ILookupService<BackgroundCheckResponse, BackgroundCheckResultEntity> BackgroundCheckResultLookups,
                                                     ILogger<GetBackgroundCheckResultsQueryHandler> Logger)
    : IRequestHandler<GetBackgroundCheckResultsQuery, IEnumerable<BackgroundCheckResponse>>
{
    private const string _activeStatus = "Active";

    public async Task<IEnumerable<BackgroundCheckResponse>> Handle(GetBackgroundCheckResultsQuery request, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        var agencyId = AuthenticationService.GetAgencyId();

        var compliacneSetupOffices = await ComplianceSetupOfficeLookups.FindAsync(x => x.ProviderId == agencyId && x.OfficeId == request.OfficeId);

        if (compliacneSetupOffices.Any())
        {
            var complianceSetupOffice = compliacneSetupOffices.OrderByDescending(x => x.PublishVersion).First();

            var response = await BackgroundCheckResultLookups.FindAsync(x => x.ComplianceSetupId == complianceSetupOffice.ComplianceSetupId &&
                                                                             x.AgencyId == agencyId &&
                                                                             x.Status == _activeStatus);

            Logger.LogInformation("Background Check Results were retrieved successfully.");

            return response;
        }

        Logger.LogInformation("Background Check Results not found.");

        return Enumerable.Empty<BackgroundCheckResponse>();
    }
}
