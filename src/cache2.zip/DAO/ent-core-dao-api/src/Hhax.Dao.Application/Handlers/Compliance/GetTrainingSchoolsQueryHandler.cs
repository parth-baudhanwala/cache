﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class GetTrainingSchoolsQueryHandler : IRequestHandler<GetTrainingSchoolsQuery, IEnumerable<TrainingSchool>>
{
    private readonly ILookupService<ComplianceSetupOffice, ComplianceSetupOfficeEntity> _compliancesSetupsLookupService;
    private readonly ILookupService<TrainingSchool, TrainingSchoolEntity> _trainingSchoolsLookupService;

    private readonly IAuthenticationService _authenticationService;

    private readonly ILogger<GetTrainingSchoolsQueryHandler> _logger;

    public GetTrainingSchoolsQueryHandler(ILookupService<ComplianceSetupOffice, ComplianceSetupOfficeEntity> compliancesSetupsLookupService,
                                          ILookupService<TrainingSchool, TrainingSchoolEntity> trainingSchoolsLookupService,
                                          IAuthenticationService authenticationService,
                                          ILogger<GetTrainingSchoolsQueryHandler> logger)
    {
        _compliancesSetupsLookupService = compliancesSetupsLookupService;

        _trainingSchoolsLookupService = trainingSchoolsLookupService;
        _authenticationService = authenticationService;
        
        _logger = logger;
    }

    public async Task<IEnumerable<TrainingSchool>> Handle(GetTrainingSchoolsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        const string activeStatus = "Active";

        var agencyId = _authenticationService.GetAgencyId();

        IEnumerable<ComplianceSetupOffice> compliacneSetupOffices = await _compliancesSetupsLookupService.FindAsync(x => x.ProviderId == agencyId && 
                                                                                                                         x.OfficeId == request.OfficeId);

        if (compliacneSetupOffices.Any())
        {
            var complianceSetupOffice = compliacneSetupOffices.OrderByDescending(x => x.PublishVersion).First();

            var schools = await _trainingSchoolsLookupService.FindAsync(x => x.ComplianceSetupId == complianceSetupOffice.ComplianceSetupId &&
                                                                             x.ProviderId == complianceSetupOffice.ProviderId &&
                                                                             x.Status == activeStatus);
            if (schools.Any())
            {
                _logger.LogInformation("Training Schools were retrieved successfully.");

                return schools.ToList();
            }
        }

        _logger.LogInformation("Training Schools not found.");

        return Enumerable.Empty<TrainingSchool>();
    }
}
