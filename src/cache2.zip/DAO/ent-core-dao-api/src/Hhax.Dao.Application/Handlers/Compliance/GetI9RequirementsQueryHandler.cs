﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class GetI9RequirementsQueryHandler : IRequestHandler<GetI9RequirementsQuery, ComplianceI9Requirement>
{
    private readonly IGenericRepository<ComplianceI9RequirementEntity> _i9RequirementsRepository;

    private readonly IMapper _mapper;
    private readonly IMediatorService _mediator;
    private readonly ILogger<GetI9RequirementsQueryHandler> _logger;

    public GetI9RequirementsQueryHandler(IGenericRepository<ComplianceI9RequirementEntity> i9RequirementsRepository,
                                         IMapper mapper,
                                         IMediatorService mediator,
                                         ILogger<GetI9RequirementsQueryHandler> logger)
    {
        _i9RequirementsRepository = i9RequirementsRepository;
        _mapper = mapper;
        _mediator = mediator;
        _logger = logger;
    }

    public async Task<ComplianceI9Requirement> Handle(GetI9RequirementsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var entity = await _i9RequirementsRepository.FirstOrDefaultAsync(x => x.ApplicantId == request.ApplicantId);
        var response = _mapper.Map<ComplianceI9Requirement>(entity);

        if (response is not null)
        {
            GetApplicantSignatureCommand signatureCommand = new(request.ApplicantId, response.Id, new int[1] { (int)ApplicationFormApplicantSections.GeneralCompliance });
            response.Signature = (await _mediator.SendAsync<GetApplicantSignatureCommand, IEnumerable<Signature>>(signatureCommand)).FirstOrDefault();
        }

        _logger.LogInformation("I9 Requirements were retrieved successfully.");

        return response ?? new();
    }
}
