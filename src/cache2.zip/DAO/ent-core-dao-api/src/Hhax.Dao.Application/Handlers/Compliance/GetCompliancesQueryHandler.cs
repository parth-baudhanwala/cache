﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance
{
    public class GetCompliancesQueryHandler : IRequestHandler<GetCompliancesQuery, CompliancesResponse>
    {
        private readonly IReadOnlyRepository<OfficeInfoEntity> _officeInfoEntityRepository;
        private readonly IReadOnlyRepository<ComplianceSetupEntity> _complianceSetupEntityRepository;
        private readonly IReadOnlyRepository<ComplianceSetupOfficeEntity> _complianceSetupOfficeEntityRepository;
        private readonly IReadOnlyRepository<ApplicationFormOfficeMappingEntity> _applicationFormOfficeMappingEntityRepository;

        private readonly IAuthenticationService _authenticationService;

        private readonly ILogger<GetCompliancesQueryHandler> _logger;

        public GetCompliancesQueryHandler(
            IReadOnlyRepository<OfficeInfoEntity> officeInfoEntityRepository,
            IReadOnlyRepository<ComplianceSetupOfficeEntity> complianceSetupOfficeEntityRepository,
            IReadOnlyRepository<ComplianceSetupEntity> complianceSetupEntityRepository,
            IReadOnlyRepository<ApplicationFormOfficeMappingEntity> applicationFormOfficeMappingEntityRepository,
            IAuthenticationService authenticationService,
            ILogger<GetCompliancesQueryHandler> logger)
        {
            _officeInfoEntityRepository = officeInfoEntityRepository;
            _complianceSetupEntityRepository = complianceSetupEntityRepository;
            _complianceSetupOfficeEntityRepository = complianceSetupOfficeEntityRepository;
            _applicationFormOfficeMappingEntityRepository = applicationFormOfficeMappingEntityRepository;

            _authenticationService = authenticationService;

            _logger = logger;
        }

        public async Task<CompliancesResponse> Handle(GetCompliancesQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(Handle)}.");

            var agencyId = _authenticationService.GetAgencyId();

            var response = new CompliancesResponse();

            var officesByAgency = await _officeInfoEntityRepository.FindAsync(entity => entity.IsActive && entity.VendorId == agencyId && entity.OfficeLevelId != -1);
            if (officesByAgency.Any())
            {
                var officeIds = officesByAgency.Select(entity => entity.Id)
                                               .Distinct()
                                               .ToArray();

                var complianceSetupsOffices = await _complianceSetupOfficeEntityRepository
                    .FindAsync(entity => officeIds.Contains(entity.OfficeId!.Value));
                if (complianceSetupsOffices.Any())
                {
                    response = await GetCompliances(request.ApplicationFormId, complianceSetupsOffices, officesByAgency, officeIds);
                }
            }

            return response;
        }

        private async Task<CompliancesResponse> GetCompliances(int? applicationFormId, IEnumerable<ComplianceSetupOfficeEntity> complianceSetupsOffices, IEnumerable<OfficeInfoEntity> officesByAgency, int[] officeIds)
        {
            var response = new CompliancesResponse();

            var complicanceSetupIds = complianceSetupsOffices.Select(entity => entity.ComplianceSetupId).ToArray();

            var comlianceSetups = await _complianceSetupEntityRepository
                .FindAsync(entity => complicanceSetupIds.Contains(entity.Id));

            var compliances = GetCompliances(comlianceSetups, complianceSetupsOffices);

            var officesWithComplianceIds = compliances.SelectMany(entity => entity.Offices!)
                                                             .Select(entity => entity.OfficeId)
                                                             .OrderBy(entity => entity)
                                                             .ToArray();

            var offices = GetOffices(officesByAgency, officesWithComplianceIds);

            var setupsMappingOfficeIds = await GetApplicationFormOfficeMappings(officeIds);

            foreach (var office in compliances.SelectMany(entity => entity.Offices!).ToArray())
            {
                var officeSetup = setupsMappingOfficeIds.FirstOrDefault(entity => entity.OfficeId == office.OfficeId);
                if (officeSetup == null)
                {
                    office.OfficeApplicationFormAvailabilityId = (int)OfficeApplicationFormAvailability.NotAssigned;
                    continue;
                }
                if (officeSetup.ApplicationFormId == applicationFormId)
                {
                    office.OfficeApplicationFormAvailabilityId = (int)OfficeApplicationFormAvailability.AssignetToCurrent;
                    continue;
                }
                office.OfficeApplicationFormAvailabilityId = (int)OfficeApplicationFormAvailability.Assigned;
            }

            response.Compliances = compliances;
            response.Offices = offices;

            return response;
        }

        private static IEnumerable<ComplianceInfo> GetCompliances(IEnumerable<ComplianceSetupEntity> comlianceSetups, IEnumerable<ComplianceSetupOfficeEntity> complianceSetupOffices)
        {
            var response = comlianceSetups.Join(complianceSetupOffices, cs => cs.Id, cso => cso.ComplianceSetupId, (cs, cso) => new
            {
                ComplianceId = cs.Id,
                ComplianceName = cs.ComplianceSetupName,
                cso.OfficeId,
                cso.OfficeName
            })
                                          .GroupBy(entity => new { entity.ComplianceId, entity.ComplianceName })
                                          .Select(x => new ComplianceInfo
                                          {
                                              ComplianceId = x.Key.ComplianceId,
                                              ComplianceName = x.Key.ComplianceName,
                                              Offices = x.Select(entity => new ApplicationFormOfficeInfo
                                              {
                                                  OfficeId = entity.OfficeId,
                                                  OfficeName = entity.OfficeName
                                              }).ToArray()
                                          }).ToArray();

            return response;
        }

        private static IEnumerable<ApplicationFormOfficeInfo> GetOffices(IEnumerable<OfficeInfoEntity> officesByAgency, IEnumerable<int?> officesWithComplianceIDs)
        {
            var response = officesByAgency.Where(entity => !officesWithComplianceIDs.Contains(entity.Id))
                                          .Select(entity => new ApplicationFormOfficeInfo
                                          {
                                              OfficeId = entity.Id,
                                              OfficeName = entity.OfficeName,
                                              OfficeApplicationFormAvailabilityId = (int)OfficeApplicationFormAvailability.NotAssigned
                                          })
                                          .ToArray();

            return response;
        }

        private async Task<IEnumerable<OfficeApplicationForm>> GetApplicationFormOfficeMappings(IEnumerable<int> officeIds)
        {
            var entities = await _applicationFormOfficeMappingEntityRepository.FindAsync(x => officeIds.Contains(x.OfficeId));

            var response = entities.Select(entity => new OfficeApplicationForm { OfficeId = entity.OfficeId, ApplicationFormId = entity.ApplicationFormId }).ToArray();

            return response;
        }
    }
}
