﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class DeleteApplicationBackgroundChecksHandler : IRequestHandler<DeleteApplicationBackgroundChecksCommand, Unit>
{
    private readonly IGenericRepository<ComplianceBackgroundCheckEntity> _complianceBackgroundCheckRepository;
    private readonly IFilesUploadService _filesUploadService;
    private readonly ILogger<DeleteApplicationBackgroundChecksHandler> _logger;

    public DeleteApplicationBackgroundChecksHandler(IGenericRepository<ComplianceBackgroundCheckEntity> complianceBackgroundCheckRepository,
                                                    IFilesUploadService filesUploadService,
                                                    ILogger<DeleteApplicationBackgroundChecksHandler> logger)
    {
        _complianceBackgroundCheckRepository = complianceBackgroundCheckRepository;
        _filesUploadService = filesUploadService;
        _logger = logger;
    }

    public async Task<Unit> Handle(DeleteApplicationBackgroundChecksCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)} with applicantId: {request.ApplicantId}.");

        List<string> fileKeys = new();
        long totalFileSize = 0;

        if (request.Ids.Any())
        {
            var toRemove = await _complianceBackgroundCheckRepository.FindAsync(x => x.ApplicantId == request.ApplicantId && request.Ids.Contains(x.Id));

            foreach (var item in toRemove)
            {
                if (item.FileKey is null || item.FileSize is null) continue;

                fileKeys.Add(item.FileKey);
                totalFileSize += item.FileSize.Value;
            }

            await _complianceBackgroundCheckRepository.RemoveRangeAsync(toRemove);

            if (fileKeys.Any())
            {
                await _filesUploadService.DeleteDocumentsAsync(fileKeys, totalFileSize, request.ApplicantId);
            }

            _logger.LogInformation($"Applicant Background Checks with Ids: {string.Join(", ", request.Ids)} were deleted.");
        }
        else
        {
            _logger.LogInformation($"Applicant Background Checks with Ids: {string.Join(", ", request.Ids)} not found.");
        }

        return Unit.Value;
    }
}
