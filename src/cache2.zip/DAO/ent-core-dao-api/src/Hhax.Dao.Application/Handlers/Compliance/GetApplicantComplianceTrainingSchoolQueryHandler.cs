﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class GetApplicantComplianceTrainingSchoolQueryHandler 
    : IRequestHandler<GetApplicantComplianceTrainingSchoolQuery, PaginatationResponse<ComplianceTrainingSchool>>
{
    private readonly IGenericRepository<ComplianceTrainingSchoolEntity> _complianceTrainingSchoolRepository;
    private readonly IMediatorService _mediator;
    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicantComplianceTrainingSchoolQueryHandler> _logger;

    public GetApplicantComplianceTrainingSchoolQueryHandler(IGenericRepository<ComplianceTrainingSchoolEntity> complianceTrainingSchoolRepository,
                                                            ILogger<GetApplicantComplianceTrainingSchoolQueryHandler> logger,
                                                            IMediatorService mediator,
                                                            IMapper mapper)
    {
        _complianceTrainingSchoolRepository = complianceTrainingSchoolRepository;
        _mediator = mediator;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<PaginatationResponse<ComplianceTrainingSchool>> Handle(GetApplicantComplianceTrainingSchoolQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("GetApplicantComplianceTrainingSchoolAsync with 'Search' params: {ApplicantId}.", request.Request.Filters?.ApplicantId);

        var response = new PaginatationResponse<ComplianceTrainingSchool>
        {
            Data = Enumerable.Empty<ComplianceTrainingSchool>(),
            PageInfo = new PageInfo { TotalRecordCount = 0 }
        };

        if (request.Request.Filters is not null)
        {
            var rows = await _complianceTrainingSchoolRepository.FindAsync(x => x.ApplicantId == request.Request.Filters.ApplicantId);
            var total = rows.Count();
            var mappedRows = _mapper.Map<IEnumerable<ComplianceTrainingSchool>>(rows);

            mappedRows = mappedRows.OrderByDescending(x => x.Id);

            mappedRows = mappedRows.Skip((request.Request.Page!.PageNumber - 1) * request.Request.Page.PageSize)
                                   .Take(request.Request.Page.PageSize)
                                   .ToArray();

            await MapSignature(request.Request.Filters.ApplicantId, mappedRows);

            _logger.LogInformation("Training Schools were getting successfully.");

            response.Data = mappedRows;
            response.PageInfo.TotalRecordCount = total;
        }
        else
        {
            _logger.LogInformation("Training Schools not found.");
        }

        return response;
    }

    private async Task MapSignature(int applicantId, IEnumerable<ComplianceTrainingSchool> trainingSchools)
    {
        GetApplicantSignatureCommand signatureCommand = new(applicantId, 0, new int[1] { (int)ApplicationFormApplicantSections.GeneralCompliance });

        var applicantSignatures = await _mediator.SendAsync<GetApplicantSignatureCommand, IEnumerable<Signature>>(signatureCommand);

        foreach (var trainingSchool in trainingSchools)
        {
            trainingSchool.Signature = applicantSignatures.FirstOrDefault(x => x.ReferenceId == trainingSchool.Id);
        }
    }
}
