﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class GetColumnAbDocumentsQueryHandler : IRequestHandler<GetColumnAbDocumentsQuery, IEnumerable<I9ColumnABDocument>>
{
    private const string _activeStatus = "Active";

    private readonly IAuthenticationService _authenticationService;

    private readonly ILookupService<I9Document, I9DocumentEntity> _i9DocumentLookups;
    private readonly ILookupService<ComplianceSetupOffice, ComplianceSetupOfficeEntity> _complianceSetupOfficeLookups;
    private readonly ILookupService<I9DocumentComplianceSetupOffice, I9DocumentComplianceSetupOfficeEntity> _i9DocumentComplianceSetupOfficeLookups;

    private readonly ILogger<GetColumnAbDocumentsQueryHandler> _logger;

    public GetColumnAbDocumentsQueryHandler(IAuthenticationService authenticationService,
                                            ILookupService<I9Document, I9DocumentEntity> i9DocumentLookups,
                                            ILookupService<ComplianceSetupOffice, ComplianceSetupOfficeEntity> complianceSetupOfficeLookups,
                                            ILookupService<I9DocumentComplianceSetupOffice, I9DocumentComplianceSetupOfficeEntity> i9DocumentComplianceSetupOfficeLookups,
                                            ILogger<GetColumnAbDocumentsQueryHandler> logger)
    {
        _i9DocumentLookups = i9DocumentLookups;
        _authenticationService = authenticationService;
        _complianceSetupOfficeLookups = complianceSetupOfficeLookups;
        _i9DocumentComplianceSetupOfficeLookups = i9DocumentComplianceSetupOfficeLookups;

        _logger = logger;
    }

    public async Task<IEnumerable<I9ColumnABDocument>> Handle(GetColumnAbDocumentsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var compliacneSetupOffices = await _complianceSetupOfficeLookups.FindAsync(x => x.ProviderId == _authenticationService.GetAgencyId() && x.OfficeId == request.OfficeId);
        if (compliacneSetupOffices.Any())
        {
            var complianceSetupOffice = compliacneSetupOffices.OrderByDescending(x => x.PublishVersion).First();

            var i9Result = await _i9DocumentComplianceSetupOfficeLookups.FindAsync(x => x.ComplianceSetupId == complianceSetupOffice.ComplianceSetupId &&
                                                                                        x.ProviderId == complianceSetupOffice.ProviderId &&
                                                                                        x.Status == _activeStatus);
            if (i9Result.Any())
            {
                var i9DocumentIds = i9Result.Select(x => x.I9DocumentId).ToArray();

                var idResult = await _i9DocumentLookups.FindAsync(x => i9DocumentIds.Contains(x.Id));
                if (idResult.Any())
                {
                    var documents = i9Result.Join(idResult, i9 => i9.I9DocumentId, id => id.Id, (i9, id) => new I9ColumnABDocument
                    {
                        Id = i9.Id,
                        I9DocumentID = i9.I9DocumentId,
                        I9DocumentName = id.DocumentName,
                        IsExpires = i9.IsExpires,
                        IsNonCompliantIfExpired = i9.IsNonCompliantIfExpired,
                        IsColumnCDependent = id.IsColumnCDependent,
                        SortOrder = id.SortOrder
                    });

                    _logger.LogInformation("Column A Documents were retrieved successfully.");

                    return documents.OrderBy(x => x.SortOrder).ToArray();
                }
            }
        }

        _logger.LogInformation("Column A Documents not found.");

        return Enumerable.Empty<I9ColumnABDocument>();
    }
}
