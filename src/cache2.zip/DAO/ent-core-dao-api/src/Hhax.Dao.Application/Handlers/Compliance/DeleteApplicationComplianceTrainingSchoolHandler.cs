﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class DeleteApplicationComplianceTrainingSchoolHandler : IRequestHandler<DeleteApplicationComplianceTrainingSchoolCommand, Unit>
{
    private readonly IGenericRepository<ComplianceTrainingSchoolEntity> _complianceTrainingSchoolRepository;
    private readonly IFilesUploadService _filesUploadService;
    private readonly ILogger<DeleteApplicationComplianceTrainingSchoolHandler> _logger;
    private readonly IMediator _mediator;

    public DeleteApplicationComplianceTrainingSchoolHandler(IGenericRepository<ComplianceTrainingSchoolEntity> complianceTrainingSchoolRepository,
                                                            IFilesUploadService filesUploadService,
                                                            ILogger<DeleteApplicationComplianceTrainingSchoolHandler> logger,
                                                            IMediator mediator)
    {
        _complianceTrainingSchoolRepository = complianceTrainingSchoolRepository;
        _filesUploadService = filesUploadService;
        _logger = logger;
        _mediator = mediator;
    }

    public async Task<Unit> Handle(DeleteApplicationComplianceTrainingSchoolCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)} with id: {request.Id}.");

        List<string> fileKeys = new();
        long totalFileSize = 0;

        var toDelete = await _complianceTrainingSchoolRepository.FindAsync(x => x.Id == request.Id && x.ApplicantId == request.ApplicantId);

        if (toDelete.Any())
        {
            foreach (var item in toDelete)
            {
                if (item.CertificateFileKey is null || item.CertificateFileSize is null) continue;

                fileKeys.Add(item.CertificateFileKey);
                totalFileSize += item.CertificateFileSize.Value;
            }

            await _complianceTrainingSchoolRepository.RemoveRangeAsync(toDelete);
            await UpdateApplicantEligibilities(request.ApplicantId, cancellationToken);

            if (fileKeys.Any())
            {
                await _filesUploadService.DeleteDocumentsAsync(fileKeys, totalFileSize, request.ApplicantId);
            }

            _logger.LogInformation($"Applicant Training School with Id: {request.Id} was deleted.");
        }
        else
        {
            _logger.LogInformation($"Applicant Training School with Id: {request.Id} not found.");
        }

        return Unit.Value;
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await _mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
