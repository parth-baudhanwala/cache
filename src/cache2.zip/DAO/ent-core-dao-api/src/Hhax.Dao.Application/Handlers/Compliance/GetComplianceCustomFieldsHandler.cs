﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public record GetComplianceCustomFieldsHandler(IReadOnlyRepository<ComplianceCustomFieldEntity> ComplianceCustomFieldRepository,
                                               IReadOnlyRepository<ComplianceCustomFieldValueEntity> ComplianceCustomFieldValueRepository,
                                               IReadOnlyRepository<ComplianceCustomFieldApplicantValueEntity> ComplianceCustomFieldApplicantValueRepository,
                                               ILookupService<ComplianceSetupOffice, ComplianceSetupOfficeEntity> ComplianceSetupOfficeLookups,
                                               IAuthenticationService AuthenticationService,
                                               IMediatorService Mediator,
                                               ILogger<GetComplianceCustomFieldsHandler> Logger)
    : IRequestHandler<GetComplianceCustomFieldsQuery, ComplianceCustomFieldModel>
{
    public async Task<ComplianceCustomFieldModel> Handle(GetComplianceCustomFieldsQuery query, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        ComplianceCustomFieldModel customFieldModel = new(Enumerable.Empty<ComplianceCustomFieldApplicantValue>());

        var compliacneSetupOffices = await ComplianceSetupOfficeLookups.FindAsync(x => x.ProviderId == AuthenticationService.GetAgencyId() && x.OfficeId == query.OfficeId);

        if (compliacneSetupOffices.Any())
        {
            var complianceSetupOffice = compliacneSetupOffices.OrderByDescending(x => x.PublishVersion).First();

            var complianceCustomFields = await ComplianceCustomFieldRepository.FindAsync(x => x.ComplianceSetupId == complianceSetupOffice.ComplianceSetupId && x.Status == ComplianceCustomFieldStatuses.Active);

            if (complianceCustomFields.Any())
            {
                var complianceCustomFieldsIds = complianceCustomFields.Select(x => x.Id);

                var complianceCustomFieldOptions = await ComplianceCustomFieldValueRepository.FindAsync(x => x.ComplianceCustomFieldId.HasValue && complianceCustomFieldsIds.Contains(x.ComplianceCustomFieldId.Value));

                var complianceCustomFieldValues = await ComplianceCustomFieldApplicantValueRepository.FindAsync(x => x.ApplicantId == query.ApplicantId);

                GetApplicantSignatureCommand signatureCommand = new(query.ApplicantId, 0, new int[1] { (int)ApplicationFormApplicantSections.ComplianceFields });

                customFieldModel.Signature = (await Mediator.SendAsync<GetApplicantSignatureCommand, IEnumerable<Signature>>(signatureCommand)).FirstOrDefault();

                customFieldModel.ComplianceCustomFields = MapData(query.ApplicantId, complianceCustomFields, complianceCustomFieldOptions, complianceCustomFieldValues);

                Logger.LogInformation("Compliance Custom Fields were retrieved successfully.");

                return customFieldModel;
            }
        }

        Logger.LogInformation("Compliance Custom Fields not found.");

        return customFieldModel;
    }

    private static IEnumerable<ComplianceCustomFieldApplicantValue> MapData(int applicantId,
                                                                            IEnumerable<ComplianceCustomFieldEntity> fields,
                                                                            IEnumerable<ComplianceCustomFieldValueEntity> options,
                                                                            IEnumerable<ComplianceCustomFieldApplicantValueEntity> values)
    {
        foreach (var field in fields)
        {
            ComplianceCustomFieldType fieldType = GetFieldType(field.CustomFieldType);

            ComplianceCustomFieldApplicantValue value = new()
            {
                ApplicantId = applicantId,
                ComplianceFieldId = field.ComplianceFieldId ?? throw new NullValueException("Compliance Custom Field Id should not be null."),
                CmpFieldId = field.ComplianceFieldId ?? 0,
                DisplayOrder = field.DisplayOrder,
                CustomFieldLabel = field.CustomFieldLabel,
                CustomFieldName = field.CustomFieldName != null ? field.CustomFieldName.Value : Guid.NewGuid(),
                ComplianceFieldType = (byte)fieldType
            };

            if (fieldType == ComplianceCustomFieldType.DropdownMultiSelect || fieldType == ComplianceCustomFieldType.DropdownSingleSelect)
            {
                value.Options = GetOptions(field.Id, options);
            }

            PopulateValueFields(value, values);

            yield return value;
        }
    }

    private static ComplianceCustomFieldType GetFieldType(string? fieldTypeName) => fieldTypeName switch
    {
        "Date Picker" => ComplianceCustomFieldType.DatePicker,
        "Single Select - Dropdown" => ComplianceCustomFieldType.DropdownSingleSelect,
        "Multi Select - Dropdown" => ComplianceCustomFieldType.DropdownMultiSelect,
        "Free Text - Multi-Line" => ComplianceCustomFieldType.TextMultiLine,
        "Checkbox" => ComplianceCustomFieldType.Checkbox,
        _ => ComplianceCustomFieldType.TextSingleLine,
    };

    private static IEnumerable<SelectFieldValue> GetOptions(int fieldId, IEnumerable<ComplianceCustomFieldValueEntity> options)
        => options.Where(x => x.ComplianceCustomFieldId == fieldId).OrderBy(x => x.Id).Select(x => new SelectFieldValue
        {
            OptionId = x.DraftComplianceCustomFieldValueId ?? 0,
            OptionText = x.OptionText,
            OptionValue = x.OptionValue
        });

    private static void PopulateValueFields(ComplianceCustomFieldApplicantValue target, IEnumerable<ComplianceCustomFieldApplicantValueEntity> values)
    {
        var targetValue = values.FirstOrDefault(x => x.ComplianceFieldId == target.ComplianceFieldId);

        if (targetValue is not null)
        {
            target.Id = targetValue.Id;
            target.Value = targetValue.Value;
            target.Updated = targetValue.Updated;
            target.UpdatedBy = targetValue.UpdatedBy;
            target.Created = targetValue.Created;
            target.CreatedBy = targetValue.CreatedBy;
        }
    }
}
