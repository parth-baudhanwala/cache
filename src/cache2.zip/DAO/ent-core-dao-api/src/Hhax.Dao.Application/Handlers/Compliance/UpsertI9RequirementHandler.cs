﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public record UpsertI9RequirementHandler(IMediator Mediator,
                                         IGenericRepository<ComplianceI9RequirementEntity> I9RequirementsRepository,
                                         IMapper Mapper,
                                         ILogger<UpsertI9RequirementHandler> Logger,
                                         IFilesUploadService FilesUploadService)
    : IRequestHandler<UpsertI9RequirementCommand, BaseResponse>
{
    public async Task<BaseResponse> Handle(UpsertI9RequirementCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        List<string> fileKeys = new();
        long totalFileSize = 0;

        await Mediator.Send(new ValidateApplicantRequestDataCommand(command.ApplicantId, null, command, ApplicantEligibilitySection.I9), cancellationToken);

        var upsertEntity = Mapper.Map<ComplianceI9RequirementEntity>(command);

        var id = await I9RequirementsRepository.Upsert(upsertEntity, x => x.ApplicantId == command.ApplicantId, request =>
        {
            request.ExpirationDate = upsertEntity.ExpirationDate?.ToUniversalTime();
            request.ColumnABDocumentId = upsertEntity.ColumnABDocumentId;
            request.ColumnCDocumentId = upsertEntity.ColumnCDocumentId;
            request.EVerifyNumber = upsertEntity.EVerifyNumber;
            request.IsVerified = upsertEntity.IsVerified;

            if (command.IsColumnABDocumentFileDeleted
                && request.ColumnABDocumentFileKey is not null
                && request.ColumnABDocumentFileSize is not null
                && !request.ColumnABDocumentFileKey.Equals(upsertEntity.ColumnABDocumentFileKey)
                && request.ColumnABDocumentFileSize != upsertEntity.ColumnABDocumentFileSize)
            {
                fileKeys.Add(request.ColumnABDocumentFileKey);
                totalFileSize += request.ColumnABDocumentFileSize.Value;
                request.ColumnABDocumentFileKey = null;
                request.ColumnABDocumentFileSize = null;
            }

            if (upsertEntity.ColumnABDocumentId is null or 0)
            {
                request.ColumnABDocumentFileKey = null;
                request.ColumnABDocumentFileSize = null;
            }
            else if (!string.IsNullOrWhiteSpace(upsertEntity.ColumnABDocumentFileKey))
            {
                request.ColumnABDocumentFileKey = upsertEntity.ColumnABDocumentFileKey;
                request.ColumnABDocumentFileSize = upsertEntity.ColumnABDocumentFileSize;
            }

            if (command.IsColumnCDocumentFileDeleted
                    && request.ColumnCDocumentFileKey is not null
                    && request.ColumnCDocumentFileSize is not null
                    && !request.ColumnCDocumentFileKey.Equals(upsertEntity.ColumnCDocumentFileKey)
                    && request.ColumnCDocumentFileSize != upsertEntity.ColumnCDocumentFileSize)
            {
                fileKeys.Add(request.ColumnCDocumentFileKey);
                totalFileSize += request.ColumnCDocumentFileSize.Value;
                request.ColumnCDocumentFileKey = null;
                request.ColumnCDocumentFileSize = null;
            }

            if (upsertEntity.ColumnCDocumentId is null or 0)
            {
                request.ColumnCDocumentFileKey = null;
                request.ColumnCDocumentFileSize = null;
            }
            else if (!string.IsNullOrWhiteSpace(upsertEntity.ColumnCDocumentFileKey))
            {
                request.ColumnCDocumentFileKey = upsertEntity.ColumnCDocumentFileKey;
                request.ColumnCDocumentFileSize = upsertEntity.ColumnCDocumentFileSize;
            }

            if (command.IsEverifyDocumentFileDeleted
                && !string.IsNullOrEmpty(request.EverifyDocumentFileKey)
                && request.EverifyDocumentFileSize != null
                && !request.EverifyDocumentFileKey.Equals(upsertEntity.EverifyDocumentFileKey)
                && request.EverifyDocumentFileSize != upsertEntity.EverifyDocumentFileSize)
            {
                fileKeys.Add(request.EverifyDocumentFileKey);
                totalFileSize += request.EverifyDocumentFileSize.Value;
                request.EverifyDocumentFileKey = null;
                request.EverifyDocumentFileSize = null;
            }

            if (string.IsNullOrEmpty(upsertEntity.EVerifyNumber))
            {
                request.EverifyDocumentFileKey = null;
                request.EverifyDocumentFileSize = null;
            }
            else if (!string.IsNullOrWhiteSpace(upsertEntity.EverifyDocumentFileKey))
            {
                request.EverifyDocumentFileKey = upsertEntity.EverifyDocumentFileKey;
                request.EverifyDocumentFileSize = upsertEntity.EverifyDocumentFileSize;
            }

            request.Updated = DateTime.UtcNow;
            upsertEntity.Id = request.Id;
            return request;
        });

        if (command.Signature is not null)
        {
            command.Signature.ReferenceId = upsertEntity.Id;
            command.Signature.ApplicantSectionId = (int)ApplicationFormApplicantSections.GeneralCompliance;
            await Mediator.Send(new SaveApplicantSignatureCommand(command.ApplicantId, new List<Signature>() { command.Signature }), cancellationToken);
        }

        await UpdateApplicantEligibilities(command.ApplicantId, cancellationToken);

        if (fileKeys.Any())
        {
            await FilesUploadService.DeleteDocumentsAsync(fileKeys, totalFileSize, command.ApplicantId);
        }

        Logger.LogInformation("Compliance I9 Requirement was upserted successfully.");

        return new() { Id = id };
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
