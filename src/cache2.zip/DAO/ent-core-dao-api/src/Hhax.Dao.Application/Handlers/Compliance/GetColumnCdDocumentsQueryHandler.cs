﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class GetColumnCdDocumentsQueryHandler : IRequestHandler<GetColumnCdDocumentsQuery, IEnumerable<I9ColumnCDocument>>
{
    private readonly ILookupService<I9ColumnCDocument, I9ColumnCDocumentEntity> _i9ColumnCDocumentLookups;
    private readonly ILogger<GetColumnCdDocumentsQueryHandler> _logger;

    public GetColumnCdDocumentsQueryHandler(ILookupService<I9ColumnCDocument, I9ColumnCDocumentEntity> i9ColumnCDocumentLookups,
                                            ILogger<GetColumnCdDocumentsQueryHandler> logger)
    {
        _i9ColumnCDocumentLookups = i9ColumnCDocumentLookups;
        _logger = logger;
    }

    public async Task<IEnumerable<I9ColumnCDocument>> Handle(GetColumnCdDocumentsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var documents = await _i9ColumnCDocumentLookups.GetAllAsync();
        
        var response = documents.OrderBy(x => x.SortOrder).ToArray();

        _logger.LogInformation("Column B+C Documents were retrieved successfully.");

        return response;
    }
}
