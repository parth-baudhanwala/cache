﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public record UpsertApplicationBackgroundChecksHandler(IGenericRepository<ComplianceBackgroundCheckEntity> ComplianceBackgroundCheckRepository,
                                                       IMapper Mapper,
                                                       ILogger<UpsertApplicationBackgroundChecksHandler> Logger,
                                                       IMediator Mediator,
                                                       IFilesUploadService FilesUploadService)
    : IRequestHandler<UpsertApplicationBackgroundChecksCommand, IEnumerable<int>>
{
    public async Task<IEnumerable<int>> Handle(UpsertApplicationBackgroundChecksCommand request, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        List<int> response = new();
        List<string> fileKeys = new();
        long totalFileSize = 0;

        await Mediator.Send(new ValidateApplicantRequestDataCommand(request.ApplicantId, null, Mapper.Map<IEnumerable<ComplianceBackgroundCheckEntity>>(request.Rows), ApplicantEligibilitySection.BackgroundCheck), cancellationToken);

        foreach (var row in request.Rows)
        {
            ComplianceBackgroundCheckEntity entity = Mapper.Map<ComplianceBackgroundCheckEntity>(row);

            entity.SentOutDate = row.SentOutDate?.ToUniversalTime();
            entity.ReceivedDate = row.ReceivedDate?.ToUniversalTime();
            entity.ApplicantId = request.ApplicantId;

            var ids = await ComplianceBackgroundCheckRepository.Upsert(entity, x => x.Id == entity.Id, request =>
            {
                request.SentOutDate = entity.SentOutDate;
                request.ReceivedDate = entity.ReceivedDate;
                request.ResultId = entity.ResultId;

                if (row.IsFileDeleted
                    && request.FileKey is not null
                    && request.FileSize is not null
                    && !request.FileKey.Equals(entity.FileKey)
                    && request.FileSize != entity.FileSize)
                {
                    fileKeys.Add(request.FileKey);
                    totalFileSize += request.FileSize.Value;
                    request.FileKey = null;
                    request.FileSize = null;
                }

                if (request.ResultId is null or 0)
                {
                    request.FileKey = null;
                    request.FileSize = null;
                }
                else if (!string.IsNullOrWhiteSpace(entity.FileKey))
                {
                    request.FileKey = entity.FileKey;
                    request.FileSize = entity.FileSize;
                }

                request.Updated = DateTime.UtcNow;

                return request;
            });

            response.Add(ids);
        }

        await UpdateApplicantEligibilities(request.ApplicantId, cancellationToken);

        if (fileKeys.Any())
        {
            await FilesUploadService.DeleteDocumentsAsync(fileKeys, totalFileSize, request.ApplicantId);
        }

        Logger.LogInformation($" Application Background Checks were upserted successfully.");

        return response;
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
