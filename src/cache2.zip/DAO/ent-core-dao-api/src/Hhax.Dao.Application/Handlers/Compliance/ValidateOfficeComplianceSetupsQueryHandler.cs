﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class ValidateOfficeComplianceSetupsQueryHandler : IRequestHandler<ValidateOfficeComplianceSetupsQuery, CompliancesSetupsValidationResponse>
{
    private readonly IGenericRepository<ComplianceSetupOfficeEntity> _complianceSetupOfficeRepository;

    private readonly IMapper _mapper;
    private readonly ILogger<ValidateOfficeComplianceSetupsQueryHandler> _logger;

    public ValidateOfficeComplianceSetupsQueryHandler(IGenericRepository<ComplianceSetupOfficeEntity> complianceSetupOfficeRepository,
                                                      IMapper mapper,
                                                      ILogger<ValidateOfficeComplianceSetupsQueryHandler> logger)
    {
        _complianceSetupOfficeRepository = complianceSetupOfficeRepository;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<CompliancesSetupsValidationResponse> Handle(ValidateOfficeComplianceSetupsQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        const string noComplianceSetupMessage = "Please create the compliance setup for the selected offices before proceeding with office management setup.";
        const string message = "You cannot select offices with different compliance setups applied.";
        const string successMessage = "Office compliance setups were validated succssfully.";

        var response = new CompliancesSetupsValidationResponse { IsValid = true };

        var complianceSetupsValidations = new List<ComplianceSetupsValidationResponse>();

        var officeComplianceSetups = new Dictionary<int, IEnumerable<ComplianceSetupOffice>>();

        var complianceSetupOffices = new List<ComplianceSetupOfficeEntity>();

        var officeIds = request.OfficeIds!.Distinct().ToArray();

        var sourceOficeComplianceSetups = await _complianceSetupOfficeRepository.FindAsync(x => officeIds.Contains(x.OfficeId!.Value));

        foreach (var officeId in officeIds)
        {
            var targetComplianceSetupOffices = sourceOficeComplianceSetups.Where(x => x.OfficeId == officeId).ToArray();

            officeComplianceSetups.Add(officeId, _mapper.Map<IEnumerable<ComplianceSetupOffice>>(targetComplianceSetupOffices));

            if (complianceSetupOffices.Count == 0 && targetComplianceSetupOffices?.Length > 0)
            {
                complianceSetupsValidations.Add(new ComplianceSetupsValidationResponse
                {
                    IsSuccess = true,
                    OfficeId = officeId,
                    Message = successMessage
                });

                complianceSetupOffices.AddRange(targetComplianceSetupOffices);
            }
            else if (complianceSetupOffices.Count > 0 && targetComplianceSetupOffices?.Length > 0 &&
                     complianceSetupOffices.Count == targetComplianceSetupOffices.Length)
            {
                var isSuccess = complianceSetupOffices.All(x => targetComplianceSetupOffices.Any(f => f.ComplianceSetupId == x.ComplianceSetupId));

                complianceSetupsValidations.Add(new ComplianceSetupsValidationResponse { IsSuccess = isSuccess, OfficeId = officeId, Message = !isSuccess ? message : successMessage });
            }
            else if (targetComplianceSetupOffices?.Length == 0)
            {
                complianceSetupsValidations.Add(new ComplianceSetupsValidationResponse
                {
                    IsSuccess = false,
                    Message = noComplianceSetupMessage,
                    OfficeId = officeId
                });
            }
            else if (complianceSetupOffices.Count != targetComplianceSetupOffices?.Length)
            {
                complianceSetupsValidations.Add(new ComplianceSetupsValidationResponse
                {
                    IsSuccess = false,
                    Message = message,
                    OfficeId = officeId
                });
            }
            else
            {
                complianceSetupsValidations.Add(new ComplianceSetupsValidationResponse
                {
                    IsSuccess = true,
                    OfficeId = officeId,
                    Message = successMessage
                });
            }
        }

        response.ComplianceSetupsValidations = complianceSetupsValidations;
        response.IsValid = complianceSetupsValidations.All(x => x.IsSuccess);

        _logger.LogInformation("Offices Compliance Setups were validated successfully.");

        return response;
    }
}
