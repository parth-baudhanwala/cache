﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;

namespace Hhax.Dao.Application.Handlers.Compliance;

public record UpsertApplicationTrainingSchoolHandler(IGenericRepository<ComplianceTrainingSchoolEntity> ComplianceTrainingSchoolRepository,
                                                     IMapper Mapper,
                                                     IMediator Mediator,
                                                     IFilesUploadService FilesUploadService)
    : IRequestHandler<UpsertApplicationTrainingSchoolCommand, BaseResponse>
{
    public async Task<BaseResponse> Handle(UpsertApplicationTrainingSchoolCommand command, CancellationToken cancellationToken)
    {
        List<string> fileKeys = new();
        long totalFileSize = 0;

        var upsertEntity = Mapper.Map<ComplianceTrainingSchoolEntity>(command);

        await Mediator.Send(new ValidateApplicantRequestDataCommand(command.ApplicantId, null, new[] { Mapper.Map<ComplianceTrainingSchoolEntity>(command) }, ApplicantEligibilitySection.TrainingSchools), cancellationToken);

        upsertEntity.VerificationDate = command.VerificationDate?.ToUniversalTime();
        upsertEntity.CertificationDate = command.CertificationDate?.ToUniversalTime();

        var id = await ComplianceTrainingSchoolRepository.Upsert(upsertEntity, x => x.Id == command.Id, request =>
        {
            request.IsVerified = upsertEntity.IsVerified;
            request.VerificationDate = upsertEntity.VerificationDate;
            request.CertificationDate = upsertEntity.CertificationDate;
            request.SchoolId = upsertEntity.SchoolId;
            request.DisciplineId = upsertEntity.DisciplineId;
            request.InstructorName = upsertEntity.InstructorName;

            if (command.IsFileDeleted
                && request.CertificateFileKey is not null
                && request.CertificateFileSize is not null
                && !request.CertificateFileKey.Equals(upsertEntity.CertificateFileKey)
                && request.CertificateFileSize != upsertEntity.CertificateFileSize)
            {
                fileKeys.Add(request.CertificateFileKey);
                totalFileSize += request.CertificateFileSize.Value;
                request.CertificateFileKey = null;
                request.CertificateFileSize = null;
            }

            if (upsertEntity.SchoolId is null or 0)
            {
                request.CertificateFileKey = null;
                request.CertificateFileSize = null;
            }
            else if (!string.IsNullOrWhiteSpace(upsertEntity.CertificateFileKey))
            {
                request.CertificateFileKey = upsertEntity.CertificateFileKey;
                request.CertificateFileSize = upsertEntity.CertificateFileSize;
            }

            request.Updated = DateTime.UtcNow;
            upsertEntity.Id = request.Id;
            return request;
        });

        if (command.Signature is not null)
        {
            command.Signature.ReferenceId = upsertEntity.Id;
            command.Signature.ApplicantSectionId = (int)ApplicationFormApplicantSections.GeneralCompliance;
            await Mediator.Send(new SaveApplicantSignatureCommand(command.ApplicantId, new List<Signature>() { command.Signature }), cancellationToken);
        }

        await UpdateApplicantEligibilities(command.ApplicantId, cancellationToken);

        if (fileKeys.Any())
        {
            await FilesUploadService.DeleteDocumentsAsync(fileKeys, totalFileSize, command.ApplicantId);
        }

        return new() { Id = id };
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
