﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public record UpsertApplicantComplianceCustomFieldsHandler(IGenericRepository<ComplianceCustomFieldApplicantValueEntity> ComplianceCustomFieldApplicantValueRepository,
                                                           IMapper Mapper,
                                                           ILogger<UpsertApplicantComplianceCustomFieldsHandler> Logger,
                                                           IMediator Mediator)
    : IRequestHandler<UpsertApplicantComplianceCustomFieldsCommand, BaseRangeResponse>
{
    public async Task<BaseRangeResponse> Handle(UpsertApplicantComplianceCustomFieldsCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        await Mediator.Send(new ValidateApplicantRequestDataCommand(command.ApplicantId, null, command.Data, ApplicantEligibilitySection.ComplianceFields), cancellationToken);

        List<int> ids = new();

        foreach (var row in command.Data)
        {
            var entity = Mapper.Map<ComplianceCustomFieldApplicantValueEntity>(row);

            entity.ApplicantId = command.ApplicantId;

            int id = await ComplianceCustomFieldApplicantValueRepository.Upsert(entity, x => x.ApplicantId == command.ApplicantId && x.ComplianceFieldId == entity.ComplianceFieldId, upsertEntity =>
            {
                upsertEntity.Value = entity.Value;
                upsertEntity.Updated = DateTime.UtcNow;

                return upsertEntity;
            });

            ids.Add(id);
        }

        if (command.Signature is not null)
        {
            command.Signature.ApplicantSectionId = (int)ApplicationFormApplicantSections.ComplianceFields;
            await Mediator.Send(new SaveApplicantSignatureCommand(command.ApplicantId, new List<Signature>() { command.Signature }), cancellationToken);
        }

        await UpdateApplicantEligibilities(command.ApplicantId, cancellationToken);

        Logger.LogInformation($"Applicant Compliance Custom fields were upserted successfully.");

        return new(ids);
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
