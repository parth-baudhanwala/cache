﻿using AutoMapper;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public class GetApplicantComplianceBackgroundCheckQueryHandler : IRequestHandler<GetApplicantComplianceBackgroundCheckQuery, IEnumerable<ComplianceBackgroundCheck>>
{
    private readonly IGenericRepository<ComplianceBackgroundCheckEntity> _complianceBackgroundCheckRepository;

    private readonly IMapper _mapper;
    private readonly ILogger<GetApplicantComplianceBackgroundCheckQueryHandler> _logger;

    public GetApplicantComplianceBackgroundCheckQueryHandler(IGenericRepository<ComplianceBackgroundCheckEntity> complianceBackgroundCheckRepository,
                                                             IMapper mapper,
                                                             ILogger<GetApplicantComplianceBackgroundCheckQueryHandler> logger)
    {
        _complianceBackgroundCheckRepository = complianceBackgroundCheckRepository;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<ComplianceBackgroundCheck>> Handle(GetApplicantComplianceBackgroundCheckQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)} with applicantId: {request.ApplicantId}.");

        IEnumerable<ComplianceBackgroundCheckEntity> response = await _complianceBackgroundCheckRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);
        if (response.Any())
        {
            _logger.LogInformation($"Background checks with applicantId: {request.ApplicantId} were retrieved successfully.");

            return _mapper.Map<IEnumerable<ComplianceBackgroundCheck>>(response);
        }

        _logger.LogInformation($"Background checks with applicantId: {request.ApplicantId} not found.");

        return new ComplianceBackgroundCheck[] { new() };
    }
}
