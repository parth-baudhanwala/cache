﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Common.Extensions;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Globalization;

public class GetEthnicityHandler : IRequestHandler<GetEthnicityQuery, IEnumerable<Ethnicity>>
{
    private readonly ILookupService<Relationship, GenericReferenceEntity> _ethnicityLookupService;
    private readonly ILogger<GetEthnicityHandler> _logger;

    public GetEthnicityHandler(ILookupService<Relationship, GenericReferenceEntity> ethnicityLookupService,
                               ILogger<GetEthnicityHandler> logger)
    {
        _ethnicityLookupService = ethnicityLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<Ethnicity>> Handle(GetEthnicityQuery query, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        string referenceType = ReferenceType.CaregiverEthnicity.GetDisplayName();

        var ethnicity = (await _ethnicityLookupService.FindAsync(x => x.IsActive && x.Type == referenceType))
                                                 .Select(x => new Ethnicity
                                                 {
                                                     Id = Convert.ToInt32(x.Code),
                                                     Name = x.Value
                                                 })
                                                 .OrderBy(x => x.Name);

        _logger.LogInformation("Ethnicity fetched successfully.");

        return ethnicity;
    }
}
