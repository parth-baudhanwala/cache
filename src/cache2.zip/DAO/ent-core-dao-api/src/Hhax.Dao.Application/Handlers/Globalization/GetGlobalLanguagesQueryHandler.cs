﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Globalization;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Globalization;

public class GetGlobalLanguagesQueryHandler : IRequestHandler<GetGlobalLanguagesQuery, IEnumerable<GlobalLanguage>>
{
    private readonly ILookupService<GlobalLanguage, GlobalLanguageEntity> _languagesLookupService;
    private readonly ILogger<GetGlobalLanguagesQueryHandler> _logger;

    public GetGlobalLanguagesQueryHandler(ILookupService<GlobalLanguage, GlobalLanguageEntity> languagesLookupService,
                                          ILogger<GetGlobalLanguagesQueryHandler> logger)
    {
        _languagesLookupService = languagesLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<GlobalLanguage>> Handle(GetGlobalLanguagesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var response = (await _languagesLookupService.GetAllAsync()).Where(x => x.IsActive);

        _logger.LogInformation("Global languages were getting successfully.");

        return response;
    }
}
