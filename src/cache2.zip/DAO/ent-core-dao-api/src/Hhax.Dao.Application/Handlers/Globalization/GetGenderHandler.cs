﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Caregiver;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Globalization;

public class GetGenderHandler : IRequestHandler<GetGenderQuery, IEnumerable<Gender>>
{
    private readonly ILookupService<Gender, CaregiverGenderEntity> _genderLookupService;
    private readonly IReadOnlyRepository<OfficeInfoEntity> _officeInfoEntityRepository;
    private readonly ILogger<GetGenderHandler> _logger;

    public GetGenderHandler(ILookupService<Gender, CaregiverGenderEntity> genderLookupService,
                            IReadOnlyRepository<OfficeInfoEntity> officeInfoEntityRepository,
                            ILogger<GetGenderHandler> logger)
    {
        _genderLookupService = genderLookupService;
        _officeInfoEntityRepository = officeInfoEntityRepository;
        _logger = logger;
    }

    public async Task<IEnumerable<Gender>> Handle(GetGenderQuery query, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var office = await _officeInfoEntityRepository.GetByIdAsync(query.OfficeId);

        var gender = (await _genderLookupService.FindAsync(x => x.Active == Answer.Yes.ToString()
                                                                && x.ProviderId == office.VendorId))
                                                .OrderBy(x => x.Name);

        _logger.LogInformation("Gender fetched successfully.");

        return gender;
    }
}
