﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Globalization;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Globalization;

public class SearchStatesQueryHandler : IRequestHandler<SearchStatesQuery, IEnumerable<State>>
{
    private readonly RedisConfiguration _redisConfiguration;

    private readonly IDistributedCacheService _distributedCacheService;
    private readonly IDbContextFactory<HhaDbContext> _hhaDbContextFactory;

    private readonly IMapper _mapper;
    private readonly ILogger<SearchStatesQueryHandler> _logger;

    public SearchStatesQueryHandler(IOptions<RedisConfiguration> redisOptions, 
                                    IDistributedCacheService distributedCacheService,
                                    IDbContextFactory<HhaDbContext> hhaDbContextFactory,
                                    IMapper mapper,
                                    ILogger<SearchStatesQueryHandler> logger)
    {
        _redisConfiguration = redisOptions.Value;

        _distributedCacheService = distributedCacheService;
        _hhaDbContextFactory = hhaDbContextFactory;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<State>> Handle(SearchStatesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("SearchStatesAsync with 'State Name' params: {StateName}.", request?.StateName);

        var cachePrefix = $"{nameof(SearchStatesQueryHandler)}";

        CacheKey key = _distributedCacheService.BuildKey(cachePrefix, nameof(State), request?.StateName);

        IEnumerable<State> response = new List<State>();

        try
        {
            var states = await _distributedCacheService.GetFromCacheOrSource(key, async () => await SearchStatesAsync(request?.StateName, cancellationToken),
                                                                             _redisConfiguration.CacheEnabled,
                                                                             _redisConfiguration.RecordExpirationInSeconds);
            response = _mapper.Map<IEnumerable<State>>(states);
        }
        catch (Exception exc)
        {
            _logger.LogError(exc, exc.Message);
        }

        _logger.LogInformation("States were getting successfully.");

        return response;
    }

    private async Task<IEnumerable<StateEntity>> SearchStatesAsync(string? search, CancellationToken cancellationToken)
    {
        _logger.LogInformation("SearchStatesAsync with 'Search' params: {search}.", search);

        using var context = await _hhaDbContextFactory.CreateDbContextAsync(cancellationToken);
        var query = context.States!.AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            query = query.Where(x => !string.IsNullOrWhiteSpace(x.StateName) && EF.Functions.Like(x.StateName!, $"%{search}%"));
        }

        var result = await query.ToArrayAsync(cancellationToken: cancellationToken);

        _logger.LogInformation("States were getting successfully.");

        return result;
    }
}
