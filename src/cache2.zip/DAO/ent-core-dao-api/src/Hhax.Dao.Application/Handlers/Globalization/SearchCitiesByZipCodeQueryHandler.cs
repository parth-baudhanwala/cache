﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Globalization;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Globalization;

public class SearchCitiesByZipCodeQueryHandler : IRequestHandler<SearchCitiesByZipCodeQuery, IEnumerable<City>>
{
    private const int _pageNumberOffset = 1;

    private const int _defaultPageNumber = 1;
    private const int _defaultPageSize = 100;

    private readonly RedisConfiguration _redisConfiguration;

    private readonly IDistributedCacheService _distributedCacheService;
    private readonly IDbContextFactory<HhaDbContext> _hhaDbContextFactory;

    private readonly IMapper _mapper;
    private readonly ILogger<SearchCitiesByZipCodeQueryHandler> _logger;

    public SearchCitiesByZipCodeQueryHandler(IOptions<RedisConfiguration> redisOptions,
                                             IDistributedCacheService distributedCacheService,
                                             IDbContextFactory<HhaDbContext> hhaDbContextFactory,
                                             IMapper mapper,
                                             ILogger<SearchCitiesByZipCodeQueryHandler> logger)
    {
        _redisConfiguration = redisOptions.Value;

        _distributedCacheService = distributedCacheService;
        _hhaDbContextFactory = hhaDbContextFactory;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<City>> Handle(SearchCitiesByZipCodeQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("SearchCitiesByZipCodeAsync with 'ZipCode' param: {ZipCode}.", request.Request!.Filters?.ZipCode);

        var cachePrefix = $"{nameof(SearchCitiesByZipCodeQueryHandler)}";

        IEnumerable<City> response = new List<City>();

        try
        {
            CacheKey key = _distributedCacheService.BuildKey(cachePrefix, nameof(City), request.Request!.Filters?.ZipCode);

            var cities = await SearchCitiesByZipCodeAsync(key, cancellationToken, zipCode: request.Request?.Filters?.ZipCode,
                                                          pageNumber: request.Request?.Page?.PageNumber ?? _defaultPageNumber, pageSize: request.Request?.Page?.PageSize ?? _defaultPageSize);

            response = _mapper.Map<IEnumerable<City>>(cities);

            _logger.LogInformation("Cities were getting successfully.");
        }
        catch (Exception exc)
        {
            _logger.LogError(exc, exc.Message);
        }

        _logger.LogInformation("Cities were getting successfully.");

        return response;
    }

    private async Task<IEnumerable<CityEntity>> SearchCitiesByZipCodeAsync(CacheKey key, CancellationToken cancellationToken, string? zipCode = null, int? pageNumber = null, int? pageSize = null)
    {
        var cities = await _distributedCacheService.GetFromCacheOrSource(key, async () => await SearchCitiesByZipCodeAsync(cancellationToken, zipCode, pageNumber, pageSize),
                                                                         _redisConfiguration.CacheEnabled,
                                                                         _redisConfiguration.RecordExpirationInSeconds);
        return cities;
    }

    private async Task<IEnumerable<CityEntity>> SearchCitiesByZipCodeAsync(CancellationToken cancellationToken, string? zipCode = null, int? pageNumber = null, int? pageSize = null)
    {
        _logger.LogInformation("SearchCitiesByZipCodeAsync with params: 'ZipCode'={zipCode}, 'PageNumber'={pageNumber}, 'PageSize'={pageSize}.", zipCode, pageNumber, pageSize);

        using var context = await _hhaDbContextFactory.CreateDbContextAsync(cancellationToken);
        var query = context.Cities!.AsQueryable();

        if (!string.IsNullOrWhiteSpace(zipCode))
        {
            query = query.Where(x => !string.IsNullOrWhiteSpace(x!.ZipCode) && EF.Functions.Like(x.ZipCode!, $"%{zipCode}%"));
        }

        var result = pageNumber.HasValue && pageSize.HasValue ? await query.Skip((pageNumber.Value - _pageNumberOffset) * pageSize.Value).Take(pageSize.Value).ToArrayAsync()
                                                              : await query.ToArrayAsync();

        _logger.LogInformation("Cities were getting successfully.");

        return result!;
    }
}
