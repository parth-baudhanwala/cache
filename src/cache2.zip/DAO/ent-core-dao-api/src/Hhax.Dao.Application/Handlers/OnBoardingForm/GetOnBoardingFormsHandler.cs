﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.FormBuilder;
using Hhax.Dao.Application.Abstracts.Requests.FormBuilder;
using Hhax.Dao.Application.Abstracts.Responses.OnBoardingForm;
using Hhax.Dao.Application.Commands.OnBoardingForm;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.OnBoardingForm
{
    public class GetOnBoardingFormsHandler : IRequestHandler<GetOnBoardingFormsCommand, IEnumerable<OnBoardingFormResponse>>
    {
        private readonly ILogger<GetOnBoardingFormsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IFormBuilderApiClient _formBuilderApiClient;

        public GetOnBoardingFormsHandler(ILogger<GetOnBoardingFormsHandler> logger, IServiceProvider serviceProvider, IMapper mapper)
        {
            _logger = logger;
            _mapper = mapper;
            _formBuilderApiClient = serviceProvider.GetRequiredService<IFormBuilderApiClient>();
        }

        public async Task<IEnumerable<OnBoardingFormResponse>> Handle(GetOnBoardingFormsCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(Handle)}.");

            var formRequest = _mapper.Map<FormListByCategoryNameRequest>(request);

            var response = await _formBuilderApiClient.GetFormListByCategoryName(formRequest).ConfigureAwait(false);

            if (response != null)
            {
                var onBoardingForms = _mapper.Map<IEnumerable<OnBoardingFormResponse>>(response.FormDetails);
                return onBoardingForms;
            }

            return Enumerable.Empty<OnBoardingFormResponse>();
        }
    }
}
