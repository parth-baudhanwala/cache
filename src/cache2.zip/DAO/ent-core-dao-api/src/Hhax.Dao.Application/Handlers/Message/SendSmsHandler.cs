﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Application.Commands.Message;
using Hhax.Dao.Domain.Message;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Text;

namespace Hhax.Dao.Application.Handlers.Message
{
    public class SendSmsHandler : IRequestHandler<SendSmsCommand, SendMessagesResponse>
    {
        private readonly ILogger<SendSmsHandler> _logger;
        private readonly ISmsSenderService _smsSenderService;
        private readonly IAuthenticationService _authenticationService;

        private const int maxLengthOfMessagePart = 60;

        public SendSmsHandler(ILogger<SendSmsHandler> logger,
            ISmsSenderService smsSenderService,
            IAuthenticationService authenticationService)
        {
            _logger = logger;
            _smsSenderService = smsSenderService;
            _authenticationService = authenticationService;
        }

        public async Task<SendMessagesResponse> Handle(SendSmsCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(SendSmsHandler)} was invoked by user {_authenticationService.GetUserId()}");

            var response = await _smsSenderService.SendSmsAsync(PrepareSmsData(request));

            _logger.LogInformation($"The {nameof(SendSmsHandler)} has executed.");

            return response;
        }

        private List<Sms> PrepareSmsData(SendSmsCommand request)
        {
            List<Sms> smsList = new List<Sms>();

            List<string> messages = SplitLongMessage(request.Message);

            request.SmsRecipients?.ForEach(recipient =>
            {
                messages.ForEach(message => {
                    smsList.Add(new Sms(new SmsRecipient(recipient.PhoneNumber, recipient.Name), message));
                });
            });

            return smsList;
        }

        private static List<string> SplitLongMessage(string message)
        {
            if (message.Length > maxLengthOfMessagePart)
            {
                return DivideIntoSmallerParts(message);
            }
  
            return new List<string>() { message };
        }

        private static List<string> DivideIntoSmallerParts(string message)
        {
            List<string> messages = new List<string>();

            var messageParts = message.Split(' ');

            var stringBuilder = new StringBuilder();

            foreach (var item in messageParts)
            {
                var messagePart = $"{item} ";
                var itemlength = messagePart.Length;

                if (stringBuilder.Length + itemlength <= maxLengthOfMessagePart)
                {
                    stringBuilder.Append(messagePart);
                }
                else
                {
                    messages.Add(stringBuilder.ToString());
                    stringBuilder.Clear();
                    stringBuilder.Append(messagePart);
                }
            }

            if (stringBuilder.Length > 0)
            {
                messages.Add(stringBuilder.ToString());
            }

            return messages;
        }
    }
}
