﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Message;
using Hhax.Dao.Domain.Message;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Message;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Message
{
    public class GetTemplatesHandler : IRequestHandler<GetTemplatesRequest, IEnumerable<MessageTemplate>?>
    {
        private readonly ILogger<GetTemplatesHandler> _logger;
        private readonly IAuthenticationService _authenticationService;
        private readonly IReadOnlyRepository<TemplateEntity> _templateRepository;
        private readonly IReadOnlyRepository<OfficeTemplateEntity> _officeTemplateRepository;

        public GetTemplatesHandler(ILogger<GetTemplatesHandler> logger,
            IAuthenticationService authenticationService,
            IReadOnlyRepository<TemplateEntity> templateRepository,
            IReadOnlyRepository<OfficeTemplateEntity> officeTemplateRepository)
        {
            _logger = logger;
            _authenticationService = authenticationService;
            _templateRepository = templateRepository;
            _officeTemplateRepository = officeTemplateRepository;
        }

        public async Task<IEnumerable<MessageTemplate>?> Handle(GetTemplatesRequest request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(GetTemplatesHandler)} was invoked by user {_authenticationService.GetUserId()}");

            var response = await GetTemplates(request, cancellationToken);

            _logger.LogInformation($"The {nameof(GetTemplatesHandler)} has executed.");

            return response;
        }

        private async Task<IEnumerable<MessageTemplate>?> GetTemplates(GetTemplatesRequest request, CancellationToken cancellationToken)
        {
            if (request.OfficeIds?.Any() ?? false)
            {
                return await (from template in _templateRepository.GetQuery()
                                            from officeTemplate in _officeTemplateRepository.GetQuery()
                                                .Where(officeTemplate => officeTemplate.TemplateID == template.Id)

                                            where request.OfficeIds.Contains(officeTemplate.OfficeID) &&
                                            template.Status == "Active" &&
                                            template.TemplateType == (int)request.TemplateType

                                            select new MessageTemplate
                                            {
                                                Id = template.Id,
                                                Description = template.Description,
                                                Message = template.Message,
                                                Subject = template.Subject
                                            }).Distinct().ToListAsync(cancellationToken);
            }

            return default;
        }
    }
}
