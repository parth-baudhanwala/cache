﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Application.Commands.Message;
using Hhax.Dao.Domain.Message;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Message
{
    public class SendEmailHandler : IRequestHandler<SendEmailCommand, SendMessagesResponse>
    {
        private readonly ILogger<SendEmailHandler> _logger;
        private readonly IMailSenderService<ConeXusMailSenderConfiguration> _mailSenderService;
        private readonly ConeXusMailSenderConfiguration _mailSenderConfiguration;
        private readonly IAuthenticationService _authenticationService;

        private readonly int bytes1024 = 1024;

        public SendEmailHandler(ILogger<SendEmailHandler> logger,
            IMailSenderService<ConeXusMailSenderConfiguration> mailSenderService,
            IOptions<ConeXusMailSenderConfiguration> mailSenderConfiguration,
            IAuthenticationService authenticationService)
        {
            _logger = logger;
            _mailSenderService = mailSenderService;
            _mailSenderConfiguration = mailSenderConfiguration.Value;
            _authenticationService = authenticationService;
        }
        public async Task<SendMessagesResponse> Handle(SendEmailCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(SendEmailHandler)} was invoked by user {_authenticationService.GetUserId()}");

            var response = await SendEmailsAsync(request);

            _logger.LogInformation($"The {nameof(SendEmailHandler)} has executed.");

            return response;
        }

        private async Task<SendMessagesResponse> SendEmailsAsync(SendEmailCommand request)
        {
            var sendMessagesResponse = new SendMessagesResponse();

            ValidateAttachments(request.Attachments, sendMessagesResponse);

            if (sendMessagesResponse.Errors.Any())
            {
                return sendMessagesResponse;
            }

            return await _mailSenderService.SendEmailAsync(PrepareMailData(request));
        }

        private List<Email> PrepareMailData(SendEmailCommand request)
        {
            List<Email> emails = new List<Email>();

            if (request.Attachments != null && request.Attachments.Any())
            {
                emails = GetEmailsWithAttachments(request);
            }
            else
            {
                emails.Add(new Email(request.EmailRecipients, request.Message, request.Subject));
            }

            return emails;
        }

        private List<Email> GetEmailsWithAttachments(SendEmailCommand request)
        {
            long attachmentsSize = request.Attachments!.Sum(x => x.Length);
            long sumAttachmentsSize = 0;

            List<Email> emails = new List<Email>();
            List<EmailRecipient> recipients = new List<EmailRecipient>();

            foreach (var item in request.EmailRecipients)
            {
                sumAttachmentsSize = sumAttachmentsSize + attachmentsSize;

                if (sumAttachmentsSize <= Constants.MaxSizeOfAttachmentsPerSession16MB)
                {
                    recipients.Add(item);
                }
                else
                {
                    emails.Add(new Email()
                    {
                        Recipients = recipients,
                        Subject = request.Subject,
                        Message = request.Message,
                        Attachments = request.Attachments
                    });

                    recipients = new List<EmailRecipient> { item };
                    sumAttachmentsSize = attachmentsSize;
                }
            }

            if (sumAttachmentsSize > 0)
            {
                emails.Add(new Email() { 
                    Recipients = recipients, 
                    Subject = request.Subject, 
                    Message = request.Message, 
                    Attachments = request.Attachments });
            }

            return emails;
        }

        private void ValidateAttachments(IList<IFormFile>? attachments, SendMessagesResponse sendMessagesResponse)
        {
            if (attachments != null && attachments.Any())
            {
                var messageError = new MessageError();

                var errorMessage = CheckAttachmentSize(attachments);

                if (!string.IsNullOrEmpty(errorMessage))
                {
                    messageError.Reason = errorMessage;
                    messageError.ErrorType = typeof(InvalidDataException).Name;
                }

                errorMessage = CheckAttachmentExtensionType(attachments);

                if (!string.IsNullOrEmpty(errorMessage))
                {
                    messageError.Reason = errorMessage;
                    messageError.ErrorType = typeof(InvalidDataException).Name;
                }

                if (!string.IsNullOrWhiteSpace(messageError.Reason))
                {
                    sendMessagesResponse.Errors.Add(messageError);
                }
            }
        }

        private string CheckAttachmentSize(IList<IFormFile> attachments)
        {
            var sizeLimitMB = _mailSenderConfiguration.AttachmentSizeLimitMB;

            if (sizeLimitMB > 0
                && attachments.Any(x => x.Length > (sizeLimitMB * bytes1024 * bytes1024)))
            {
                var message = $"The attached files shouldn't be more than {sizeLimitMB} MB.";

                _logger.LogError(message);
                return message;
            }

            return string.Empty;
        }

        private string CheckAttachmentExtensionType(IList<IFormFile> attachments)
        {
            var allowedExtensions = _mailSenderConfiguration.AllowedExtensions;

            if (allowedExtensions.Any() && !HaveAllowedExtensions(attachments, allowedExtensions))
            {
                var message = $"Attachments should have allowed extensions.{Environment.NewLine} " +
                    $"Allowed extensions: {String.Join(", ", allowedExtensions)}";

                _logger.LogError(message);
                return message;
            }

            return string.Empty;
        }

        private bool HaveAllowedExtensions(IList<IFormFile> attachments, List<string> allowedExtensions)
        {
            return attachments.All(attachment =>
                {
                    var extension = Path.GetExtension(attachment.FileName).ToLower();

                    return allowedExtensions.Contains(extension);
                });
        }
    }
}
