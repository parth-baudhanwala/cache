﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.ProviderAdmin;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Common;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetOfficeDisciplinesQueryHandler : IRequestHandler<GetOfficeDisciplinesQuery, IEnumerable<OfficeDisciplineResponse>>
{
    private readonly IProviderAdminApiClient _providerAdminApiClient;
    private readonly RedisConfiguration _redisConfiguration;
    private readonly IDistributedCacheService _distributedCacheService;
    private readonly ILogger<GetOfficeDisciplinesQueryHandler> _logger;

    public GetOfficeDisciplinesQueryHandler(
        IProviderAdminApiClient providerAdminApiClient,
        IOptions<RedisConfiguration> redisOptions,
        IDistributedCacheService distributedCacheService,
        ILogger<GetOfficeDisciplinesQueryHandler> logger)
    {
        _providerAdminApiClient = providerAdminApiClient;
        _redisConfiguration = redisOptions.Value;
        _distributedCacheService = distributedCacheService;
        _logger = logger;
    }

    public async Task<IEnumerable<OfficeDisciplineResponse>> Handle(GetOfficeDisciplinesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        string cachePrefix = $"{nameof(GetOfficeDisciplinesQueryHandler)}";
        CacheKey cacheKey = _distributedCacheService.BuildKey(cachePrefix, "OfficeDisciplines", request.OfficeId.ToString());

        var disciplines = await _distributedCacheService.GetFromCacheOrSource(
                cacheKey,
                async () => await _providerAdminApiClient.GetDisciplinesAsync(new OfficeDisciplineRequest { OfficeId = request.OfficeId }),
                _redisConfiguration.CacheEnabled,
                _redisConfiguration.DisciplineTimeoutInSeconds);

        if (disciplines != null)
        {
            _logger.LogInformation("Disciplines retrieved successfully for officeId: {officeId}.", request.OfficeId);
            return disciplines;
        }

        return Enumerable.Empty<OfficeDisciplineResponse>();
    }
}

