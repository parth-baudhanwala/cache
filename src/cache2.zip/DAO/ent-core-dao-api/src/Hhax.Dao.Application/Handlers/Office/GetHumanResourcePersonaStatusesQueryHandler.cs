﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetHumanResourcePersonaStatusesQueryHandler : IRequestHandler<GetHumanResourcePersonaStatusesQuery, IEnumerable<HumanResourcePersonaStatus>>
{
    private readonly ILookupService<HumanResourcePersonaStatus, HumanResourcePersonaStatusEntity> _hrPersonaStatusesLookupService;
    private readonly ILogger<GetHumanResourcePersonaStatusesQueryHandler> _logger;

    public GetHumanResourcePersonaStatusesQueryHandler(ILookupService<HumanResourcePersonaStatus, HumanResourcePersonaStatusEntity> hrPersonaStatusesLookupService,
                                                       ILogger<GetHumanResourcePersonaStatusesQueryHandler> logger)
    {
        _hrPersonaStatusesLookupService = hrPersonaStatusesLookupService;
        _logger = logger;
    }

    public async Task<IEnumerable<HumanResourcePersonaStatus>> Handle(GetHumanResourcePersonaStatusesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var response = await _hrPersonaStatusesLookupService.GetAllAsync();

        _logger.LogInformation("HR Persona Statuses were getting successfully.");

        return response;
    }
}
