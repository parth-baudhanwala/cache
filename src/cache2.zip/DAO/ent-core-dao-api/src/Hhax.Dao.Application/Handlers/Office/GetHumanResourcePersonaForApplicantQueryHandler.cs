﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetHumanResourcePersonaForApplicantQueryHandler : IRequestHandler<GetHumanResourcePersonaForApplicantQuery, HumanResourcePersona?>
{
    private readonly IGenericRepository<HumanResourcePersonaEntity> _hrPersonaRepository;
    private readonly IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> _applicantHumanResourcePersonaMappingRepository;

    private readonly IMapper _mapper;
    private readonly ILogger<GetHumanResourcePersonaForApplicantQueryHandler> _logger;

    public GetHumanResourcePersonaForApplicantQueryHandler(IGenericRepository<HumanResourcePersonaEntity> hrPersonaRepository, 
                                                           IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> applicantHumanResourcePersonaMappingRepository,
                                                           IMapper mapper,
                                                           ILogger<GetHumanResourcePersonaForApplicantQueryHandler> logger)
    {
        _hrPersonaRepository = hrPersonaRepository;
        _applicantHumanResourcePersonaMappingRepository = applicantHumanResourcePersonaMappingRepository;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<HumanResourcePersona?> Handle(GetHumanResourcePersonaForApplicantQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("GetHumanResourcePersonaForApplicantAsync with Id: {applicantId}.", request.ApplicantId);

        var mappings = await _applicantHumanResourcePersonaMappingRepository.FindAsync(x => x.ApplicantId == request.ApplicantId);
        if (mappings.Any())
        {
            //the applicant may have many assigned hr-personas
            //we only use the last one as the currently hr
            var recent = mappings.OrderByDescending(x => x.Created).First();

            var hrPersona = await _hrPersonaRepository.GetByIdAsync(recent.HumanResourcePersonaId);
            if (hrPersona != null)
            {
                var result = _mapper.Map<HumanResourcePersona>(hrPersona);

                _logger.LogInformation("Human Resource Persona for applicant with Id: {applicantId} was getting successfully.", request.ApplicantId);

                return result!;
            }
        }

        throw new EntityNotFoundException($"Human Resource Persona For Applicant with Id: {request.ApplicantId}.");
    }
}
