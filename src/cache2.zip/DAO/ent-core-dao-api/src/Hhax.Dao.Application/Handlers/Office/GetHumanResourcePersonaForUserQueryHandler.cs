﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetHumanResourcePersonaForUserQueryHandler : IRequestHandler<GetHumanResourcePersonaForUserQuery, HumanResourcePersona?>
{
    private readonly IGenericRepository<HumanResourcePersonaEntity> _hrPersonaRepository;
    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetHumanResourcePersonaForUserQueryHandler> _logger;

    public GetHumanResourcePersonaForUserQueryHandler(IGenericRepository<HumanResourcePersonaEntity> hrPersonaRepository,
                                                      IAuthenticationService authenticationService,
                                                      IMapper mapper,
                                                      ILogger<GetHumanResourcePersonaForUserQueryHandler> logger)
    {
        _hrPersonaRepository = hrPersonaRepository;
        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<HumanResourcePersona?> Handle(GetHumanResourcePersonaForUserQuery request, CancellationToken cancellationToken)
    {
        var userId = _authenticationService.GetUserId();

        _logger.LogInformation("GetHumanResourcePersonaForUserAsync with Id: {userId}.", userId);

        var hrPersona = await _hrPersonaRepository.FirstOrDefaultAsync(x => x.UserId == userId);
        if (hrPersona == null)
        {
            const string message = "Human Resource Persona for current user not found";
            throw new EntityNotFoundException(message);
        }

        var response = _mapper.Map<HumanResourcePersona>(hrPersona);

        _logger.LogInformation("Human Resource Persona for user with Id: {userId} was getting successfully.", userId);

        return response;
    }
}
