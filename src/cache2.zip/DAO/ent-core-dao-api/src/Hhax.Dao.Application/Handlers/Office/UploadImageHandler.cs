﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Office;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Office;

public class UploadImageHandler : IRequestHandler<UploadImageCommand, Unit>
{
    private readonly AwsS3Configuration _awsS3Configuration;

    private readonly IAwsImageService _awsFileService;
    
    private readonly ILogger<UploadImageHandler> _logger;

    public UploadImageHandler(IOptions<AwsS3Configuration> awsS3ConfigurationOptions, 
                              IAwsImageService awsFileService,
                              ILogger<UploadImageHandler> logger)
    {
        _awsS3Configuration = awsS3ConfigurationOptions.Value;
        _awsFileService = awsFileService;
        _logger = logger;
    }

    public async Task<Unit> Handle(UploadImageCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Upload image with Office Id: {OfficeId} and  Type: {Type}", request.OfficeId, request.Type);

        var key = $"offices/{request.OfficeId}/{request.Type}";

        await _awsFileService.UploadImageAsync(_awsS3Configuration.BucketName!, key, request.FileName, request.Stream, request.Width, request.Height);

        _logger.LogInformation("Image was uploaded with {OfficeId} and {Type}", request.OfficeId, request.Type);

        return Unit.Value;
    }
}
