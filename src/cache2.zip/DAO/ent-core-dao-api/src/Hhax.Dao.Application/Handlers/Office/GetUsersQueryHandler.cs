﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.User;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetUsersQueryHandler : IRequestHandler<GetUsersQuery, IEnumerable<UserInfo>>
{
    private readonly IGenericRepository<UserInfoEntity> _userRepository;
    private readonly IAuthenticationService _authenticationService;

    private readonly ILogger<GetUsersQueryHandler> _logger;

    public GetUsersQueryHandler(IGenericRepository<UserInfoEntity> userRepository,
                                IAuthenticationService authenticationService,
                                ILogger<GetUsersQueryHandler> logger)
    {
        _userRepository = userRepository;
        _authenticationService = authenticationService;

        _logger = logger;
    }

    public async Task<IEnumerable<UserInfo>> Handle(GetUsersQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        const string userMasterRole = "Vendor";

        var users = await _userRepository.FindAsync(user => user.AgencyId == _authenticationService.GetAgencyId() && user.IsActive && user.UserMasterRole == userMasterRole);

        var response = users.Select(user => new UserInfo(user.Id, user.UserName, user.Created, user.CreatedBy, user.Updated, user.UpdatedBy))
                            .OrderBy(user => user.UserName)
                            .ToArray();

        _logger.LogInformation("Users were getting successfully.");

        return response;
    }
}
