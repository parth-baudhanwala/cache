﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Contexts;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetOfficesQueryHandler : IRequestHandler<GetOfficesQuery, IEnumerable<OfficeHierarchy>>
{
    private readonly IDbContextFactory<HhaDbContext> _hhaxDbContextFactory;
    private readonly IDbContextFactory<DaoDbContext> _daoDbContextFactory;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetOfficesQueryHandler> _logger;

    public GetOfficesQueryHandler(IDbContextFactory<HhaDbContext> hhaxDbContextFactory,
                                  IDbContextFactory<DaoDbContext> daoDbContextFactory,
                                  IAuthenticationService authenticationService,
                                  IMapper mapper,
                                  ILogger<GetOfficesQueryHandler> logger)
    {
        _hhaxDbContextFactory = hhaxDbContextFactory;
        _daoDbContextFactory = daoDbContextFactory;

        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<IEnumerable<OfficeHierarchy>> Handle(GetOfficesQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var agencyId = _authenticationService.GetAgencyId();

        var offices = await GetOfficesAsync(agencyId, cancellationToken);

        var response = _mapper.Map<IEnumerable<OfficeHierarchy>>(offices);

        _logger.LogInformation("Offices were getting successfully.");

        return response;
    }

    private async Task<IEnumerable<OfficeHierarchyEntity>> GetOfficesAsync(int agencyId, CancellationToken cancellationToken)
    {
        var result = new List<OfficeHierarchyEntity>();

        using (var hhaxDbContext = await _hhaxDbContextFactory.CreateDbContextAsync(cancellationToken))
        {
            var officesByAgency = await hhaxDbContext.Offices!.Where(x => x.IsActive && x.VendorId == agencyId && x.OfficeLevelId != -1)
                                                            .Select(x => new OfficeHierarchyEntity
                                                            {
                                                                Id = x.Id,
                                                                OfficeName = x.OfficeName,
                                                                OfficeParentId = x.OfficeLevelId,
                                                                HirarchyLevel = 0,
                                                                IsActive = true
                                                            })
                                                            .ToArrayAsync(cancellationToken: cancellationToken);

            var officeIds = officesByAgency.Select(x => x.Id).Distinct().ToArray();

            using (var daoDbContext = await _daoDbContextFactory.CreateDbContextAsync())
            {
                var setupsMappingOfficeIds = await daoDbContext.ApplicationFormOfficeMappings!.Where(x => officeIds.Contains(x.OfficeId))
                                                                                           .Select(x => x.OfficeId)
                                                                                           .Distinct()
                                                                                           .ToArrayAsync();

                foreach (var office in officesByAgency)
                {
                    office.IsActive = !setupsMappingOfficeIds!.Contains(office.Id);
                }

                var offices = await GetOfficesByLevels(hhaxDbContext, daoDbContext, agencyId, cancellationToken);

                result = officesByAgency.Union(offices).OrderBy(x => x.OfficeName).ToList();

                // insert default hierarchy item: "ALL" 
                var allOfficeHierarchy = new OfficeHierarchyEntity
                {
                    Id = 0,
                    OfficeName = "ALL",
                    OfficeParentId = -1,
                    HirarchyLevel = 1,
                    IsActive = true
                };

                result.Insert(0, allOfficeHierarchy);
            }
        }

        return result;
    }

    private async Task<IEnumerable<OfficeHierarchyEntity>> GetOfficesByLevels(HhaDbContext hhaDbContext, DaoDbContext daoDbContext, int agencyId, CancellationToken cancellationToken)
    {
        var officesByAgency = await hhaDbContext.Offices!.Where(x => x.IsActive && x.VendorId == agencyId && x.OfficeLevelId != -1)
                                                         .ToArrayAsync(cancellationToken: cancellationToken);

        var officeLevelIds = officesByAgency.Select(x => x.OfficeLevelId)
                                            .Distinct()
                                            .ToArray();

        var offices = await hhaDbContext.OfficeLevels!.Where(x => officeLevelIds.Contains(x.Id) && x.Active)
                                                      .Select(x => new OfficeHierarchyEntity {
                                                          Id = x.Id,
                                                          OfficeName = x.OfficeLevelName,
                                                          OfficeParentId = x.ParentOfficeLevelId == -1 ? 0 : x.ParentOfficeLevelId,
                                                          HirarchyLevel = 1,
                                                          IsActive = true
                                                      })
                                                      .ToArrayAsync(cancellationToken: cancellationToken);

        var officeIds = officesByAgency.Select(x => x.Id)
                                       .Distinct()
                                       .ToArray();

        var setupsMappingOfficeIds = await daoDbContext.ApplicationFormOfficeMappings!.Where(x => officeIds.Contains(x.OfficeId))
                                                                                      .Select(x => x.OfficeId)
                                                                                      .Distinct()
                                                                                      .ToArrayAsync(cancellationToken: cancellationToken);

        foreach (var office in offices)
        {
            office.IsActive = !setupsMappingOfficeIds!.Contains(office.Id);
        }

        return offices;
    }
}
