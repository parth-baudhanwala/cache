﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class DeleteHumanResourcePersonaHandler : IRequestHandler<DeleteHumanResourcePersonaCommand, Unit>
{
    private readonly IGenericRepository<HumanResourcePersonaEntity> _humanResourcePersonaRepository;
    private readonly ILogger<DeleteHumanResourcePersonaHandler> _logger;

    private readonly IAuthenticationService _authenticationService;

    public DeleteHumanResourcePersonaHandler(IGenericRepository<HumanResourcePersonaEntity> humanResourcePersonaRepository,
                                             ILogger<DeleteHumanResourcePersonaHandler> logger,
                                             IAuthenticationService authenticationService)
    {
        _humanResourcePersonaRepository = humanResourcePersonaRepository;
        _authenticationService = authenticationService;
        _logger = logger;
    }

    public async Task<Unit> Handle(DeleteHumanResourcePersonaCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        int agencyId = _authenticationService.GetAgencyId();

        var humanResourcePersonaEntity = await _humanResourcePersonaRepository.FirstOrDefaultAsync(x => x.Id == request.HumanResourcePersonaId && x.AgencyId == agencyId);
        
        if (humanResourcePersonaEntity == null)
        {
            var message = $"{nameof(HumanResourcePersonaEntity)} with Id: {request.HumanResourcePersonaId} not found.";

            _logger.LogError("Human Resource Persona with Id: {applicantId} not found.", request.HumanResourcePersonaId);
            throw new EntityNotFoundException(message);
        }

        await _humanResourcePersonaRepository.RemoveAsync(humanResourcePersonaEntity!);


        _logger.LogInformation("Human Resource Persona with Id: {Id} was created.", request.HumanResourcePersonaId);

        return Unit.Value;
    }
}
