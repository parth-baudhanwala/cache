﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class AddHumanResourcePersonaHandler : IRequestHandler<AddHumanResourcePersonaCommand, BaseResponse>
{
    private readonly IGenericRepository<HumanResourcePersonaEntity> _hrPersonaRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<AddHumanResourcePersonaHandler> _logger;

    public AddHumanResourcePersonaHandler(IGenericRepository<HumanResourcePersonaEntity> hrPersonaRepository,
                                          IMapper mapper,
                                          ILogger<AddHumanResourcePersonaHandler> logger,
                                          IAuthenticationService authenticationService)
    {
        _hrPersonaRepository = hrPersonaRepository;

        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<BaseResponse> Handle(AddHumanResourcePersonaCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var hrPersona = new HumanResourcePersonaEntity
        {
            Name = request.Name,
            StatusId = request.StatusId,
            UserId = request.UserId,
            Offices = request.Offices,
            Created = DateTime.UtcNow,
            Updated = DateTime.UtcNow,
            AgencyId = _authenticationService.GetAgencyId()
        };

        if (request.OfficeIds != null)
        {
            var humanResourcePersonaOfficeMappings = new List<HumanResourcePersonaOfficeMappingEntity>();

            foreach (var officeId in request.OfficeIds!)
            {
                var humanResourcePersonaMapping = new HumanResourcePersonaOfficeMappingEntity
                {
                    OfficeId = officeId,
                    HumanResourcePersonaId = hrPersona.Id,
                    Created = DateTime.UtcNow,
                    Updated = DateTime.UtcNow
                };
                humanResourcePersonaOfficeMappings.Add(humanResourcePersonaMapping);
            }
            hrPersona.HumanResourcePersonaOfficeMappings = humanResourcePersonaOfficeMappings;
        }

        await _hrPersonaRepository.AddAsync(hrPersona);

        var response = new BaseResponse { Id = hrPersona.Id };

        _logger.LogInformation("HumanResourcePersona with Id: {Id} were adding successfully.", response.Id);

        return response;
    }
}
