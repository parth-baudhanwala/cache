﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class AssignHumanResourcePersonaToApplicantHandler : IRequestHandler<AssignHumanResourcePersonaToApplicantCommand, BaseRangeResponse>
{
    private readonly IGenericRepository<UserInfoEntity> _userRepository;
    private readonly IGenericRepository<ApplicantNoteEntity> _applicantNoteRepository;
    private readonly IGenericRepository<HumanResourcePersonaEntity> _hrPersonaRepository;
    private readonly IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> _applicantHumanResourcePersonaMappingRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly ILogger<AssignHumanResourcePersonaToApplicantHandler> _logger;

    public AssignHumanResourcePersonaToApplicantHandler(IGenericRepository<UserInfoEntity> userRepository,
                                                        IGenericRepository<ApplicantNoteEntity> applicantNoteRepository,
                                                        IGenericRepository<HumanResourcePersonaEntity> hrPersonaRepository,
                                                        IGenericRepository<ApplicantHumanResourcePersonaMappingEntity> applicantHumanResourcePersonaMappingRepository,
                                                        IAuthenticationService authenticationService,
                                                        ILogger<AssignHumanResourcePersonaToApplicantHandler> logger)
    {
        _userRepository = userRepository;
        _hrPersonaRepository = hrPersonaRepository;
        _applicantNoteRepository = applicantNoteRepository;
        _applicantHumanResourcePersonaMappingRepository = applicantHumanResourcePersonaMappingRepository;

        _authenticationService = authenticationService;

        _logger = logger;
    }

    public async Task<BaseRangeResponse> Handle(AssignHumanResourcePersonaToApplicantCommand request, CancellationToken cancellationToken)
    {
        var applicantIds = string.Join(", ", request.AssignApplicants?.Select(x => x.ApplicantId)!);
        _logger.LogInformation("AssignHumanResourcePersona with ApplicantIds: '{ApplicantIds}' and HumanResourcePersonaId: {HumanResourcePersonaId}.",
            applicantIds, request.HumanResourcePersonaId);

        if (request.AssignApplicants?.Any() ?? false)
        {
            IEnumerable<HumanResourcePersonaEntity> hrPersonas = await _hrPersonaRepository.FindAsync(x => x.Id == request.HumanResourcePersonaId);

            if (hrPersonas.Any())
            {
                int userId = hrPersonas.First().UserId!.Value;
                var users = await _userRepository.FindAsync(x => x.IsActive && x.Id == userId);
                if (users.Any())
                {
                    List<int> ids = new();

                    foreach (var applicantStatus in request.AssignApplicants)
                    {
                        var mappingId = await AddApplicantHrMappingAsync(applicantStatus.ApplicantId, request.HumanResourcePersonaId);
                        await AddApplicantNoteAsync(request.NoteText!, applicantStatus.WorkflowStatus!, applicantStatus.ApplicantId, request.HumanResourcePersonaId);

                        ids.Add(mappingId);
                        _logger.LogInformation($"Human Resource Persona with Id: {request.HumanResourcePersonaId} was assigned.");
                    }

                    return new BaseRangeResponse(ids);
                }
            }
        }
        throw new EntityNotFoundException($"This HR Representative is no longer available, please select another one");
    }

    private async Task<int> AddApplicantHrMappingAsync(int applicantId, int humanResourcePersonaId)
    {
        ApplicantHumanResourcePersonaMappingEntity applicantHumanResourcePersonaMapping = new()
        {
            ApplicantId = applicantId,
            HumanResourcePersonaId = humanResourcePersonaId,
            Created = DateTime.UtcNow,
        };

        await _applicantHumanResourcePersonaMappingRepository.AddAsync(applicantHumanResourcePersonaMapping);

        return applicantHumanResourcePersonaMapping.Id;
    }

    private async Task AddApplicantNoteAsync(string noteText, string workflowStatus, int applicantId, int humanResourcePersonaId)
    {
        if (!string.IsNullOrEmpty(noteText))
        {
            ApplicantNoteEntity applicantNote = new()
            {
                Text = noteText,
                WorkflowStatus = workflowStatus,
                ApplicantId = applicantId,
                HumanResourcePersonaId = humanResourcePersonaId,
                CreatedBy = _authenticationService.GetUserId(),
                Created = DateTime.UtcNow,
            };

            await _applicantNoteRepository.AddAsync(applicantNote);

            _logger.LogInformation("Applicant Note with was added.");
        }
    }
}
