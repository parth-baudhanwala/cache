﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Office;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetOfficeImageQueryHandler : IRequestHandler<GetOfficeImageQuery, byte[]>
{
    private readonly AwsS3Configuration _awsS3Configuration;

    private readonly IAwsImageService _awsFileService;

    private readonly ILogger<GetOfficeImageQueryHandler> _logger;

    public GetOfficeImageQueryHandler(IOptions<AwsS3Configuration> awsS3ConfigurationOptions,
                                      IAwsImageService awsFileService,
                                      ILogger<GetOfficeImageQueryHandler> logger)
    {
        _awsS3Configuration = awsS3ConfigurationOptions.Value;
        _awsFileService = awsFileService;
        _logger = logger;
    }

    public async Task<byte[]> Handle(GetOfficeImageQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("Get image with {OfficeId} and {Type}", request.OfficeId, request.Type);

        var response = await _awsFileService.GetImageAsync(_awsS3Configuration.BucketName!, $"offices/{request.OfficeId}/{request.Type}.webp");

        _logger.LogInformation("Image was getting with {OfficeId} and {Type}", request.OfficeId, request.Type);

        return response;
    }
}
