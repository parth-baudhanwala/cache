﻿using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class UpdateHumanResourcePersonaHandler : IRequestHandler<UpdateHumanResourcePersonaCommand, BaseResponse>
{
    private readonly IGenericRepository<HumanResourcePersonaEntity> _hrPersonaRepository;
    private readonly ILogger<UpdateHumanResourcePersonaHandler> _logger;

    public UpdateHumanResourcePersonaHandler(IGenericRepository<HumanResourcePersonaEntity> hrPersonaRepository,
                                             ILogger<UpdateHumanResourcePersonaHandler> logger)
    {
        _hrPersonaRepository = hrPersonaRepository;
        _logger = logger;
    }

    public async Task<BaseResponse> Handle(UpdateHumanResourcePersonaCommand request, CancellationToken cancellationToken)
    {
        _logger.LogInformation($"{nameof(Handle)}.");

        var humanResourcePersona = await _hrPersonaRepository.GetByIdAsync(request.Id, hasNavigationProperties: true);
        if (humanResourcePersona == null)
        {
            var message = $"{nameof(HumanResourcePersonaEntity)} with Id: {request.Id} not found.";

            _logger.LogError("Human Resource Persona with Id: {humanResourcePersonaId} not found.", request.Id);
            throw new ApplicationFormNotFoundException(message);
        }

        humanResourcePersona.Name = request.Name;
        humanResourcePersona.StatusId = request.StatusId;
        humanResourcePersona.UserId = request.UserId;
        humanResourcePersona.Updated = DateTime.UtcNow;

        UpdateHumanResourcePersonaMappings(humanResourcePersona, request);

        await _hrPersonaRepository.UpdateAsync(humanResourcePersona);

        var response = new BaseResponse { Id = humanResourcePersona.Id };

        _logger.LogInformation("Human Resource Persona with Id: {Id} was updated successfully.", request.Id);

        return response;
    }

    private static void UpdateHumanResourcePersonaMappings(HumanResourcePersonaEntity humanResourcePersona, UpdateHumanResourcePersonaCommand parameters)
    {
        var humanResourcePersonaOfficeMappings = humanResourcePersona.HumanResourcePersonaOfficeMappings!.ToList();
        foreach (var mapping in humanResourcePersonaOfficeMappings)
        {
            if (!parameters.OfficeIds!.Any(x => x == mapping.OfficeId))
            {
                humanResourcePersona.HumanResourcePersonaOfficeMappings!.Remove(mapping);
            }
        }

        if (parameters.OfficeIds != null)
        {
            humanResourcePersonaOfficeMappings = humanResourcePersona.HumanResourcePersonaOfficeMappings!.ToList();
            foreach (var officeId in parameters.OfficeIds!)
            {
                if (!humanResourcePersonaOfficeMappings.Any(x => x.OfficeId == officeId))
                {
                    var humanResourcePersonaOfficeMapping = new HumanResourcePersonaOfficeMappingEntity
                    {
                        OfficeId = officeId,
                        HumanResourcePersonaId = humanResourcePersona.Id,
                        Created = DateTime.UtcNow,
                        Updated = DateTime.UtcNow
                    };
                    humanResourcePersona.HumanResourcePersonaOfficeMappings!.Add(humanResourcePersonaOfficeMapping);
                }
            }
        }
    }
}
