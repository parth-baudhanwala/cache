﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetHumanResourcePersonaQueryHandler : IRequestHandler<GetHumanResourcePersonaQuery, HumanResourcePersona>
{
    private readonly IGenericRepository<HumanResourcePersonaEntity> _hrPersonaRepository;
    private readonly IGenericRepository<UserInfoEntity> _userRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetHumanResourcePersonaQueryHandler> _logger;

    public GetHumanResourcePersonaQueryHandler(IGenericRepository<HumanResourcePersonaEntity> hrPersonaRepository,
                                               IGenericRepository<UserInfoEntity> userRepository,
                                               IMapper mapper,
                                               ILogger<GetHumanResourcePersonaQueryHandler> logger,
                                               IAuthenticationService authenticationService)
    {
        _hrPersonaRepository = hrPersonaRepository;
        _userRepository = userRepository;
        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<HumanResourcePersona> Handle(GetHumanResourcePersonaQuery request, CancellationToken cancellationToken)
    {
        _logger.LogInformation("GetHumanResourcePersonaAsync with Id: {HumanResourcePersonaId}.", request.HumanResourcePersonaId);

        int agencyId = _authenticationService.GetAgencyId();

        var humanResourcePersona = await _hrPersonaRepository.FirstOrDefaultAsync(x => x.Id == request.HumanResourcePersonaId && x.AgencyId == agencyId, hasNavigationProperties: true);

        if (humanResourcePersona == null)
        {
            var message = $"{nameof(HumanResourcePersona)} with Id: {request.HumanResourcePersonaId} not found.";

            _logger.LogError(message);
            throw new EntityNotFoundException(message);
        }

        var response = _mapper.Map<HumanResourcePersona>(humanResourcePersona);

        var users = await _userRepository.FindAsync(user => user.IsActive && humanResourcePersona.UserId == user.Id);
        if (users is not null && users.Any())
        {
            response.UserName = users?.First()?.UserName!;
        }

        _logger.LogInformation("Human Resource Persona with Id: {humanResourcePersonaId} was getting successfully.", request.HumanResourcePersonaId);

        return response;
    }
}
