﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Extensions;
using Hhax.Dao.Application.Queries.Office;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Abstracts.Requests;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;

namespace Hhax.Dao.Application.Handlers.Office;

public class GetHumanResourcePersonasQueryHandler : IRequestHandler<GetHumanResourcePersonasQuery, PaginatationResponse<HumanResourcePersona>>
{
    private readonly IGenericRepository<UserInfoEntity> _userRepository;
    private readonly IGenericRepository<OfficeInfoEntity> _officeRepository;
    private readonly IGenericRepository<HumanResourcePersonaEntity> _hrPersonaRepository;

    private readonly IAuthenticationService _authenticationService;

    private readonly IMapper _mapper;
    private readonly ILogger<GetHumanResourcePersonasQueryHandler> _logger;

    public GetHumanResourcePersonasQueryHandler(IGenericRepository<UserInfoEntity> userRepository,
                                                IGenericRepository<OfficeInfoEntity> officeRepository,
                                                IGenericRepository<HumanResourcePersonaEntity> hrPersonaRepository,
                                                IMapper mapper,
                                                ILogger<GetHumanResourcePersonasQueryHandler> logger,
                                                IAuthenticationService authenticationService)
    {
        _userRepository = userRepository;
        _officeRepository = officeRepository;
        _hrPersonaRepository = hrPersonaRepository;
        _authenticationService = authenticationService;

        _mapper = mapper;
        _logger = logger;
    }

    public async Task<PaginatationResponse<HumanResourcePersona>> Handle(GetHumanResourcePersonasQuery request, CancellationToken cancellationToken)
    {
        var total = 0;

        IEnumerable<HumanResourcePersonaEntity> entities;

        SortRequest<HumanResourcePersonaEntity> sortParameter = BuildSortParameter(request.Request.Sort);

        List<Expression<Func<HumanResourcePersonaEntity, bool>>> searchPredictants = BuildSearchPredicants(request.Request);
        entities = await _hrPersonaRepository.FindAsync(sortParameter, searchPredictants, request.Request?.Page?.PageNumber ?? 1, request.Request?.Page?.PageSize ?? 10, hasNavigationProperties: true);
        total = await _hrPersonaRepository.CountAsync(searchPredictants);

        var hrPersonas = _mapper.Map<IEnumerable<HumanResourcePersona>>(entities);

        var officeIds = hrPersonas.SelectMany(x => x.OfficeIds!).ToArray();
        var offices = await _officeRepository.FindAsync(x => officeIds.Contains(x.Id));

        foreach (var hrPersona in hrPersonas)
        {
            var targetOffices = offices!.Where(x => hrPersona.OfficeIds!.Contains(x.Id)).ToArray();
            hrPersona.Offices = string.Join(", ", targetOffices.Select(x => x.OfficeName).ToArray()!);
        }

        var userIds = hrPersonas.Select(x => x.UserId).Distinct().ToArray();
        var users = await _userRepository.FindAsync(x => x.IsActive && userIds.Contains(x.Id));

        foreach (var hrPersona in hrPersonas)
        {
            var user = users.FirstOrDefault(x => x.Id == hrPersona.UserId);
            if (user is not null)
            {
                hrPersona.UserName = user.UserName;
                hrPersona.FirstName = user.FirstName;
                hrPersona.LastName = user.LastName;
            }
        }

        var response = new PaginatationResponse<HumanResourcePersona>
        {
            Data = hrPersonas,
            PageInfo = new PageInfo { TotalRecordCount = total }
        };

        _logger.LogInformation("HR Personas were getting successfully.");

        return response;
    }

    private static SortRequest<HumanResourcePersonaEntity> BuildSortParameter(Sort? sort)
    {
        const string name = "name";

        var result = new SortRequest<HumanResourcePersonaEntity>();

        if (sort?.Item == name)
        {
            result = new(x => x.Name!, sort.Direction == SortDirection.Asc);
        }

        return result;
    }

    private List<Expression<Func<HumanResourcePersonaEntity, bool>>> BuildSearchPredicants(PaginationRequest<SearchHumanResourcePersonaRequest> parameters)
    {
        List<Expression<Func<HumanResourcePersonaEntity, bool>>> expressions = new();

        int agencyId = _authenticationService.GetAgencyId();

        var officesIds = parameters.Filters?.Offices.ParseInts();

        expressions.Add(x => x.AgencyId == agencyId);

        if(!string.IsNullOrWhiteSpace(parameters.Filters?.Name))
        {
            expressions.Add(x => !string.IsNullOrWhiteSpace(x.Name) && EF.Functions.ILike(x.Name, $"%{parameters.Filters.Name}%"));
        }

        if((parameters.Filters?.StatusId.HasValue ?? false) && parameters.Filters?.StatusId != (int)ActiveStatus.None)
        {
            expressions.Add(x => x.StatusId == parameters.Filters!.StatusId);
        }

        if(officesIds != null && officesIds.Any())
        {
            expressions.Add(x => x.HumanResourcePersonaOfficeMappings!.Any(m => officesIds.Contains(m.OfficeId)));
        }

        return expressions;
    }
}
