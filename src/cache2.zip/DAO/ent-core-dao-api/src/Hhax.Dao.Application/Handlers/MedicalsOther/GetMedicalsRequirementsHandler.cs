﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.MedicalsOther;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.MedicalsOther;

public record GetMedicalsRequirementsHandler(ILookupService<ComplianceSetupOffice, ComplianceSetupOfficeEntity> ComplianceSetupOfficeLookups,
                                             IReadOnlyRepository<ComplianceExpItemEntity> ComplianceExpItemsRepository,
                                             IReadOnlyRepository<ComplianceExpItemResultEntity> ComplianceExpItemResultsRepository,
                                             IReadOnlyRepository<MedicalsApplicantValueEntity> MedicalsApplicantValuesRepository,
                                             IAuthenticationService AuthenticationService,
                                             ILogger<GetMedicalsRequirementsHandler> Logger,
                                             IMediatorService Mediator)
    : IRequestHandler<GetMedicalsRequirementsQuery, IEnumerable<MedicalsApplicantValue>>
{
    public async Task<IEnumerable<MedicalsApplicantValue>> Handle(GetMedicalsRequirementsQuery query, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        var compliacneSetupOffices = await ComplianceSetupOfficeLookups.FindAsync(x => x.ProviderId == AuthenticationService.GetAgencyId() && x.OfficeId == query.OfficeId);

        if (compliacneSetupOffices.Any())
        {
            var complianceSetupOffice = compliacneSetupOffices.OrderByDescending(x => x.PublishVersion).First();

            var complianceExpItems = await ComplianceExpItemsRepository.FindAsync(x => x.ComplianceSetupId == complianceSetupOffice.ComplianceSetupId && x.Status == ComplianceExpItemStatuses.Active && x.ExpirationItemTypeId == (byte)ComplianceExpItemTypes.Medical);

            if (complianceExpItems.Any())
            {
                var complianceExpItemsIds = complianceExpItems.Select(x => x.Id);

                var complianceExpItemsResults = await ComplianceExpItemResultsRepository.FindAsync(x => x.ComplianceExpItemId.HasValue && complianceExpItemsIds.Contains(x.ComplianceExpItemId.Value));

                var complianceExtItemsValues = await MedicalsApplicantValuesRepository.FindAsync(x => x.ApplicantId == query.ApplicantId);

                GetApplicantSignatureCommand signatureCommand = new(query.ApplicantId, 0, new int[1] { (int)ApplicationFormApplicantSections.MedicalsAndOtherDocuments });

                var signatures = await Mediator.SendAsync<GetApplicantSignatureCommand, IEnumerable<Signature>>(signatureCommand);

                var result = MapData(query.ApplicantId, complianceExpItems, complianceExpItemsResults, complianceExtItemsValues, signatures);

                Logger.LogInformation("Medicals records were retrieved successfully.");

                return result.OrderBy(x => x.MedicalName);
            }
        }

        Logger.LogInformation("Medicals records not found.");

        return Enumerable.Empty<MedicalsApplicantValue>();
    }

    private static IEnumerable<MedicalsApplicantValue> MapData(int applicantId,
                                                               IEnumerable<ComplianceExpItemEntity> items,
                                                               IEnumerable<ComplianceExpItemResultEntity> results,
                                                               IEnumerable<MedicalsApplicantValueEntity> values,
                                                               IEnumerable<Signature> signatures)
    {
        foreach (var item in items)
        {
            MedicalsApplicantValue value = new()
            {
                MedicalName = item.ExpirationItem,
                ComplianceExpItemId = item.ExpirationItemId ?? throw new NullValueException("Compliance Expiration Item Id should not be null."),
                ExpirationItemId = item.ExpirationItemId,
                ApplicantId = applicantId,
                Signature = signatures.FirstOrDefault(x => x.ReferenceId == item.ExpirationItemId),
                Results = GetResults(item.Id, results)
            };

            PopulateValueFields(value, values);

            yield return value;
        }
    }

    private static IEnumerable<SelectFieldValue> GetResults(int fieldId, IEnumerable<ComplianceExpItemResultEntity> results)
        => results.Where(x => x.ComplianceExpItemId == fieldId).OrderBy(x => x.Id).Select(x => new SelectFieldValue
        {
            OptionId = x.DraftComplianceExpItemResultId ?? 0,
            OptionText = x.OptionText,
            OptionValue = x.OptionValue
        });

    private static void PopulateValueFields(MedicalsApplicantValue target, IEnumerable<MedicalsApplicantValueEntity> values)
    {
        var targetValue = values.FirstOrDefault(x => x.ComplianceExpItemId == target.ComplianceExpItemId);

        if (targetValue is not null)
        {
            target.Id = targetValue.Id;
            target.Value = targetValue.Value;
            target.PerformedDate = targetValue.PerformedDate;
            target.FileKey = targetValue.FileKey;
            target.FileSize = targetValue.FileSize;
            target.Updated = targetValue.Updated;
            target.UpdatedBy = targetValue.UpdatedBy;
            target.Created = targetValue.Created;
            target.CreatedBy = targetValue.CreatedBy;
        }
    }
}
