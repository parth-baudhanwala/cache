﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.MedicalsOther;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.MedicalsOther;

public record DeleteMedicalsRequirementsHandler(IGenericRepository<MedicalsApplicantValueEntity> MedicalsApplicantValuesRepository,
                                                ILogger<DeleteMedicalsRequirementsHandler> Logger,
                                                IMediator Mediator,
                                                IFilesUploadService FilesUploadService)
    : IRequestHandler<DeleteMedicalsRequirementsCommand, Unit>
{
    public async Task<Unit> Handle(DeleteMedicalsRequirementsCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)} with applicantId: {command.ApplicantId}.");

        List<string> fileKeys = new();
        long totalFileSize = 0;

        if (command.Ids.Any())
        {
            var toRemove = await MedicalsApplicantValuesRepository.FindAsync(x => x.ApplicantId == command.ApplicantId && command.Ids.Contains(x.Id));

            foreach (var item in toRemove)
            {
                if (item.FileKey is null || item.FileSize is null) continue;

                fileKeys.Add(item.FileKey);
                totalFileSize += item.FileSize.Value;
            }

            await MedicalsApplicantValuesRepository.RemoveRangeAsync(toRemove);

            await UpdateApplicantEligibilities(command.ApplicantId, cancellationToken);

            if (fileKeys.Any())
            {
                await FilesUploadService.DeleteDocumentsAsync(fileKeys, totalFileSize, command.ApplicantId);
            }

            Logger.LogInformation($"Medicals records with Ids: {string.Join(", ", command.Ids)} were deleted.");
        }
        else
        {
            Logger.LogInformation($"Medicals records with Ids: {string.Join(", ", command.Ids)} not found.");
        }

        return Unit.Value;
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
