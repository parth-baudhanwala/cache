﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.MedicalsOther;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.MedicalsOther;

public record UpsertOtherRequirementsHandler(IGenericRepository<OtherApplicantValueEntity> OtherApplicantValuesRepository,
                                             ILogger<UpsertOtherRequirementsHandler> Logger,
                                             IMapper Mapper,
                                             IMediator Mediator,
                                             IFilesUploadService FilesUploadService)
    : IRequestHandler<UpsertOtherRequirementsCommand, BaseResponse>
{
    public async Task<BaseResponse> Handle(UpsertOtherRequirementsCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        List<string> fileKeys = new();
        long totalFileSize = 0;

        var entity = Mapper.Map<OtherApplicantValueEntity>(command.Data);

        await Mediator.Send(new ValidateApplicantRequestDataCommand(command.ApplicantId, null, new[] { command.Data }, ApplicantEligibilitySection.OtherRequirements), cancellationToken);

        entity.ApplicantId = command.ApplicantId;
        entity.PerformedDate = command.Data.PerformedDate?.ToUniversalTime();

        int id = await OtherApplicantValuesRepository.Upsert(entity, x => x.ApplicantId == command.ApplicantId && x.ComplianceExpItemId == entity.ComplianceExpItemId, requestedEntity =>
        {
            requestedEntity.PerformedDate = entity.PerformedDate;
            requestedEntity.Value = entity.Value;

            if (command.Data.IsFileDeleted
                && requestedEntity.FileKey is not null
                && requestedEntity.FileSize is not null
                && !requestedEntity.FileKey.Equals(entity.FileKey)
                && requestedEntity.FileSize != entity.FileSize)
            {
                fileKeys.Add(requestedEntity.FileKey);
                totalFileSize += requestedEntity.FileSize.Value;
                requestedEntity.FileKey = null;
                requestedEntity.FileSize = null;
            }

            if (!string.IsNullOrWhiteSpace(entity.FileKey))
            {
                requestedEntity.FileKey = entity.FileKey;
                requestedEntity.FileSize = entity.FileSize;
            }

            requestedEntity.Updated = DateTime.UtcNow;
            return requestedEntity;
        });

        if (command.Data.Signature is not null)
        {
            command.Data.Signature.ReferenceId = command.Data.ComplianceExpItemId;
            command.Data.Signature.ApplicantSectionId = (int)ApplicationFormApplicantSections.MedicalsAndOtherDocuments;
            await Mediator.Send(new SaveApplicantSignatureCommand(command.ApplicantId, new List<Signature>() { command.Data.Signature }), cancellationToken);
        }

        await UpdateApplicantEligibilities(command.ApplicantId, cancellationToken);

        if (fileKeys.Any())
        {
            await FilesUploadService.DeleteDocumentsAsync(fileKeys, totalFileSize, command.ApplicantId);
        }

        Logger.LogInformation("Other record was upserted successfully.");

        return new() { Id = id };
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }
}
