﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.MedicalsOther;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.MedicalsOther;

public record GetOtherRequirementsHandler(ILookupService<ComplianceSetupOffice, ComplianceSetupOfficeEntity> ComplianceSetupOfficeLookups,
                                          IReadOnlyRepository<ComplianceExpItemEntity> ComplianceExpItemsRepository,
                                          IReadOnlyRepository<ComplianceExpItemResultEntity> ComplianceExpItemResultsRepository,
                                          IReadOnlyRepository<OtherApplicantValueEntity> OtherApplicantValuesRepository,
                                          IAuthenticationService AuthenticationService,
                                          ILogger<GetOtherRequirementsHandler> Logger,
                                          IMediatorService Mediator)
    : IRequestHandler<GetOtherRequirementsQuery, IEnumerable<OtherApplicantValue>>
{
    public async Task<IEnumerable<OtherApplicantValue>> Handle(GetOtherRequirementsQuery query, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        var compliacneSetupOffices = await ComplianceSetupOfficeLookups.FindAsync(x => x.ProviderId == AuthenticationService.GetAgencyId() && x.OfficeId == query.OfficeId);
        if (compliacneSetupOffices.Any())
        {
            var complianceSetupOffice = compliacneSetupOffices.OrderByDescending(x => x.PublishVersion).First();

            var complianceExpItems = await ComplianceExpItemsRepository.FindAsync(x => x.ComplianceSetupId == complianceSetupOffice.ComplianceSetupId && x.Status == ComplianceExpItemStatuses.Active && x.ExpirationItemTypeId == (byte)ComplianceExpItemTypes.Other);

            if (complianceExpItems.Any())
            {
                var complianceExpItemsIds = complianceExpItems.Select(x => x.Id);

                var complianceExpItemsResults = await ComplianceExpItemResultsRepository.FindAsync(x => x.ComplianceExpItemId.HasValue && complianceExpItemsIds.Contains(x.ComplianceExpItemId.Value));

                var complianceExtItemsValues = await OtherApplicantValuesRepository.FindAsync(x => x.ApplicantId == query.ApplicantId);

                GetApplicantSignatureCommand signatureCommand = new(query.ApplicantId, 0, new int[1] { (int)ApplicationFormApplicantSections.MedicalsAndOtherDocuments });

                var signatures = await Mediator.SendAsync<GetApplicantSignatureCommand, IEnumerable<Signature>>(signatureCommand);

                var result = MapData(query.ApplicantId, complianceExpItems, complianceExpItemsResults, complianceExtItemsValues, signatures);

                Logger.LogInformation("Other records were retrieved successfully.");

                return result.OrderBy(x => x.RequirementName);
            }
        }

        Logger.LogInformation("Other records not found.");

        return Enumerable.Empty<OtherApplicantValue>();
    }

    private static IEnumerable<OtherApplicantValue> MapData(int applicantId,
                                                            IEnumerable<ComplianceExpItemEntity> items,
                                                            IEnumerable<ComplianceExpItemResultEntity> results,
                                                            IEnumerable<OtherApplicantValueEntity> values,
                                                            IEnumerable<Signature> signatures)
    {
        foreach (var item in items)
        {
            OtherApplicantValue value = new()
            {
                RequirementName = item.ExpirationItem,
                ComplianceExpItemId = item.ExpirationItemId ?? throw new NullValueException("Compliance Expiration Item Id should not be null."),
                ExpirationItemId = item.ExpirationItemId,
                ApplicantId = applicantId,
                Signature = signatures.FirstOrDefault(x => x.ReferenceId == item.ExpirationItemId),
                Results = GetResults(item.Id, results)
            };

            PopulateValueFields(value, values);

            yield return value;
        }
    }

    private static IEnumerable<SelectFieldValue> GetResults(int fieldId, IEnumerable<ComplianceExpItemResultEntity> results)
        => results.Where(x => x.ComplianceExpItemId == fieldId).OrderBy(x => x.Id).Select(x => new SelectFieldValue
        {
            OptionId = x.DraftComplianceExpItemResultId ?? 0,
            OptionText = x.OptionText,
            OptionValue = x.OptionValue
        });

    private static void PopulateValueFields(OtherApplicantValue target, IEnumerable<OtherApplicantValueEntity> values)
    {
        var targetValue = values.FirstOrDefault(x => x.ComplianceExpItemId == target.ComplianceExpItemId);

        if (targetValue is not null)
        {
            target.Id = targetValue.Id;
            target.Value = targetValue.Value;
            target.PerformedDate = targetValue.PerformedDate;
            target.FileKey = targetValue.FileKey;
            target.FileSize = targetValue.FileSize;
            target.Updated = targetValue.Updated;
            target.UpdatedBy = targetValue.UpdatedBy;
            target.Created = targetValue.Created;
            target.CreatedBy = targetValue.CreatedBy;
        }
    }
}
