﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Queries.Availability;
using Hhax.Dao.Domain.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Availability;

public record GetWorkPreferencesHandler(ILookupService<WorkPreference, WorkPreferenceEntity> WorkPreferencesLookups,
                                        ILogger<GetWorkPreferencesHandler> Logger) 
    : IRequestHandler<GetWorkPreferencesQuery, IEnumerable<WorkPreference>>
{
    public async Task<IEnumerable<WorkPreference>> Handle(GetWorkPreferencesQuery query, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        var result = await WorkPreferencesLookups.FindAsync(x => x.IsActive);

        var response = result.OrderBy(x => x.Id).ToArray();

        Logger.LogInformation("Work Preferences were retrieved successfully.");

        return response;
    }
}
