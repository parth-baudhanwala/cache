﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Availability;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Availability;

public record UpsertApplicantAvailabilityHandler(IGenericRepository<AvailabilityDayEntity> AvailabilityDaysRepository,
                                                 IGenericRepository<AvailabilityTimeShiftEntity> AvailabilityTimeShiftsRepository,
                                                 ILogger<UpsertApplicantAvailabilityHandler> Logger,
                                                 IMapper Mapper,
                                                 IMediator Mediator)
    : IRequestHandler<UpsertApplicantAvailabilityCommand, BaseRangeResponse>
{
    public async Task<BaseRangeResponse> Handle(UpsertApplicantAvailabilityCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        var upsertEntities = Mapper.Map<IEnumerable<AvailabilityDayEntity>>(command.AvailabilityDays);

        await Mediator.Send(new ValidateApplicantRequestDataCommand(command.ApplicantId, null, upsertEntities, ApplicantEligibilitySection.Availability), cancellationToken);

        List<int> ids = new();

        if (!upsertEntities.Any())
        {
            Logger.LogInformation("Applicant availability info was not upserted successfully.");
            return new(ids);
        }

        foreach (var upsertDayEntity in upsertEntities)
        {
            await UpsertDayAsync(upsertDayEntity, command.ApplicantId);

            if (upsertDayEntity.Id > 0)
            {
                ids.Add(upsertDayEntity.Id);

                if (upsertDayEntity?.TimeShifts?.Any() ?? false)
                    await UpsertShifts(upsertDayEntity.TimeShifts, upsertDayEntity.Id);
            }
        }

        if (command.Signature is not null)
        {
            command.Signature.ReferenceId = 0;
            command.Signature.ApplicantSectionId = (int)ApplicationFormApplicantSections.Availability;
            await Mediator.Send(new SaveApplicantSignatureCommand(command.ApplicantId, new List<Signature>() { command.Signature }), cancellationToken);
        }

        await UpdateApplicantEligibilities(command.ApplicantId, cancellationToken);

        Logger.LogInformation("Applicant availability info was upserted successfully.");

        return new(ids);
    }

    private async Task UpdateApplicantEligibilities(int applicantId, CancellationToken cancellationToken)
    {
        var updateVerifyStatusApplicantEligibilitiesCommand = new UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(applicantId, false);
        await Mediator.Send(updateVerifyStatusApplicantEligibilitiesCommand, cancellationToken);
    }

    private async Task<int> UpsertDayAsync(AvailabilityDayEntity upsertDayEntity, int applicantId)
    {
        upsertDayEntity.ApplicantId = applicantId;

        return await AvailabilityDaysRepository.Upsert(upsertDayEntity, x => x.Id == upsertDayEntity.Id, requestDayEntity =>
        {
            requestDayEntity.MaxVisits = upsertDayEntity.MaxVisits;
            requestDayEntity.Updated = DateTime.UtcNow;
            return requestDayEntity;
        });
    }

    private async Task UpsertShifts(List<AvailabilityTimeShiftEntity> shifts, int dayId)
    {
        foreach (var upsertShiftEntity in shifts)
        {
            upsertShiftEntity.AvailabilityDayId = dayId;

            await AvailabilityTimeShiftsRepository.Upsert(upsertShiftEntity, x => x.Id == upsertShiftEntity.Id, requestShiftEntity =>
            {
                requestShiftEntity.From = upsertShiftEntity.From;
                requestShiftEntity.To = upsertShiftEntity.To;
                requestShiftEntity.PreferenceId = upsertShiftEntity.PreferenceId;
                requestShiftEntity.IsLiveIn = upsertShiftEntity.IsLiveIn;
                requestShiftEntity.Updated = DateTime.UtcNow;
                return requestShiftEntity;
            });
        }
    }
}
