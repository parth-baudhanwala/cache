﻿using Hhax.Dao.Application.Commands.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Compliance;

public record DeleteApplicantAvailabilityHandler(IGenericRepository<AvailabilityTimeShiftEntity> AvailabilityTimeShiftsRepository,
                                                 IReadOnlyRepository<AvailabilityDayEntity> AvailabilityDaysRepository,
                                                 ILogger<DeleteApplicantAvailabilityHandler> Logger)
    : IRequestHandler<DeleteApplicantAvailabilityCommand, Unit>
{
    public async Task<Unit> Handle(DeleteApplicantAvailabilityCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)} with applicantId: {command.ApplicantId}.");

        if (command.Ids.Any())
        {
            var days = await AvailabilityDaysRepository.FindAsync(x => x.ApplicantId == command.ApplicantId);
            var dayIds = days.Select(x => x.Id);
            var toRemove = await AvailabilityTimeShiftsRepository.FindAsync(x => dayIds.Contains(x.AvailabilityDayId) && command.Ids.Contains(x.Id));

            if(toRemove.Any())
            {
                await AvailabilityTimeShiftsRepository.RemoveRangeAsync(toRemove);
                Logger.LogInformation($"Applicant Availability Time Shisft with Ids: {string.Join(", ", command.Ids)} were deleted.");
                return Unit.Value;
            }
        }

        Logger.LogInformation($"Applicant Availability Time Shisft with Ids: {string.Join(", ", command.Ids)} not found.");
        return Unit.Value;
    }
}
