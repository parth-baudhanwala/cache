﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Queries.Availability;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Availability;

public record GetApplicantAvailabilityHandler(ILogger<GetApplicantAvailabilityHandler> Logger,
                                              IReadOnlyRepository<AvailabilityDayEntity> AvailabilityDaysRepository,
                                              IMediatorService Mediator,
                                              IMapper Mapper)
    : IRequestHandler<GetApplicantAvailabilityQuery, ApplicantAvailability>
{
    public async Task<ApplicantAvailability> Handle(GetApplicantAvailabilityQuery query, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        ApplicantAvailability availability;
        IEnumerable<AvailabilityDayEntity> result = await AvailabilityDaysRepository.FindAsync(x => x.ApplicantId == query.ApplicantId, true);

        if (result.Any())
        {
            IEnumerable<AvailabilityDay> mappedResult = Mapper.Map<IEnumerable<AvailabilityDay>>(result);

            Logger.LogInformation("Applicant availability info were retrieved successfully.");

            availability = new(CheckResult(mappedResult));

            GetApplicantSignatureCommand signatureCommand = new(query.ApplicantId, 0, new int[1] { (int)ApplicationFormApplicantSections.Availability });
            availability.Signature = (await Mediator.SendAsync<GetApplicantSignatureCommand, IEnumerable<Signature>>(signatureCommand)).FirstOrDefault();

            return availability;
        }

        Logger.LogInformation("Applicant availability info not found, retrieved default result.");

        availability = new(GetDefaultResult());
        return availability;
    }

    /// <summary>
    /// Check result and insert missing days (we must return all days)
    /// </summary>
    private static List<AvailabilityDay> CheckResult(IEnumerable<AvailabilityDay> days)
    {
        List<AvailabilityDay> list = new();

        for (byte i = 1; i < 8; i++)
        {
            AvailabilityDay? day = days.FirstOrDefault(x => x.DayType == i);
            list.Add(day is null ? new() { DayType = i, TimeShifts = new() { new() } } : day);
        }

        return list;
    }

    /// <summary>
    /// Get default availability collection (each day with an empty time shift)
    /// </summary>
    private static List<AvailabilityDay> GetDefaultResult() => new()
    {
        new() { DayType = (byte)DayType.Sunday, TimeShifts = new() { new() { } } },
        new() { DayType = (byte)DayType.Monday, TimeShifts = new() { new() { } } },
        new() { DayType = (byte)DayType.Tuesday, TimeShifts = new() { new() { } } },
        new() { DayType = (byte)DayType.Wednesday, TimeShifts = new() { new() { } } },
        new() { DayType = (byte)DayType.Thursday, TimeShifts = new() { new() { } } },
        new() { DayType = (byte)DayType.Friday, TimeShifts = new() { new() { } } },
        new() { DayType = (byte)DayType.Saturday, TimeShifts = new() { new() { } } }
    };
}
