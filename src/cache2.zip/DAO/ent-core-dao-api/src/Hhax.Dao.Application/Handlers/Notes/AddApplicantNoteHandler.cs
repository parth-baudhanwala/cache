﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Notes;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Notes;

public record AddApplicantNoteHandler(IAuthenticationService AuthenticationService,
                                     ILogger<AddApplicantNoteHandler> Logger,
                                     IGenericRepository<ApplicantNoteEntity> ApplicantNoteRepository)
    : IRequestHandler<AddApplicantNoteCommand, BaseResponse>
{
    public async Task<BaseResponse> Handle(AddApplicantNoteCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        BaseResponse response = new();

        ApplicantNoteEntity applicantNoteEntity = new()
        {
            ApplicantId = command.ApplicantId,
            Text = command.Note,
            WorkflowStatus = command.Status,
            Created = DateTime.UtcNow,
            CreatedBy = AuthenticationService.GetUserId()
        };

        response.Id = await ApplicantNoteRepository.AddAsync(applicantNoteEntity);

        Logger.LogInformation("Applicant's note was added successfully for {applicantId}", command.ApplicantId);

        return response;
    }
}
