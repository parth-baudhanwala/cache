﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Queries.Notes;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.User;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Notes
{
    public class GetApplicantNotesQueryHandler : IRequestHandler<GetApplicantNotesQuery, PaginatationResponse<ApplicantNoteInfo>>
    {
        private readonly IReadOnlyRepository<VendorEntity> _agencyRepository;
        private readonly IReadOnlyRepository<UserInfoEntity> _userInfoRepository;
        private readonly IReadOnlyRepository<ApplicantNoteEntity> _applicantNoteRepository;
        private readonly IReadOnlyRepository<ApplicantEntity> _applicantRepository;
        private readonly IReadOnlyRepository<ApplicationWorkflowStatusEntity> _applicationWorkflowStatusRepository;
        private readonly IReadOnlyRepository<HumanResourcePersonaEntity> _humanResourcePersonaRepository;
        private readonly ILogger<GetApplicantNotesQueryHandler> _logger;
        private readonly IAuthenticationService _authenticationService;

        public GetApplicantNotesQueryHandler(IServiceProvider serviceProvider,
                                             ILogger<GetApplicantNotesQueryHandler> logger,
                                             IAuthenticationService authenticationService)
        {
            _agencyRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<VendorEntity>>();
            _userInfoRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<UserInfoEntity>>();
            _applicantNoteRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<ApplicantNoteEntity>>();
            _applicantRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<ApplicantEntity>>();
            _applicationWorkflowStatusRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<ApplicationWorkflowStatusEntity>>();
            _humanResourcePersonaRepository = serviceProvider.GetRequiredService<IReadOnlyRepository<HumanResourcePersonaEntity>>();
            _logger = logger;
            _authenticationService = authenticationService;
        }

        public async Task<PaginatationResponse<ApplicantNoteInfo>> Handle(GetApplicantNotesQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{nameof(Handle)}.");

            int providerId = _authenticationService.GetAgencyId();

            string agencyName = (await _agencyRepository.GetQuery().AsNoTracking()
                                       .FirstOrDefaultAsync(x => x.Id == providerId, cancellationToken))?.Name ?? string.Empty;

            var notes = RetrieveNotesInfo(request);

            var filteredNotes = FilterNotes(request, notes);
            var users = await GetUsers(filteredNotes, cancellationToken);

            var response = PrepareResponse(filteredNotes, users, notes.Count, agencyName);

            _logger.LogInformation("Applicant notes were retrieved successfully for applicant: {ApplicantId}", request.ApplicantId);

            return response!;
        }

        private static PaginatationResponse<ApplicantNoteInfo> PrepareResponse(List<ApplicantNoteInfo> filteredNotes, IEnumerable<UserInfoEntity> users, int totalRecordCount, string agencyName)
        {
            filteredNotes?.ForEach(note =>
            {
                var user = users.SingleOrDefault(x => x.Id == note.CreatedBy);

                note.AgencyName = agencyName;
                note.HRRepresentativeUserName = user?.UserName ?? string.Empty;
                note.HRRepresentativeFirstName = user?.FirstName ?? string.Empty;
                note.HRRepresentativeLastName = user?.LastName ?? string.Empty;
            });

            return new PaginatationResponse<ApplicantNoteInfo>
            {
                Data = filteredNotes,
                PageInfo = new PageInfo { TotalRecordCount = totalRecordCount }
            };
        }

        private async Task<IEnumerable<UserInfoEntity>> GetUsers(List<ApplicantNoteInfo> filteredNotes, CancellationToken cancellationToken)
        {
            var usersIds = filteredNotes.Select(x => x.CreatedBy);

            return await _userInfoRepository.GetQuery().AsNoTracking().Where(user => usersIds.Contains(user.Id)).ToListAsync(cancellationToken);
        }

        private static List<ApplicantNoteInfo> FilterNotes(GetApplicantNotesQuery request, List<ApplicantNoteInfo> notesInfo)
        {
            var applicantNotesInfo = notesInfo
                .Skip((request.Request.Page!.PageNumber - 1) * request.Request.Page.PageSize)
                .Take(request.Request.Page.PageSize)
                .ToList();

            return applicantNotesInfo;
        }

        private List<ApplicantNoteInfo> RetrieveNotesInfo(GetApplicantNotesQuery request)
        {
            var query = from applicantNote in _applicantNoteRepository.GetQuery().AsNoTracking()
                        from applicant in _applicantRepository.GetQuery().AsNoTracking()
                            .Where(applicant => applicantNote.ApplicantId == applicant.Id)

                        from applicationWorkflowStatus in _applicationWorkflowStatusRepository.GetQuery().AsNoTracking()
                        .Where(status => applicant.ApplicationWorkflowStatusId == status.Id).DefaultIfEmpty()

                        from humanResourcePersona in _humanResourcePersonaRepository.GetQuery().AsNoTracking()
                            .Where(hr => applicantNote.CreatedBy == hr.UserId).DefaultIfEmpty()

                        where applicant.Id == request.ApplicantId

                        select new ApplicantNoteInfo
                        {
                            NoteId = applicantNote.Id,
                            ApplicantFirstName = applicant.FirstName ?? string.Empty,
                            ApplicantLastName = applicant.LastName ?? string.Empty,
                            Text = applicantNote.Text ?? string.Empty,
                            Status = applicantNote.WorkflowStatus ?? string.Empty,
                            Created = applicantNote.Created,
                            ApplicationWorkflowStatusName = applicationWorkflowStatus.Name ?? string.Empty,
                            HRRepresentativeName = humanResourcePersona.Name ?? string.Empty,
                            CreatedBy = applicantNote.CreatedBy
                        };

            return query.AsEnumerable().DistinctBy(x => x.NoteId).OrderByDescending(x => x.Created).ToList();
        }
    }
}
