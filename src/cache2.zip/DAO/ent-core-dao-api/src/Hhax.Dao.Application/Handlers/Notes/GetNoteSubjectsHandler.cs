﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Provider;
using Hhax.Dao.Application.Commands.Notes;
using Hhax.Dao.Domain.Notes;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Handlers.Notes;

public record GetNoteSubjectsHandler(IAuthenticationService AuthenticationService,
                                     IHhaStoredProceduresManager HhaStoredProceduresManager,
                                     IMapper Mapper,
                                     ILogger<GetNoteSubjectsHandler> Logger,
                                     IReadOnlyRepository<VendorEntity> VendorRepository)
    : IRequestHandler<GetNoteSubjectsCommand, IEnumerable<NoteSubject>>
{
    public async Task<IEnumerable<NoteSubject>> Handle(GetNoteSubjectsCommand command, CancellationToken cancellationToken)
    {
        Logger.LogInformation($"{nameof(Handle)}.");

        int userId = AuthenticationService.GetUserId();
        int providerId = AuthenticationService.GetAgencyId();

        var vendor = await VendorRepository.FirstOrDefaultAsync(x => x.Id == providerId) ?? throw new InvalidOperationException("Provider is not found.");

        GetReasonsRequest reasonsRequest = new()
        {
            ReasonType = 105,
            IsActive = 1,
            UserID = userId,
            Version = vendor.ProviderVersion,
            MinorVersion = vendor.ProviderMinorVersion,
        };

        var reasons = await HhaStoredProceduresManager.GetReasons(reasonsRequest);

        if (reasons == null || !reasons.Any()) return Enumerable.Empty<NoteSubject>();

        var noteSubjects = Mapper.Map<IEnumerable<NoteSubject>>(reasons);

        Logger.LogInformation("Note Subjects were retrieved successfully for provider: {providerId}", providerId);

        return noteSubjects;
    }
}
