﻿using System.Linq.Expressions;

namespace Hhax.Dao.Application.Utilities;

public class ParameterlessExpressionSearcherUtility : ExpressionVisitor
{
    private bool _containsParameter = false;
    public HashSet<Expression> ParameterlessExpressions { get; } = new HashSet<Expression>();

    public override Expression Visit(Expression node)
    {
        var originalContainsParameter = _containsParameter;

        _containsParameter = false;

        base.Visit(node);

        if (!_containsParameter)
        {
            if (node?.NodeType == ExpressionType.Parameter)
            {
                _containsParameter = true;
            }
            else
            {
                ParameterlessExpressions.Add(node!);
            }
        }

        _containsParameter |= originalContainsParameter;

        return node!;
    }
}