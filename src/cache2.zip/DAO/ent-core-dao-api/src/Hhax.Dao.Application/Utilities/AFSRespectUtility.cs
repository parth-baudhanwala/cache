﻿using Hhax.Dao.Application.Abstracts.Exceptions;

namespace Hhax.Dao.Application.Utilities;

public static class AFSRespectUtility
{
    public static void ThrowExceptionIfNotRespect(IEnumerable<string>? fields)
    {
        if (fields?.Any() ?? false)
            throw new AFSNotRespectedException(fields);
    }
}
