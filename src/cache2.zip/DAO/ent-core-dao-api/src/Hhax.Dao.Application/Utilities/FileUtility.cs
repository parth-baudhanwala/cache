﻿using Microsoft.AspNetCore.Http;

namespace Hhax.Dao.Application.Utilities;

public static class FileUtility
{
    public static IFormFile ConvertStringToFile(string filestring)
    {
        byte[] binaryData = Convert.FromBase64String(filestring);
        MemoryStream stream = new(binaryData);
        IFormFile file = new FormFile(stream, 0, binaryData.Length, "data", "Image");
        return file;
    }
}
