﻿using System.Linq.Expressions;

namespace Hhax.Dao.Application.Utilities;

public class ParameterlessExpressionEvaluatorUtility : ExpressionVisitor
{
    private readonly HashSet<Expression> parameterlessExpressions;

    public ParameterlessExpressionEvaluatorUtility(HashSet<Expression> parameterlessExpressions)
    {
        this.parameterlessExpressions = parameterlessExpressions;
    }
    public override Expression Visit(Expression node)
    {
        return parameterlessExpressions.Contains(node) ? Evaluate(node) : base.Visit(node);
    }

    private static Expression Evaluate(Expression node)
    {
        if(node is not null)
        {
            if (node.NodeType == ExpressionType.Constant)
            {
                return node;
            }

            var value = Expression.Lambda(node).Compile().DynamicInvoke();

            return Expression.Constant(value, node.Type);
        }

        return node!;
    }
}
