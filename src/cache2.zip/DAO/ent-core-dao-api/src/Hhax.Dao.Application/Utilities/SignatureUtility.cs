﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Domain.Application;

namespace Hhax.Dao.Application.Utilities;

public static class SignatureUtility
{
    public static bool CheckIsSignatureRequired(IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, int sectionSignatureId)
    {
        return applicantRequirements.FirstOrDefault(x => x.ApplicantFieldId == sectionSignatureId)?.IsRequire ?? false;
    }

    public static bool CheckProfileSectionSignatures(IEnumerable<Signature>? signatures, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        Dictionary<int, int> sectionMappings = new()
        {
            { (int)ApplicationFormApplicantFields.DemographicSignature, (int)ApplicationFormApplicantSections.Demographics },
            { (int)ApplicationFormApplicantFields.AddressSignature, (int)ApplicationFormApplicantSections.Address },
            { (int)ApplicationFormApplicantFields.LanguageSignature, (int)ApplicationFormApplicantSections.Languages },
            { (int) ApplicationFormApplicantFields.EmergencyContactSignature, (int) ApplicationFormApplicantSections.EmergencyContact },
            { (int)ApplicationFormApplicantFields.EmploymentInformationSignature, (int) ApplicationFormApplicantSections.EmploymentInformation },
            { (int) ApplicationFormApplicantFields.NotificationPreferenceSignature, (int) ApplicationFormApplicantSections.NotificationPreferences }
        };

        if (signatures != null)
        {
            foreach (var sectionMapping in sectionMappings)
            {
                var applicantField = applicantRequirements.FirstOrDefault(x => x.ApplicantFieldId == sectionMapping.Key);

                if (applicantField != null && applicantField.IsRequire && !signatures.Any(x => x.ApplicantSectionId == sectionMapping.Value))
                {
                    return true;
                }
            }
        }
        return false;
    }
}

