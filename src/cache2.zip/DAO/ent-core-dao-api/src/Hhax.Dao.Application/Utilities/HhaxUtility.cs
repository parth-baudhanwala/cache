﻿namespace Hhax.Dao.Application.Utilities;

public static class HhaxUtility
{
    public static string GetDateFolderPrefix()
    {
        return $"{DateTime.UtcNow.Year}/{DateTime.UtcNow.Month}/{DateTime.UtcNow.Day}";
    }
}
