﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Interfaces.FormBuilder;
using Hhax.Dao.Application.Abstracts.Requests.FormBuilder;
using Hhax.Dao.Application.Abstracts.Responses.FormBuilder;
using Hhax.Dao.Application.Queries.Feature;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Hhax.Dao.Infrastructure.Abstracts.Requests;
using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Concrete.Clients;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RestSharp;

namespace Hhax.Dao.Application.Services.FormBuilder;

public class FormBuilderApiClient : BaseClient, IFormBuilderApiClient
{
    private readonly ILogger<FormBuilderApiClient> _logger;
    private readonly IIdentityClient _identityClient;
    private readonly IdentityConfiguration _identityConfiguration;
    private readonly ScopeConfiguration _scopeConfiguration;
    private readonly SettingsConfiguration _settingsConfiguration;
    private readonly IMediatorService _mediatorService;
    private readonly IAuthenticationService _authenticationService;
    private readonly IReadOnlyRepository<VendorEntity> _vendorEntity;

    public FormBuilderApiClient(IRestClient client,
                                IIdentityClient identityClient,
                                IOptions<IdentityConfiguration> identityConfigurationOptions,
                                IOptions<ScopeConfiguration> scopeConfigurationOptions,
                                IOptions<SettingsConfiguration> settingsConfigurationOptions,
                                IMediatorService mediatorService,
                                IAuthenticationService authenticationService,
                                IReadOnlyRepository<VendorEntity> vendorEntity,
                                ILogger<FormBuilderApiClient> logger) : base(client, logger)
    {
        _logger = logger;
        _identityClient = identityClient;
        _identityConfiguration = identityConfigurationOptions.Value;
        _scopeConfiguration = scopeConfigurationOptions.Value;
        _settingsConfiguration = settingsConfigurationOptions.Value;
        _mediatorService = mediatorService;
        _authenticationService = authenticationService;
        _vendorEntity = vendorEntity;
    }

    public async Task<FormListByCategoryNameResponse> GetFormListByCategoryName(FormListByCategoryNameRequest request)
    {
        _logger.LogInformation($"{nameof(GetFormListByCategoryName)}.");

        string formBuilderUrl = await GetFormBuilderUrl();
        string uriString = $"{formBuilderUrl}api/Common/GetFormListByCategoryName";
        request.UserId = _authenticationService.GetUserId();
        var headers = new Dictionary<string, string>();

        var token = await _identityClient.AccountsClient.GetTokenWithClientCredentialsAsync(_identityConfiguration.ClientId,
                                                                                            _identityConfiguration.ClientSecret,
                                                                                            _scopeConfiguration.AllRead);
        headers.Add("Authorization", $"Bearer {token.AccessToken}");

        var response = await PostAsync<FormListByCategoryNameResponse, FormListByCategoryNameRequest>(uriString, request, headers);

        _logger.LogInformation("GetFormListByCategoryName API is called successfully: {response}", response);

        return response;
    }

    public async Task<FormDataResponse> GetFormResponseData(FormDataRequest request)
    {
        _logger.LogInformation($"{nameof(GetFormResponseData)}.");

        string formBuilderUrl = await GetFormBuilderUrl();
        string uriString = $"{formBuilderUrl}api/Form/GetFormResponseData";
        request.UserId = _authenticationService.GetUserId();
        var headers = new Dictionary<string, string>();

        var token = await _identityClient.AccountsClient.GetTokenWithClientCredentialsAsync(_identityConfiguration.ClientId,
                                                                                            _identityConfiguration.ClientSecret,
                                                                                            _scopeConfiguration.AllRead);
        headers.Add("Authorization", $"Bearer {token.AccessToken}");

        FormDataResponse response = await PostAsync<FormDataResponse, FormDataRequest>(uriString, request, headers);

        _logger.LogInformation("GetFormResponseData API is called successfully: {response}", response);

        return response;
    }

    public async Task<FormCompletionStatusResponse> GetMandatoryFieldStatusForBulkId(FormCompletionStatusRequest request)
    {
        _logger.LogInformation($"{nameof(GetMandatoryFieldStatusForBulkId)}.");

        string formBuilderUrl = await GetFormBuilderUrl();
        string uriString = $"{formBuilderUrl}api/Common/GetMandatoryFieldStatusForBulkId";
        var headers = new Dictionary<string, string>();

        var token = await _identityClient.AccountsClient.GetTokenWithClientCredentialsAsync(_identityConfiguration.ClientId,
                                                                                            _identityConfiguration.ClientSecret,
                                                                                            _scopeConfiguration.AllRead);
        headers.Add("Authorization", $"Bearer {token.AccessToken}");

        FormCompletionStatusResponse response = await PostAsync<FormCompletionStatusResponse, FormCompletionStatusRequest>(uriString, request, headers);

        _logger.LogInformation("GetMandatoryFieldStatusForBulkId API is called successfully: {response}", response);

        return response;
    }

    private async Task<string> GetFormBuilderUrl()
    {
        int providerId = _authenticationService.GetAgencyId();

        var vendor = await _vendorEntity.GetByIdAsync(providerId);

        GetApplicationUrlQuery query = new(new int[1] { _settingsConfiguration.FormBuilderAppVersionID })
        {
            Version = vendor.ProviderVersion ?? 0,
            MinorVersion = vendor.ProviderMinorVersion ?? 0,
        };

        var url = await _mediatorService.SendAsync<GetApplicationUrlQuery, Dictionary<int, string?>>(query);

        if (url.TryGetValue(_settingsConfiguration.FormBuilderAppVersionID, out string? formBuilderUrl) && !string.IsNullOrEmpty(formBuilderUrl))
        {
            return formBuilderUrl;
        }

        throw new InvalidOperationException();
    }
}
