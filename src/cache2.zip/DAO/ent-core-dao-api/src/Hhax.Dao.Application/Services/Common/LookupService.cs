﻿using AutoMapper;
using AutoMapper.Extensions.ExpressionMapping;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Linq.Expressions;

namespace Hhax.Dao.Application.Services.Common;

public class LookupService<TDtoEntity, TDalEntity> : ILookupService<TDtoEntity, TDalEntity>
    where TDtoEntity : Domain.Common.BaseEntity
    where TDalEntity : Infrastructure.Abstracts.Entities.Common.BaseEntity
{
    private readonly RedisConfiguration _redisConfiguration;

    private readonly IReadOnlyRepository<TDalEntity> _readOnlyRepository;
    private readonly IDistributedCacheService _distributedCacheService;

    private readonly IMapper _mapper;
    private readonly ILogger<LookupService<TDtoEntity, TDalEntity>> _logger;

    public LookupService(IOptions<RedisConfiguration> redisOptions,
                         IDistributedCacheService distributedCacheService,
                         IMapper mapper,
                         IReadOnlyRepository<TDalEntity> readOnlyRepository,
                         ILogger<LookupService<TDtoEntity, TDalEntity>> logger)
    {
        _redisConfiguration = redisOptions.Value;

        _readOnlyRepository = readOnlyRepository;
        _distributedCacheService = distributedCacheService;

        _mapper = mapper;
        _logger = logger;
    }

    private readonly string _cachePrefix = string.Empty;

    public virtual Task<IEnumerable<TDtoEntity>> FindAsync(Expression<Func<TDtoEntity, bool>> expression, bool hasNavigationProperties = false)
        => FindAsync(expression, 0, 0, hasNavigationProperties);

    public virtual async Task<IEnumerable<TDtoEntity>> FindAsync(Expression<Func<TDtoEntity, bool>> expression, int pageNumber, int pageSize, bool hasNavigationProperties = false)
    {
        _logger.LogInformation("FindAsync with 'PageNumber' params: {pageNumber} and 'PageSize' params: {pageSize}.", pageNumber, pageSize);

        CacheKey key = _distributedCacheService.BuildKey(expression, _cachePrefix, typeof(TDtoEntity).Name, pageNumber, pageSize);

        IEnumerable<TDtoEntity> result = await _distributedCacheService.GetFromCacheOrSource(key, async () =>
        {
            Expression<Func<TDalEntity, bool>> dtoExpression = _mapper.MapExpression<Expression<Func<TDalEntity, bool>>>(expression);

            IEnumerable<TDalEntity> TDALEntityResult = pageNumber >= 0 && pageSize > 0 ? await _readOnlyRepository.FindAsync(dtoExpression, pageNumber, pageSize, hasNavigationProperties: hasNavigationProperties) :
                                                                                         await _readOnlyRepository.FindAsync(dtoExpression, hasNavigationProperties: hasNavigationProperties);

            IEnumerable<TDtoEntity> dtoResult = TDALEntityResult.Select(x => _mapper.Map<TDtoEntity>(x));

            return dtoResult;
        }, _redisConfiguration.CacheEnabled, _redisConfiguration.RecordExpirationInSeconds);

        _logger.LogInformation("{cachePrefix} retrieved by filter {count}", _cachePrefix, result.Count());

        return result;
    }

    public virtual Task<IEnumerable<TDtoEntity>> GetAllAsync(bool hasNavigationProperties = false)
        => GetAllAsync(0, 0, hasNavigationProperties);

    public virtual async Task<IEnumerable<TDtoEntity>> GetAllAsync(int pageNumber, int pageSize, bool hasNavigationProperties = false)
    {
        _logger.LogInformation("GetAllAsync with 'PageNumber' params: {pageNumber} and 'PageSize' params: {pageSize}.", pageNumber, pageSize);

        CacheKey key = _distributedCacheService.BuildKey(_cachePrefix, typeof(TDtoEntity).Name, pageNumber, pageSize, "All");

        IEnumerable<TDtoEntity> result = await _distributedCacheService.GetFromCacheOrSource(key, async () =>
        {
            IEnumerable<TDalEntity> TDALEntityResult = pageNumber >= 0 && pageSize > 0 ? await _readOnlyRepository.GetAllAsync(pageNumber, pageSize) :
                                                                                         await _readOnlyRepository.GetAllAsync();

            IEnumerable<TDtoEntity> dtoResul = TDALEntityResult.Select(x => _mapper.Map<TDtoEntity>(x));

            return dtoResul;
        }, _redisConfiguration.CacheEnabled, _redisConfiguration.RecordExpirationInSeconds);

        _logger.LogInformation("{cachePrefix} retrieved {count}", _cachePrefix, result.Count());

        return result;
    }
}
