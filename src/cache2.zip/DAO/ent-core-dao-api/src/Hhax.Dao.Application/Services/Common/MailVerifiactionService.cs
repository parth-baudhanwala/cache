﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Services.Common;

public class MailVerifiactionService : VerificationServiceBase, IMailVerificationService
{
    private readonly MailVerificationConfiguration _mailVerificationConfiguration;

    public MailVerifiactionService(ILogger<IMailSenderService<HelpMailSenderConfiguration>> logger, 
                                IOptions<MailVerificationConfiguration> mailVerificationConfiguration, 
                                IMailSenderService<HelpMailSenderConfiguration> mailService,
                                IDistributedCacheService distributedCacheService,
                                IEmailTemplateClient emailTemplateClient) : base(logger, mailService, distributedCacheService, emailTemplateClient)
    {
        _mailVerificationConfiguration = mailVerificationConfiguration.Value;
    }

    public override bool IsVerificationEnabled() => _mailVerificationConfiguration.VerificationEnabled;

    protected override string MailSubject => "Welcome to Caregiver Applicant Portal!";

    protected override string KeyAdditionName => nameof(MailVerifiactionService);

    protected override EmailTemplateTypes TemplateType => EmailTemplateTypes.VerifyEmail;

    protected override int TokenExpirationInMinutes => _mailVerificationConfiguration.TokenExpirationInMinutes!.Value;

    protected override string VerifyingURL => _mailVerificationConfiguration.MailVerifyingURL!;
}
