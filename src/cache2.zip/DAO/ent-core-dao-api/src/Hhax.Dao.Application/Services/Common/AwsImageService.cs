﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using ImageMagick;
using Microsoft.Extensions.Logging;
using Microsoft.IO;

namespace Hhax.Dao.Application.Services.Common;

public class AwsImageService : IAwsImageService
{
    private readonly IAwsS3Client _awsS3Client;

    private readonly ILogger<AwsImageService> _logger;

    public AwsImageService(IAwsS3Client awsS3Client, ILogger<AwsImageService> logger)
    {
        _awsS3Client = awsS3Client;

        _logger = logger;
    }

    public async Task UploadImageAsync(string bucketName, string key, string fileName, Stream inputStream, int width, int height)
    {
        _logger.LogInformation("UploadImageAsync with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, key);

        var fileExtension = Path.GetExtension(fileName);

        using (var image = new MagickImage(inputStream))
        {
            var recyclableMemoryStreamManager = new RecyclableMemoryStreamManager();
            using var resultImage = recyclableMemoryStreamManager.GetStream();

            if (!string.Equals(fileExtension, ".webp", StringComparison.OrdinalIgnoreCase))
            {
                ConvertImageToWebPFormat(image);
            }

            if (width > 0 && height > 0)
            {
                ScaleImage(image, width, height);
            }

            image.Write(resultImage);
            await SaveImageAsync(resultImage, bucketName, $"{key}.webp");
        }

        await SaveImageAsync(inputStream, bucketName, $"{key}_source_{DateTime.UtcNow:dd_MM_yyyy_H_m_s_f}{fileExtension}");

        _logger.LogInformation("Image was uploaded successfully with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, key);
    }

    public async Task<byte[]> GetImageAsync(string bucketName, string key)
    {
        _logger.LogInformation("GetImageAsync with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, key);

        var result = await _awsS3Client.GetAsync(bucketName, key);

        _logger.LogInformation("Image was getting successfully with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, key);

        return result;
    }

    public async Task<string> GetImageUrlAsync(string bucketName, string key)
    {
        _logger.LogInformation("GetImageUrlAsync with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, key);

        var result = await _awsS3Client.GetPreSignedUrlAsync(bucketName, key);

        _logger.LogInformation("Pre Signed Url of Image was getting successfully with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, key);

        return result;
    }

    private async Task SaveImageAsync(Stream inputStream, string bucketName, string key)
    {
        _logger.LogInformation("SaveImageAsync with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, key);

        await _awsS3Client.PutAsync(inputStream, bucketName, key);

        _logger.LogInformation("Image was successfully with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, key);
    }

    private void ScaleImage(MagickImage image, int width, int height)
    {
        try
        {
            var size = new MagickGeometry(width, height)
            {
                IgnoreAspectRatio = true
            };
            image.Resize(size);
        }
        catch (Exception exc)
        {
            _logger.LogError(exc, exc.Message);
        }
    }

    private void ConvertImageToWebPFormat(MagickImage image)
    {
        try
        {
            image.Quality = 100;
            image.Format = MagickFormat.WebP;
        }
        catch (Exception exc)
        {
            _logger.LogError(exc, exc.Message);
        }
    }
}
