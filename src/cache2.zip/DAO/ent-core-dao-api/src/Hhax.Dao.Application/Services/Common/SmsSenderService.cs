﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Domain.Message;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Text.RegularExpressions;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace Hhax.Dao.Application.Services.Common
{
    public class SmsSenderService : ISmsSenderService
    {
        private readonly ILogger<SmsSenderService> _logger;
        private readonly SmsSenderConfiguration _smsSenderConfiguration;

        private string smsSendingError = "SMS sending error. Parameters: Recipient='{To}', ErrorMessage='{ErrorMessage}'";

        public SmsSenderService(ILogger<SmsSenderService> logger, IOptions<SmsSenderConfiguration> smsSenderConfiguration)
        {
            _logger = logger;
            _smsSenderConfiguration = smsSenderConfiguration.Value;
        }
        public async Task<SendMessagesResponse> SendSmsAsync(List<Sms> smsList)
        {
            Dictionary<string, MessageError> messageErrors = new Dictionary<string, MessageError>();
            List<Task<MessageResource>> tasks = new List<Task<MessageResource>>();

            TwilioClient.Init(_smsSenderConfiguration.AccountSID, _smsSenderConfiguration.AuthenticationToken);

            smsList.ForEach(sms =>
            {
                if (IsValidPhoneNumber(sms.Recipient.PhoneNumber))
                {
                    tasks.Add(MessageResource.CreateAsync(
                    body: sms.Message,
                    from: new PhoneNumber(_smsSenderConfiguration.PhoneNumber),
                    to: new PhoneNumber(sms.Recipient.PhoneNumber)));
                }
                else
                {
                    if (!messageErrors.ContainsKey(sms.Recipient.Name))
                    {
                        _logger.LogInformation("SMS sending error. Invalid phone number.");

                        messageErrors.Add(sms.Recipient.Name, CreateMessageError(sms.Recipient.Name, "Invalid phone number", typeof(InvalidDataException).Name));
                    }
                }
            });

            try
            {
                await Task.WhenAll(tasks);
            }
            catch (Exception)
            {
                _logger.LogInformation("SMS sending error occurred.");
            }

            var response = CreateResponse(smsList, tasks);
            response.Errors.AddRange(messageErrors.Values.ToList());

            return response;
        }

        private SendMessagesResponse CreateResponse(List<Sms> smsList, List<Task<MessageResource>> tasks)
        {
            SendMessagesResponse response = new SendMessagesResponse();
            Dictionary<string, MessageError> messageErrors = new Dictionary<string, MessageError>();
            HashSet<string> counter = new HashSet<string>();

            response.Errors.AddRange(ProcessFaultedTasks(tasks, smsList));

            foreach (var task in tasks.Where(task => !task.IsFaulted))
            {
                var message = task.Result;
                var status = message.Status;

                if (isProcessedSuccessfully(status))
                {
                    counter.Add(message.To);
                    _logger.LogInformation("Sms sent successfully with params: Recipient='{To}'", message.To);
                }
                else
                {
                    if (!messageErrors.ContainsKey(message.To))
                    {
                        var recipient = GetRecipientNameByPhone(smsList, message.To);
                        messageErrors.Add(message.To, CreateMessageError(recipient, message.ErrorMessage));
                        _logger.LogInformation(smsSendingError, recipient, message.ErrorMessage);
                    }
                }
            }

            response.Errors.AddRange(messageErrors.Values.ToList());
            response.Succeeded = counter.Count;

            return response;
        }

        private static bool isProcessedSuccessfully(MessageResource.StatusEnum status)
        {
            return status == MessageResource.StatusEnum.Sent
                                || status == MessageResource.StatusEnum.Delivered
                                || status == MessageResource.StatusEnum.Queued;
        }

        private List<MessageError> ProcessFaultedTasks(List<Task<MessageResource>> tasks, List<Sms> smsList)
        {
            Dictionary<string, MessageError> messageErrors = new Dictionary<string, MessageError>();

            tasks.Where(task => task.IsFaulted)
                .ToList()
                .ForEach(task =>
                {
                    string phoneNumber = GetRecipientNumberFromErrorMessage(task.Exception!.Message);
                    if (!messageErrors.ContainsKey(phoneNumber))
                    {
                        var recipient = GetRecipientNameByPhone(smsList, phoneNumber);
                        messageErrors.Add(phoneNumber, CreateMessageError(recipient, task.Exception!.Message));
                        _logger.LogInformation(smsSendingError, recipient, task.Exception!.Message);
                    }
                });

            return messageErrors.Values.ToList();
        }

        private bool IsValidPhoneNumber(string? phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber))
            {
                return false;
            }

            return Regex.IsMatch(phoneNumber, Constants.PhonePattern, RegexOptions.IgnoreCase);
        }

        private static string GetRecipientNameByPhone(List<Sms> smsList, string phone)
        {
            var recipient = smsList.FirstOrDefault(x => x.Recipient.PhoneNumber == phone)?.Recipient;
            return recipient?.Name ?? String.Empty;
        }

        private static MessageError CreateMessageError(string recipient, string reasonOfError, string errorType = "SmsProviderError")
        {
            MessageError messageError = new MessageError();
            messageError.RecipientName = recipient;
            messageError.Reason = reasonOfError;
            messageError.ErrorType = errorType;
            return messageError;
        }

        private string GetRecipientNumberFromErrorMessage(string message)
        {
            Regex regex = new Regex(Constants.ShortPhonePattern);
            Match match = regex.Match(message);

            if (match.Success)
            {
                return match.Value;
            }

            return String.Empty;
        }
    }
}
