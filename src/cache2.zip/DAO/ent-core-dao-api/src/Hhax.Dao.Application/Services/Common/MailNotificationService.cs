﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Domain.Message;
using Hhax.Dao.Domain.Notification;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Services.Common
{
    public class MailNotificationService : IMailNotificationService
    {
        private readonly ILogger<IMailSenderService<HelpMailSenderConfiguration>> _logger;
        private readonly MailNotificationConfiguration _mailNotificationConfiguration;
        private readonly IMailSenderService<HelpMailSenderConfiguration> _mailService;

        private readonly IEmailTemplateClient _emailTemplateClient;

        private const string imageName = "logo.png";

        public MailNotificationService(ILogger<IMailSenderService<HelpMailSenderConfiguration>> logger,
                                IOptions<MailNotificationConfiguration> mailNotificationConfiguration,
                                IMailSenderService<HelpMailSenderConfiguration> mailService,
                                IEmailTemplateClient emailTemplateClient)
        {
            _logger = logger;
            _mailNotificationConfiguration = mailNotificationConfiguration.Value;
            _mailService = mailService;
            _emailTemplateClient = emailTemplateClient;
        }

        /// <summary>
        /// Send notification about applicant status changes by email
        /// </summary>
        public async Task SendStatusChangedEmailAsync(StatusChangedNotificationData data, string address)
        {
            if (_mailNotificationConfiguration.NotificationEnabled)
            {
                _logger.LogInformation($"Send Notification Email with params: Address='{address}'");

                Email email = await PrepareEmailData(data, address);

                var response = await _mailService.SendEmailAsync(new List<Email>() { email });

                MessageError? error = RetrieveInvalidDataException(response);

                if (error != null)
                {
                    throw new InvalidDataException(error.Reason);
                }

                _logger.LogInformation($"Notification Email sent successfully with params: Address='{address}'");
            }
            else
                _logger.LogInformation($"Email Notification sis disabled. Email was no sent for: Address='{address}'");
        }

        private async Task<Email> PrepareEmailData(StatusChangedNotificationData data, string address)
        {
            var image = await FormImageAsync(imageName);
            var body = await FormMailBodyAsync(data);

            var recipients = new List<EmailRecipient>() { new EmailRecipient() { Name = data.HumanResourcePersonaName!, Email = address } };
            var email = new Email()
            {
                Recipients = recipients,
                Subject = "Status of the applicant has been updated",
                Message = body,
                LinkedResources = new List<IFormFile> { image }
            };

            return email;
        }

        private static MessageError? RetrieveInvalidDataException(SendMessagesResponse response)
        {
            MessageError? error = null;

            response.Errors.ForEach(x =>
            {
                if (x.ErrorType == typeof(InvalidDataException).Name)
                {
                    error = x;
                }
            });

            return error;
        }

        private async Task<IFormFile> FormImageAsync(string name)
        {
            var imageBytes = await _emailTemplateClient.GetImageByTypeAsync(EmailImageTypes.HHAXLogo);
            var stream = new MemoryStream(imageBytes);
            return new FormFile(stream, 0, imageBytes.Length, name, name)
            {
                Headers = new HeaderDictionary(),
                ContentType = "image/png"
            };
        }

        private string FormLink(string domain, string url) => url.Replace($"#{nameof(domain)}#", domain);

        private string FormName(string firstName, string lastName, int id) => $"{firstName} {lastName} ({id})";

        private string FormDate(DateTime date) => date.ToString("dd/MM/yyyy");

        private async Task<string> FormMailBodyAsync(StatusChangedNotificationData data)
        {
            var link = FormLink(data.Domain!, _mailNotificationConfiguration.ViewApplicantsURL!);
            var applicantName = FormName(data.ApplicantFirstName!, data.ApplicantLastName!, data.ApplicantId!);
            var statusDate = FormDate(data.StatusUpdated);

            IDictionary<string, string> parameters = new Dictionary<string, string>
            {
                {"hrName", data.HumanResourcePersonaName!},
                {"statusName", data.StatusName!},
                {"statusBackgroundColor", data.StatusBackgroundColor!},
                {"statusBorderColor", data.StatusBorderColor!},
                {"logoLink", imageName},
                {nameof(applicantName), applicantName},
                {nameof(statusDate), statusDate},
                {nameof(link), link}
            };
            var body = await _emailTemplateClient.GetTemplateByTypeAsync(EmailTemplateTypes.StatusChanged, parameters);
            return body;
        }
    }
}
