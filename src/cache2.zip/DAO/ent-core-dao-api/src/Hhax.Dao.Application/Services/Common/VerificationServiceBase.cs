﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Domain.Message;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Security.Cryptography;
using System.Text;

namespace Hhax.Dao.Application.Services.Common
{
    public abstract class VerificationServiceBase : IVerificationService
    {
        private readonly IMailSenderService<HelpMailSenderConfiguration> _mailService;
        private readonly IEmailTemplateClient _emailTemplateClient;

        protected readonly IDistributedCacheService _distributedCacheService;
        protected readonly ILogger<IMailSenderService<HelpMailSenderConfiguration>> _logger;

        private const string imageName = "logo.png";

        protected abstract string MailSubject { get; }
        protected abstract string KeyAdditionName { get; }
        protected abstract string VerifyingURL { get; }
        protected abstract int TokenExpirationInMinutes { get; }
        protected abstract Infrastructure.Abstracts.Enums.EmailTemplateTypes TemplateType { get; }

        public VerificationServiceBase(ILogger<IMailSenderService<HelpMailSenderConfiguration>> logger,
                                IMailSenderService<HelpMailSenderConfiguration> mailService,
                                IDistributedCacheService distributedCacheService,
                                IEmailTemplateClient emailTemplateClient)
        {
            _logger = logger;
            _mailService = mailService;
            _distributedCacheService = distributedCacheService;
            _emailTemplateClient = emailTemplateClient;
        }

        /// <summary>
        /// Is mail verification enabled
        /// </summary>
        public abstract bool IsVerificationEnabled();

        /// <summary>
        /// Create token and send link to verifying by email
        /// </summary>
        public async Task SendEmailAsync(int applicantId, string name, string address, string domain)
        {
            if (IsVerificationEnabled())
            {
                _logger.LogInformation($"Send Verification Email with params: Name='{name}', Address='{address}'");

                Email email = await PrepareEmailData(applicantId, name, address, domain);

                var response = await _mailService.SendEmailAsync(new List<Email>() { email });

                MessageError? error = RetrieveInvalidDataException(response);

                if (error != null)
                {
                    throw new InvalidDataException(error.Reason);
                }

                _logger.LogInformation($"Verification Email sent successfully with params: Name='{name}', Address='{address}'");
            }
            else
                _logger.LogInformation($"Email Verification is disabled. Email was no sent for: Name='{name}', Address='{address}'");
        }

        /// <summary>
        /// Verify key
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>Is key verified</returns>
        public async Task<bool> VerifуKeyAsync(int applicantId, string key)
        {
            if (!IsVerificationEnabled())
            {
                _logger.LogInformation($"Email Verification is disabled. Key '{key}' was verified automaticaly");
                return true;
            }

            _logger.LogInformation($"Verifying key with params: Key='{key}'");

            var cacheKey = _distributedCacheService.BuildKey(key);
            var result = await _distributedCacheService.GetAsync<MailVerification>(cacheKey);

            if (result != null && result.ApplicantId == applicantId)
            {
                _logger.LogInformation($"Key='{key}' was verified successfully");
                return true;
            }
            else
            {
                _logger.LogInformation($"Key='{key}' was not found");
                return false;
            }
        }

        private async Task<Email> PrepareEmailData(int applicantId, string name, string address, string domain)
        {
            var getKeyTask = GenerateKeyAsync(applicantId, address);
            var getImageTask = FormImageAsync(imageName);

            await Task.WhenAll(getKeyTask, getImageTask);

            var link = FormLink(applicantId, getKeyTask.Result, domain);
            var body = await FormMailBodyAsync(name, link, imageName);

            var recipients = new List<EmailRecipient>() { new EmailRecipient() { Name = name, Email = address } };
            var email = new Email()
            {
                Recipients = recipients,
                Subject = MailSubject,
                Message = body,
                LinkedResources = new List<IFormFile> { getImageTask.Result }
            };

            return email;
        }

        private static MessageError? RetrieveInvalidDataException(SendMessagesResponse response)
        {
            MessageError? error = null;

            response.Errors.ForEach(x =>
            {
                if (x.ErrorType == typeof(InvalidDataException).Name)
                {
                    error = x;
                }
            });

            return error;
        }

        private async Task<string> GenerateKeyAsync(int applicantId, string address)
        {
            var key = _distributedCacheService.BuildKey(HashWithSHA256(applicantId + address + KeyAdditionName + DateTime.UtcNow));
            var mailVerification = new MailVerification { ApplicantId = applicantId, Address = address };
            await _distributedCacheService.SetAsync(key, mailVerification,
                TimeSpan.FromMinutes(TokenExpirationInMinutes));
            return key.GetKey();
        }

        private async Task<IFormFile> FormImageAsync(string name)
        {
            var imageBytes = await _emailTemplateClient.GetImageByTypeAsync(Infrastructure.Abstracts.Enums.EmailImageTypes.HHAXLogo);
            var stream = new MemoryStream(imageBytes);
            return new FormFile(stream, 0, imageBytes.Length, name, name)
            {
                Headers = new HeaderDictionary(),
                ContentType = "image/png"
            };
        }

        private string HashWithSHA256(string value)
        {
            using (var hash = SHA256.Create())
            {
                var byteArray = hash.ComputeHash(Encoding.UTF8.GetBytes(value));
                return Convert.ToHexString(byteArray);
            }
        }

        private string FormLink(int applicantId, string key, string domain)
        {
            string link = VerifyingURL;
            link = link.Replace($"#{nameof(applicantId)}#", applicantId.ToString());
            link = link.Replace($"#{nameof(key)}#", key);
            link = link.Replace($"#{nameof(domain)}#", domain);
            return $"{link}";
        }

        private async Task<string> FormMailBodyAsync(string firstName, string link, string logoLink)
        {
            IDictionary<string, string> parameters = new Dictionary<string, string>
            {
                {nameof(firstName), firstName},
                {nameof(link), link},
                {nameof(logoLink), logoLink}
            };
            var body = await _emailTemplateClient.GetTemplateByTypeAsync(TemplateType, parameters);
            return body;
        }
    }
}
