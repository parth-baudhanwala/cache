﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Services.Common
{
    public class ResetPasswordService : VerificationServiceBase, IResetPasswordService
    {
        private readonly ResetPasswordConfiguration _resetPasswordConfiguration;

        public ResetPasswordService(ILogger<IMailSenderService<HelpMailSenderConfiguration>> logger, 
            IMailSenderService<HelpMailSenderConfiguration> mailService,
            IOptions<ResetPasswordConfiguration> resetPasswordConfiguration,
            IDistributedCacheService distributedCacheService, 
            IEmailTemplateClient emailTemplateClient) : base(logger, mailService, distributedCacheService, emailTemplateClient)
        {
            _resetPasswordConfiguration = resetPasswordConfiguration.Value;
        }

        public override bool IsVerificationEnabled() => true;

        protected override string MailSubject => "Password reset request";

        protected override string KeyAdditionName => nameof(ResetPasswordService);

        protected override EmailTemplateTypes TemplateType => EmailTemplateTypes.ResetPassword;

        protected override int TokenExpirationInMinutes => _resetPasswordConfiguration.TokenExpirationInMinutes!.Value;

        protected override string VerifyingURL => _resetPasswordConfiguration.ResetPasswordURL!;

        public async Task InvalidateKeyAsync(int applicantId, string key)
        {
            var cacheKey = _distributedCacheService.BuildKey(key);
            await _distributedCacheService.RemoveAsync(cacheKey);
            _logger.LogInformation($"Invalidated key for reseting password for applicant with id: '{applicantId}'");
        }
    }
}
