﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Security.Claims;

namespace Hhax.Dao.Application.Services.Common;

public class AuthenticationService : IAuthenticationService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    private readonly ILogger<AuthenticationService> _logger;

    public AuthenticationService(IHttpContextAccessor httpContextAccessor, ILogger<AuthenticationService> logger)
    {
        _httpContextAccessor = httpContextAccessor;
        _logger = logger;
    }

    public int GetUserId()
    {
        _logger.LogInformation("GetUserId");

        var userId = Convert.ToInt32(_httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value);

        _logger.LogInformation("GetUserId: {userId}", userId);

        return userId;
    }

    public int GetAgencyId()
    {
        _logger.LogInformation("GetAgencyId");

        const string type = "vendorid";
        var agencyId = Convert.ToInt32(_httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == type)?.Value);

        _logger.LogInformation("GetAgencyId: {vendorId}", agencyId);

        return agencyId;
    }

    public string GetUserName()
    {
        _logger.LogInformation("GetUserName");

        var userName = _httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Name)?.Value!;

        _logger.LogInformation("GetUserName: {userName}", userName);

        return userName;
    }

    public string GetFirstName()
    {
        _logger.LogInformation("GetFirstName");

        var firstName = _httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == "firstname")?.Value!;

        _logger.LogInformation("GetFirstName: {firstName}", firstName);

        return firstName;
    }

    public string GetLastName()
    {
        _logger.LogInformation("GetLastName");

        var lastName = _httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == "lastname")?.Value!;

        _logger.LogInformation("GetLastName: {lastName}", lastName);

        return lastName;
    }

    public bool IsSupportUser()
    {
        _logger.LogInformation("IsSupportUser");

        const string type = "impersonated";
        bool isSupportUser = Convert.ToBoolean(_httpContextAccessor.HttpContext?.User?.Claims
                                               .FirstOrDefault(x => x.Type == type)?.Value);

        _logger.LogInformation("IsSupportUser: {isSupportUser}", isSupportUser);

        return isSupportUser;
    }

    public bool IsCAPUser()
    {
        _logger.LogInformation("IsCAPUser");

        const string type = "usertype";
        var userType = _httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(x => x.Type == type)?.Value!;
        bool isCAPUser = userType is null || userType.Equals("CAPortal");

        _logger.LogInformation("IsCAPUser: {IsCAPUser}", isCAPUser);

        return isCAPUser;
    }
}
