﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Microsoft.Extensions.Logging;
using MailKit.Net.Smtp;
using MimeKit;
using Hhax.Dao.Application.Abstracts.Configurations;
using Microsoft.Extensions.Options;
using System.Net.Sockets;
using Hhax.Dao.Domain.Message;
using Microsoft.AspNetCore.Http;
using Hhax.Dao.Application.Abstracts.Responses.Message;
using System.Text.RegularExpressions;
using Hhax.Dao.Application.Abstracts.Constants;

namespace Hhax.Dao.Application.Services.Common;

public class MailSenderService<TConfig> : IMailSenderService<TConfig> where TConfig : MailBaseConfiguration
{
    private readonly MailboxAddress _mailBoxSender;
    private readonly ILogger<MailSenderService<TConfig>> _logger;
    private readonly TConfig _mailSenderConfiguration;
    private readonly ISmtpClient _smtpClient;

    private readonly SendMessagesResponse _sendMessagesResponse;

    public MailSenderService(ISmtpClient smtpClient, ILogger<MailSenderService<TConfig>> logger, IOptions<TConfig> mailSenderConfiguration)
    {
        _mailSenderConfiguration = mailSenderConfiguration.Value;
        _mailBoxSender = new MailboxAddress(mailSenderConfiguration.Value.SenderName, mailSenderConfiguration.Value.SenderAddress);
        _logger = logger;
        _smtpClient = smtpClient;
        _sendMessagesResponse = new SendMessagesResponse();
    }

    public async Task<SendMessagesResponse> SendEmailAsync(List<Email> emails)
    {
        foreach (var email in emails)
        {
            try
            {
                await SmtpClientConnect();
                await SendAsync(email);
            }
            catch (SocketException exc)
            {
                _sendMessagesResponse.Errors.Add(GetSocketError());
                _logger.LogError(exc, $"SendEmail connection error {exc.Message}");
            }
            finally
            {
                if (_smtpClient.IsConnected)
                {
                    await _smtpClient.DisconnectAsync(true);
                }
            }
        }

        return _sendMessagesResponse;
    }

    private MessageError GetEmailAddressError(string recipientName)
    {
        var messageError = new MessageError();
        messageError.RecipientName = recipientName;
        messageError.Reason = "Invalid email address given";
        messageError.ErrorType = typeof(InvalidDataException).Name;
        return messageError;
    }

    private MessageError GetSocketError()
    {
        var messageError = new MessageError();
        messageError.Reason = "A socket error occurs";
        messageError.ErrorType = typeof(SocketException).Name;
        return messageError;
    }

    private async Task SmtpClientConnect()
    {
        await _smtpClient.ConnectAsync(_mailSenderConfiguration.ClientHost, _mailSenderConfiguration.ClientPort, MailKit.Security.SecureSocketOptions.Auto);
        await AuthenticateClient();
    }

    private async Task AuthenticateClient()
    {
        if (!string.IsNullOrEmpty(_mailSenderConfiguration.Password))
        {
            await _smtpClient.AuthenticateAsync(_mailBoxSender.Address, _mailSenderConfiguration.Password);
        }
    }

    private async Task SendAsync(Email email)
    {
        foreach (var recipient in email.Recipients)
        {
            if (!IsValidMailAddress(recipient.Email))
            {
                _sendMessagesResponse.Errors.Add(GetEmailAddressError(recipient.Name));
            }
            else
            {
                await _smtpClient.SendAsync(FormMessage(recipient, email));

                _sendMessagesResponse.Succeeded = _sendMessagesResponse.Succeeded + 1;

                _logger.LogInformation("Email sent successfully with params: Name='{name}', Address='{address}', Subject='{subject}'",
                    recipient.Name, recipient.Email, email.Subject);
            }
        }
    }

    private bool IsValidMailAddress(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;

        return Regex.IsMatch(email, Constants.EmailPattern, RegexOptions.IgnoreCase);
    }

    private MimeMessage FormMessage(EmailRecipient recipient, Email email)
    {
        var builder = new BodyBuilder { HtmlBody = email.Message };

        AddAttachments(email.Attachments, builder);
        AddLinkedResources(email.LinkedResources, builder);

        var message = new MimeMessage();
        message.From.Add(_mailBoxSender);
        message.To.Add(new MailboxAddress(recipient.Name, recipient.Email));
        message.Subject = email.Subject;
        message.Body = builder.ToMessageBody();
        message.Prepare(EncodingConstraint.SevenBit);

        return message;
    }

    private void AddAttachments(IList<IFormFile>? attachments, BodyBuilder builder)
    {
        if (attachments != null)
        {
            foreach (var attachment in attachments.ToList())
            {
                string fileName = Path.GetFileName(attachment.FileName);
                builder.Attachments.Add(fileName, attachment.OpenReadStream(), ContentType.Parse(attachment.ContentType));
            }
        }
    }

    private void AddLinkedResources(IList<IFormFile>? linkedResources, BodyBuilder builder)
    {
        if (linkedResources != null)
        {
            foreach (var linkedResource in linkedResources.ToList())
            {
                string fileName = Path.GetFileName(linkedResource.FileName);
                builder.LinkedResources.Add(fileName, linkedResource.OpenReadStream(), ContentType.Parse(linkedResource.ContentType));
            }
        }
    }
}
