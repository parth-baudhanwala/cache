﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Services.Common;

public class AwsFileService : IAwsFileService
{
    private readonly IAwsS3Client _awsS3Client;
    private readonly ILogger<IAwsFileService> _logger;

    public AwsFileService(IAwsS3Client awsS3Client, ILogger<IAwsFileService> logger)
    {
        _awsS3Client = awsS3Client;
        _logger = logger;
    }

    public async Task<byte[]> GetFileContentAsync(AwsFileRequest request)
    {
        _logger.LogInformation($"{nameof(GetFileContentAsync)}");

        var result = await _awsS3Client.GetAsync(request.BucketName!, request.FileName!.ToLower());

        _logger.LogInformation("File Content was getting successfully.");

        return result;
    }

    public async Task<string> GetFileUrlAsync(AwsFileRequest request)
    {
        _logger.LogInformation("GetFileUrlAsync with params: Bucket Name='{bucketName}', Key='{key}'", request.BucketName!, request.FileName!.ToLower());

        var result = await _awsS3Client.GetPreSignedUrlAsync(request.BucketName!, request.FileName!.ToLower());

        _logger.LogInformation("Pre Signed Url of File was getting successfully with params: Bucket Name='{bucketName}', Key='{key}'", request.BucketName!, request.FileName!.ToLower());

        return result;
    }

    public async Task UploadFileAsync(UploadFileRequest request)
    {
        _logger.LogInformation("UploadFileAsync with params: Bucket Name='{bucketName}', Key='{key}'", request.BucketName, request.FileName!.ToLower());

        await _awsS3Client.PutAsync(request.ContentStream!, request.BucketName!, request.FileName!.ToLower());

        _logger.LogInformation("File has been uploaded successfully with params: Bucket Name='{bucketName}', Key='{key}'", request.BucketName, request.FileName!.ToLower());
    }

    public async Task DeleteFilesAsync(string bucketName, List<string> fileKeys)
    {
        _logger.LogInformation("DeleteFileAsync with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, fileKeys);

        await _awsS3Client.DeleteObjectsAsync(bucketName, fileKeys);

        _logger.LogInformation("File has been deleted successfully with params: Bucket Name='{bucketName}', Key='{key}'", bucketName, fileKeys);
    }
}
