﻿using Hhax.Dao.Application.Abstracts.Caregiver;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Caregiver;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Caregiver;
using Hhax.Dao.Application.Abstracts.Responses.Settings;
using Hhax.Dao.Application.Commands.Settings;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System.Runtime.InteropServices;

namespace Hhax.Dao.Application.Services.Common;

public class FilesUploadService : IFilesUploadService
{
    private readonly IAwsS3Client _awsS3Client;
    private readonly IAuthenticationService _authenticationService;
    private readonly IMediatorService _mediator;
    private readonly ICaregiverApiClient _caregiverAPIClient;
    private readonly AwsS3Configuration _aws3Configuration;
    private readonly IReadOnlyRepository<VendorEntity> _vendorRepository;

    public FilesUploadService(IAwsS3Client awsS3Client,
                              IAuthenticationService authenticationService,
                              IMediatorService mediator,
                              ICaregiverApiClient caregiverAPIClient,
                              IOptions<AwsS3Configuration> aws3ConfigurationOptions,
                              IReadOnlyRepository<VendorEntity> vendorRepository)
    {
        _awsS3Client = awsS3Client;
        _authenticationService = authenticationService;
        _mediator = mediator;
        _caregiverAPIClient = caregiverAPIClient;
        _aws3Configuration = aws3ConfigurationOptions.Value;
        _vendorRepository = vendorRepository;
    }

    public async Task<byte[]> GetDocumentAsync(string key) 
    {
        string bucketName = _aws3Configuration.ApplicantFilesBucketName!;
        return await _awsS3Client.GetAsync(bucketName, key);
    }

    public async Task UploadDocumentAsync(IFormFile file, string key)
    {
        var inputStream = file.OpenReadStream();
        string bucketName = _aws3Configuration.ApplicantFilesBucketName!;

        await _awsS3Client.PutAsync(inputStream, bucketName, key);
    }

    public async Task UploadDocumentAsync(IFormFile file, string key, int applicantId)
    {
        var inputStream = file.OpenReadStream();
        string bucketName = _aws3Configuration.ApplicantFilesBucketName!;

        Task s3Task = _awsS3Client.PutAsync(inputStream, bucketName, key);
        Task updateTotalFileSizeTask = SaveVendorTotalUploadedFileSize(file.Length, applicantId);
        await Task.WhenAll(s3Task, updateTotalFileSizeTask);
    }

    public async Task<string> UploadDocumentAsync(ComplianceFileType fileType, IFormFileCollection files, int applicantId, [Optional] int? documentTypeId, [Optional] string? fileName)
    {
        string key = string.Empty;
        string bucketName = _aws3Configuration.ApplicantFilesBucketName!;
        fileName ??= GetFileName(fileType);

        IFormFile? file = files.FirstOrDefault(x => x.Name == fileName);

        if (file is not null)
        {
            key = $"applicant/{applicantId}/{GetFileFolderName(fileType)}/{GetDateFolderPrefix()}/{(documentTypeId.HasValue ? $"{documentTypeId}/" : "")}{file.FileName}";
            using var stream = file.OpenReadStream();
            Task s3Task = _awsS3Client.PutAsync(stream, bucketName, key);
            Task updateTotalFileSizeTask = SaveVendorTotalUploadedFileSize(file.Length, applicantId);
            await Task.WhenAll(s3Task, updateTotalFileSizeTask);
        }

        return key;
    }

    public async Task DeleteDocumentsAsync(List<string> fileKeys, long totalFilesize = 0, int applicantId = 0)
    {
        List<Task> tasks = new();
        Task deleteFileTask = _awsS3Client.DeleteObjectsAsync(_aws3Configuration.ApplicantFilesBucketName!, fileKeys);
        tasks.Add(deleteFileTask);

        if (totalFilesize > 0 && applicantId > 0)
        {
            Task updateUploadedFileSizeTask = SaveVendorTotalUploadedFileSize(-totalFilesize, applicantId);
            tasks.Add(updateUploadedFileSizeTask);
        }

        await Task.WhenAll(tasks);
    }

    public Task<string> GetFileUrlAsync(string fileKey)
    {
        string bucketName = _aws3Configuration.ApplicantFilesBucketName!;
        return _awsS3Client.GetPreSignedUrlAsync(bucketName, fileKey);
    }

    public async Task<ProviderFileSizeLimitResponse> ValidateTotalFileSizeLimitByProviderAsync(long fileSize)
    {
        if (_authenticationService.IsCAPUser() || fileSize <= 0)
        {
            return new ProviderFileSizeLimitResponse { IsSaved = true };
        }

        var request = await CreateProviderFileSizeLimitRequestAsync(fileSize);
        return await _caregiverAPIClient.ValidateTotalFileSizeLimitByProvider(request).ConfigureAwait(false);
    }

    private async Task<ProviderFileSizeLimitRequest> CreateProviderFileSizeLimitRequestAsync(long fileSize)
    {
        long? totalFileSize = (await SaveVendorTotalUploadedFileSize(0, 0)).TotalUploadedFileUsage;
        fileSize = totalFileSize.HasValue ? (fileSize + totalFileSize.Value) : fileSize;

        var vendorInfo = await GetVendorInfo();
        ProviderFileSizeLimitRequest request = new()
        {
            UserId = (int)UserTypes.WebApplicant,
            ProviderId = _authenticationService.GetAgencyId(),
            Version = vendorInfo.ProviderVersion ?? 0,
            MinorVersion = vendorInfo.ProviderMinorVersion ?? 0,
            FileSize = fileSize,
        };

        return request;
    }

    private async Task<VendorTotalUploadedFileSizeResponse> SaveVendorTotalUploadedFileSize(long fileSize, int applicantId)
    {
        SaveVendorTotalUploadedFileSizeRequest request = new() { ApplicantId = applicantId, TotalUploadedFileUsage = fileSize };
        return await _mediator.SendAsync<SaveVendorTotalUploadedFileSizeRequest, VendorTotalUploadedFileSizeResponse>(request);
    }

    private async Task<VendorEntity> GetVendorInfo()
    {
        int providerId = _authenticationService.GetAgencyId();
        var vendor = await _vendorRepository.GetByIdAsync(providerId);
        return vendor;
    }

    private static string GetFileName(ComplianceFileType fileType) => fileType switch
    {
        ComplianceFileType.ColumnAB => "abFile",
        ComplianceFileType.ColumnC => "cFile",
        ComplianceFileType.EverifyDocuments => "eVerifyFile",
        ComplianceFileType.TrainingSchool => "certificateFile",
        ComplianceFileType.MedicalsRequirements => "document",
        ComplianceFileType.OtherRequirements => "document",
        _ => string.Empty
    };

    private static string GetFileFolderName(ComplianceFileType fileType) => fileType switch
    {
        ComplianceFileType.ColumnAB => "i9",
        ComplianceFileType.ColumnC => "i9",
        ComplianceFileType.EverifyDocuments => "i9",
        ComplianceFileType.BackgroundCheck => "background-check",
        ComplianceFileType.TrainingSchool => "training-schools",
        ComplianceFileType.MedicalsRequirements => "medicals-requirements",
        ComplianceFileType.OtherRequirements => "other-requirements",
        _ => "other"
    };

    private static string GetDateFolderPrefix()
        => $"{DateTime.UtcNow.Year}/{DateTime.UtcNow.Month}/{DateTime.UtcNow.Day}";

}
