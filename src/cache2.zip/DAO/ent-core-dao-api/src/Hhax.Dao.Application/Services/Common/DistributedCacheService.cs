﻿using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Extensions;
using Hhax.Dao.Domain.Common;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;
using System.Text;
using System.Text.Json;

namespace Hhax.Dao.Application.Services.Common;

public record DistributedCacheService(IDistributedCache Cache,
                                      ILogger<DistributedCacheService> Logger)
    : IDistributedCacheService
{

    public async Task<TEntity> GetFromCacheOrSource<TEntity>(CacheKey key, Func<Task<TEntity>> source, bool isEnabled = false, int expirationInSeconds = 60) where TEntity : class
    {
        if (isEnabled)
        {
            TEntity? value = await GetAsync<TEntity>(key);

            if (value is not null)
            {
                return value;
            }
            else
            {
                TEntity originValue = await source();
                await SetAsync(key, originValue, TimeSpan.FromSeconds(expirationInSeconds));
                return originValue;
            }
        }
        else
        {
            return await source();
        }
    }

    public async Task SetAsync<TEntity>(CacheKey key, TEntity value, TimeSpan? absoluteExpireTime = null, TimeSpan? slidingExpireTime = null) where TEntity : class
    {
        var options = new DistributedCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = absoluteExpireTime ?? TimeSpan.FromSeconds(60),
            SlidingExpiration = slidingExpireTime ?? TimeSpan.FromSeconds(36000)
        };

        try
        {
            await Cache.SetStringAsync(key.GetKey(), JsonSerializer.Serialize(value), options, GetCancellationToken());
        }
        catch (OperationCanceledException oe)
        {
            Logger.LogWarning(oe, "Cache Set Timeout");
        }
        catch (Exception e)
        {
            Logger.LogWarning(e, "Cache Set Error");
        }
    }

    public async Task<TEntity?> GetAsync<TEntity>(CacheKey key) where TEntity : class
    {
        string? value = null;

        try
        {
            value = await Cache.GetStringAsync(key.GetKey(), GetCancellationToken());
        }
        catch(OperationCanceledException oe)
        {
            Logger.LogWarning(oe, "Cache Set Timeout");
        }
        catch (Exception e)
        {
            Logger.LogWarning(e, "Cache Get Error");
        }

        if (value is null || value is "")
        {
            return default;
        }

        return JsonSerializer.Deserialize<TEntity>(value);
    }

    public async Task RemoveAsync(CacheKey key)
    {
        try
        {
            await Cache.RemoveAsync(key.GetKey(), GetCancellationToken());
        }
        catch (OperationCanceledException oe)
        {
            Logger.LogWarning(oe, "Cache Set Timeout");
        }
        catch (Exception e)
        {
            Logger.LogWarning(e, "Cache Set Error");
        }
    }

    public CacheKey BuildKey<TDtoEntity>(Expression<Func<TDtoEntity, bool>> expression, params object?[] keyParts) where TDtoEntity : BaseEntity
    {
        StringBuilder sb = GetStringBuildForKey(keyParts);

        sb.Append($"_{expression.GenerateCacheKeyPart()}");

        return new(() => sb.ToString());
    }

    public CacheKey BuildKey(params object?[] keyParts)
        => new(() => GetStringBuildForKey(keyParts).ToString());

    private static StringBuilder GetStringBuildForKey(params object?[] keyParts)
        => new(string.Join("_", keyParts.Where(x => x is not null && !string.IsNullOrWhiteSpace(x.ToString()))));

    private static CancellationToken GetCancellationToken()
        => new CancellationTokenSource(TimeSpan.FromSeconds(3)).Token;
}
