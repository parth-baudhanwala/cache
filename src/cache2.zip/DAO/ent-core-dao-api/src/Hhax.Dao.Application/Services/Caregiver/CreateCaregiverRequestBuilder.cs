﻿using Hhax.Dao.Application.Abstracts.Caregiver;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Exceptions;
using Hhax.Dao.Application.Abstracts.Interfaces.Caregiver;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.Settings;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Settings;
using Hhax.Dao.Application.Extensions;
using Hhax.Dao.Application.Queries.Application;
using Hhax.Dao.Application.Queries.Availability;
using Hhax.Dao.Application.Queries.Compliance;
using Hhax.Dao.Application.Queries.Globalization;
using Hhax.Dao.Application.Queries.InService;
using Hhax.Dao.Application.Queries.MedicalsOther;
using Hhax.Dao.Common.Extensions;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Availability;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;
using Hhax.Dao.Infrastructure.Abstracts.Enums;
using Hhax.Dao.Infrastructure.Abstracts.Interfaces;
using Microsoft.Extensions.Logging;

namespace Hhax.Dao.Application.Services.Caregiver;

public record CreateCaregiverRequestBuilder(IMediatorService Mediator,
                                            IAuthenticationService AuthenticationService,
                                            IFilesUploadService FilesUploadService,
                                            IReadOnlyRepository<VendorEntity> VendorRepository,
                                            ILookupService<ApplicationFormApplicantSection, ApplicationFormApplicantSectionEntity> ApplicantSectionLookupService,
                                            ILogger<CreateCaregiverRequestBuilder> Logger)
    : ICreateCaregiverRequestBuilder
{
    int applicantId;
    Dictionary<int, string> employmentType = new();

    int OfficeId
    {
        get
        {
            return profile?.Offices?.FirstOrDefault()?.OfficeId ?? 0;
        }
    }

    CaregiverProfile? profile;
    MaxNumberOfVisits? maxNumberOfVisits;
    List<PermanentWeek>? permanentWeeks;
    Abstracts.Caregiver.ComplianceInfo? complianceI9;
    List<CaregiverCriminalBackground>? criminalBackgrounds;
    List<Abstracts.Caregiver.TrainingSchool>? trainingSchools;
    List<MedicalOtherRequirement>? medicalRequirements, otherRequirements;
    List<CaregiverCustomField>? customFields;
    List<CaregiverOnBoardingForm>? onBoardingForms;
    IEnumerable<Inservice>? inservices;
    (IEnumerable<CaregiverComplianceCustomField>? fields, IEnumerable<CaregiverComplianceCustomFieldValue>? values)? complianceCustomFields;

    public ICreateCaregiverRequestBuilder SetApplicant(int applicantId)
    {
        this.applicantId = applicantId;
        employmentType = GetEmploymentTypes().ToDictionary(x => x.Id, x => x.Name!);
        return this;
    }

    public ICreateCaregiverRequestBuilder WithProfile()
    {
        VerifySupportUser();
        VerifyApplicantId();

        var vendorInfo = GetVendorInfo();
        var applicant = Mediator.SendAsync<GetApplicantQuery, Applicant>(new(applicantId)).Result;
        profile = applicant.ConvertToCaregiverProfileModel();
        profile.UserId = (int)UserTypes.WebApplicant;
        profile.UserName = UserTypes.WebApplicant.GetDisplayName();
        profile.ProviderId = AuthenticationService.GetAgencyId();
        profile.Version = vendorInfo.ProviderVersion ?? 0;
        profile.MinorVersion = vendorInfo.ProviderMinorVersion ?? 0;
        profile.ReferralSource = GetReferalSource(applicant.OfficeId, applicant.ReferralSourceId);
        profile.EmploymentTypes = GetEmploymentTypes(applicant.EmploymentTypeIds);
        profile.TotalUploadedFileSize = GetVendorTotalUploadedFileSize();

        if (applicant.Gender != null && applicant.Gender.Value > 0)
        {
            string? genderValue = GetGenderById(applicant.Gender.Value);

            if (!string.IsNullOrWhiteSpace(genderValue))
            {
                profile.Gender = new()
                {
                    Id = applicant.Gender.Value,
                    Value = genderValue
                };
            }
        }

        return this;
    }

    public ICreateCaregiverRequestBuilder WithAvailability()
    {
        VerifyApplicantId();

        var availability = Mediator.SendAsync<GetApplicantAvailabilityQuery, ApplicantAvailability>(new(applicantId)).Result.Days;

        maxNumberOfVisits = new MaxNumberOfVisits
        {
            MondayMaxVisit = availability.GetMaxVisitsInDay(DayType.Monday),
            TuesdayMaxVisit = availability.GetMaxVisitsInDay(DayType.Tuesday),
            WednesdayMaxVisit = availability.GetMaxVisitsInDay(DayType.Wednesday),
            ThursdayMaxVisit = availability.GetMaxVisitsInDay(DayType.Thursday),
            FridayMaxVisit = availability.GetMaxVisitsInDay(DayType.Friday),
            SaturdayMaxVisit = availability.GetMaxVisitsInDay(DayType.Saturday),
            SundayMaxVisit = availability.GetMaxVisitsInDay(DayType.Sunday),
        };

        permanentWeeks = availability.ToList().ConvertToPermanentWeekFields();
        return this;
    }

    public ICreateCaregiverRequestBuilder WithComplinaceCustomFields()
    {
        VerifyApplicantId();
        VerifyOfficeId();

        complianceCustomFields = Mediator.SendAsync<GetComplianceCustomFieldsQuery, ComplianceCustomFieldModel>(new(applicantId, OfficeId))
                                         .ContinueWith(task => (fields: task.Result.ComplianceCustomFields.ConvertToCustomFields(), values: task.Result.ComplianceCustomFields.ConvertToCustomFieldValues())).Result;

        return this;
    }

    public ICreateCaregiverRequestBuilder WithComplinaceI9()
    {
        VerifyApplicantId();

        var applicantComplianceI9 = Mediator.SendAsync<GetI9RequirementsQuery, ComplianceI9Requirement>(new(applicantId)).Result;

        if (!string.IsNullOrEmpty(applicantComplianceI9.ColumnABDocumentFileKey))
        {
            applicantComplianceI9.ColumnABDocumentFileKey = FilesUploadService.GetFileUrlAsync(applicantComplianceI9.ColumnABDocumentFileKey).Result;
        }

        if (!string.IsNullOrEmpty(applicantComplianceI9.ColumnCDocumentFileKey))
        {
            applicantComplianceI9.ColumnCDocumentFileKey = FilesUploadService.GetFileUrlAsync(applicantComplianceI9.ColumnCDocumentFileKey).Result;
        }

        if (!string.IsNullOrEmpty(applicantComplianceI9.EverifyDocumentFileKey))
        {
            applicantComplianceI9.EverifyDocumentFileKey = FilesUploadService.GetFileUrlAsync(applicantComplianceI9.EverifyDocumentFileKey).Result;
        }

        complianceI9 = applicantComplianceI9.ConvertToComplianceI9Fields();
        return this;
    }

    public ICreateCaregiverRequestBuilder WithCriminalBackgroundCheck()
    {
        VerifyApplicantId();

        var applicantCriminalBackground = Mediator.SendAsync<GetApplicantComplianceBackgroundCheckQuery, IEnumerable<ComplianceBackgroundCheck>>(new(applicantId)).Result;

        if (applicantCriminalBackground != null)
        {
            criminalBackgrounds = new();
            foreach (var item in applicantCriminalBackground)
            {
                if (item.Id <= 0) continue;

                if (!string.IsNullOrEmpty(item.FileKey))
                {
                    item.FileKey = FilesUploadService.GetFileUrlAsync(item.FileKey).Result;
                }

                criminalBackgrounds.Add(new()
                {
                    CaregiverCriminalBackgroundId = -1,
                    ReceivedDate = item.ReceivedDate,
                    CbCheckStatusMasterId = item.ResultId ?? 0,
                    ScanFilePath = item.FileKey,
                    SentOutDate = item.SentOutDate
                });
            }
        }

        return this;
    }

    public ICreateCaregiverRequestBuilder WithTrainingSchools()
    {
        VerifyApplicantId();

        GetApplicantComplianceTrainingSchoolQuery query = new(new()
        {
            Filters = new() { ApplicantId = applicantId },
            Page = new()
            {
                PageNumber = 1,
                PageSize = int.MaxValue
            }
        });

        var applicantTrainingSchool = Mediator.SendAsync<GetApplicantComplianceTrainingSchoolQuery, PaginatationResponse<ComplianceTrainingSchool>>(query).Result.Data;

        if (applicantTrainingSchool != null)
        {
            trainingSchools = new();
            foreach (var item in applicantTrainingSchool)
            {
                if (item.Id <= 0) continue;

                if (!string.IsNullOrEmpty(item.CertificateFileKey))
                {
                    item.CertificateFileKey = FilesUploadService.GetFileUrlAsync(item.CertificateFileKey).Result;
                }

                trainingSchools.Add(new()
                {
                    CaregiverTrainingSchoolId = -1,
                    CertificationDate = item.CertificationDate,
                    CertificationVerifiedDate = item.VerificationDate,
                    CertificationVerified = item.IsVerified ? Answer.Yes.ToString() : Answer.No.ToString(),
                    Default = Answer.No.ToString(),
                    Discipline = new()
                    {
                        Id = item.DisciplineId ?? -1,
                        Value = item.DisciplineId != null ? employmentType[item.DisciplineId.Value] : string.Empty
                    },
                    FilePath = item.CertificateFileKey,
                    InstructorName = item.InstructorName,
                    OnFile = Answer.No.ToString(),
                    TrainingSchoolMasterId = item.SchoolId ?? throw new NullValueException("Training School Id is not configured.")
                });
            }
        }

        return this;
    }

    public ICreateCaregiverRequestBuilder WithMedicalsAndOtherRequirement()
    {
        VerifyApplicantId();
        VerifyOfficeId();

        var applicantMedicalRequirement = Mediator.SendAsync<GetMedicalsRequirementsQuery, IEnumerable<MedicalsApplicantValue>>(new(applicantId, OfficeId)).Result;
        var applicantOtherRequirement = Mediator.SendAsync<GetOtherRequirementsQuery, IEnumerable<OtherApplicantValue>>(new(applicantId, OfficeId)).Result;

        if (applicantMedicalRequirement != null)
        {
            medicalRequirements = new();
            foreach (var item in applicantMedicalRequirement)
            {
                if (item.Id <= 0) continue;

                if (!string.IsNullOrEmpty(item.FileKey))
                {
                    item.FileKey = FilesUploadService.GetFileUrlAsync(item.FileKey).Result;
                }

                medicalRequirements.Add(new()
                {
                    CaregiverComplianceExpItemId = -1,
                    ComplianceExpItemResultId = item.Results?.FirstOrDefault(x => x.OptionValue == item.Value)?.OptionId ?? -1,
                    DateCompleted = item.PerformedDate,
                    DueDate = item.PerformedDate ?? DateTime.Today.AddYears(1),
                    ExpirationItem = item.MedicalName,
                    ExpirationItemId = item.ExpirationItemId ?? -1,
                    ExpirationItemType = ComplianceExpItemTypes.Medical.GetEnumMemberValue(),
                    FilePath = item.FileKey,
                    Result = item.Value
                });
            }
        }

        if (applicantOtherRequirement != null)
        {
            otherRequirements = new();
            foreach (var item in applicantOtherRequirement)
            {
                if (item.Id <= 0) continue;

                if (!string.IsNullOrEmpty(item.FileKey))
                {
                    item.FileKey = FilesUploadService.GetFileUrlAsync(item.FileKey).Result;
                }

                otherRequirements.Add(new()
                {
                    CaregiverComplianceExpItemId = -1,
                    ComplianceExpItemResultId = item.Results?.FirstOrDefault(x => x.OptionValue == item.Value)?.OptionId ?? -1,
                    DateCompleted = item.PerformedDate,
                    DueDate = item.PerformedDate ?? DateTime.Today.AddYears(1),
                    ExpirationItem = item.RequirementName,
                    ExpirationItemId = item.ExpirationItemId ?? -1,
                    ExpirationItemType = ComplianceExpItemTypes.Other.GetEnumMemberValue(),
                    FilePath = item.FileKey,
                    Result = item.Value
                });
            }
        }

        return this;
    }

    public ICreateCaregiverRequestBuilder WithInService()
    {
        VerifyApplicantId();

        GetApplicantInServicesQuery query = new(new()
        {
            Filters = new() { ApplicantId = applicantId },
            Page = new()
            {
                PageNumber = 1,
                PageSize = int.MaxValue
            }
        });

        inservices = Mediator.SendAsync<GetApplicantInServicesQuery, PaginatationResponse<ApplicantInServiceTableItem>>(query)
                            .Result.Data?.ConvertToInserviceFields();

        return this;
    }

    public ICreateCaregiverRequestBuilder WithCustomFields()
    {
        VerifyApplicantId();
        VerifyOfficeId();

        CaregiverCustomField customField;
        GetApplicantCustomFieldCommand command = new(applicantId, OfficeId);

        var applicantCustomFieldInfo = Mediator.SendAsync<GetApplicantCustomFieldCommand, IEnumerable<ApplicantCustomFieldInfo>>(command).Result
                                               .Where(x => x.IsShow);

        if (applicantCustomFieldInfo == null) return this;

        var customFieldType = Mediator.SendAsync<GetApplicationFieldTypes, IEnumerable<ApplicationFieldType>>(new()).Result
                                      .ToDictionary(x => x.Id, x => x.Name);

        var applicationSection = ApplicantSectionLookupService.FindAsync(x => x.IsActive).Result
                                                              .ToDictionary(x => x.Id, x => x.Name);


        customFields = new();

        foreach (var field in applicantCustomFieldInfo)
        {
            customField = new()
            {
                CustomFieldLabel = field.FieldName,
                CustomFieldType = customFieldType[field.FieldTypeId],
                CustomFieldValue = field.Value,
                SectionName = applicationSection[field.ApplicantSectionId]
            };

            if (!string.IsNullOrEmpty(field.FileKey))
            {
                customField.FileUrl = FilesUploadService.GetFileUrlAsync(field.FileKey).Result;
            }

            customFields.Add(customField);
        }

        return this;
    }

    public ICreateCaregiverRequestBuilder WithOnBoardingForms()
    {
        VerifyApplicantId();

        var applicantOnBoardingforms = Mediator.SendAsync<GetApplicantOnBoardingFormsQuery, IEnumerable<ApplicantOnBoardingFormInfo>>(new() { OfficeId = OfficeId, ApplicantId = applicantId }).Result;

        if (applicantOnBoardingforms == null) return this;

        onBoardingForms = new();

        CaregiverOnBoardingForm onBoardingForm;

        foreach (var form in applicantOnBoardingforms)
        {
            onBoardingForm = new()
            {
                OnBoardingFormId = form.OnBoardingFormId,
                OnBoardingFormName = form.Name,
                FormResponseId = form.FormResponseId
            };

            onBoardingForms.Add(onBoardingForm);
        }

        return this;
    }

    public CreateCaregiverRequest CreateRequest()
    {
        VerifySteps();

        CreateCaregiverRequest request = new()
        {
            CurrentUserId = AuthenticationService.GetUserId(),
            CaregiverProfile = profile,
            MaxNumberOfVisits = maxNumberOfVisits,
            PermanentWeeks = permanentWeeks,
            Inservices = inservices?.ToList(),
            ComplianceInfo = complianceI9,
            CaregiverCriminalBackgrounds = criminalBackgrounds,
            TrainingSchools = trainingSchools,
            MedicalOtherRequirements = medicalRequirements,
            CustomFields = customFields,
            OnBoardingForms = onBoardingForms,
        };

        if (complianceCustomFields.HasValue)
        {
            request.CaregiverComplianceCustomFields = complianceCustomFields.Value.fields?.ToList();
            request.CaregiverComplianceCustomFieldValues = complianceCustomFields.Value.values?.ToList();
        }

        if (request.MedicalOtherRequirements != null && otherRequirements != null)
        {
            request.MedicalOtherRequirements.AddRange(otherRequirements);
        }

        return request;
    }

    private void VerifyApplicantId()
    {
        if (applicantId <= 0)
            throw new NullValueException("Applicant Id is not configured.");
    }

    private void VerifyOfficeId()
    {
        if (OfficeId <= 0)
            throw new NullValueException("Applicant Office Id is not found.");
    }

    private void VerifySteps()
    {
        if (profile == null)
            throw new NullValueException("Specify at least profile step to create a request.");
    }

    private void VerifySupportUser()
    {
        if (AuthenticationService.IsSupportUser())
            throw new UnauthorizedAccessException("Support user is not allowed to convert applicant into caregiver.");
    }

    private Abstracts.Caregiver.ReferralSource? GetReferalSource(int officeId, int? referalSourceId)
    {
        if (!referalSourceId.HasValue)
            return null;

        var referalSource = Mediator.SendAsync<GetReferralSourcesQuery, IEnumerable<Domain.Application.ReferralSource>>(new(officeId))
                                    .WaitWithResult()
                                    .FirstOrDefault(x => x.Id == referalSourceId);

        return referalSource != null ? new() { Id = referalSource.Id, Value = referalSource.ReferalSource } : null;
    }

    private IEnumerable<EmploymentType> GetEmploymentTypes()
    {
        return Mediator.SendAsync<GetEmploymentTypesQuery, IEnumerable<EmploymentType>>(new())
                       .WaitWithResult();
    }

    private List<string>? GetEmploymentTypes(int[]? employmentTypesIds)
    {
        List<string>? employmentTypes = new();

        if (employmentTypesIds == null || !employmentTypesIds.Any())
            return employmentTypes;

        foreach (int id in employmentTypesIds)
        {
            if (employmentType.TryGetValue(id, out string? value)) employmentTypes.Add(value);
        }

        return employmentTypes;
    }

    private long? GetVendorTotalUploadedFileSize()
    {
        SaveVendorTotalUploadedFileSizeRequest request = new() { ApplicantId = 0, TotalUploadedFileUsage = 0 };
        return Mediator.SendAsync<SaveVendorTotalUploadedFileSizeRequest, VendorTotalUploadedFileSizeResponse>(request).Result.TotalUploadedFileUsage;
    }

    private VendorEntity GetVendorInfo()
    {
        int providerId = AuthenticationService.GetAgencyId();
        var vendor = VendorRepository.GetByIdAsync(providerId).Result;
        return vendor;
    }

    private string? GetGenderById(int id)
    {
        return Mediator.SendAsync<GetGenderQuery, IEnumerable<Domain.Globalization.Gender>>(new(OfficeId)).Result
                       .Where(x => x.Id == id)
                       .Select(x => x.Name)
                       .FirstOrDefault();
    }
}
