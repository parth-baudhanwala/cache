﻿using Hhax.Dao.Application.Abstracts.Caregiver;
using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Caregiver;
using Hhax.Dao.Application.Abstracts.Responses.Caregiver;
using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Concrete.Clients;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RestSharp;

namespace Hhax.Dao.Application.Services.Caregiver;

public class CaregiverApiClient : BaseClient, ICaregiverApiClient
{
    private readonly ILogger<CaregiverApiClient> _logger;
    private readonly IIdentityClient _identityClient;
    private readonly IdentityConfiguration _identityConfiguration;
    private readonly ScopeConfiguration _scopeConfiguration;
    private readonly SettingsConfiguration _settingsConfiguration;

    public CaregiverApiClient(IRestClient client,
                              IIdentityClient identityClient,
                              IOptions<IdentityConfiguration> identityConfigurationOptions,
                              IOptions<ScopeConfiguration> scopeConfigurationOptions,
                              IOptions<SettingsConfiguration> settingsConfigurationOptions,
                              ILogger<CaregiverApiClient> logger) : base(client, logger)
    {
        _logger = logger;
        _identityClient = identityClient;
        _identityConfiguration = identityConfigurationOptions.Value;
        _scopeConfiguration = scopeConfigurationOptions.Value;
        _settingsConfiguration = settingsConfigurationOptions.Value;
    }

    public async Task<CreateCaregiverResponse> ConvertApplicantToCaregiver(CreateCaregiverRequest request)
    {
        _logger.LogInformation($"{nameof(ConvertApplicantToCaregiver)}.");

        string uriString = $"{_settingsConfiguration.CaregiverApiUrl}/Caregiver/ConvertApplicantToCaregiver";
        var headers = new Dictionary<string, string>();

        var token = await _identityClient.AccountsClient.GetTokenWithClientCredentialsAsync(_identityConfiguration.ClientId,
                                                                                            _identityConfiguration.ClientSecret,
                                                                                            _scopeConfiguration.AllRead);
        headers.Add("Authorization", $"Bearer {token.AccessToken}");

        var caregiverResponse = await PostAsync<CreateCaregiverResponse, CreateCaregiverRequest>(uriString, request, headers, false);

        _logger.LogInformation("ConvertApplicantToCaregiver API is called successfully: {CaregiverResponse}", caregiverResponse);

        return caregiverResponse;
    }

    public async Task<ProviderFileSizeLimitResponse> ValidateTotalFileSizeLimitByProvider(ProviderFileSizeLimitRequest request)
    {
        _logger.LogInformation($"{nameof(ValidateTotalFileSizeLimitByProvider)}.");

        string uriString = $"{_settingsConfiguration.CaregiverApiUrl}/File/ValidateTotalFileSizeLimitByProvider";
        var headers = new Dictionary<string, string>();

        var token = await _identityClient.AccountsClient.GetTokenWithClientCredentialsAsync(_identityConfiguration.ClientId,
                                                                                            _identityConfiguration.ClientSecret,
                                                                                            _scopeConfiguration.AllRead);
        headers.Add("Authorization", $"Bearer {token.AccessToken}");

        var validationResponse = await PostAsync<ProviderFileSizeLimitResponse, ProviderFileSizeLimitRequest>(uriString, request, headers, false);

        _logger.LogInformation("ValidateTotalFileSizeLimitByProvider API is called successfully: {validationResponse}", validationResponse);

        return validationResponse;
    }
}
