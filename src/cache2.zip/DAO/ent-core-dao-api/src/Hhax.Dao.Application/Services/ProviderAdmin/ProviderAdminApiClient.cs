﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.ProviderAdmin;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Domain.Application;
using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Concrete.Clients;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RestSharp;

namespace Hhax.Dao.Application.Services.Caregiver
{
    public class ProviderAdminApiClient : BaseClient, IProviderAdminApiClient
    {
        private readonly SettingsConfiguration _settingsConfiguration;
        private readonly IIdentityClient _identityClient;
        private readonly IdentityConfiguration _identityConfiguration;
        private readonly ScopeConfiguration _scopeConfiguration;
        private readonly ILogger<ProviderAdminApiClient> _logger;

        public ProviderAdminApiClient(
            IRestClient client,
            IOptions<SettingsConfiguration> settingsConfiguration,
            IIdentityClient identityClient,
            IOptions<ScopeConfiguration> scopeConfigurationOptions,
            IOptions<IdentityConfiguration> identityConfigurationOptions,
            ILogger<ProviderAdminApiClient> logger)
            : base(client, logger)
        {
            _settingsConfiguration = settingsConfiguration.Value;
            _identityClient = identityClient;
            _identityConfiguration = identityConfigurationOptions.Value;
            _scopeConfiguration = scopeConfigurationOptions.Value;
            _logger = logger;
        }

        public async Task<IEnumerable<OfficeDisciplineResponse>> GetDisciplinesAsync(OfficeDisciplineRequest request)
        {
            _logger.LogInformation("GetDisciplinesAsync for officeId: {officeId}", request.OfficeId);

            string uriString = $"{_settingsConfiguration.ProviderAdminApiUrl}/ProviderOffice/{request.OfficeId}/Disciplines";

            Dictionary<string, string> headers = new();
            
            var token = await _identityClient.AccountsClient.GetTokenWithClientCredentialsAsync(
                _identityConfiguration.ClientId,
                _identityConfiguration.ClientSecret,
                _scopeConfiguration.AllRead).ConfigureAwait(false);
            headers.Add("Authorization", $"Bearer {token.AccessToken}");

            var response = await GetAsync<OfficeDiscipline, OfficeDisciplineRequest>(uriString, request, headers);

            if (response != null && response.Payload?.OfficeDisciplines != null)
            {
                var disciplines = response.Payload.OfficeDisciplines
                    .Where(discipline => discipline.Selected)
                    .Select(discipline => new OfficeDisciplineResponse
                    {
                        Name = discipline.Discipline,
                        Id = discipline.DisciplineId,
                        Type = discipline.DisciplineType,
                        Description = discipline.Description
                    });

                return disciplines;
            }

            return Enumerable.Empty<OfficeDisciplineResponse>();
        }
    }
}
