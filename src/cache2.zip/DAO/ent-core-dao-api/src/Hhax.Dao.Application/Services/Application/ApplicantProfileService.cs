﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Interfaces.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;
using Hhax.Dao.Common.Extensions;
using Hhax.Dao.Domain.MedicalsOther;
using Hhax.Dao.Domain.InService;
using Hhax.Dao.Application.Utilities;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;

namespace Hhax.Dao.Application.Services.Application;

public class ApplicantProfileService : IApplicantProfileService
{
    private bool throwExcpetionIfNotValid;

    private bool isCapUser = false;

    public IApplicantProfileService ThrowExceptionIfNotValid()
    {
        throwExcpetionIfNotValid = true;
        return this;
    }

    public ApplicantProfileService(IAuthenticationService authenticationService)
    {
        isCapUser = authenticationService.IsCAPUser();
    }

    #region Profile Validation

    public IEnumerable<string> ValidateApplicantProfileSection(ApplicantEntity applicantEntity, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        // Demographics section
        var demographicsApplicantRequirements = applicantRequirements.Where(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.Demographics).OrderBy(x => x.ApplicantFieldId);
        var demographicsNotEligibleFields = ValidateDemographicsSection(applicantEntity, demographicsApplicantRequirements);
        notEligibleFields.AddRange(demographicsNotEligibleFields);

        // Employee Information section
        var employeeInformationApplicantRequirements = applicantRequirements.Where(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.EmploymentInformation).OrderBy(x => x.ApplicantFieldId);
        var employeeInformationNotEligibleFields = ValidateEmployeeInformationSection(applicantEntity, employeeInformationApplicantRequirements);
        notEligibleFields.AddRange(employeeInformationNotEligibleFields);

        // Address section
        var addressApplicantRequirements = applicantRequirements.Where(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.Address).OrderBy(x => x.ApplicantFieldId);
        var addressNotEligibleFields = ValidateAddressSection(applicantEntity, addressApplicantRequirements);
        notEligibleFields.AddRange(addressNotEligibleFields);

        // Emergency Contacts section
        var emergencyContactApplicantRequirements = applicantRequirements.Where(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.EmergencyContact).OrderBy(x => x.ApplicantFieldId);
        var emergencyContactNotEligibleFields = ValidateEmergencyContactSection(applicantEntity, emergencyContactApplicantRequirements);
        notEligibleFields.AddRange(emergencyContactNotEligibleFields);

        // Notification Preferences section
        var notificationPreferencesApplicantRequirements = applicantRequirements.Where(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.NotificationPreferences).OrderBy(x => x.ApplicantFieldId);
        var notificationPreferencesNotEligibleFields = ValidateNotificationPreferencesSection(applicantEntity, notificationPreferencesApplicantRequirements);
        notEligibleFields.AddRange(notificationPreferencesNotEligibleFields);

        // Languages section
        var languagesApplicantRequirements = applicantRequirements.Where(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.Languages).OrderBy(x => x.ApplicantFieldId);
        var languagesNotEligibleFields = ValidateLanguagesSection(applicantEntity, languagesApplicantRequirements);
        notEligibleFields.AddRange(languagesNotEligibleFields);

        // Check Application Language
        if (applicantEntity.ApplicationLanguageId <= 0)
            notEligibleFields.Add(Constants.ApplicationLanguageErrorMessage);

        if (throwExcpetionIfNotValid)
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateDemographicsSection(ApplicantEntity applicantEntity, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        foreach (var applicantRequirement in applicantRequirements)
        {
            if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.FirstName, applicantEntity.FirstName))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.FirstName.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.MiddleName, applicantEntity.MiddleName))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.MiddleName.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.LastName, applicantEntity.LastName))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.LastName.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.DateOfBirth, applicantEntity.DateOfBirth))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.DateOfBirth.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.CountryOfBirth, applicantEntity.CountryOfBirth))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.CountryOfBirth.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.MaritalStatus, applicantEntity.MaritalStatusId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.MaritalStatus.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.SocialSecurityNumber, applicantEntity.SocialSecurityNumber))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.SocialSecurityNumber.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.Ethnicity, applicantEntity.Ethnicity))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.Ethnicity.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.Gender, applicantEntity.Gender))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.Gender.GetDisplayName());
            }

            else if (applicantRequirement.IsRequire && applicantRequirement.ApplicantFieldId == (int)ApplicationFormApplicantFields.EmploymentType)
            {
                if (applicantEntity.ApplicantEmploymentTypeMappings != null && !applicantEntity.ApplicantEmploymentTypeMappings.Any() ||
                    applicantEntity.ApplicantEmploymentTypeMappings == null)
                {
                    notEligibleFields.Add(ApplicationFormApplicantFields.EmploymentType.GetDisplayName());
                }
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.ReferralSource, applicantEntity.ReferralSourceId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.ReferralSource.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.ReferralPerson, applicantEntity.ReferralPerson))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.ReferralPerson.GetDisplayName());
            }
        }

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateEmployeeInformationSection(ApplicantEntity applicantEntity, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        foreach (var applicantRequirement in applicantRequirements)
        {
            if (applicantRequirement.IsRequire && applicantRequirement.ApplicantFieldId == (int)ApplicationFormApplicantFields.EmploymentType)
            {
                if (applicantEntity.ApplicantEmploymentTypeMappings != null && !applicantEntity.ApplicantEmploymentTypeMappings.Any() ||
                    applicantEntity.ApplicantEmploymentTypeMappings == null)
                {
                    notEligibleFields.Add(ApplicationFormApplicantFields.EmploymentType.GetDisplayName());
                }
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.RegistryNumber, applicantEntity.RegistryNumber))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.RegistryNumber.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.RegistryDate, applicantEntity.RegistryDate))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.RegistryDate.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.ReferralSource, applicantEntity.ReferralSourceId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.ReferralSource.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.ReferralPerson, applicantEntity.ReferralPerson))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.ReferralPerson.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.NationalProviderIdentity, applicantEntity.NationalProviderIdentity))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.NationalProviderIdentity.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.ProfessionalLicenseNumber, applicantEntity.ProfessionalLicenseNumber))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.ProfessionalLicenseNumber.GetDisplayName());
            }
        }

        if (applicantRequirements.Any(c => c.ApplicantFieldId == (int)ApplicationFormApplicantFields.EmploymentType)
            && applicantEntity.ApplicantEmploymentTypeMappings != null
            && !applicantEntity.ApplicantEmploymentTypeMappings.Any(c => c.EmploymentTypeId == 1 || c.EmploymentTypeId == 2))
        {
            notEligibleFields.Remove(ApplicationFormApplicantFields.RegistryNumber.GetDisplayName());
            notEligibleFields.Remove(ApplicationFormApplicantFields.RegistryDate.GetDisplayName());
        }

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateAddressSection(ApplicantEntity applicantEntity, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        foreach (var applicantRequirement in applicantRequirements)
        {
            if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.AddressLine1, applicantEntity.PrimaryStreet))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.AddressLine1.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.AddressLine2, applicantEntity.SecondaryStreet))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.AddressLine2.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.ZipCode, applicantEntity.Zip))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.ZipCode.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.City, applicantEntity.City))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.City.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.State, applicantEntity.State))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.State.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.PrimaryPhone, applicantEntity.PrimaryPhone))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.PrimaryPhone.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.SecondaryPhone, applicantEntity.AdditionalPhone1))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.SecondaryPhone.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.TertiaryPhone, applicantEntity.AdditionalPhone2))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.TertiaryPhone.GetDisplayName());
            }
        }

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateEmergencyContactSection(ApplicantEntity applicantEntity, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        foreach (var applicantRequirement in applicantRequirements)
        {
            if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.FirstEmergencyContactName, applicantEntity.FirstEmergencyContactName))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.FirstEmergencyContactName.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.FirstEmergencyContactRelationship, applicantEntity.FirstEmergencyContactRelationshipId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.FirstEmergencyContactRelationship.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.FirstEmergencyContactAddress, applicantEntity.FirstEmergencyContactAddress))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.FirstEmergencyContactAddress.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.FirstEmergencyContactPrimaryPhone, applicantEntity.FirstEmergencyContactPhone1))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.FirstEmergencyContactPrimaryPhone.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.FirstEmergencyContactSecondaryPhone, applicantEntity.FirstEmergencyContactPhone2))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.FirstEmergencyContactSecondaryPhone.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.SecondEmergencyContactName, applicantEntity.SecondEmergencyContactName))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.SecondEmergencyContactName.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.SecondEmergencyContactRelationship, applicantEntity.SecondEmergencyContactRelationshipId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.SecondEmergencyContactRelationship.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.SecondEmergencyContactAddress, applicantEntity.SecondEmergencyContactAddress))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.SecondEmergencyContactAddress.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.SecondEmergencyContactPrimaryPhone, applicantEntity.SecondEmergencyContactPhone1))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.SecondEmergencyContactPrimaryPhone.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.SecondEmergencyContactSecondaryPhone, applicantEntity.SecondEmergencyContactPhone2))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.SecondEmergencyContactSecondaryPhone.GetDisplayName());
            }
        }

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateNotificationPreferencesSection(ApplicantEntity applicantEntity, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        var mainRequirement = applicantRequirements.FirstOrDefault(x => x.ApplicantFieldId == (int)ApplicationFormApplicantFields.PreferredContactMethod);
        bool isRequiredSection = mainRequirement != null && mainRequirement.IsRequire;

        if (isRequiredSection && !applicantEntity.PreferredContactMethod.HasValue)
            notEligibleFields.Add(ApplicationFormApplicantFields.PreferredContactMethod.GetDisplayName());

        if ((isRequiredSection || applicantRequirements.Any(x => x.ApplicantFieldId == (int)ApplicationFormApplicantFields.Email && x.IsRequire)) &&
            string.IsNullOrEmpty(applicantEntity.ContactEmail))
            notEligibleFields.Add(ApplicationFormApplicantFields.Email.GetDisplayName());

        if ((isRequiredSection || applicantRequirements.Any(x => x.ApplicantFieldId == (int)ApplicationFormApplicantFields.MobileTextMessage && x.IsRequire)) &&
            string.IsNullOrEmpty(applicantEntity.TextMessagePhone))
            notEligibleFields.Add(ApplicationFormApplicantFields.MobileTextMessage.GetDisplayName());

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateLanguagesSection(ApplicantEntity applicantEntity, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        foreach (var applicantRequirement in applicantRequirements)
        {
            if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.PrimaryLanguage, applicantEntity.PrimaryLanguageId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.PrimaryLanguage.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.SecondaryLanguage, applicantEntity.SecondaryLanguageId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.SecondaryLanguage.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.ThirdLanguage, applicantEntity.ThirdLanguageId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.ThirdLanguage.GetDisplayName());
            }
            else if (!IsValidField(applicantRequirement, ApplicationFormApplicantFields.FourthLanguage, applicantEntity.FourthLanguageId))
            {
                notEligibleFields.Add(ApplicationFormApplicantFields.FourthLanguage.GetDisplayName());
            }
        }

        return notEligibleFields;
    }

    #endregion

    #region Availability Validation

    public IEnumerable<string> ValidateApplicantAvailabilitySection(IEnumerable<AvailabilityDayEntity> applicantAvailabilityDays, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        const string maxVisits = "MaxVisits";

        var availabilityApplicantRequirement = applicantRequirements.FirstOrDefault(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.Availability);

        if (!IsValidApplicantAvailability(applicantAvailabilityDays, availabilityApplicantRequirement!))
        {
            notEligibleFields.Add(maxVisits);
        }

        if (throwExcpetionIfNotValid)
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);

        return notEligibleFields;
    }

    private static bool IsValidApplicantAvailability(IEnumerable<AvailabilityDayEntity> applicantAvailabilityDays, ApplicationFormApplicantRequirement availabilityApplicantRequirement)
    {
        if (availabilityApplicantRequirement is not null && availabilityApplicantRequirement.IsRequire &&
                       availabilityApplicantRequirement.ApplicantFieldId == (int)ApplicationFormApplicantFields.PermanentWeekAvailability)
        {
            return applicantAvailabilityDays is not null &&
                (applicantAvailabilityDays.Any(x => x.MaxVisits is not null) ||
                 applicantAvailabilityDays.Any(x => x.TimeShifts is not null &&
                 (x.TimeShifts.Any(y => y.From is not null && y.To is not null) || x.TimeShifts.Any(y => y.IsLiveIn == true))));
        }

        return true;
    }

    #endregion

    #region Compliance General Requirements Validation

    public IEnumerable<string> ValidateApplicantI9Section(IEnumerable<I9ColumnABDocument> i9ColumnABDocuments,
                                                          ComplianceI9Requirement complianceI9Requirement,
                                                          IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements,
                                                          bool skipEVerifyField,
                                                          bool skipVerificationField)
    {
        const string columnADocument = "Column A Document";
        const string columnBCDocument = "Column B+C Document";
        const string columnI9Expiration = "I-9 Document Expiration Date";
        const string eVerifyNumber = "E-Verify #";
        const string i9Verification = "I-9 Verification";

        var notEligibleFields = new List<string>();

        var i9ApplicantRequirement = applicantRequirements.FirstOrDefault(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.GeneralCompliance &&
                                                                               x.ApplicantFieldId == (int?)ApplicationFormApplicantFields.I9);

        if (i9ApplicantRequirement != null && i9ApplicantRequirement.IsRequire && !i9ColumnABDocuments.Any())
        {
            notEligibleFields.Add(columnADocument);
        }
        else if (i9ApplicantRequirement != null && i9ApplicantRequirement.IsRequire &&
                 i9ColumnABDocuments.Any() && complianceI9Requirement != null)
        {
            if (!complianceI9Requirement.ColumnABDocumentId.HasValue || string.IsNullOrEmpty(complianceI9Requirement.ColumnABDocumentFileKey) && complianceI9Requirement.ColumnABDocumentId.Value != (int)I9Documents.OtherAB)
            {
                notEligibleFields.Add(columnADocument);
            }
            else
            {
                var i9ColumnABDocument = i9ColumnABDocuments.FirstOrDefault(x => x.I9DocumentID == complianceI9Requirement.ColumnABDocumentId);
                if (i9ColumnABDocument != null)
                {
                    if (i9ColumnABDocument.IsColumnCDependent &&
                        (!complianceI9Requirement.ColumnCDocumentId.HasValue || string.IsNullOrEmpty(complianceI9Requirement.ColumnCDocumentFileKey)) && complianceI9Requirement.ColumnCDocumentId != (int)I9Documents.OtherC)
                    {
                        notEligibleFields.Add(columnBCDocument);
                    }
                    if (i9ColumnABDocument.IsExpires && !complianceI9Requirement.ExpirationDate.HasValue)
                    {
                        notEligibleFields.Add(columnI9Expiration);
                    }
                    if (!skipEVerifyField && string.IsNullOrEmpty(complianceI9Requirement.EVerifyNumber))
                    {
                        notEligibleFields.Add(eVerifyNumber);
                    }
                    if (!skipVerificationField && !complianceI9Requirement.IsVerified)
                    {
                        notEligibleFields.Add(i9Verification);
                    }
                }
            }
        }

        if (throwExcpetionIfNotValid)
        {
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);
        }

        if (skipEVerifyField && SignatureUtility.CheckIsSignatureRequired(applicantRequirements, (int)ApplicationFormApplicantFields.GeneralComplianceSignature) && complianceI9Requirement.Signature?.Value == null)
        {
            notEligibleFields.Add("Signature");
        }

        return notEligibleFields;
    }

    public IEnumerable<string> ValidateApplicantBackgroundCheckSection(IEnumerable<ComplianceBackgroundCheckEntity> applicantBackgroundChecks, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        const string backgroundChecks = "BackgroundChecks";

        var backgroundCheckApplicantRequirement = applicantRequirements.FirstOrDefault(
            x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.GeneralCompliance &&
            x.ApplicantFieldId == (int)ApplicationFormApplicantFields.BackgroundCheck);

        if (!IsValidBackgroundChecks(applicantBackgroundChecks, backgroundCheckApplicantRequirement!))
        {
            notEligibleFields.Add(backgroundChecks);
        }

        if (throwExcpetionIfNotValid)
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);

        return notEligibleFields;
    }

    private static bool IsValidBackgroundChecks(IEnumerable<ComplianceBackgroundCheckEntity> applicantBackgroundChecks, ApplicationFormApplicantRequirement backgroundCheckApplicantRequirement)
    {
        if (backgroundCheckApplicantRequirement is not null && backgroundCheckApplicantRequirement.IsRequire &&
                       backgroundCheckApplicantRequirement.ApplicantFieldId == (int)ApplicationFormApplicantFields.BackgroundCheck)
        {
            return (applicantBackgroundChecks is not null) &&
                applicantBackgroundChecks.Any(x => x.ResultId is not null && x.SentOutDate is not null && x.ReceivedDate is not null &&
                !string.IsNullOrWhiteSpace(x.FileKey));
        }

        return true;
    }

    public IEnumerable<string> ValidateApplicantTrainingSchoolsCheckSection(IEnumerable<ComplianceTrainingSchoolEntity> applicantComplianceTrainingSchools, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements, bool skipIsVerifiedField, bool skipVerificationDateField)
    {
        var notEligibleFields = new List<string>();

        const string trainingSchools = "TrainingSchools";

        var trainingSchoolsApplicantRequirement = applicantRequirements.FirstOrDefault(
            x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.GeneralCompliance &&
            x.ApplicantFieldId == (int)ApplicationFormApplicantFields.TrainingSchools);

        if (!IsValidTrainingSchools(applicantComplianceTrainingSchools, trainingSchoolsApplicantRequirement!, skipIsVerifiedField, skipVerificationDateField))
        {
            notEligibleFields.Add(trainingSchools);
        }

        if (throwExcpetionIfNotValid)
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);

        return notEligibleFields;
    }

    private static bool IsValidTrainingSchools(IEnumerable<ComplianceTrainingSchoolEntity> applicantComplianceTrainingSchools, ApplicationFormApplicantRequirement trainingSchoolsApplicantRequirement, bool skipIsVerifiedField, bool skipVerificationDateField)
    {
        if (trainingSchoolsApplicantRequirement is not null && trainingSchoolsApplicantRequirement.IsRequire &&
                       trainingSchoolsApplicantRequirement.ApplicantFieldId == (int)ApplicationFormApplicantFields.TrainingSchools)
        {


            return applicantComplianceTrainingSchools is not null &&
                applicantComplianceTrainingSchools.Any(x => x.SchoolId is not null &&
                x.DisciplineId is not null &&
                x.CertificationDate is not null &&
                !string.IsNullOrEmpty(x.InstructorName) &&
                (skipIsVerifiedField || x.IsVerified) &&
                !string.IsNullOrEmpty(x.CertificateFileKey) &&
                (skipVerificationDateField || x.VerificationDate is not null));
        }

        return true;
    }

    public IEnumerable<string> ValidateApplicantCustomComplianceSection(IEnumerable<ComplianceCustomFieldApplicantValue> customFieldsApplicantValues, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        var customCompliancesApplicantRequirements = applicantRequirements.Where(
            x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.ComplianceFields);

        notEligibleFields.AddRange(ValidateCustomCompliances(customFieldsApplicantValues, customCompliancesApplicantRequirements));

        if (throwExcpetionIfNotValid)
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateCustomCompliances(IEnumerable<ComplianceCustomFieldApplicantValue> customFields, IEnumerable<ApplicationFormApplicantRequirement> customCompliancesApplicantRequirements)
    {
        var notEligibleFields = new List<string>();

        foreach (var customCompliancesApplicantRequirement in customCompliancesApplicantRequirements.Where(x => x.IsRequire))
        {
            var applicantCustomField = customFields.FirstOrDefault(x => x.ComplianceFieldId == customCompliancesApplicantRequirement.ApplicantFieldId);
            if (applicantCustomField != null && !IsValidCustomField(applicantCustomField))
            {
                notEligibleFields.Add(applicantCustomField.CustomFieldLabel!);
            }
        }

        return notEligibleFields;
    }

    private static bool IsValidCustomField(ComplianceCustomFieldApplicantValue customField)
    {
        return !string.IsNullOrEmpty(customField.Value);
    }

    #endregion

    #region Compliance Medicals & Other Requirements Validation

    public IEnumerable<string> ValidateApplicantMedicalsCheckSection(IEnumerable<MedicalsApplicantValue> medicalsApplicantValues, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        var medicalsApplicantRequirements = applicantRequirements.Where(
            x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.MedicalsAndOtherDocuments);

        var isSignatureRequired = SignatureUtility.CheckIsSignatureRequired(applicantRequirements, (int)ApplicationFormApplicantFields.MedicalsAndOtherDocumentSignature);

        notEligibleFields.AddRange(ValidateMedicals(medicalsApplicantValues, medicalsApplicantRequirements, isSignatureRequired, isCapUser));

        if (throwExcpetionIfNotValid)
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateMedicals(IEnumerable<MedicalsApplicantValue> applicantMedicals, IEnumerable<ApplicationFormApplicantRequirement> medicalsApplicantRequirements, bool isSignatureRequired, bool isCAPUser)
    {
        var notEligibleFields = new List<string>();

        foreach (var medicalsApplicantRequirement in medicalsApplicantRequirements.Where(x => x.IsRequire))
        {
            var applicantMedical = applicantMedicals.FirstOrDefault(x => x.ComplianceExpItemId == medicalsApplicantRequirement.ApplicantFieldId);
            if (applicantMedical != null && !IsValidMedical(applicantMedical))
            {
                notEligibleFields.Add(applicantMedical.MedicalName!);
            }
        }

        if (isSignatureRequired && isCAPUser)
        {
            foreach (var medicalsApplicantRequirement in medicalsApplicantRequirements.Where(x => x.IsShow))
            {
                bool applicantMedical = applicantMedicals.Any(x => x.ComplianceExpItemId == medicalsApplicantRequirement.ApplicantFieldId && x.Signature?.Value == null);
                if (isSignatureRequired && applicantMedical)
                {
                    notEligibleFields.Add("Signature");
                    isSignatureRequired = false;
                }
            }
        }

        return notEligibleFields;
    }

    private static bool IsValidMedical(MedicalsApplicantValue applicantMedical)
    {
        return !string.IsNullOrWhiteSpace(applicantMedical.FileKey) &&
                applicantMedical.PerformedDate is not null &&
               !string.IsNullOrEmpty(applicantMedical.Value);
    }

    public IEnumerable<string> ValidateApplicantOtherDocumentsCheckSection(IEnumerable<OtherApplicantValue> otherDocumentsApplicantValues, IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        var medicalsApplicantRequirements = applicantRequirements.Where(
            x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.MedicalsAndOtherDocuments);

        var isSignatureRequired = SignatureUtility.CheckIsSignatureRequired(applicantRequirements, (int)ApplicationFormApplicantFields.MedicalsAndOtherDocumentSignature);

        notEligibleFields.AddRange(ValidateOtherDocuments(otherDocumentsApplicantValues, medicalsApplicantRequirements, isSignatureRequired, isCapUser));

        if (throwExcpetionIfNotValid)
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateOtherDocuments(IEnumerable<OtherApplicantValue> applicantOtherDocuments, IEnumerable<ApplicationFormApplicantRequirement> otherDocumentsApplicantRequirements, bool isSignatureRequired, bool isCAPUser)
    {
        var notEligibleFields = new List<string>();

        foreach (var otherDocumentsApplicantRequirement in otherDocumentsApplicantRequirements.Where(x => x.IsRequire))
        {
            var otherDocument = applicantOtherDocuments.FirstOrDefault(x => x.ComplianceExpItemId == otherDocumentsApplicantRequirement.ApplicantFieldId);
            if (otherDocument != null && !IsValidOtherDocument(otherDocument))
                notEligibleFields.Add(otherDocument.RequirementName!);
        }

        if (isSignatureRequired && isCAPUser)
        {
            foreach (var otherDocumentsApplicantRequirement in otherDocumentsApplicantRequirements.Where(x => x.IsShow))
            {
                bool otherDocument = applicantOtherDocuments.Any(x => x.ComplianceExpItemId == otherDocumentsApplicantRequirement.ApplicantFieldId && x.Signature?.Value == null);
                if (isSignatureRequired && otherDocument)
                {
                    notEligibleFields.Add("Signature");
                    isSignatureRequired = false;
                }
            }
        }

        return notEligibleFields;
    }

    private static bool IsValidOtherDocument(OtherApplicantValue otherDocument)
    {
        return !string.IsNullOrWhiteSpace(otherDocument.FileKey) &&
                otherDocument.PerformedDate is not null &&
               !string.IsNullOrEmpty(otherDocument.Value);
    }

    #endregion

    #region In-Service Validation

    public IEnumerable<string> ValidateApplicantInServiceSection(IEnumerable<ApplicantInServiceTableItem> inServiceApplicantValues, IEnumerable<InServiceTopic> inServiceTopics,
        IEnumerable<ApplicationFormApplicantRequirement> applicantRequirements)
    {
        var notEligibleFields = new List<string>();

        if (applicantRequirements.Any(x => x.ApplicantSectionId == (int)ApplicationFormApplicantSections.InServiceTopics && x.IsRequire))
            notEligibleFields.AddRange(ValidateInServices(inServiceApplicantValues, inServiceTopics));

        if (throwExcpetionIfNotValid)
            AFSRespectUtility.ThrowExceptionIfNotRespect(notEligibleFields);

        return notEligibleFields;
    }

    private static IEnumerable<string> ValidateInServices(IEnumerable<ApplicantInServiceTableItem> inServices, IEnumerable<InServiceTopic> inServiceTopics)
    {
        var notEligibleFields = new List<string>();

        foreach (var inServiceTopic in inServiceTopics.Where(x => x.IsRequire))
        {
            if (inServices is not null && !inServices.Any(x => x.TopicIds != null && x.TopicIds.Contains(inServiceTopic.Id) && IsValidInService(x)))
                notEligibleFields.Add(inServiceTopic.TopicDescription!);
        }

        return notEligibleFields;
    }

    private static bool IsValidInService(ApplicantInServiceTableItem inService)
    {
        return inService.DisciplineId is not null && inService.PaycodeId is not null &&
            !string.IsNullOrEmpty(inService.StartTime) && !string.IsNullOrEmpty(inService.EndTime) &&
            inService.Date != default;
    }

    #endregion

    private static bool IsValidField(ApplicationFormApplicantRequirement applicantRequirement, ApplicationFormApplicantFields applicantField, DateTime? value)
    => !(applicantRequirement.IsRequire && applicantRequirement.ApplicantFieldId == (int)applicantField && !value.HasValue);

    private static bool IsValidField(ApplicationFormApplicantRequirement applicantRequirement, ApplicationFormApplicantFields applicantField, int? value)
    => !(applicantRequirement.IsRequire && applicantRequirement.ApplicantFieldId == (int)applicantField && !value.HasValue);

    private static bool IsValidField(ApplicationFormApplicantRequirement applicantRequirement, ApplicationFormApplicantFields applicantField, string? value)
    => !(applicantRequirement.IsRequire && applicantRequirement.ApplicantFieldId == (int)applicantField && string.IsNullOrEmpty(value));
}
