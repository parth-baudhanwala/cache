﻿using Hhax.Dao.Application.Abstracts.Configurations;
using Hhax.Dao.Application.Abstracts.Interfaces.Common;
using Hhax.Dao.Application.Abstracts.Requests.Header;
using Hhax.Dao.Application.Abstracts.Requests.Permission;
using Hhax.Dao.Application.Abstracts.Requests.Provider;
using Hhax.Dao.Application.Abstracts.Responses.Header;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using Hhax.Dao.Application.Abstracts.Responses.Provider;
using Hhax.Dao.Infrastructure.Helpers;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Hhax.Dao.Application.Managers
{
    public class HhaStoredProceduresManager : IHhaStoredProceduresManager
    {
        private readonly IReadOnlyDictionary<string, string> _storedProcConnectionStringsMapping;
        private readonly HhaStoredProceduresConfiguration _storedProcedures;
        private readonly StoredProceduresConnectionStringsConfiguration _storedProcConnectionStringsKeys;
        private readonly ILogger<HhaStoredProceduresManager> _logger;

        public HhaStoredProceduresManager(IReadOnlyDictionary<string, string> storedProcConnectionStringsMapping,
            IOptions<HhaStoredProceduresConfiguration> storedProcedures,
            IOptions<StoredProceduresConnectionStringsConfiguration> storedProcConnectionStringsKeys,
            ILogger<HhaStoredProceduresManager> logger)
        {
            string procedureNotFoundErrorMessage = " was not found in the HHAStoredProcedures section in the config.";

            _storedProcConnectionStringsMapping = storedProcConnectionStringsMapping;
            _logger = logger;
            _storedProcedures = storedProcedures.Value;
            _storedProcConnectionStringsKeys = storedProcConnectionStringsKeys.Value;

            if (string.IsNullOrEmpty(_storedProcedures.CheckAccess))
                throw new InvalidOperationException(nameof(_storedProcedures.CheckAccess) + procedureNotFoundErrorMessage);
            if (string.IsNullOrEmpty(_storedProcedures.CheckAccessByOfficeId))
                throw new InvalidOperationException(nameof(_storedProcedures.CheckAccessByOfficeId) + procedureNotFoundErrorMessage);
            if (string.IsNullOrEmpty(_storedProcedures.GetUserNotificationsCountAll))
                throw new InvalidOperationException(nameof(_storedProcedures.GetUserNotificationsCountAll) + procedureNotFoundErrorMessage);
            if (string.IsNullOrEmpty(_storedProcedures.GetMaxLoginAttempts))
                throw new InvalidOperationException(nameof(_storedProcedures.GetMaxLoginAttempts) + procedureNotFoundErrorMessage);
            if (string.IsNullOrEmpty(_storedProcedures.CheckCaregiverChatAccess))
                throw new InvalidOperationException(nameof(_storedProcedures.CheckCaregiverChatAccess) + procedureNotFoundErrorMessage);
            if (string.IsNullOrEmpty(_storedProcedures.GetReasons))
                throw new InvalidOperationException(nameof(_storedProcedures.GetReasons) + procedureNotFoundErrorMessage);
        }

        public async Task<PermissionSPResponse> CheckAccess(int userId, string[] nodes, string? appVersion, decimal? version, decimal? minorVersion)
        {
            try
            {
                string connectionStringKey = _storedProcConnectionStringsKeys.CheckAccess;
                string connectionString = _storedProcConnectionStringsMapping.GetValueOrDefault(connectionStringKey)!;

                PermissionSPRequest userPermissionRequest = new()
                {
                    UserID = userId,
                    Nodes = GetNodesXml(nodes),
                    AppVersion = appVersion,
                    Version = version,
                    MinorVersion = minorVersion,
                    CallerInfo = StoredProceduresHelper.GetCallerInfo(nameof(HhaStoredProceduresManager))
                };

                IEnumerable<string?> result = await StoredProceduresHelper
                    .CallStoredProcedureAsync<string?>(connectionString, _storedProcedures.CheckAccess, userPermissionRequest);

                return new PermissionSPResponse(result);
            }
            catch (Exception e)
            {
                _logger.LogError("The error occured while executing {method} stored procedure: '{message}'.", nameof(CheckAccess), e.Message);
                throw;
            }
        }

        public async Task<PermissionSPResponse> CheckAccessByOfficeId(int userId, string[] nodes, string? appVersion, decimal? version, decimal? minorVersion)
        {
            try
            {
                string connectionStringKey = _storedProcConnectionStringsKeys.CheckAccess;
                string connectionString = _storedProcConnectionStringsMapping.GetValueOrDefault(connectionStringKey)!;

                PermissionSPRequest userPermissionRequest = new()
                {
                    UserID = userId,
                    Nodes = GetNodesXml(nodes),
                    AppVersion = appVersion,
                    Version = version,
                    MinorVersion = minorVersion,
                    CallerInfo = StoredProceduresHelper.GetCallerInfo(nameof(HhaStoredProceduresManager))
                };

                IEnumerable<string?> result = await StoredProceduresHelper
                    .CallStoredProcedureAsync<string?>(connectionString, _storedProcedures.CheckAccessByOfficeId, userPermissionRequest);

                return new PermissionSPResponse(result);
            }
            catch (Exception e)
            {
                _logger.LogError("The error occured while executing {method} stored procedure: '{message}'.", nameof(CheckAccessByOfficeId), e.Message);
                throw;
            }
        }

        public async Task<NotificationsDetailSPResponse> GetUserNotificationsCountAll(int userId, int providerId, string? appVersion, decimal? version, decimal? minorVersion)
        {
            try
            {
                string connectionStringKey = _storedProcConnectionStringsKeys.GetUserNotificationsCountAll;
                string connectionString = _storedProcConnectionStringsMapping.GetValueOrDefault(connectionStringKey)!;

                NotificationsDetailSPRequest notificationsRequest = new()
                {
                    UserID = userId,
                    ProviderID = providerId,
                    AppVersion = appVersion,
                    Version = version,
                    MinorVersion = minorVersion,
                    CallerInfo = StoredProceduresHelper.GetCallerInfo(nameof(HhaStoredProceduresManager))
                };

                IEnumerable<NotificationsDetailSPResponse> result = await StoredProceduresHelper
                    .CallStoredProcedureAsync<NotificationsDetailSPResponse>(connectionString, _storedProcedures.GetUserNotificationsCountAll, notificationsRequest);

                return result.FirstOrDefault() ?? new();
            }
            catch (Exception e)
            {
                _logger.LogError("The error occured while executing {method} stored procedure: '{message}'.", nameof(GetUserNotificationsCountAll), e.Message);
                throw;
            }
        }

        public async Task<int> GetMaxLoginAttempts()
        {
            try
            {
                string connectionStringKey = _storedProcConnectionStringsKeys.GetMaxLoginAttempts;
                string connectionString = _storedProcConnectionStringsMapping.GetValueOrDefault(connectionStringKey)!;

                IEnumerable<int> result = await StoredProceduresHelper.CallSqlFunctionWIthOutParams<int>(connectionString, _storedProcedures.GetMaxLoginAttempts);

                return result.FirstOrDefault();
            }
            catch (Exception e)
            {
                _logger.LogError("The error occured while executing {method} stored procedure: '{message}'.", nameof(GetMaxLoginAttempts), e.Message);
                throw;
            }
        }

        public async Task<bool> CheckCaregiverChatAccess(int userId)
        {
            try
            {
                string connectionStringKey = _storedProcConnectionStringsKeys.CheckCaregiverChatAccess;
                string connectionString = _storedProcConnectionStringsMapping.GetValueOrDefault(connectionStringKey)!;
                var parameters = new
                {
                    UserID = userId,
                    CallerInfo = StoredProceduresHelper.GetCallerInfo(nameof(HhaStoredProceduresManager))
                };

                bool hasChatAccess = await StoredProceduresHelper.CallStoredProcedureFirstAsync<bool>(connectionString, _storedProcedures.CheckCaregiverChatAccess, parameters);

                return hasChatAccess;
            }
            catch (Exception e)
            {
                _logger.LogError("The error occured while executing {method} stored procedure: '{message}'.", nameof(CheckCaregiverChatAccess), e.Message);
                throw;
            }
        }

        public async Task<IEnumerable<GetReasonsResponse>> GetReasons(GetReasonsRequest reasonsRequest)
        {
            try
            {
                string connectionStringKey = _storedProcConnectionStringsKeys.GetReasons;
                string connectionString = _storedProcConnectionStringsMapping.GetValueOrDefault(connectionStringKey)!;
                reasonsRequest.CallerInfo = StoredProceduresHelper.GetCallerInfo(nameof(HhaStoredProceduresManager));

                var reasons = await StoredProceduresHelper.CallStoredProcedureAsync<GetReasonsResponse>(connectionString, _storedProcedures.GetReasons, reasonsRequest);

                return reasons;
            }
            catch (Exception e)
            {
                _logger.LogError("The error occured while executing {method} stored procedure: '{message}'.", nameof(GetReasons), e.Message);
                throw;
            }
        }

        private static string GetNodesXml(string[] menuItems)
        {
            return $@"<Nodes>{string.Join(string.Empty, menuItems.Select(x => $@"<Node Name=""{x}""/>").ToArray())}</Nodes>";
        }
    }
}