﻿using AutoMapper;
using Hhax.Dao.Application.Commands.InService;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.InService;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;

namespace Hhax.Dao.Application.Profiles.InService;

public class InServiceProfile : Profile
{
    public InServiceProfile()
    {
        CreateMap<PayRateEntity, InServicePayRate>();

        CreateMap<InstructorEntity, InServiceInstructor>();

        CreateMap<UpsertInServiceCommand, ApplicantInServiceTableItem>();

        CreateMap<InserviceNoShowReasonEntity, InServiceNoShowReason>();

        CreateMap<RefInServiceTopicEntity, InServiceTopic>();

        CreateMap<ApplicantInServiceEntity, ApplicantInServiceInfo>();

        CreateMap<UpsertInServiceCommand, ApplicantInServiceEntity>()
            .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (int)src.StatusId!))
            .ForMember(dest => dest.NoShowReasonId, opt => opt.MapFrom(src => src.ReasonId))
            .ForMember(dest => dest.Date, opt => opt.MapFrom(src => TimeZoneInfo.ConvertTimeToUtc(src.Date!.Value)));
    }
}
