﻿using AutoMapper;
using Hhax.Dao.Domain.MedicalsOther;

namespace Hhax.Dao.Application.Profiles.MedicalsOther;

public class OtherApplicantValueProfile : Profile
{
    public OtherApplicantValueProfile()
        => CreateMap<OtherApplicantValueEntity, OtherApplicantValue>()
            .ReverseMap();
}
