﻿using AutoMapper;
using Hhax.Dao.Domain.MedicalsOther;

namespace Hhax.Dao.Application.Profiles.MedicalsOther;

public class MedicalsApplicantValueProfile : Profile
{
    public MedicalsApplicantValueProfile()
        => CreateMap<MedicalsApplicantValueEntity, MedicalsApplicantValue>()
            .ReverseMap();
}
