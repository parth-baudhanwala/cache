﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Requests.Account;
using Hhax.Dao.Application.Abstracts.Requests.Permission;
using Hhax.Dao.Application.Commands.Account;
using Hhax.Dao.Application.Queries.Account;

namespace Hhax.Dao.Application.Profiles.Account;

public class AccountProfile : Profile
{
    public AccountProfile()
    {
        CreateMap<PermissionsRequest, ValidatePermissionsCommand>()
            .ConvertUsing(request => new ValidatePermissionsCommand(request.Permissions!));

        CreateMap<PermissionsRequest, ValidatePermissionsByIdsCommand>()
            .ConvertUsing(request => new ValidatePermissionsByIdsCommand(request.Permissions!));

        CreateMap<ApplicantLoginRequest, ApplicantLoginQuery>()
            .ConvertUsing(request => new ApplicantLoginQuery(request.Email, request.Password, request.ApplicationLanguageId));
        CreateMap<ApplicantRefreshTokenRequest, ApplicantRefreshTokenQuery>()
            .ConvertUsing(request => new ApplicantRefreshTokenQuery(request.RefreshToken));
    }
}
