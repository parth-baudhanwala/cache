﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Responses.Provider;
using Hhax.Dao.Domain.Notes;

namespace Hhax.Dao.Application.Profiles.Provider;

public class SubjectProfile : Profile
{
    public SubjectProfile()
    {
        CreateMap<GetReasonsResponse, NoteSubject>()
            .ForMember(x => x.SubjectId, opt => opt.MapFrom(y => y.ReasonID))
            .ForMember(x => x.Subject, opt => opt.MapFrom(y => y.Reason))
            .ForMember(x => x.SubjectDescription, opt => opt.MapFrom(y => y.ReasonDescription));
    }
}
