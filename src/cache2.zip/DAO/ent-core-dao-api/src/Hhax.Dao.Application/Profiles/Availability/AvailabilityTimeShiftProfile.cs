﻿using AutoMapper;
using Hhax.Dao.Domain.Availability;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Availability;

namespace Hhax.Dao.Application.Profiles.Availability;

public class AvailabilityTimeShiftProfile : Profile
{
    public AvailabilityTimeShiftProfile()
        => CreateMap<AvailabilityTimeShiftEntity, AvailabilityTimeShift>().ReverseMap();
}