﻿using AutoMapper;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;

namespace Hhax.Dao.Application.Profiles.Office;

public class OfficeInfoProfile : Profile
{
    public OfficeInfoProfile()
    {
        CreateMap<OfficeInfoEntity, OfficeInfo>().ReverseMap();
    }
}
