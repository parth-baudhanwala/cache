﻿using AutoMapper;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;

namespace Hhax.Dao.Application.Profiles.Office;

public class OfficeHierarchyProfile : Profile
{
    public OfficeHierarchyProfile()
    {
        CreateMap<OfficeHierarchyEntity, OfficeHierarchy>().ReverseMap();
    }
}
