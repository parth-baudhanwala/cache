﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Application.Commands.Office;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Office;

namespace Hhax.Dao.Application.Profiles.Office;

public class HumanResourcePersonaProfile : Profile
{
    public HumanResourcePersonaProfile()
    {
        CreateMap<HumanResourcePersonaEntity, HumanResourcePersona>()
            .ForMember(x => x.OfficeIds, opt => opt.MapFrom(x => x.HumanResourcePersonaOfficeMappings != null ? x.HumanResourcePersonaOfficeMappings.Select(x => x.OfficeId).ToArray() : Array.Empty<int>()))
            .ReverseMap();

        CreateMap<AssignApplicantRequest, AssignHumanResourcePersonaToApplicantCommand>();

        CreateMap<HumanResourcePersonaRequest, AddHumanResourcePersonaCommand>();

        CreateMap<HumanResourcePersonaRequest, UpdateHumanResourcePersonaCommand>();
    }
}
