﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Responses.Header;

namespace Hhax.Dao.Application.Profiles.Header
{
    public class NotificationsDetailResponseProfile : Profile
    {
        public NotificationsDetailResponseProfile()
        {
            CreateMap<NotificationsDetailSPResponse, NotificationsDetailResponse>()
                .ForMember(x => x.UserNotificationMsgCount, opt => opt.MapFrom(x => x.UserNotifMsgCnt))
                .ForMember(x => x.UserNotificationMsgColor, opt => opt.MapFrom(x => x.UserNotifMsgColor))
                .ForMember(x => x.UserMsgCount, opt => opt.MapFrom(x => x.UserMessagesCnt))
                .ForMember(x => x.UserMessageColor, opt => opt.MapFrom(x => x.UserMessagesColor))
                .ForMember(x => x.UserToDoMsgCount, opt => opt.MapFrom(x => x.UserToDosMsgCnt))
                .ForMember(x => x.UserToDoMsgColor, opt => opt.MapFrom(x => x.UserToDosMsgColor))
                .ForMember(x => x.OpenCaseMsgCount, opt => opt.MapFrom(x => x.OpenCaseMsgCnt))
                .ForMember(x => x.OpenCaseMsgColor, opt => opt.MapFrom(x => x.OpenCaseMsgColor))
                .ForMember(x => x.OpenCaseURL, opt => opt.MapFrom(x => x.OpenCaseURL));
        }
    }
}
