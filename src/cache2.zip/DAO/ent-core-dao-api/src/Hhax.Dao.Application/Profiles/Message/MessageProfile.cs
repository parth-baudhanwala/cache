﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Requests.Message;
using Hhax.Dao.Application.Commands.Message;

namespace Hhax.Dao.Application.Profiles.Message
{
    public class MessageProfile : Profile
    {
        public MessageProfile()
        {
            CreateMap<SendEmailRequest, SendEmailCommand>();
            CreateMap<SendSmsRequest, SendSmsCommand>();
        }
    }
}
