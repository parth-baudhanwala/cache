﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Requests.FormBuilder;
using Hhax.Dao.Application.Abstracts.Responses.FormBuilder;
using Hhax.Dao.Application.Abstracts.Responses.OnBoardingForm;
using Hhax.Dao.Application.Commands.OnBoardingForm;

namespace Hhax.Dao.Application.Profiles.Header
{
    public class OnBoardingFormServiceProfile : Profile
    {
        public OnBoardingFormServiceProfile()
        {
            CreateMap<FormListByCategoryNameRequest, GetOnBoardingFormsCommand>().ReverseMap();
            CreateMap<OnBoardingFormResponse, FormDetails>().ReverseMap();
        }
    }
}
