﻿using AutoMapper;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;

namespace Hhax.Dao.Application.Profiles.Compliance;

public class ComplianceTrainingSchoolProfile : Profile
{
    public ComplianceTrainingSchoolProfile()
        => CreateMap<ComplianceTrainingSchoolEntity, ComplianceTrainingSchool>()
            .ReverseMap();
}
