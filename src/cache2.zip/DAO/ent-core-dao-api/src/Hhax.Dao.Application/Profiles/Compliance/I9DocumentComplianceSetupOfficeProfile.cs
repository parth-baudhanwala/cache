﻿using AutoMapper;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;

namespace Hhax.Dao.Application.Profiles.Compliance;

public class I9DocumentComplianceSetupOfficeProfile : Profile
{
    public I9DocumentComplianceSetupOfficeProfile()
        => CreateMap<I9DocumentComplianceSetupOfficeEntity, I9DocumentComplianceSetupOffice>()
            .ReverseMap();
}