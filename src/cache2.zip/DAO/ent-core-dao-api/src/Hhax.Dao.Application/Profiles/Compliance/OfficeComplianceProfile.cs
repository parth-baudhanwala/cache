﻿using AutoMapper;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;

namespace Hhax.Dao.Application.Profiles.Compliance;

public class OfficeComplianceProfile : Profile
{
    public OfficeComplianceProfile()
    {
        CreateMap<ComplianceSetupOffice, ComplianceSetupOfficeEntity>().ReverseMap();
    }
}
