﻿using AutoMapper;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;

namespace Hhax.Dao.Application.Profiles.Compliance;

public class ComplianceI9RequirementsProfile : Profile
{
    public ComplianceI9RequirementsProfile()
    {
        CreateMap<ComplianceI9RequirementEntity, ComplianceI9Requirement>()
            .ReverseMap();

        CreateMap<ComplianceI9Requirement, UpsertI9RequirementCommand>()
            .ReverseMap();

        CreateMap<UpsertI9RequirementCommand, ComplianceI9RequirementEntity>()
            .ForMember(x => x.ExpirationDate, opt => opt.MapFrom(x => x.ExpirationDate.HasValue ? x.ExpirationDate.Value.ToUniversalTime() : (DateTime?)null));

    }
}

