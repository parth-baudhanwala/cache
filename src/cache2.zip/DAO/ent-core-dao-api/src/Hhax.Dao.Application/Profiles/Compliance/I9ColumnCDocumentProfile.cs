﻿using AutoMapper;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;

namespace Hhax.Dao.Application.Profiles.Compliance;

public class I9ColumnCDocumentProfile : Profile
{
    public I9ColumnCDocumentProfile()
        => CreateMap<I9ColumnCDocumentEntity, I9ColumnCDocument>()
            .ReverseMap();
}
