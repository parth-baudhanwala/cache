﻿using AutoMapper;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;

namespace Hhax.Dao.Application.Profiles.Compliance;

public class BackgroundCheckResultProfile : Profile
{
    public BackgroundCheckResultProfile()
        => CreateMap<BackgroundCheckResultEntity, BackgroundCheckResponse>()
            .ReverseMap();
}
