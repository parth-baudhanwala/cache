﻿using AutoMapper;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;

namespace Hhax.Dao.Application.Profiles.Compliance;

public class I9DocumentProfile : Profile
{
    public I9DocumentProfile()
    {
        CreateMap<I9Document, I9DocumentEntity>()
            .ReverseMap();

        CreateMap<I9DocumentEntity, I9DocumentEntity>()
           .ReverseMap();
    }
}
