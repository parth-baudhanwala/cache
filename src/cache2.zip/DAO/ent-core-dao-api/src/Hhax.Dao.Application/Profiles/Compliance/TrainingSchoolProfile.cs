﻿using AutoMapper;
using Hhax.Dao.Application.Commands.Compliance;
using Hhax.Dao.Domain.Compliance;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Compliance;

namespace Hhax.Dao.Application.Profiles.Compliance;

public class TrainingSchoolProfile : Profile
{
    public TrainingSchoolProfile()
    { 
        CreateMap<TrainingSchoolEntity, TrainingSchool>()
            .ReverseMap();

        CreateMap<ComplianceTrainingSchool, UpsertApplicationTrainingSchoolCommand>();

        CreateMap<UpsertApplicationTrainingSchoolCommand, ComplianceTrainingSchoolEntity>();
    }
}
