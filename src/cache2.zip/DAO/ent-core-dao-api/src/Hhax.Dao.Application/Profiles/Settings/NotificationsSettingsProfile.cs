﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Responses.Settings;
using Hhax.Dao.Application.Commands.Settings;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Vendor;

namespace Hhax.Dao.Application.Profiles.Settings;

public class NotificationsSettingsProfile : Profile
{
    public NotificationsSettingsProfile()
    {
        CreateMap<VendorNotificationsSettingsEntity, NotificationsSettingsResponse>().ReverseMap();
        CreateMap<VendorNotificationsSettingsEntity, SaveNotificationsSettingsCommand>().ReverseMap();
    }
}
