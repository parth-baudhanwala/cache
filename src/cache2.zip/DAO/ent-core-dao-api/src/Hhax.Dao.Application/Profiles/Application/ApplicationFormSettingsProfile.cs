﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Commands.Settings;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicationFormSettingsProfile : Profile
{
    public ApplicationFormSettingsProfile()
    {
        CreateMap<SaveAgencyLogoRequest, SaveAgencyLogoCommand>();
    }
}
