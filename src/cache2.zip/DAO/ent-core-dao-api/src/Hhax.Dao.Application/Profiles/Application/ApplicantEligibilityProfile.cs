﻿using AutoMapper;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicantEligibilityProfile : Profile
{
    public ApplicantEligibilityProfile()
    {
        CreateMap<ApplicantEligibilityEntity, Domain.Common.BaseEntity>()
           .ReverseMap();

        CreateMap<ApplicantEligibilityEntity, ApplicantEligibility>()
            .ReverseMap();
    }
}
