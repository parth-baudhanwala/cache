﻿using AutoMapper;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicationFormApplicantRequirementProfile : Profile
{
    public ApplicationFormApplicantRequirementProfile()
    {
        CreateMap<ApplicationFormApplicantRequirementEntity, ApplicationFormApplicantRequirement>().ReverseMap();
        
        CreateMap<ApplicationFormApplicantRequirement, ApplicationFormApplicantRequirement>().ReverseMap();
    }
}
