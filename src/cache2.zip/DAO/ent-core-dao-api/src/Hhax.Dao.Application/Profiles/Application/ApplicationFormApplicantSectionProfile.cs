﻿using AutoMapper;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicationFormApplicantSectionProfile : Profile
{
    public ApplicationFormApplicantSectionProfile()
    {
        CreateMap<ApplicationFormApplicantSectionEntity, ApplicationFormApplicantSection>().ReverseMap();
    }
}
