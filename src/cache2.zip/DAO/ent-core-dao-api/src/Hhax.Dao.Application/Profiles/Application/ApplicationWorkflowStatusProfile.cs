﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Common;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicationWorkflowStatusProfile : Profile
{
    public ApplicationWorkflowStatusProfile()
    {
        CreateMap<ApplicationWorkflowStatusEntity, BaseEntity>()
            .ReverseMap();

        CreateMap<ApplicationWorkflowStatusMappingEntity, ApplicationWorkflowStatusMapping>()
            .ReverseMap();

        CreateMap<ApplicationWorkflowStatusEntity, ApplicationWorkflowStatus>()
           .ForMember(x => x.IsActive, ops => ops.MapFrom(x => true));

        CreateMap<ApplicationWorkflowStatus, ApplicationWorkflowStatusEntity>()
             .ForMember(x => x.ColorId, opt => opt.MapFrom(x => x.ColorId))
             .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
             .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow))
             .ForMember(x => x.ApplicationWorkflowStatusMappings, opt => opt.MapFrom(x => x.ApplicationWorkflowStatusMappings!.Select(f => new ApplicationWorkflowStatusMappingEntity {
                Id = f.Id,
                ApplicationWorkflowStatusId = f.ApplicationWorkflowStatusId,
                NextApplicationWorkflowStatusId = f.NextApplicationWorkflowStatusId,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
             }).ToArray()));

        CreateMap<ApplicationWorkflowStatusRequest, AddApplicationWorkflowStatusCommand>()
             .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
             .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow));
        
        CreateMap<ApplicationWorkflowStatusRequest, UpdateApplicationWorkflowStatusCommand>()
             .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
             .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow));

        CreateMap<AddApplicationWorkflowStatusCommand, ApplicationWorkflowStatus>()
            .ForMember(x => x.ApplicationWorkflowStatusMappings, opt => opt.MapFrom(x => x.NextApplicationWorkflowStatusIds!.Select(nextApplicationWorkflowStatusId => new ApplicationWorkflowStatusMapping { 
                NextApplicationWorkflowStatusId = nextApplicationWorkflowStatusId, 
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            }).ToArray()))
            .ForMember(x => x.CreatedBy, opt => opt.MapFrom(x => x.UserId))
             .ForMember(x => x.UpdatedBy, opt => opt.MapFrom(x => x.UserId))
             .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
             .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow));

        CreateMap<UpdateApplicationWorkflowStatusCommand, ApplicationWorkflowStatus>()
             .ForMember(x => x.ApplicationWorkflowStatusMappings, opt => opt.MapFrom(x => x.NextApplicationWorkflowStatusIds!.Select(nextApplicationWorkflowStatusId => new ApplicationWorkflowStatusMapping {
                 NextApplicationWorkflowStatusId = nextApplicationWorkflowStatusId,
                 Created = DateTime.UtcNow,
                 Updated = DateTime.UtcNow
             }).ToArray()))
             .ForMember(x => x.CreatedBy, opt => opt.MapFrom(x => x.UserId))
             .ForMember(x => x.UpdatedBy, opt => opt.MapFrom(x => x.UserId))
             .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
             .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow));
    }
}
