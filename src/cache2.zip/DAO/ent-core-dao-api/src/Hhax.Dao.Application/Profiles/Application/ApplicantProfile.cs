﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Common;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicantProfile : Profile
{
    public ApplicantProfile()
    {
        CreateMap<Domain.Common.BaseEntity, BaseEntity>().ReverseMap();

        CreateMap<Applicant, ApplicantEntity>()
            .ForMember(x => x.ApplicantEmploymentTypeMappings, opt => opt.MapFrom(x => x.EmploymentTypeIds!.Select(employmentTypeId => new ApplicantEmploymentTypeMappingEntity
            {
                EmploymentTypeId = employmentTypeId,
                ApplicantId = x.Id,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            }).ToArray()))
            .ForMember(x => x.DateOfBirth, opt => opt.MapFrom(x => !string.IsNullOrEmpty(x.DateOfBirth) ? Convert.ToDateTime(x.DateOfBirth).ToUniversalTime() : (DateTime?)null))
            .ForMember(x => x.RegistryDate, opt => opt.MapFrom(x => x.RegistryDate.HasValue ? x.RegistryDate.Value.ToUniversalTime() : (DateTime?)null))
            .ForMember(x => x.TextMessagePhone, opt => opt.MapFrom(x => string.IsNullOrEmpty(x.TextMessagePhone) ? null : x.TextMessagePhone));

        CreateMap<ApplicantEntity, Applicant>()
            .ForMember(x => x.EmploymentTypeIds, opt => opt.MapFrom(x => x.ApplicantEmploymentTypeMappings != null ? x.ApplicantEmploymentTypeMappings.Select(x => x.EmploymentTypeId).ToArray() : Array.Empty<int>()))
            .ForMember(x => x.HasNotes, opt => opt.MapFrom(x => x.ApplicantNotes!.Any()));

        CreateMap<ApplicantEntity, ApplicantEntity>();

        CreateMap<ApplicantAddRequest, AddApplicantCommand>();

        CreateMap<ApplicantUpdateRequest, UpdateApplicantCommand>();

        CreateMap<AddApplicantCommand, Applicant>()
            .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ForMember(x => x.ApplicationWorkflowStatusUpdated, opt => opt.MapFrom(x => DateTime.UtcNow));

        CreateMap<UpdateApplicantCommand, Applicant>()
            .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow));
    }
}
