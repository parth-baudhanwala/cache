﻿using AutoMapper;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicantEligibilityStatusProfile : Profile
{
    public ApplicantEligibilityStatusProfile()
    {
        CreateMap<ApplicantEligibilityStatusEntity, BaseEntity>().ReverseMap();

        CreateMap<ApplicantEligibilityStatusEntity, ApplicantEligibilityStatus>().ReverseMap();
    }
}
