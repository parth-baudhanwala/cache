﻿using AutoMapper;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class ContactMethodProfile : Profile
{
    public ContactMethodProfile()
    {
        CreateMap<ContactMethodEntity, ContactMethod>().ReverseMap();
    }
}
