﻿using AutoMapper;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicationWorkflowStatusBadgeColorProfile : Profile
{
    public ApplicationWorkflowStatusBadgeColorProfile()
    {
        CreateMap<ApplicationWorkflowStatusBadgeColorEntity, ApplicationWorkflowStatusBadgeColor>()
            .ForMember(x => x.IsActive, ops => ops.MapFrom(x => true))
            .ReverseMap();
    }
}
