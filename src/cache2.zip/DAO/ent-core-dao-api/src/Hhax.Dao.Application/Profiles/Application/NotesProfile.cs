﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Requests.Notes;
using Hhax.Dao.Application.Commands.Notes;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class NotesProfile : Profile
{
    public NotesProfile()
    {
        CreateMap<AddApplicantNoteRequest, AddApplicantNoteCommand>();
    }
}
