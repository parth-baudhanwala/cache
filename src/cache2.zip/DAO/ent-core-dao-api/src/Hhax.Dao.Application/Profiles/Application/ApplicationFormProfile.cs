﻿using AutoMapper;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Commands.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicationFormProfile : Profile
{
    public ApplicationFormProfile()
    {
        CreateMap<ApplicationFormApplicantRequirement, Domain.Common.BaseEntity>()
            .ReverseMap();

        CreateMap<ApplicationFormEntity, ApplicationFormEntity>();

        CreateMap<ApplicationFormEntity, ApplicationForm>()
            .ForMember(x => x.OfficeIds, opt => opt.MapFrom(x => x.ApplicationFormOfficeMappings != null ? x.ApplicationFormOfficeMappings.Select(x => x.OfficeId).ToArray() : Array.Empty<int>()));

        CreateMap<ApplicationForm, ApplicationFormEntity>()
            .ForMember(x => x.ApplicationFormApplicantRequirements, opt => opt.MapFrom(x => x.ApplicationFormApplicantRequirements!.Select(f => new ApplicationFormApplicantRequirementEntity {
                ApplicantFieldId = f.ApplicantFieldId,
                ApplicantSectionId = f.ApplicantSectionId,
                IsRequire = f.IsRequire,
                IsShow = f.IsShow, 
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            }).ToArray()))
            .ForMember(x => x.ApplicationFormOfficeMappings, opt => opt.MapFrom(x => x.OfficeIds!.Select(officeId => new ApplicationFormOfficeMappingEntity {
                OfficeId = officeId,
                Created = DateTime.UtcNow,
                Updated = DateTime.UtcNow
            }).ToArray()));

        CreateMap<ApplicationForm, ApplicationFormInfo>();

        CreateMap<ApplicationFormEntity, ApplicationFormInfo>()
            .ForMember(x => x.OfficeIds, opt => opt.MapFrom(x => x.ApplicationFormOfficeMappings != null ? x.ApplicationFormOfficeMappings.Select(x => x.OfficeId).ToArray() : Array.Empty<int>()));

        CreateMap<ApplicationFormRequest, AddApplicationFormCommand>()
            .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ReverseMap();

        CreateMap<ApplicationFormRequest, UpdateApplicationFormCommand>()
            .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ReverseMap();

        CreateMap<AddApplicationFormCommand, ApplicationForm>()
            .ForMember(x => x.UniqueUrlId, opt => opt.MapFrom(x => Guid.NewGuid()))
            .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ReverseMap();

        CreateMap<UpdateApplicationFormCommand, ApplicationForm>()
            .ForMember(x => x.Created, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ForMember(x => x.Updated, opt => opt.MapFrom(x => DateTime.UtcNow))
            .ReverseMap();

        CreateMap<ApplicationFormEntity, BaseResponse>();
    }
}
