﻿using AutoMapper;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Application;

namespace Hhax.Dao.Application.Profiles.Application;

public class ApplicationFormApplicantFieldProfile : Profile
{
    public ApplicationFormApplicantFieldProfile()
    {
        CreateMap<ApplicationFormApplicantFieldEntity, ApplicationFormApplicantField>().ReverseMap();
        CreateMap<ApplicationFieldTypeEntity, ApplicationFieldType>().ReverseMap();
        CreateMap<ApplicationFormCustomFieldEntity, ApplicationFormCustomFieldInfo>().ReverseMap();
        CreateMap<ApplicationCustomFieldValueMappingEntity, ApplicationCustomFieldValueMappingInfo>().ReverseMap();
    }
}
