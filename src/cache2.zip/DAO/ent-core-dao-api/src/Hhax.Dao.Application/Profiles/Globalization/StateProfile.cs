﻿using AutoMapper;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Globalization;

namespace Hhax.Dao.Application.Profiles.Globalization;

public class StateProfile : Profile
{
    public StateProfile()
        => CreateMap<StateEntity, State>().ReverseMap();
}
