﻿using AutoMapper;
using Hhax.Dao.Domain.Globalization;
using Hhax.Dao.Infrastructure.Abstracts.Entities.Caregiver;

namespace Hhax.Dao.Application.Profiles.Globalization;

public class GenderProfile : Profile
{
    public GenderProfile()
       => CreateMap<CaregiverGenderEntity, Gender>().ReverseMap();
}
