﻿using Hhax.Dao.Application.Utilities;
using System.Linq.Expressions;

namespace Hhax.Dao.Application.Extensions;

public static class ExpressionsExtensions
{
    public static string GenerateCacheKeyPart<T>(this Expression<Func<T, bool>> expression)
    {
        if (expression is null)
            return string.Empty;

        ParameterlessExpressionSearcherUtility searcher = new();
        searcher.Visit(expression);
        return new ParameterlessExpressionEvaluatorUtility(searcher.ParameterlessExpressions).Visit(expression).ToString();
    }
}
