﻿using Hhax.Dao.Application.Abstracts.Caregiver;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Domain.Availability;

namespace Hhax.Dao.Application.Extensions;

internal static class AvailabilityExtensions
{
    public static int GetMaxVisitsInDay(this IEnumerable<AvailabilityDay>? days, DayType type)
        => days?.FirstOrDefault(x => x.DayType == (byte)type)?.MaxVisits ?? 0;

    public static List<PermanentWeek> ConvertToPermanentWeekFields(this List<AvailabilityDay>? days)
    {
        if (days == null || !days.Any()) return new();

        int maxSize = 0;

        foreach (var day in days)
        {
            if (day.Id > 0)
            {
                maxSize = Math.Max(maxSize, day.TimeShifts.Count);
            }
        }

        if (maxSize == 0) return new();

        PermanentWeek[] permanentWeeks = new PermanentWeek[maxSize];

        foreach (var day in days)
        {
            for (int j = 0; j < day.TimeShifts.Count; j++)
            {
                if (day.TimeShifts[j].Id <= 0) continue;
                if (permanentWeeks[j] == null) permanentWeeks[j] = new();
                switch ((DayType)day.DayType)
                {
                    case DayType.Sunday:
                        permanentWeeks[j].SundayLiveIn = day.TimeShifts[j].IsLiveIn ?? false;
                        permanentWeeks[j].SundayFrom = day.TimeShifts[j].From?.Replace(":", "");
                        permanentWeeks[j].SundayTo = day.TimeShifts[j].To?.Replace(":", "");
                        permanentWeeks[j].SundayAvailabilityType = day.TimeShifts[j].GetAvailabilityType();
                        break;
                    case DayType.Monday:
                        permanentWeeks[j].MondayLiveIn = day.TimeShifts[j].IsLiveIn ?? false;
                        permanentWeeks[j].MondayFrom = day.TimeShifts[j].From?.Replace(":", "");
                        permanentWeeks[j].MondayTo = day.TimeShifts[j].To?.Replace(":", "");
                        permanentWeeks[j].MondayAvailabilityType = day.TimeShifts[j].GetAvailabilityType();
                        break;
                    case DayType.Tuesday:
                        permanentWeeks[j].TuesdayLiveIn = day.TimeShifts[j].IsLiveIn ?? false;
                        permanentWeeks[j].TuesdayFrom = day.TimeShifts[j].From?.Replace(":", "");
                        permanentWeeks[j].TuesdayTo = day.TimeShifts[j].To?.Replace(":", "");
                        permanentWeeks[j].TuesdayAvailabilityType = day.TimeShifts[j].GetAvailabilityType();
                        break;
                    case DayType.Wednesday:
                        permanentWeeks[j].WednesdayLiveIn = day.TimeShifts[j].IsLiveIn ?? false;
                        permanentWeeks[j].WednesdayFrom = day.TimeShifts[j].From?.Replace(":", "");
                        permanentWeeks[j].WednesdayTo = day.TimeShifts[j].To?.Replace(":", "");
                        permanentWeeks[j].WednesdayAvailabilityType = day.TimeShifts[j].GetAvailabilityType();
                        break;
                    case DayType.Thursday:
                        permanentWeeks[j].ThursdayLiveIn = day.TimeShifts[j].IsLiveIn ?? false;
                        permanentWeeks[j].ThursdayFrom = day.TimeShifts[j].From?.Replace(":", "");
                        permanentWeeks[j].ThursdayTo = day.TimeShifts[j].To?.Replace(":", "");
                        permanentWeeks[j].ThursdayAvailabilityType = day.TimeShifts[j].GetAvailabilityType();
                        break;
                    case DayType.Friday:
                        permanentWeeks[j].FridayLiveIn = day.TimeShifts[j].IsLiveIn ?? false;
                        permanentWeeks[j].FridayFrom = day.TimeShifts[j].From?.Replace(":", "");
                        permanentWeeks[j].FridayTo = day.TimeShifts[j].To?.Replace(":", "");
                        permanentWeeks[j].FridayAvailabilityType = day.TimeShifts[j].GetAvailabilityType();
                        break;
                    case DayType.Saturday:
                        permanentWeeks[j].SaturdayLiveIn = day.TimeShifts[j].IsLiveIn ?? false;
                        permanentWeeks[j].SaturdayFrom = day.TimeShifts[j].From?.Replace(":", "");
                        permanentWeeks[j].SaturdayTo = day.TimeShifts[j].To?.Replace(":", "");
                        permanentWeeks[j].SaturdayAvailabilityType = day.TimeShifts[j].GetAvailabilityType();
                        break;
                    case DayType.Unknown:
                    default:
                        continue;
                }
            }
        }

        return permanentWeeks.ToList();
    }

    public static string? GetAvailabilityType(this AvailabilityTimeShift shift)
    {
        return shift.PreferenceId switch
        {
            1 => AvailabilityType.Preferred.ToString(),
            2 => AvailabilityType.MightWork.ToString(),
            _ => null,
        };
    }
}
