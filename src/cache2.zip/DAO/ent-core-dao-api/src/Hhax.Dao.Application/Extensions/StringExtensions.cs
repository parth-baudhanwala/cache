﻿using Hhax.Dao.Application.Utilities;
using System.Linq.Expressions;

namespace Hhax.Dao.Application.Extensions;

public static class StringExtension
{
    public static IEnumerable<int>? ParseInts(this string? value, char separator = ',')
    {
        if (!string.IsNullOrWhiteSpace(value))
        {
            List<int>? result = new List<int>();
            foreach (var segment in value.Split(separator))
            {
                if (int.TryParse(segment, out int integer))
                    result.Add(integer);
            }
            return result;
        }
        else
            return null;
    }
}
