﻿using Hhax.Dao.Application.Abstracts.Caregiver;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Domain.Application;

namespace Hhax.Dao.Application.Extensions;

internal static class InserviceExtensions
{
    public static IEnumerable<Inservice> ConvertToInserviceFields(this IEnumerable<ApplicantInServiceTableItem> values)
    {
        if (values.Any())
        {
            foreach (var value in values)
            {
                if (value.Id <= 0) continue;
                yield return new Inservice
                {
                    AllowForInserviceOverlap = false,
                    BypassAbsenceOverlapWarnings = true,
                    InserviceId = -1,
                    CompanyType = "V",
                    DisciplineId = value.DisciplineId ?? 0,
                    EndTime = value.EndTime.Replace(":", ""),
                    FromTime = value.StartTime.Replace(":", ""),
                    InserviceDate = value.Date,
                    Instructor = value.InstructorId ?? 0,
                    MaxAttendees = -1,
                    NoShow = value.ReasonId > 0,
                    NoShowReason = value.ReasonId ?? 0,
                    PayRateId = value.PaycodeId ?? 0,
                    ScheduledOrConfirmed = value.Status?.Equals(InServiceStatus.Completed.ToString()) ?? false,
                    TopicIds = value.TopicIds?.ToList(),
                    ValidateAbsentOverlapping = false
                };
            }
        }
    }
}
