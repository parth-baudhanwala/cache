﻿using Hhax.Dao.Application.Abstracts.Caregiver;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Domain.Application;
using System.Text.RegularExpressions;

namespace Hhax.Dao.Application.Extensions;

internal static class CaregiverProfileExtensions
{
    public static CaregiverProfile ConvertToCaregiverProfileModel(this Applicant applicant)
    {
        return new CaregiverProfile
        {
            FirstName = applicant.FirstName,
            LastName = applicant.LastName,
            MiddleName = applicant.MiddleName,
            DateOfBirth = string.IsNullOrEmpty(applicant.DateOfBirth) ? null : Convert.ToDateTime(applicant.DateOfBirth),
            CountryOfBirth = applicant.CountryOfBirth,
            MaritalStatus = applicant.MaritalStatusId ?? 0,
            ReferralPerson = applicant.ReferralPerson,
            Offices = new() { new() { OfficeId = applicant.OfficeId, IsPrimary = true } },
            HireDate = DateTime.Today,
            Address = new()
            {
                Line1 = applicant.PrimaryStreet,
                Line2 = applicant.SecondaryStreet,
                City = applicant.City,
                State = applicant.State,
                Phone1 = ConvertPhone(applicant.PrimaryPhone),
                Phone2 = ConvertPhone(applicant.AdditionalPhone1),
                Phone3 = ConvertPhone(applicant.AdditionalPhone2),
                ZipCode = applicant.GetZipCode(),
                Zip4 = applicant.GetZip4()
            },
            EmergencyContacts = applicant.GetEmergencyContacts(),
            NotificationPreference = applicant.GetNotificationPreference(),
            SpecialPreference = applicant.GetSpecialPreference(),
            ApplicationDate = applicant.Created,
            CaregiverType = (int)CaregiverType.Employee,
            CaregiverStatus = ActiveStatus(),
            Ssn = applicant.SocialSecurityNumber,
            EthnicityId = applicant.Ethnicity ?? 0,
            NpiNumber = applicant.NationalProviderIdentity,
            ProfLicenseNumber = applicant.ProfessionalLicenseNumber,
            StateRegistry = new()
            {
                Number = applicant.RegistryNumber,
                Date = applicant.RegistryDate
            }
        };
    }

    private static int GetZipCode(this Applicant applicant)
    {
        if (!string.IsNullOrWhiteSpace(applicant.Zip))
        {
            _ = int.TryParse(applicant.Zip[..5], out int zip);
            return zip;
        }

        return 0;
    }

    private static int GetZip4(this Applicant applicant)
    {
        if (!string.IsNullOrWhiteSpace(applicant.Zip) && applicant.Zip.Length > 5)
        {
            _ = int.TryParse(applicant.Zip.AsSpan(4, 4), out int zip);
            return zip;
        }

        return 0;
    }

    private static List<EmergencyContact> GetEmergencyContacts(this Applicant applicant)
    {
        List<EmergencyContact> contacts = new();

        if (!string.IsNullOrWhiteSpace(applicant.FirstEmergencyContactAddress) ||
           !string.IsNullOrWhiteSpace(applicant.FirstEmergencyContactName) ||
           !string.IsNullOrWhiteSpace(applicant.FirstEmergencyContactPhone1) ||
           !string.IsNullOrWhiteSpace(applicant.FirstEmergencyContactPhone2) ||
           applicant.FirstEmergencyContactRelationshipId.HasValue)
            contacts.Add(new()
            {
                Address = applicant.FirstEmergencyContactAddress,
                Name = applicant.FirstEmergencyContactName,
                Phone1 = ConvertPhone(applicant.FirstEmergencyContactPhone1),
                Phone2 = ConvertPhone(applicant.FirstEmergencyContactPhone2),
                RelationshipId = applicant.FirstEmergencyContactRelationshipId ?? 0
            });

        if (!string.IsNullOrWhiteSpace(applicant.SecondEmergencyContactAddress) ||
           !string.IsNullOrWhiteSpace(applicant.SecondEmergencyContactName) ||
           !string.IsNullOrWhiteSpace(applicant.SecondEmergencyContactPhone1) ||
           !string.IsNullOrWhiteSpace(applicant.SecondEmergencyContactPhone2) ||
           applicant.SecondEmergencyContactRelationshipId.HasValue)
            contacts.Add(new()
            {
                Address = applicant.SecondEmergencyContactAddress,
                Name = applicant.SecondEmergencyContactName,
                Phone1 = ConvertPhone(applicant.SecondEmergencyContactPhone1),
                Phone2 = ConvertPhone(applicant.SecondEmergencyContactPhone2),
                RelationshipId = applicant.SecondEmergencyContactRelationshipId ?? 0
            });

        return contacts;
    }

    private static NotificationPreference GetNotificationPreference(this Applicant applicant)
    {
        return new NotificationPreference
        {
            ContactMethod = applicant.PreferredContactMethod ?? 0,
            Email = applicant.ContactEmail ?? applicant.LoginEmail,
            TextMessageNumber = ConvertPhone(applicant.TextMessagePhone)
        };
    }

    private static SpecialPreference GetSpecialPreference(this Applicant applicant)
    {
        return new SpecialPreference
        {
            LanguageId1 = applicant.PrimaryLanguageId ?? -1,
            LanguageId2 = applicant.SecondaryLanguageId ?? -1,
            LanguageId3 = applicant.ThirdLanguageId ?? -1,
            LanguageId4 = applicant.FourthLanguageId ?? -1
        };
    }

    private static string ConvertPhone(string? phone)
    {
        return string.IsNullOrWhiteSpace(phone) ? string.Empty :
                                                  Regex.Replace(phone, "\\D+([0-9]{3})\\D+([0-9]{3})\\D+([0-9]{4})", @"$1-$2-$3");
    }

    private static CaregiverStatus ActiveStatus()
        => new() { Status = 1, ChangeDate = DateTime.Today.ToString("yyyy-MM-dd") };
}
