﻿using Hhax.Dao.Application.Abstracts.Caregiver;
using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Domain.Compliance;

namespace Hhax.Dao.Application.Extensions;

internal static class ComplianceExtensions
{
    public static Abstracts.Caregiver.ComplianceInfo? ConvertToComplianceI9Fields(this ComplianceI9Requirement value)
    {
        if (value != null)
        {
            return new Abstracts.Caregiver.ComplianceInfo()
            {
                HireDate = DateTime.Today,
                Document = value.ColumnABDocumentId ?? -1,
                Document1 = value.ColumnCDocumentId ?? -1,
                I9ColumnCDocumentFilePath = value.ColumnCDocumentFileKey,
                I9DocumentFilePath = value.ColumnABDocumentFileKey,
                I9EVerifyNumber = value.EVerifyNumber,
                I9Verified = value.IsVerified,
                NotesFilePath = value.EverifyDocumentFileKey,
                I9FormExpirationDate = value.ExpirationDate
            };
        }

        return null;
    }

    public static IEnumerable<CaregiverComplianceCustomField>? ConvertToCustomFields(this IEnumerable<ComplianceCustomFieldApplicantValue> values)
    {
        if (values.Any())
            foreach (var value in values)
                yield return new CaregiverComplianceCustomField
                {
                    CaregiverComplianceCustomFieldId = -1,
                    ComplianceFieldId = value.CmpFieldId,
                    CustomFieldLabel = value.CustomFieldLabel,
                    CustomFieldValue = GetFieldValue((ComplianceCustomFieldType)value.ComplianceFieldType, value.Value),
                    DisplayOrder = value.DisplayOrder ?? 0,
                    Status = ActiveStatus.Active.ToString(),
                    CustomFieldType = GetFieldType((ComplianceCustomFieldType)value.ComplianceFieldType),
                    Required = Answer.No.ToString(),
                    CustomFieldName = value.CustomFieldName
                };
    }

    public static IEnumerable<CaregiverComplianceCustomFieldValue>? ConvertToCustomFieldValues(this IEnumerable<ComplianceCustomFieldApplicantValue> values)
    {
        var customFieldValues = values.Where(x => (x.Options?.Any() ?? false) && (!string.IsNullOrWhiteSpace(x.Value)));

        foreach (var value in customFieldValues)
        {
            var selectedValues = value.Value!.Split(",");
            var options = value.Options!.Where(x => selectedValues.Contains(x.OptionValue));
            foreach (var option in options)
            {
                yield return new CaregiverComplianceCustomFieldValue
                {
                    CaregiverComplianceCustomFieldValueId = -1,
                    CaregiverComplianceCustomFieldId = -1,
                    ComplianceCustomFieldValueId = option.OptionId,
                    ComplianceFieldId = value.CmpFieldId,
                    CustomFieldName = value.CustomFieldName,
                    OptionText = option.OptionText,
                    OptionValue = option.OptionValue
                };
            }
        }
    }

    private static string GetFieldType(ComplianceCustomFieldType fieldType) => fieldType switch
    {
        ComplianceCustomFieldType.DatePicker => "Date Picker",
        ComplianceCustomFieldType.DropdownSingleSelect => "Single Select - Dropdown",
        ComplianceCustomFieldType.DropdownMultiSelect => "Multi Select - Dropdown",
        ComplianceCustomFieldType.TextMultiLine => "Free Text - Multi-Line",
        ComplianceCustomFieldType.Checkbox => "Checkbox",
        _ => "Free Text - Single Line"
    };

    private static string GetFieldValue(ComplianceCustomFieldType fieldType, string? fieldValue)
    {
        if (string.IsNullOrEmpty(fieldValue)) return string.Empty;

        if (fieldType == ComplianceCustomFieldType.Checkbox)
        {
            return fieldValue.Replace(fieldValue[0].ToString(), fieldValue[0].ToString().ToUpper());
        }

        return fieldValue;
    }
}
