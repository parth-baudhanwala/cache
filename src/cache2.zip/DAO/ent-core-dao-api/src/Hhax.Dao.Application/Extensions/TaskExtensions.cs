﻿namespace Hhax.Dao.Application.Extensions;

internal static class TaskExtensions
{
    public static async Task<T?> NonNullable<T>(this Task<T>? task)
    {
        return task != null ? await task : default;
    }

    public static T WaitWithResult<T>(this Task<T> task)
    {
        task.Wait();
        return task.Result;
    }
}
