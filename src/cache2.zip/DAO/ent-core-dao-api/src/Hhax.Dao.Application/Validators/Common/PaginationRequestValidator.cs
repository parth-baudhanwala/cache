﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Common;

namespace Hhax.Dao.Application.Validators.Common;

public class PaginationRequestValidator : AbstractValidator<BasePaginationRequest>
{
    public PaginationRequestValidator()
    {
        RuleFor(x => x.Page!.PageNumber).GreaterThanOrEqualTo(0)
                                        .WithMessage(x => "Page number cannot be less than zero.");

        RuleFor(x => x.Page!.PageSize).GreaterThan(0)
                                      .WithMessage(x => "Page size must be greater than zero.");
    }
}
