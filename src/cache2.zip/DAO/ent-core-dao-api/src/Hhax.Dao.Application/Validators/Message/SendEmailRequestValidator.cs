﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Message;

namespace Hhax.Dao.Application.Validators.Message
{
    public class SendEmailRequestValidator : AbstractValidator<SendEmailRequest>
    {
        public SendEmailRequestValidator()
        {
            RuleFor(x => x.Message)
                .NotNull()
                .NotEmpty()
                .MaximumLength(1000)
                .WithMessage(x => $"{nameof(x.Message)} must not exceed 1000 characters.");

            RuleFor(x => x.Subject)
                .NotNull()
                .NotEmpty()
                .MaximumLength(50)
                .WithMessage(x => $"{nameof(x.Subject)} must not exceed 50 characters.");

            RuleFor(x => x.EmailRecipients)
                .NotNull()
                .NotEmpty()
                .WithMessage(x => "Please, select at least one recipient.");
        }
    }
}
