﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Application;

namespace Hhax.Dao.Application.Validators.Application;

public class ApplicationWorkflowStatusRequestValidator : AbstractValidator<ApplicationWorkflowStatusRequest>
{
    public ApplicationWorkflowStatusRequestValidator()
    {
        RuleFor(x => x.Name)
            .NotNull()
            .NotEmpty()
            .MaximumLength(100)
            .WithMessage(x => $"{x.Name} is required.");

        RuleFor(x => x.Description)
            .MaximumLength(250)
            .WithMessage(x => $"{nameof(x.Description)} must not exceed 250 characters.");
    }
}
