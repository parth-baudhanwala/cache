﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Requests.Application;

namespace Hhax.Dao.Application.Validators.Application;

public class ApplicantEmailResentRequestValidator : AbstractValidator<ApplicantEmailResentRequest>
{
    public ApplicantEmailResentRequestValidator()
    {
        RuleFor(x => x.Name).NotEmpty()
                                 .NotNull()
                                 .WithMessage(x => $"{nameof(x.Name)} is required.");

        RuleFor(x => x.Email).NotEmpty()
                             .NotNull()
                             .Matches(Constants.EmailPattern)
                             .When(x => !string.IsNullOrWhiteSpace(x.Email))
                             .WithMessage(x => $"{nameof(x.Email)} is in incorrect format.");

        RuleFor(x => x.Domain).NotEmpty()
                                 .NotNull()
                                 .WithMessage(x => $"{nameof(x.Domain)} is required.");
    }
}