﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Application;

namespace Hhax.Dao.Application.Validators.Application;

public class ApplicationFormRequestValidator : AbstractValidator<ApplicationFormRequest>
{
    public ApplicationFormRequestValidator()
    {
        RuleFor(x => x.Name)
            .NotNull()
            .NotEmpty()
            .MaximumLength(100)
            .WithMessage(x => $"{x.Name} is required.");
    }
}
