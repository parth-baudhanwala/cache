﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Requests.Application;

namespace Hhax.Dao.Application.Validators.Application;

public class ApplicantRequestValidator<T> : AbstractValidator<T> where T : ApplicantRequestBase
{
    // US number with format [+99 (999) 999-9999]: ^(\+\d{1,2}\s)\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$
    // US number with format [(999) 999-9999]
    const string phonePattern = @"^\(\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$";
    const string zipPattern = @"^(\d{9}|\d{5})$";

    public ApplicantRequestValidator()
    {
        //office id
        RuleFor(x => x.OfficeId).GreaterThan(0)
                                .WithMessage(x => $"{nameof(x.OfficeId)} is required.");

        //names
        RuleFor(x => x.FirstName).NotEmpty()
                                 .NotNull()
                                 .Must(x => x?.Length <= 50)
                                 .WithMessage(x => $"{nameof(x.FirstName)} is required.");

        RuleFor(x => x.LastName).NotEmpty()
                                .NotNull()
                                .Must(x => x?.Length <= 50)
                                .WithMessage(x => $"{nameof(x.LastName)} is required.");

        RuleFor(x => x.MiddleName).Must(x => x?.Length <= 50)
                                  .When(x => !string.IsNullOrWhiteSpace(x.MiddleName))
                                  .WithMessage(x => $"Max lenght for {nameof(x.LastName)} is 50 chars.");

        RuleFor(x => x.DateOfBirth).Must(x => x < DateTime.Now)
                                   .When(x => x.DateOfBirth.HasValue)
                                   .WithMessage(x => $"{nameof(x.DateOfBirth)} cannot be in the future");

        //emergency contacts
        RuleFor(x => x.FirstEmergencyContactName).Must(x => x?.Length <= 200)
                                                 .When(x => !string.IsNullOrWhiteSpace(x.FirstEmergencyContactName))
                                                 .WithMessage(x => $"Max lenght for {nameof(x.FirstEmergencyContactName)} is 50 chars.");

        RuleFor(x => x.FirstEmergencyContactAddress).NotEmpty()
                                                    .NotNull()
                                                    .Must(x => x?.Length <= 100)
                                                    .When(x => !string.IsNullOrWhiteSpace(x.FirstEmergencyContactAddress))
                                                    .WithMessage(x => $"{nameof(x.FirstEmergencyContactAddress)} is required.");

        RuleFor(x => x.ContactEmail).Matches(Constants.EmailPattern)
                             .When(x => !string.IsNullOrWhiteSpace(x.ContactEmail))
                             .WithMessage(x => $"{nameof(x.ContactEmail)} is in incorrect format.");

        RuleFor(x => x.PrimaryPhone).Must(x => x?.Length <= 14)
                                    .Matches(phonePattern)
                                    .When(x => !string.IsNullOrWhiteSpace(x.PrimaryPhone))
                                    .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.AdditionalPhone1).Must(x => x?.Length <= 14)
                                        .Matches(phonePattern)
                                        .When(x => !string.IsNullOrWhiteSpace(x.AdditionalPhone1))
                                        .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.AdditionalPhone2).Must(x => x?.Length <= 14)
                                        .Matches(phonePattern)
                                        .When(x => !string.IsNullOrWhiteSpace(x.AdditionalPhone2))
                                        .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.TextMessagePhone).Must(x => x?.Length <= 14)
                                        .Matches(phonePattern)
                                        .When(x => !string.IsNullOrWhiteSpace(x.TextMessagePhone))
                                        .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.FirstEmergencyContactPhone1).Must(x => x?.Length <= 14)
                                                   .Matches(phonePattern)
                                                   .When(x => !string.IsNullOrWhiteSpace(x.FirstEmergencyContactPhone1))
                                                   .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.FirstEmergencyContactPhone2).Must(x => x?.Length <= 14)
                                                   .Matches(phonePattern)
                                                   .When(x => !string.IsNullOrWhiteSpace(x.FirstEmergencyContactPhone2))
                                                   .WithMessage("US phone number should be in (999) 999-9999 format");


        RuleFor(x => x.SecondEmergencyContactName).Must(x => x?.Length <= 200)
                                                  .When(x => !string.IsNullOrWhiteSpace(x.SecondEmergencyContactName))
                                                  .WithMessage(x => $"Max lenght for {nameof(x.SecondEmergencyContactName)} is 200 chars.");

        RuleFor(x => x.SecondEmergencyContactAddress).NotEmpty()
                                                     .NotNull()
                                                     .Must(x => x?.Length <= 100)
                                                     .When(x => !string.IsNullOrWhiteSpace(x.SecondEmergencyContactAddress))
                                                     .WithMessage(x => $"{nameof(x.SecondEmergencyContactAddress)} is required.");

        RuleFor(x => x.SecondEmergencyContactPhone1).Must(x => x?.Length <= 14)
                                                    .Matches(phonePattern)
                                                    .When(x => !string.IsNullOrWhiteSpace(x.SecondEmergencyContactPhone1))
                                                    .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.SecondEmergencyContactPhone2).Must(x => x?.Length <= 14)
                                                    .Matches(phonePattern)
                                                    .When(x => !string.IsNullOrWhiteSpace(x.SecondEmergencyContactPhone2))
                                                    .WithMessage("US phone number should be in (999) 999-9999 format");

        //languages
        RuleFor(x => x.PrimaryLanguageId).Must((s, e) => e != s.SecondaryLanguageId)
                                         .When(x => x.SecondaryLanguageId.HasValue)
                                         .WithMessage("Same value selected for the secondary language");

        RuleFor(x => x.PrimaryLanguageId).Must((s, e) => e != s.ThirdLanguageId)
                                         .When(x => x.ThirdLanguageId.HasValue)
                                         .WithMessage("Same value selected for the third language");

        RuleFor(x => x.PrimaryLanguageId).Must((s, e) => e != s.FourthLanguageId)
                                         .When(x => x.FourthLanguageId.HasValue)
                                         .WithMessage("Same value selected for the fourth language");

        RuleFor(x => x.SecondaryLanguageId).Must((s, e) => e != s.PrimaryLanguageId)
                                           .When(x => x.PrimaryLanguageId.HasValue)
                                           .WithMessage("Same value selected for the primary language");

        RuleFor(x => x.SecondaryLanguageId).Must((s, e) => e != s.ThirdLanguageId)
                                           .When(x => x.ThirdLanguageId.HasValue)
                                           .WithMessage("Same value selected for the third language");

        RuleFor(x => x.SecondaryLanguageId).Must((s, e) => e != s.FourthLanguageId)
                                           .When(x => x.FourthLanguageId.HasValue)
                                           .WithMessage("Same value selected for the fourth language");

        RuleFor(x => x.ThirdLanguageId).Must((s, e) => e != s.PrimaryLanguageId)
                                       .When(x => x.PrimaryLanguageId.HasValue)
                                       .WithMessage("Same value selected for the primary language");

        RuleFor(x => x.ThirdLanguageId).Must((s, e) => e != s.SecondaryLanguageId)
                                       .When(x => x.SecondaryLanguageId.HasValue)
                                       .WithMessage("Same value selected for the secondary language");

        RuleFor(x => x.ThirdLanguageId).Must((s, e) => e != s.FourthLanguageId)
                                       .When(x => x.FourthLanguageId.HasValue)
                                       .WithMessage("Same value selected for the fourth language");

        RuleFor(x => x.FourthLanguageId).Must((s, e) => e != s.PrimaryLanguageId)
                                        .When(x => x.PrimaryLanguageId.HasValue)
                                        .WithMessage("Same value selected for the primary language");

        RuleFor(x => x.FourthLanguageId).Must((s, e) => e != s.SecondaryLanguageId)
                                        .When(x => x.SecondaryLanguageId.HasValue)
                                        .WithMessage("Same value selected for the secondary language");

        RuleFor(x => x.FourthLanguageId).Must((s, e) => e != s.ThirdLanguageId)
                                        .When(x => x.ThirdLanguageId.HasValue)
                                        .WithMessage("Same value selected for the third language");

        //Notification preferences
        RuleFor(x => x.ContactEmail).NotEmpty()
                                    .NotNull()
                                    .When(x => x.PreferredContactMethod == 1)
                                    .WithMessage(x => $"{nameof(x.ContactEmail)} is required.");

        RuleFor(x => x.TextMessagePhone).NotEmpty()
                                        .NotNull()
                                        .Must(x => x?.Length <= 14)
                                        .Matches(phonePattern)
                                        .When(x => x.PreferredContactMethod == 2)
                                        .WithMessage(x => $"{nameof(x.TextMessagePhone)} is required.");

        //Address information
        RuleFor(x => x.PrimaryPhone).Must(x => x?.Length <= 14)
                                    .Matches(phonePattern)
                                    .When(x => !string.IsNullOrWhiteSpace(x.PrimaryPhone))
                                    .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.AdditionalPhone1).Must(x => x?.Length <= 14)
                                        .Matches(phonePattern)
                                        .When(x => !string.IsNullOrWhiteSpace(x.AdditionalPhone1))
                                        .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.AdditionalPhone2).Must(x => x?.Length <= 14)
                                        .Matches(phonePattern)
                                        .When(x => !string.IsNullOrWhiteSpace(x.AdditionalPhone2))
                                        .WithMessage("US phone number should be in (999) 999-9999 format");

        RuleFor(x => x.PrimaryStreet).Must(x => x?.Length <= 100)
                                     .When(x => !string.IsNullOrWhiteSpace(x.PrimaryStreet))
                                     .WithMessage(x => $"Max lenght for {nameof(x.PrimaryStreet)} is 100 chars.");

        RuleFor(x => x.SecondaryStreet).Must(x => x?.Length <= 100)
                                       .When(x => !string.IsNullOrWhiteSpace(x.SecondaryStreet))
                                       .WithMessage(x => $"Max lenght for {nameof(x.SecondaryStreet)} is 100 chars.");

        RuleFor(x => x.City).Must(x => x?.Length <= 100)
                            .When(x => !string.IsNullOrWhiteSpace(x.City))
                            .WithMessage(x => $"Max lenght for {nameof(x.City)} is 100 chars.");

        RuleFor(x => x.State).Must(x => x?.Length == 2)
                             .When(x => !string.IsNullOrWhiteSpace(x.State))
                             .WithMessage(x => $"Lenght for {nameof(x.State)} is 2 chars.");

        RuleFor(x => x.Zip).Matches(zipPattern)
                           .When(x => !string.IsNullOrWhiteSpace(x.Zip))
                           .WithMessage(x => $"{nameof(x.Zip)} should be 5 or 9 numbers.");
    }
}