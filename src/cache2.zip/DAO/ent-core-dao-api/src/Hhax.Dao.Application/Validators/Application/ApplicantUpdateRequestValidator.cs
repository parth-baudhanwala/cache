﻿using Hhax.Dao.Application.Abstracts.Requests.Application;

namespace Hhax.Dao.Application.Validators.Application
{
    public class ApplicantUpdateRequestValidator : ApplicantRequestValidator<ApplicantUpdateRequest>
    {
    }
}
