﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Infrastructure.Helpers;

namespace Hhax.Dao.Application.Validators.Application
{
    public class ApplicantAddRequestValidator : ApplicantRequestValidator<ApplicantAddRequest>
    {
        private readonly List<string> reservedWords = new() { "hhaexchange", "qwerty", "password" };

        public ApplicantAddRequestValidator()
        {
            RuleFor(x => x.LoginEmail).NotEmpty()
                                      .NotNull()
                                      .Must(x => x?.Length <= 50)
                                      .Matches(Constants.EmailPattern)
                                      .WithMessage("Email Address is invalid.");

            RuleFor(x => x.Password).NotEmpty()
                                    .NotNull()
                                    .Must(x => x?.Length >= 8 && x?.Length <= 64)
                                    .WithMessage(x => $"{nameof(x.Password)} should " +
                                    $"contain 8 - 64 characters in length.");

            RuleFor(x => x.Password).Must((s, e) => string.IsNullOrWhiteSpace(s.LoginEmail) || !e!.ToLower().Contains(s.LoginEmail.ToLower()))
                                    .WithMessage(x => $"{nameof(x.Password)} should " +
                                    $"not contain your email address.");

            RuleFor(x => x.Password).Must(x => !PasswordCheckHelper.CheckSequenceError(x!) &&
                                               !PasswordCheckHelper.CheckRepetitivesError(x!))
                                    .WithMessage(x => $"{nameof(x.Password)} should " +
                                    $"not contain more than 3 repeated or sequential characters.");

            RuleFor(x => x.Password).Must(x => !reservedWords.Any(r => x!.ToLower().Contains(r)))
                                    .WithMessage(x => $"{nameof(x.Password)} should " +
                                    $"not contain any of the following words: {string.Join(", ", reservedWords)}.");
        }
    }
}
