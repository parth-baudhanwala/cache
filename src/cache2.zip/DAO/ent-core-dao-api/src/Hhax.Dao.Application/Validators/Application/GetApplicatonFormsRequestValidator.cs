﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;

namespace Hhax.Dao.Application.Validators.Application;

public class GetApplicatonFormsRequestValidator : AbstractValidator<PaginationRequest<GetApplicationFormRequest>>
{
    public GetApplicatonFormsRequestValidator()
    {
        RuleFor(x => x.Page).NotNull()
                            .WithMessage(x => "Page must be provided");

        RuleFor(x => x.Page!.PageNumber).GreaterThanOrEqualTo(0)
                                        .When(x => x.Page != null)
                                        .WithMessage(x => "Page number cannot be less than zero.");

        RuleFor(x => x.Page!.PageSize).GreaterThan(0)
                                      .When(x => x.Page != null)
                                      .WithMessage(x => "Page size must be greater than zero.");
    }
}
