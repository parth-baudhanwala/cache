﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Globalization;

namespace Hhax.Dao.Application.Validators.Globalization;

public class SearchCitiesRequestValidator : AbstractValidator<SearchCitiesRequest>
{
    public SearchCitiesRequestValidator()
    {
        RuleFor(x => x.StateName).Must(x => x?.Length <= 2)
                             .When(x => !string.IsNullOrWhiteSpace(x.StateName))
                             .WithMessage("State Name is incorrect format. An example: 'NY'.");
    }
}
