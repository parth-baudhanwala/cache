﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Globalization;

namespace Hhax.Dao.Application.Validators.Globalization;

public class SearchCitiesByZipCodeRequestValidator : AbstractValidator<PaginationRequest<SearchCitiesByZipCodeRequest>>
{
    public SearchCitiesByZipCodeRequestValidator()
    {
        // US zipcode format [99999, 999999999, 99999-9999]: ^\d{5}-\d{4}|\d{4}|\d{5}|[A-Z]\d[A-Z] \d[A-Z]\d$
        const string zipPattern = @"^\d{5}-\d{4}|\d{4}|\d{5}|[A-Z]\d[A-Z] \d[A-Z]\d$";

        RuleFor(x => x.Filters!.ZipCode).Must(x => x?.Length <= 10)
                               .Matches(zipPattern)
                               .When(x => x.Filters != null && !string.IsNullOrWhiteSpace(x.Filters!.ZipCode))
                               .WithMessage("The US zip code must be in one of these formats 99999, 999999999, or 99999-9999");
    }
}
