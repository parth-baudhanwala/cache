﻿using FluentValidation;
using Microsoft.AspNetCore.Http;

namespace Hhax.Dao.Application.Validators.Office;

public class OfficeImageFileValidator : AbstractValidator<IFormFile>
{
    public OfficeImageFileValidator()
    {
        var allowedExtensions = new string[] { ".jpg", ".jpeg", ".png" };

        const int bytesInMegabyte = 1024 * 1024;
        const int maxFileSizeMB = 2;
        const int maxFileSizeB = bytesInMegabyte * maxFileSizeMB;

        RuleFor(x => x.FileName).NotEmpty().NotNull()
            .Must(x => allowedExtensions.Contains(Path.GetExtension(x).ToLower()))
            .WithMessage(x => $"The file type is not supported.");

        RuleFor(x => x.Length).NotEmpty().NotNull()
            .Must(x => x! < maxFileSizeB)
            .WithMessage(x => $"The maximum file size is {maxFileSizeMB} MB.");
    }
}
