﻿using Hhax.Dao.Application.Abstracts.Requests.Office;

namespace Hhax.Dao.Application.Validators.Office;

public class OfficeImageRequestValidator : OfficeImageValidator<OfficeImageRequest>
{
}
