﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Office;

namespace Hhax.Dao.Application.Validators.Office;

public abstract class OfficeImageValidator<T> : AbstractValidator<T> where T : OfficeImageRequest
{
    public OfficeImageValidator()
    {
        var allowedTypes = new string[] { "logo", "cover" };
        RuleFor(x => x.Type).NotEmpty()
                            .NotNull()
                            .Must(x => !string.IsNullOrWhiteSpace(x) && allowedTypes.Contains(x!.ToLower()))
                            .WithMessage(x => $"{nameof(x.Type)} incorrect.");
    }
}
