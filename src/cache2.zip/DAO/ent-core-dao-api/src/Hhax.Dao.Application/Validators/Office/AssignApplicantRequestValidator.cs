﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Application;

namespace Hhax.Dao.Infrastructure.Validators;

public class AssignApplicantRequestValidator : AbstractValidator<AssignApplicantRequest>
{
    public AssignApplicantRequestValidator()
    {
        RuleFor(x => x.NoteText)
            .MaximumLength(500)
            .WithMessage(x => $"{nameof(x.NoteText)} must not exceed 500 characters.");

    }
}
