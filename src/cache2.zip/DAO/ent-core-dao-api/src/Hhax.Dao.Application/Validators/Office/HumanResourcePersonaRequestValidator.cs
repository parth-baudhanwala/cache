﻿using FluentValidation;
using Hhax.Dao.Application.Abstracts.Requests.Office;

namespace Hhax.Dao.Application.Validators.Office;

public class HumanResourcePersonaRequestValidator : AbstractValidator<HumanResourcePersonaRequest>
{
    public HumanResourcePersonaRequestValidator()
    {
        RuleFor(x => x.Name)
            .NotNull()
            .NotEmpty()
            .MaximumLength(100)
            .WithMessage(x => $"{x.Name} is required.");

        RuleFor(x => x.StatusId)
            .NotNull()
            .WithMessage(x => $"{x.StatusId} is required.");

        RuleFor(x => x.UserId)
            .NotNull()
            .WithMessage(x => $"{x.UserId} is required.");
    }
}
