﻿using FluentValidation;
using Hhax.Dao.Application.Commands.InService;

namespace Hhax.Dao.Application.Validators.InService;

public class UpsertInServiceCommandValidator : AbstractValidator<UpsertInServiceCommand>
{
	public UpsertInServiceCommandValidator()
	{
		RuleFor(x => x.Date).NotNull().NotEmpty();
		RuleFor(x => x.StartTime).NotNull().NotEmpty();
		RuleFor(x => x.EndTime).NotNull().NotEmpty();
		RuleFor(x => x.TopicIds).NotNull().NotEmpty();
		RuleFor(x => x.InstructorId).NotNull().NotEmpty();
		RuleFor(x => x.DisciplineId).NotNull().NotEmpty();
		RuleFor(x => x.PaycodeId).NotNull().NotEmpty();
    }
}
