﻿using FluentValidation;
using Hhax.Dao.Domain.Compliance;

namespace Hhax.Dao.Application.Validators.Complinaces;

public class ComplianceTrainingSchoolValidator : AbstractValidator<ComplianceTrainingSchool>
{
    public ComplianceTrainingSchoolValidator()
    {
        RuleFor(x => x.SchoolId).Must(x => x.HasValue && x.Value > 0)
                                .WithMessage("The school id is required");
    }
}
