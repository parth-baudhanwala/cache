﻿using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Commands.Compliance;

public class UpsertApplicationBackgroundChecksCommand : IRequest<IEnumerable<int>>
{
    public UpsertApplicationBackgroundChecksCommand(int applicantId, IEnumerable<ComplianceBackgroundCheck> rows)
    {
        ApplicantId = applicantId;
        Rows = rows;
    }

    public int ApplicantId { get; }
    public IEnumerable<ComplianceBackgroundCheck> Rows { get; }
}
