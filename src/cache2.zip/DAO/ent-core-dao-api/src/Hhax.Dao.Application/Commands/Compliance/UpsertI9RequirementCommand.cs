﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Commands.Compliance;

public class UpsertI9RequirementCommand : IRequest<BaseResponse>
{
    public UpsertI9RequirementCommand(int applicantId, int? columnABDocumentId, int? columnCDocumentId, string? columnABDocumentFileKey,
                                      int? columnABDocumentFileSize, bool isColumnABDocumentFileDeleted, string? columnCDocumentFileKey,
                                      int? columnCDocumentFileSize, bool isColumnCDocumentFileDeleted, DateTime? expirationDate,
                                      string? eVerifyNumber, string? eVerifyDocumentFileKey, int? eVerifyDocumentFileSize, bool isEverifyDocumentFileDeleted, bool isVerified)
    {
        ApplicantId = applicantId;
        ColumnABDocumentId = columnABDocumentId;
        ColumnCDocumentId = columnCDocumentId;
        ColumnABDocumentFileKey = columnABDocumentFileKey;
        ColumnABDocumentFileSize = columnABDocumentFileSize;
        IsColumnABDocumentFileDeleted = isColumnABDocumentFileDeleted;
        ColumnCDocumentFileKey = columnCDocumentFileKey;
        ColumnCDocumentFileSize = columnCDocumentFileSize;
        IsColumnCDocumentFileDeleted = isColumnCDocumentFileDeleted;
        ExpirationDate = expirationDate;
        EVerifyNumber = eVerifyNumber;
        IsEverifyDocumentFileDeleted = isEverifyDocumentFileDeleted;
        EverifyDocumentFileKey = eVerifyDocumentFileKey;
        EverifyDocumentFileSize = eVerifyDocumentFileSize;
        IsVerified = isVerified;
    }

    public int ApplicantId { get; set; }
    public int? ColumnABDocumentId { get; set; }
    public int? ColumnCDocumentId { get; set; }
    public string? ColumnABDocumentFileKey { get; set; }
    public int? ColumnABDocumentFileSize { get; set; }
    public bool IsColumnABDocumentFileDeleted { get; set; }
    public string? ColumnCDocumentFileKey { get; set; }
    public int? ColumnCDocumentFileSize { get; set; }
    public bool IsColumnCDocumentFileDeleted { get; set; }
    public DateTime? ExpirationDate { get; set; }
    public string? EVerifyNumber { get; set; }
    public bool IsEverifyDocumentFileDeleted { get; set; }
    public string? EverifyDocumentFileKey { get; set; }
    public int? EverifyDocumentFileSize { get; set; }
    public bool IsVerified { get; set; }
    public Signature? Signature { get; set; }
}
