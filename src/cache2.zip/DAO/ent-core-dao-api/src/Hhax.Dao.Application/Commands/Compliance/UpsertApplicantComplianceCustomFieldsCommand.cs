﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Commands.Compliance;

public class UpsertApplicantComplianceCustomFieldsCommand : IRequest<BaseRangeResponse>
{
    public int ApplicantId { get; }
    public IEnumerable<ComplianceCustomFieldApplicantValue> Data { get; }
    public Signature? Signature { get; }

    public UpsertApplicantComplianceCustomFieldsCommand(int applicantId, IEnumerable<ComplianceCustomFieldApplicantValue> data, Signature? signature)
    {
        ApplicantId = applicantId;
        Data = data;
        Signature = signature;
    }
}
