﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Compliance;

public class DeleteApplicationComplianceTrainingSchoolCommand : IRequest<Unit>
{
    public DeleteApplicationComplianceTrainingSchoolCommand(int applicantId, int id)
    {
        Id = id;
        ApplicantId = applicantId;
    }

    public int Id { get; }
    public int ApplicantId { get; }
}
