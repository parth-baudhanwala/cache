﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Compliance;

public class DeleteApplicationBackgroundChecksCommand : IRequest<Unit>
{
    public DeleteApplicationBackgroundChecksCommand(int applicantId, IEnumerable<int> ids)
    {
        ApplicantId = applicantId;
        Ids = ids;
    }

    public int ApplicantId { get; }
    public IEnumerable<int> Ids { get; }
}
