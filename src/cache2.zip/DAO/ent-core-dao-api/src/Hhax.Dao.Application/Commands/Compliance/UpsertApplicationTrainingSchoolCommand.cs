﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Commands.Compliance;

public class UpsertApplicationTrainingSchoolCommand : BaseRequest, IRequest<BaseResponse>
{
    public UpsertApplicationTrainingSchoolCommand() : base() { }

    public UpsertApplicationTrainingSchoolCommand(int applicantId, string? certificateFileKey, int? certificateFileSize, bool isFileDeleted, DateTime? verificationDate,
                                                  DateTime? certificationDate, int? schoolId, int? disciplineId, string? instructorName, bool isVerified)
    {
        ApplicantId = applicantId;
        CertificateFileKey = certificateFileKey;
        CertificateFileSize = certificateFileSize;
        IsFileDeleted = isFileDeleted;
        VerificationDate = verificationDate;
        CertificationDate = certificationDate;
        SchoolId = schoolId;
        DisciplineId = disciplineId;
        InstructorName = instructorName;
        IsVerified = isVerified;
    }

    public int ApplicantId { get; set; }
    public string? CertificateFileKey { get; set; }
    public int? CertificateFileSize { get; set; }
    public bool IsFileDeleted { get; set; }
    public DateTime? VerificationDate { get; set; }
    public DateTime? CertificationDate { get; set; }
    public int? SchoolId { get; set; }
    public int? DisciplineId { get; set; }
    public string? InstructorName { get; set; }
    public bool IsVerified { get; set; }
    public Signature? Signature { get; set; }
}
