﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Availability;
using MediatR;

namespace Hhax.Dao.Application.Commands.Availability;

public class UpsertApplicantAvailabilityCommand : IRequest<BaseRangeResponse>
{
    public int ApplicantId { get; set; }
    public IEnumerable<AvailabilityDay> AvailabilityDays { get; set; }
    public Signature? Signature { get; set; }

    public UpsertApplicantAvailabilityCommand(int applicantId, IEnumerable<AvailabilityDay> availabilityDays, Signature? signature)
    {
        ApplicantId = applicantId;
        AvailabilityDays = availabilityDays;
        Signature = signature;
    }
}
