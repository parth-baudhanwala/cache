﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Availability;

public class DeleteApplicantAvailabilityCommand : IRequest<Unit>
{
    public int ApplicantId { get; set; }
    public IEnumerable<int> Ids { get; }

    public DeleteApplicantAvailabilityCommand(int applicantId, IEnumerable<int> ids)
    {
        Ids = ids;
        ApplicantId = applicantId;
    }
}
