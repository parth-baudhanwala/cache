﻿using Hhax.Dao.Domain.Notes;
using MediatR;

namespace Hhax.Dao.Application.Commands.Notes;

public class GetNoteSubjectsCommand : IRequest<IEnumerable<NoteSubject>> { }
