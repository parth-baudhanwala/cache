﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Notes;

public class AddApplicantNoteCommand : IRequest<BaseResponse>
{
    public int ApplicantId { get; set; }
    public string? Note { get; set; }
    public string? Status { get; set; }
}
