﻿using Hhax.Dao.Application.Abstracts.Responses.Caregiver;
using MediatR;

namespace Hhax.Dao.Application.Commands.Caregiver;

public class ConvertToCaregiverCommand : IRequest<CreateCaregiverResponse>
{
    public int ApplicantId { get; set; }

    public ConvertToCaregiverCommand(int applicantId)
    {
        ApplicantId = applicantId;
    }
}
