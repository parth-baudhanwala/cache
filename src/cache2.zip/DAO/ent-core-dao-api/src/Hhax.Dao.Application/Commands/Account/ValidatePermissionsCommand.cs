﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using MediatR;

namespace Hhax.Dao.Application.Commands.Account;

public class ValidatePermissionsCommand : IRequest<ValidatePermissionsResponse>
{
    public ValidatePermissionsCommand(HhaxPermissions[] permissions)
    {
        Permissions = permissions;
    }

    public HhaxPermissions[]? Permissions { get; }
}
