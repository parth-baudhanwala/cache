﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Responses.Permission;
using MediatR;

namespace Hhax.Dao.Application.Commands.Account;

public class ValidatePermissionsByIdsCommand : IRequest<ValidatePermissionsResponse>
{
    public ValidatePermissionsByIdsCommand(HhaxPermissions[] permissions)
    {
        Permissions = permissions;
    }

    public HhaxPermissions[]? Permissions { get; }
}
