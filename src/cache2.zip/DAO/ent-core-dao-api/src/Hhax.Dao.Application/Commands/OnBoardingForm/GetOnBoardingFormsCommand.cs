﻿using Hhax.Dao.Application.Abstracts.Responses.OnBoardingForm;
using MediatR;

namespace Hhax.Dao.Application.Commands.OnBoardingForm;

public class GetOnBoardingFormsCommand : IRequest<IEnumerable<OnBoardingFormResponse>>
{
    public GetOnBoardingFormsCommand(int statusId,
                                     int userId,
                                     string categoryName,
                                     string searchText,
                                     string environmentName,
                                     int pageNumber,
                                     int pageSize,
                                     string sortItem,
                                     string sortOrder)
    {
        StatusId = statusId;
        UserId = userId;
        CategoryName = categoryName;
        SearchText = searchText;
        EnvironmentName = environmentName;
        PageNumber = pageNumber;
        PageSize = pageSize;
        SortItem = sortItem;
        SortOrder = sortOrder;
    }

    public int StatusId { get; set; }
    public int UserId { get; set; }
    public string CategoryName { get; set; }
    public string SearchText { get; set; }
    public string EnvironmentName { get; set; }
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public string SortItem { get; set; }
    public string SortOrder { get; set; }
}

