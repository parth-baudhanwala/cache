﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Settings;

public class UploadAgencyLogoCommand : IRequest<string>
{
    public UploadAgencyLogoCommand(
        string type,
        string fileName,
        Stream stream,
        int width,
        int height)
    {
        Type = type;
        FileName = fileName;
        Stream = stream;
        Width = width;
        Height = height;
    }

    public int AgencyId { get; set; }
    public string Type { get; }
    public string FileName { get; }
    public Stream Stream { get; }
    public int Width { get; }
    public int Height { get; }
}
