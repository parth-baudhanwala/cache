﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Settings
{
    public class SaveAgencyLogoCommand : IRequest<BaseResponse>
    {
        public string? FileName { get; set; }
        public string? FileExtension { get; set; }
    }
}
