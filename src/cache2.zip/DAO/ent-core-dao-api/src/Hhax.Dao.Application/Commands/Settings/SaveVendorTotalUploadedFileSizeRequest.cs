﻿using Hhax.Dao.Application.Abstracts.Responses.Settings;
using MediatR;

namespace Hhax.Dao.Application.Commands.Settings
{
    public class SaveVendorTotalUploadedFileSizeRequest : IRequest<VendorTotalUploadedFileSizeResponse>
    {
        public int ApplicantId { get; set; }
        public long? TotalUploadedFileUsage { get; set; }
    }
}
