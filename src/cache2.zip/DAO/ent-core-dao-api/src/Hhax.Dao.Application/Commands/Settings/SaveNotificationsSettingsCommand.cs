﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Settings;

public class SaveNotificationsSettingsCommand : IRequest<BaseResponse> 
{
    public bool IsNotifyApplicantNotLogged { get; set; }
    public int NotifyApplicantNotLoggedDays { get; set; }
    public bool IsNotifyApplicantStatusChanges { get; set; }
    public bool IsNotifyApplicantRequiredInfoMissing { get; set; }
    public int NotifyApplicantRequiredInfoMissingDays { get; set; }
    public bool IsNotifyApplicantRequiredTrainingDue { get; set; }
    public int NotifyApplicantRequiredTrainingDueDays { get; set; }
    public bool IsRepeatNotifyApplicantRequiredTrainingDue { get; set; }
    public bool IsNotifyHRNotLogged { get; set; }
    public int NotifyHRNotLoggedDays { get; set; }
    public bool IsNotifyHRStatusNotChanged { get; set; }
    public int NotifyHRStatusNotChangedDays { get; set; }
    public bool IsNotifyHRStatusChanges { get; set; }

    public SaveNotificationsSettingsCommand(bool isNotifyApplicantNotLogged, 
                                            int notifyApplicantNotLoggedDays, 
                                            bool isNotifyApplicantStatusChanges, 
                                            bool isNotifyApplicantRequiredInfoMissing, 
                                            int notifyApplicantRequiredInfoMissingDays, 
                                            bool isNotifyApplicantRequiredTrainingDue, 
                                            int notifyApplicantRequiredTrainingDueDays, 
                                            bool isRepeatNotifyApplicantRequiredTrainingDue, 
                                            bool isNotifyHRNotLogged, 
                                            int notifyHRNotLoggedDays, 
                                            bool isNotifyHRStatusNotChanged, 
                                            int notifyHRStatusNotChangedDays, 
                                            bool isNotifyHRStatusChanges)
    {
        IsNotifyApplicantNotLogged = isNotifyApplicantNotLogged;
        NotifyApplicantNotLoggedDays = notifyApplicantNotLoggedDays;
        IsNotifyApplicantStatusChanges = isNotifyApplicantStatusChanges;
        IsNotifyApplicantRequiredInfoMissing = isNotifyApplicantRequiredInfoMissing;
        NotifyApplicantRequiredInfoMissingDays = notifyApplicantRequiredInfoMissingDays;
        IsNotifyApplicantRequiredTrainingDue = isNotifyApplicantRequiredTrainingDue;
        NotifyApplicantRequiredTrainingDueDays = notifyApplicantRequiredTrainingDueDays;
        IsRepeatNotifyApplicantRequiredTrainingDue = isRepeatNotifyApplicantRequiredTrainingDue;
        IsNotifyHRNotLogged = isNotifyHRNotLogged;
        NotifyHRNotLoggedDays = notifyHRNotLoggedDays;
        IsNotifyHRStatusNotChanged = isNotifyHRStatusNotChanged;
        NotifyHRStatusNotChangedDays = notifyHRStatusNotChangedDays;
        IsNotifyHRStatusChanges = isNotifyHRStatusChanges;
    }
}
