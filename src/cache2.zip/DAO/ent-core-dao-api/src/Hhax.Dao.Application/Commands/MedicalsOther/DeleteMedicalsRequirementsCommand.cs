﻿using MediatR;

namespace Hhax.Dao.Application.Commands.MedicalsOther;

public class DeleteMedicalsRequirementsCommand : IRequest<Unit>
{
    public int ApplicantId { get; }
    public IEnumerable<int> Ids { get; }

    public DeleteMedicalsRequirementsCommand(int applicantId, IEnumerable<int> ids)
    {
        ApplicantId = applicantId;
        Ids = ids;
    }
}
