﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.MedicalsOther;
using MediatR;

namespace Hhax.Dao.Application.Commands.MedicalsOther;

public class UpsertOtherRequirementsCommand : IRequest<BaseResponse>
{
    public int ApplicantId { get; }
    public OtherApplicantValue Data { get; }

    public UpsertOtherRequirementsCommand(int applicantId, OtherApplicantValue data)
    {
        ApplicantId = applicantId;
        Data = data;
    }
}