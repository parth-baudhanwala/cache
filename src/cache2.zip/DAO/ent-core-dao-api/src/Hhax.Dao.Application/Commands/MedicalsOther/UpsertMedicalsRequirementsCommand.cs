﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.MedicalsOther;
using MediatR;

namespace Hhax.Dao.Application.Commands.MedicalsOther;

public class UpsertMedicalsRequirementsCommand : IRequest<BaseResponse>
{
    public int ApplicantId { get; }
    public MedicalsApplicantValue Data { get; }

    public UpsertMedicalsRequirementsCommand(int applicantId, MedicalsApplicantValue data)
    {
        ApplicantId = applicantId;
        Data = data;
    }
}