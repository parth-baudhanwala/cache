﻿using MediatR;

namespace Hhax.Dao.Application.Commands.MedicalsOther;

public class DeleteOtherRequirementsCommand : IRequest<Unit>
{
    public int ApplicantId { get; }
    public IEnumerable<int> Ids { get; }

    public DeleteOtherRequirementsCommand(int applicantId, IEnumerable<int> ids)
    {
        ApplicantId = applicantId;
        Ids = ids;
    }
}
