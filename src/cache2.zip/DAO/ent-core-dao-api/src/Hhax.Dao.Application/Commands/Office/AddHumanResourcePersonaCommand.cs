﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Office
{
    public class AddHumanResourcePersonaCommand : IRequest<BaseResponse>
    {
        public string? Name { get; set; }
        public int? StatusId { get; set; }
        public int? UserId { get; set; }
        public string? Offices { get; set; }
        public int[]? OfficeIds { get; set; }
    }
}
