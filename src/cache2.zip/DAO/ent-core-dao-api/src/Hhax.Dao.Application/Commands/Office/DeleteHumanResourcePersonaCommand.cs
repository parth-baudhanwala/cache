﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Office;

public class DeleteHumanResourcePersonaCommand : IRequest<Unit>
{
    public DeleteHumanResourcePersonaCommand(int humanResourcePersonaId)
    {
        HumanResourcePersonaId = humanResourcePersonaId;
    }

    public int HumanResourcePersonaId { get; }
}
