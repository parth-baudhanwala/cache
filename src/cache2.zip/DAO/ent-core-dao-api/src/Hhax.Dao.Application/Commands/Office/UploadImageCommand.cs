﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Office;

public class UploadImageCommand : IRequest<Unit>
{
    public UploadImageCommand(int officeId, string type, string fileName, Stream stream, int width, int height)
    {
        OfficeId = officeId;
        Type = type;
        FileName = fileName;
        Stream = stream;
        Width = width;
        Height = height;
    }

    public int OfficeId { get; }
    
    public string Type { get; }
    
    public string FileName { get; }

    public Stream Stream { get; }
    
    public int Width { get; }

    public int Height { get; }
}
