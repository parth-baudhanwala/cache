﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Commands.Office;

public class AssignHumanResourcePersonaToApplicantCommand : IRequest<BaseRangeResponse>
{
    public int HumanResourcePersonaId { get; set; }
    public string? NoteText { get; set; }
    public List<AssignApplicant>? AssignApplicants { get; set; }
}
