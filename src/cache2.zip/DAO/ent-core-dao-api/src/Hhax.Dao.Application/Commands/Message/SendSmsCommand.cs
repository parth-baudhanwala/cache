﻿using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Domain.Message;
using MediatR;

namespace Hhax.Dao.Application.Commands.Message
{
    public class SendSmsCommand : IRequest<SendMessagesResponse>
    {
        public SendSmsCommand()
        {
            SmsRecipients = new List<SmsRecipient>();
            Message = string.Empty;
        }

        public SendSmsCommand(List<SmsRecipient> smsRecipients, string message)
        {
            SmsRecipients = smsRecipients;
            Message = message;
        }

        public List<SmsRecipient> SmsRecipients { get; set; }
        public string Message { get; set; }
    }
}
