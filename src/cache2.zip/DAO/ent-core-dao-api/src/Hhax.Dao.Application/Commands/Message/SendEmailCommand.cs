﻿using Hhax.Dao.Application.Abstracts.Responses.Message;
using Hhax.Dao.Domain.Message;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace Hhax.Dao.Application.Commands.Message
{
    public class SendEmailCommand : IRequest<SendMessagesResponse>
    {
        public SendEmailCommand()
        {
            EmailRecipients = new List<EmailRecipient>();
            Message = string.Empty;
            Subject = string.Empty;
        }

        public SendEmailCommand(List<EmailRecipient> emailRecipients, string message, string subject, IList<IFormFile>? attachments)
        {
            EmailRecipients = emailRecipients;
            Message = message;
            Subject = subject;
            Attachments = attachments;
        }

        public List<EmailRecipient> EmailRecipients { get; set; }
        public string Message { get; set; }
        public string Subject { get; set; }
        public IList<IFormFile>? Attachments { get; set; }
    }
}
