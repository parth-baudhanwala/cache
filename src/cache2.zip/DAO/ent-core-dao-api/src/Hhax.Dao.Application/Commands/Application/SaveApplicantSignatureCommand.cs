﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class SaveApplicantSignatureCommand : IRequest<BaseResponse>
{
    public SaveApplicantSignatureCommand(int applicantId, IEnumerable<Signature> signatures)
    {
        ApplicantId = applicantId;
        Signatures = signatures;
    }

    public int ApplicantId { get; set; }
    public IEnumerable<Signature> Signatures { get; set; }
}
