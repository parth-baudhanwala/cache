﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class InitializeApplicationWorkflowStatusesCommand : IRequest<Unit>
{
    public InitializeApplicationWorkflowStatusesCommand()
    {
    }
}