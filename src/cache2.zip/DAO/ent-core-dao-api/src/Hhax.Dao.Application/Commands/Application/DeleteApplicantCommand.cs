﻿using Hhax.Dao.Application.Abstracts.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class DeleteApplicantCommand : BaseRequest, IRequest<Unit>
{
    public DeleteApplicantCommand() : base() { }

    public DeleteApplicantCommand(int applicantId)
    {
        ApplicantId = applicantId;
    }

    public int ApplicantId { get; }
}
