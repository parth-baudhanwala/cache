﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class UpdateApplicationWorkflowStatusCommand : BaseRequest, IRequest<BaseResponse>
{
    public UpdateApplicationWorkflowStatusCommand() : base() { }

    public UpdateApplicationWorkflowStatusCommand(int id, string name, string? description, int? colorId, bool? isInterviewPossible, int[]? nextApplicationWorkflowStatusIds)
    {
        Id = id;
        Name = name;
        Description = description;
        ColorId = colorId;
        IsInterviewPossible = isInterviewPossible;
        NextApplicationWorkflowStatusIds = nextApplicationWorkflowStatusIds;
    }

    public string? Name { get; set; }
    public string? Description { get; set; }
    public int? ColorId { get; set; }
    public int? UserId { get; set; }
    public int? AgencyId { get; set; }
    public bool? IsInterviewPossible { get; set; }
    public int[]? NextApplicationWorkflowStatusIds { get; set; }
}
