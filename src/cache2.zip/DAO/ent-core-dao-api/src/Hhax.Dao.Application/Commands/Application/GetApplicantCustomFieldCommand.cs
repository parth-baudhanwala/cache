﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class GetApplicantCustomFieldCommand : IRequest<IEnumerable<ApplicantCustomFieldInfo>>
{
    public GetApplicantCustomFieldCommand(int applicantId, int officeId)
    {
        ApplicantId = applicantId;
        OfficeId = officeId;
    }

    public int ApplicantId { get; set; }
    public int OfficeId { get; set; }
}
