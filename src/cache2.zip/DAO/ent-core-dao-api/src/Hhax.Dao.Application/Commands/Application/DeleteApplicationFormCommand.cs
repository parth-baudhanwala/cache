﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class DeleteApplicationFormCommand : IRequest<Unit>
{
    public DeleteApplicationFormCommand(int applicationFormId)
    {
        ApplicationFormId = applicationFormId;
    }

    public int ApplicationFormId { get; }
}
