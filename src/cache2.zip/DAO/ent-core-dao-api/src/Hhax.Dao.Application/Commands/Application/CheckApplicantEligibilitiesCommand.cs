﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class CheckApplicantEligibilitiesCommand : IRequest<Unit>
{
    public CheckApplicantEligibilitiesCommand(int? applicantId)
    {
        ApplicantId = applicantId;
    }

    public int? ApplicantId { get; set; }
}
