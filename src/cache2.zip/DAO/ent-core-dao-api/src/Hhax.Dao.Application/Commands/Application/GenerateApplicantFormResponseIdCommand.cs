﻿using Hhax.Dao.Application.Abstracts.Responses.FormBuilder;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class GenerateApplicantFormResponseIdCommand : IRequest<FormDataResponse>
{
    public int ApplicantId { get; set; }
    public int OfficeId { get; set; }
    public int OnBoardingFormId { get; set; }
}
