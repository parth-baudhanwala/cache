﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class UpdateApplicantActivityStatusCommand : IRequest<Unit>
{
    public UpdateApplicantActivityStatusCommand(bool isActive, int[] applicantIds)
    {
        IsActive = isActive;
        ApplicantIds = applicantIds;
    }

    public bool IsActive { get; set; }
    public int[] ApplicantIds { get; set; }
}
