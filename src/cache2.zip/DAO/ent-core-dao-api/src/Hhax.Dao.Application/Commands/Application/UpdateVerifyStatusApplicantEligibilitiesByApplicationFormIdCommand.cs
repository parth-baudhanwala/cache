﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class UpdateVerifyStatusApplicantEligibilitiesByApplicationFormIdCommand : IRequest<Unit>
{
    public UpdateVerifyStatusApplicantEligibilitiesByApplicationFormIdCommand(int? applicationFormId, bool? isVerified)
    {
        ApplicationFormId = applicationFormId;
        IsVerified = isVerified;
    }

    public int? ApplicationFormId { get; set; }
    public bool? IsVerified { get; set; }
}
