﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand : IRequest<Unit>
{
    public UpdateVerifyStatusApplicantEligibilitiesByApplicantIdCommand(int? applicantId, bool? isVerified)
    {
        ApplicantId = applicantId;
        IsVerified = isVerified;
    }

    public int? ApplicantId { get; set; }
    public bool? IsVerified { get; set; }
}
