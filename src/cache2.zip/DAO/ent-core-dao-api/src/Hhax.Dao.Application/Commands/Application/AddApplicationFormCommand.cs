﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class AddApplicationFormCommand : BaseRequest, IRequest<BaseResponse>
{
    public string? Name { get; set; }
    public string? Notes { get; set; }
    public bool IsActive { get; set; }
    public int? ComplianceSetupId { get; set; }
    public IEnumerable<int>? OfficeIds { get; set; }
    public IEnumerable<ApplicationFormApplicantRequirement>? ApplicationFormApplicantRequirements { get; set; }
    public IEnumerable<ApplicationFormCustomFieldInfo>? ApplicationFormCustomFields { get; set; }
    public IEnumerable<ApplicationOnBoardingFormInfo>? ApplicationOnBoardingForms { get; set; }
}
