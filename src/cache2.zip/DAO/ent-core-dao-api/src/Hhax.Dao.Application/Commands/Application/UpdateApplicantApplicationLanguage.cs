﻿using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Hhax.Dao.Application.Commands.Application;

public class UpdateApplicantApplicationLanguageCommand : IRequest<BaseResponse>
{
    public int ApplicantId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = Constants.ApplicationLanguageErrorMessage)]
    public int LanguageId { get; set; }
}
