﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class SaveApplicantOnBoardingFormSignatureCommand : IRequest<BaseResponse>
{
    public int ApplicantId { get; set; }
    public bool IsSignatureDrawn { get; set; }
    public bool IsClearOldSignature { get; set; }
    public string? Signature { get; set; }
    public DateTime SignatureDate { get; set; }
}
