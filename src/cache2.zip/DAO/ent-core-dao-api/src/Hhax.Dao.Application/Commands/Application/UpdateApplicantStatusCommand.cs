﻿using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class UpdateApplicantStatusCommand : IRequest<BaseResponse>
{
    public UpdateApplicantStatusCommand() : base() { }

    public UpdateApplicantStatusCommand(int applicantId, int statusId, ApplicantUpdateWorkflowStatusRequest request, Guid? globalCaregiverId = null)
    {
        ApplicantId = applicantId;
        StatusId = statusId;
        Domain = request.Domain;
        StatusBackgroundColor = request.StatusBackgroundColor;
        StatusBorderColor = request.StatusBorderColor;
        GlobalCaregiverId = globalCaregiverId;
    }

    public int ApplicantId { get; }
    public int StatusId { get; }
    public string? Domain { get; set; }
    public string? StatusBackgroundColor { get; set; }
    public string? StatusBorderColor { get; set; }
    public Guid? GlobalCaregiverId { get; set; }
}
