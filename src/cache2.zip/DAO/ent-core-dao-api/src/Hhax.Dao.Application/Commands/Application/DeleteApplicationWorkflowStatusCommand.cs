﻿using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class DeleteApplicationWorkflowStatusCommand : IRequest<Unit>
{
    public DeleteApplicationWorkflowStatusCommand(int applicationFormId)
    {
        ApplicationFormId = applicationFormId;
    }

    public int ApplicationFormId { get; }
}
