﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Constants;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;
using System.ComponentModel.DataAnnotations;

namespace Hhax.Dao.Application.Commands.Application;

public class AddApplicantCommand : BaseRequest, IRequest<BaseResponse>
{
    public AddApplicantCommand() : base()
    { }

    public AddApplicantCommand(int officeId, string? loginEmail, string? password, int? userId, bool? isVerified, bool? isActive,
                               string? domain, string? firstName, string? lastName, string? middleName, string? countryOfBirth,
                               int? maritalStatusId, string? referralPerson, int? referralSourceId, int[]? employmentTypeIds, DateTime? dateOfBirth,
                               string? primaryStreet, string? secondaryStreet, string? city, string? state, string? zip, string? primaryPhone,
                               string? additionalPhone1, string? additionalPhone2, string? firstEmergencyContactName, string? firstEmergencyContactAddress,
                               string? firstEmergencyContactPhone1, string? firstEmergencyContactPhone2, int? firstEmergencyContactRelationshipId, string? secondEmergencyContactName,
                               string? secondEmergencyContactAddress, string? secondEmergencyContactPhone1, string? secondEmergencyContactPhone2, int? secondEmergencyContactRelationshipId,
                               int? preferredContactMethod, string? email, string? textMessagePhone, int? primaryLanguageId, int? secondaryLanguageId, int? thirdLanguageId, int? fourthLanguageId,
                               int? primaryLanguageProficiencyId, int? secondaryLanguageProficiencyId, int? thirdLanguageProficiencyId, int? fourthLanguageProficiencyId, int? applicationWorkflowStatusId,
                               string? socialSecurityNumber, int? ethnicity, int? gender, string? registryNumber, DateTime? registryDate, string? nationalProviderIdentity, string? professionalLicenseNumber)
    {
        OfficeId = officeId;
        LoginEmail = loginEmail;
        Password = password;
        UserId = userId;
        IsVerified = isVerified;
        IsActive = isActive;
        Domain = domain;
        FirstName = firstName;
        LastName = lastName;
        MiddleName = middleName;
        CountryOfBirth = countryOfBirth;
        MaritalStatusId = maritalStatusId;
        ReferralPerson = referralPerson;
        ReferralSourceId = referralSourceId;
        EmploymentTypeIds = employmentTypeIds;
        DateOfBirth = dateOfBirth;
        PrimaryStreet = primaryStreet;
        SecondaryStreet = secondaryStreet;
        City = city;
        State = state;
        Zip = zip;
        PrimaryPhone = primaryPhone;
        AdditionalPhone1 = additionalPhone1;
        AdditionalPhone2 = additionalPhone2;
        FirstEmergencyContactName = firstEmergencyContactName;
        FirstEmergencyContactAddress = firstEmergencyContactAddress;
        FirstEmergencyContactPhone1 = firstEmergencyContactPhone1;
        FirstEmergencyContactPhone2 = firstEmergencyContactPhone2;
        FirstEmergencyContactRelationshipId = firstEmergencyContactRelationshipId;
        SecondEmergencyContactName = secondEmergencyContactName;
        SecondEmergencyContactAddress = secondEmergencyContactAddress;
        SecondEmergencyContactPhone1 = secondEmergencyContactPhone1;
        SecondEmergencyContactPhone2 = secondEmergencyContactPhone2;
        SecondEmergencyContactRelationshipId = secondEmergencyContactRelationshipId;
        PreferredContactMethod = preferredContactMethod;
        ContactEmail = email;
        TextMessagePhone = textMessagePhone;
        PrimaryLanguageId = primaryLanguageId;
        SecondaryLanguageId = secondaryLanguageId;
        ThirdLanguageId = thirdLanguageId;
        FourthLanguageId = fourthLanguageId;
        PrimaryLanguageProficiencyId = primaryLanguageProficiencyId;
        SecondaryLanguageProficiencyId = secondaryLanguageProficiencyId;
        ThirdLanguageProficiencyId = thirdLanguageProficiencyId;
        FourthLanguageProficiencyId = fourthLanguageProficiencyId;
        ApplicationWorkflowStatusId = applicationWorkflowStatusId;
        SocialSecurityNumber = socialSecurityNumber;
        Ethnicity = ethnicity;
        Gender = gender;
        RegistryNumber = registryNumber;
        RegistryDate = registryDate;
        NationalProviderIdentity = nationalProviderIdentity;
        ProfessionalLicenseNumber = professionalLicenseNumber;
    }

    public int OfficeId { get; set; }

    // Credentials
    public string? LoginEmail { get; set; }
    public string? Password { get; set; }
    public int? UserId { get; set; }
    public bool? IsVerified { get; set; }
    public bool? IsActive { get; set; }
    public string? Domain { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = Constants.ApplicationLanguageErrorMessage)]
    public int ApplicationLanguageId { get; set; }

    // Demographics
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? MiddleName { get; set; }
    public string? CountryOfBirth { get; set; }
    public int? MaritalStatusId { get; set; }
    public int[]? EmploymentTypeIds { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public string? SocialSecurityNumber { get; set; }
    public int? Ethnicity { get; set; }
    public int? Gender { get; set; }

    // Employment Information
    public string? ReferralPerson { get; set; }
    public int? ReferralSourceId { get; set; }
    public string? RegistryNumber { get; set; }
    public DateTime? RegistryDate { get; set; }
    public string? NationalProviderIdentity { get; set; }
    public string? ProfessionalLicenseNumber { get; set; }

    // Address
    public string? PrimaryStreet { get; set; }
    public string? SecondaryStreet { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? Zip { get; set; }
    public string? PrimaryPhone { get; set; }
    public string? AdditionalPhone1 { get; set; }
    public string? AdditionalPhone2 { get; set; }

    // Emergency Contact Information
    public string? FirstEmergencyContactName { get; set; }
    public string? FirstEmergencyContactAddress { get; set; }
    public string? FirstEmergencyContactPhone1 { get; set; }
    public string? FirstEmergencyContactPhone2 { get; set; }
    public int? FirstEmergencyContactRelationshipId { get; set; }
    public string? SecondEmergencyContactName { get; set; }
    public string? SecondEmergencyContactAddress { get; set; }
    public string? SecondEmergencyContactPhone1 { get; set; }
    public string? SecondEmergencyContactPhone2 { get; set; }
    public int? SecondEmergencyContactRelationshipId { get; set; }

    // Notification Preferences
    public int? PreferredContactMethod { get; set; }
    public string? ContactEmail { get; set; }
    public string? TextMessagePhone { get; set; }

    // Language You Can Speak
    public int? PrimaryLanguageId { get; set; }
    public int? SecondaryLanguageId { get; set; }
    public int? ThirdLanguageId { get; set; }
    public int? FourthLanguageId { get; set; }

    // Language Proficiency
    public int? PrimaryLanguageProficiencyId { get; set; }
    public int? SecondaryLanguageProficiencyId { get; set; }
    public int? ThirdLanguageProficiencyId { get; set; }
    public int? FourthLanguageProficiencyId { get; set; }

    // Status of the application
    public int? ApplicationWorkflowStatusId { get; set; }

    public IEnumerable<Signature>? Signatures { get; set; }
}
