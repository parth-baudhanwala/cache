﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class SaveApplicantCustomFieldCommand : IRequest<BaseResponse>
{
    public SaveApplicantCustomFieldCommand(int applicantId, IEnumerable<ApplicantCustomField> applicantCustomFields)
    {
        ApplicantId = applicantId;
        ApplicantCustomFields = applicantCustomFields;
    }

    public int ApplicantId { get; set; }
    public IEnumerable<ApplicantCustomField> ApplicantCustomFields { get; set; }
}
