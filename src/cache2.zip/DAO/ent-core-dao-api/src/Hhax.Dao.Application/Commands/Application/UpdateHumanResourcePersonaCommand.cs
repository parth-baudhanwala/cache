﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class UpdateHumanResourcePersonaCommand : IRequest<BaseResponse>
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public int? StatusId { get; set; }
    public int? UserId { get; set; }
    public string? Offices { get; set; }
    public int[]? OfficeIds { get; set; }
}
