﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class GetApplicantSignatureCommand : IRequest<IEnumerable<Signature>>
{
    public GetApplicantSignatureCommand(int applicantId, int referenceId, int[] applicantSectionIds)
    {
        ApplicantId = applicantId;
        ReferenceId = referenceId;
        ApplicantSectionIds = applicantSectionIds;
    }

    public int ApplicantId { get; set; }
    public int ReferenceId { get; set; }
    public int[] ApplicantSectionIds { get; set; }
}
