﻿using Hhax.Dao.Application.Abstracts.Enums;
using MediatR;

namespace Hhax.Dao.Application.Commands.Application;

public class ValidateApplicantRequestDataCommand : IRequest<Unit>
{
    public int ApplicantId { get; set; }
    public int? OfficeId { get; set; }
    public object RequestData { get; set; }
    public ApplicantEligibilitySection Section { get; set; }

    private ValidateApplicantRequestDataCommand() 
    {
        ApplicantId = 0;
        RequestData = null!;
        Section = ApplicantEligibilitySection.None;
    }

    public ValidateApplicantRequestDataCommand(int applicantId, int? officeId, object data, ApplicantEligibilitySection section)
    {
        ApplicantId = applicantId;
        OfficeId = officeId;
        RequestData = data;
        Section = section;
    }
}
