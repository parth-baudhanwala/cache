﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Domain.Application;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hhax.Dao.Application.Commands.InService;

public class DeleteInServiceCommand : BaseRequest, IRequest<Unit>
{
    public DeleteInServiceCommand(int applicantId, int inServiceId)
    {
        ApplicantId = applicantId;
        InServiceId = inServiceId;
    }

    public int ApplicantId { get; set; }
    public int InServiceId { get; set; }
}
