﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hhax.Dao.Application.Commands.InService;

public class UpsertInServiceCommand : IRequest<BaseResponse>
{
    public int? Id { get; set; }
    public int ApplicantId { get; set; }
    public DateTime? Date { get; set; }
    public string? StartTime { get; set; }
    public string? EndTime { get; set; }
    public int? OfficeId { get; set; }
    public int? InstructorId { get; set; }
    public int? DisciplineId { get; set; }
    public int? PaycodeId { get; set; }
    public InServiceStatus? StatusId { get; set; }
    public int? ReasonId { get; set; }
    public int[]? TopicIds { get; set; }
}
