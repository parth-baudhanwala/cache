﻿using FluentValidation;
using MediatR;

namespace Hhax.Dao.Application.Behaviours;

public sealed class ValidatorBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> where TRequest : IRequest<TResponse>
{
    private readonly IValidator<TRequest>[] _validators;

    public ValidatorBehavior(IValidator<TRequest>[] validators) => _validators = validators;

    public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
    {
        var failures = _validators.Select(validator => validator.Validate(request))
                                  .SelectMany(validationResult => validationResult.Errors)
                                  .Where(error => error != null)
                                  .ToArray();
        if (failures.Any())
        {
            throw new ValidationException($"Validator Behavior Validation Errors for type {typeof(TRequest).Name}", failures);
        }

        var response = await next();

        return response;
    }
}
