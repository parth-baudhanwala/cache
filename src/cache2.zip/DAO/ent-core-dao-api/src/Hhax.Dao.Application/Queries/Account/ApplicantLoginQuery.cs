﻿using Hhax.Dao.Application.Abstracts.Responses.Account;
using MediatR;

namespace Hhax.Dao.Application.Queries.Account;

public class ApplicantLoginQuery : IRequest<ApplicantLoginResponse>
{
    public ApplicantLoginQuery(string? email, string? password, int applicationLanguageId)
    {
        Email = email;
        Password = password;
        ApplicationLanguageId = applicationLanguageId;
    }

    public string? Email { get; set; }
    public string? Password { get; set; }
    public int ApplicationLanguageId { get; set; }
}
