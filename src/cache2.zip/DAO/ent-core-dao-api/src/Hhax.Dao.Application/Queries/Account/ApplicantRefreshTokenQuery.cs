﻿using Hhax.Identity.Api.Client.Abstracts.Models.Responses;
using MediatR;

namespace Hhax.Dao.Application.Queries.Account
{
    public class ApplicantRefreshTokenQuery : IRequest<TokenResponse>
    {
        public ApplicantRefreshTokenQuery(string? refreshToken)
        {
            RefreshToken = refreshToken;
        }

        public string? RefreshToken { get; set; }
    }
}
