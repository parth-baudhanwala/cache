﻿using Hhax.Dao.Application.Abstracts.Responses.Permission;
using MediatR;

namespace Hhax.Dao.Application.Queries.Account;

public class GetPermissionsQuery : IRequest<PermissionsResponse>
{
}
