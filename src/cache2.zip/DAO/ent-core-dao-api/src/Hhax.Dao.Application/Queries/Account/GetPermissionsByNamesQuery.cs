﻿using MediatR;

namespace Hhax.Dao.Application.Queries.Account;

public class GetPermissionsByNamesQuery : IRequest<IEnumerable<string>>
{
    public GetPermissionsByNamesQuery(int userId, IEnumerable<string>? permissions)
    {
        UserId = userId;
        Permissions = permissions;
    }

    public int UserId { get; } 
    public IEnumerable<string>? Permissions { get; }
}
