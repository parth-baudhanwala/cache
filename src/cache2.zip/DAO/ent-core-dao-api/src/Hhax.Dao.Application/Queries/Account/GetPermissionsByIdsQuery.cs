﻿using MediatR;

namespace Hhax.Dao.Application.Queries.Account;

public class GetPermissionsByIdsQuery : IRequest<IEnumerable<int>>
{
    public GetPermissionsByIdsQuery(int userId, IEnumerable<int> permissions)
    {
        UserId = userId;
        Permissions = permissions;
    }

    public int UserId { get; } 
    
    public IEnumerable<int> Permissions { get; }

}
