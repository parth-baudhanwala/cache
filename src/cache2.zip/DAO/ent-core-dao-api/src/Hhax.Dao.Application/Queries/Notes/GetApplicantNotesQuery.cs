﻿using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Notes;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Notes;

public class GetApplicantNotesQuery : IRequest<PaginatationResponse<ApplicantNoteInfo>>
{
    public GetApplicantNotesQuery(int applicantId, PaginationRequest<GetApplicantNotesRequest> request)
    {
        ApplicantId = applicantId;
        Request = request;
    }

    public int ApplicantId { get; }
    public PaginationRequest<GetApplicantNotesRequest> Request { get; }
}
