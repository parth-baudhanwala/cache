﻿using Hhax.Dao.Application.Abstracts.Responses.Settings;
using MediatR;

namespace Hhax.Dao.Application.Queries.Settings;

public class GetNotificationsSettingsQuery : IRequest<NotificationsSettingsResponse> { }
