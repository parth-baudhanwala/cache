﻿using Hhax.Dao.Application.Abstracts.Responses.Feature;
using MediatR;

namespace Hhax.Dao.Application.Queries.Feature;

public class GetFeatureQuery : IRequest<FeatureResponse>
{
    public int? ProviderId { get; set; }
}
