﻿using Hhax.Dao.Application.Abstracts.Responses.Header;
using MediatR;

namespace Hhax.Dao.Application.Queries.Header;

public class GetApplicationFormSkinInfoQuery : IRequest<ApplicationFormSkinInfo>
{
    public GetApplicationFormSkinInfoQuery(int officeId)
    {
        OfficeId = officeId;
    }

    public int OfficeId { get; set; }
}
