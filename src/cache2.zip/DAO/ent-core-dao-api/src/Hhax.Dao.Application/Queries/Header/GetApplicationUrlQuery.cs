﻿using MediatR;

namespace Hhax.Dao.Application.Queries.Feature;

public class GetApplicationUrlQuery : IRequest<Dictionary<int, string?>>
{
    public GetApplicationUrlQuery(int[] appVersionIDs)
    {
        AppVersionIDs = appVersionIDs;
    }

    public int[] AppVersionIDs { get; set; }
    public int ProviderId { get; set; }
    public decimal Version { get; set; }
    public decimal MinorVersion { get; set; }
}
