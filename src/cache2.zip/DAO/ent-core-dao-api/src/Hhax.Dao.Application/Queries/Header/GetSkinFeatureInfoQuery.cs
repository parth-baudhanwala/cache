﻿using Hhax.Dao.Application.Abstracts.Responses.Feature;
using MediatR;

namespace Hhax.Dao.Application.Queries.Feature
{
    public class GetSkinFeatureInfoQuery : IRequest<SkinFeatureInfoResponse>
    {
    }
}
