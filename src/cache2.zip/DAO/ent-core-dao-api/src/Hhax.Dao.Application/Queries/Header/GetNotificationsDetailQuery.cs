﻿using Hhax.Dao.Application.Abstracts.Responses.Header;
using MediatR;

namespace Hhax.Dao.Application.Queries.Header
{
    public class GetNotificationsDetailQuery : IRequest<NotificationsDetailResponse>
    {
    }
}
