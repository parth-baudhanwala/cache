﻿using Hhax.Dao.Domain.MedicalsOther;
using MediatR;

namespace Hhax.Dao.Application.Queries.MedicalsOther;

public class GetMedicalsRequirementsQuery : IRequest<IEnumerable<MedicalsApplicantValue>>
{
    public int ApplicantId { get; }
    public int OfficeId { get; }

    public GetMedicalsRequirementsQuery(int applicantId, int officeId)
    {
        ApplicantId = applicantId;
        OfficeId = officeId;
    }
}