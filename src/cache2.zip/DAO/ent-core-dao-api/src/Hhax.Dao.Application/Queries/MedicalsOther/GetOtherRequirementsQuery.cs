﻿using Hhax.Dao.Domain.MedicalsOther;
using MediatR;

namespace Hhax.Dao.Application.Queries.MedicalsOther;

public class GetOtherRequirementsQuery : IRequest<IEnumerable<OtherApplicantValue>>
{
    public int ApplicantId { get; }
    public int OfficeId { get; }

    public GetOtherRequirementsQuery(int applicantId, int officeId)
    {
        ApplicantId = applicantId;
        OfficeId = officeId;
    }
}