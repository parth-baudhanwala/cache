﻿using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Globalization;
using Hhax.Dao.Domain.Globalization;
using MediatR;

namespace Hhax.Dao.Application.Queries.Globalization;

public class SearchCitiesQuery : IRequest<IEnumerable<City>>
{
    public SearchCitiesQuery(PaginationRequest<SearchCitiesRequest> request)
    {
        Request = request;
    }

    public PaginationRequest<SearchCitiesRequest> Request { get; }
}
