﻿using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Globalization;
using Hhax.Dao.Domain.Globalization;
using MediatR;

namespace Hhax.Dao.Application.Queries.Globalization;

public class SearchCitiesByZipCodeQuery : IRequest<IEnumerable<City>>
{
    public SearchCitiesByZipCodeQuery(PaginationRequest<SearchCitiesByZipCodeRequest>? request)
    {
        Request = request;
    }

    public PaginationRequest<SearchCitiesByZipCodeRequest>? Request { get; }
}
