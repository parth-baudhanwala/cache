﻿using Hhax.Dao.Domain.Globalization;
using MediatR;

namespace Hhax.Dao.Application.Queries.Globalization;

public class GetGenderQuery : IRequest<IEnumerable<Gender>>
{
    public GetGenderQuery(int officeId) => OfficeId = officeId;

    public int OfficeId { get; set; }
}
