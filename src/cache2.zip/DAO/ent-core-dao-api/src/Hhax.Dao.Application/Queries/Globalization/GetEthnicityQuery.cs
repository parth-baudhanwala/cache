﻿using Hhax.Dao.Domain.Globalization;
using MediatR;

namespace Hhax.Dao.Application.Queries.Globalization;

public class GetEthnicityQuery : IRequest<IEnumerable<Ethnicity>> { }
