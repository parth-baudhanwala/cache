﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantBackgroundEligibilityQuery : IRequest<ApplicantEligibility>
{
    public GetApplicantBackgroundEligibilityQuery(int? applicantId)
    {
        ApplicantId = applicantId;
    }

    public int? ApplicantId { get; set; }
}
