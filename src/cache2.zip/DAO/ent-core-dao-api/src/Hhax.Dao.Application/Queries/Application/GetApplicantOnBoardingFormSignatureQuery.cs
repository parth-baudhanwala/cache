﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantOnBoardingFormSignatureQuery : IRequest<OnBoardingFormSignatureInfo>
{
    public GetApplicantOnBoardingFormSignatureQuery(int applicantId)
    {
        ApplicantId = applicantId;
    }

    public int ApplicantId { get; }
}
