﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class ValidateContactEmailUniquenessQuery : IRequest<ValidationResponse>
{
    public ValidateContactEmailUniquenessQuery(string email, int? id = null)
    {
        Email = email;
        Id = id;
    }

    public string Email { get; }
    public int? Id { get; }
}
