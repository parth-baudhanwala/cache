﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationWorkflowStatusQuery : IRequest<ApplicationWorkflowStatus>
{
    public GetApplicationWorkflowStatusQuery(int applicationWorkflowStatusId)
    {
        ApplicationWorkflowStatusId = applicationWorkflowStatusId;
    }

    public int ApplicationWorkflowStatusId { get; }
}
