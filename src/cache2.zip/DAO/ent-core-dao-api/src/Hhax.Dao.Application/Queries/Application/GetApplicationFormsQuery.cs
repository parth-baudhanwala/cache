﻿using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFormsQuery : IRequest<PaginatationResponse<ApplicationFormInfo>>
{
    public GetApplicationFormsQuery(PaginationRequest<GetApplicationFormRequest> request)
    {
        Request = request;
    }

    public PaginationRequest<GetApplicationFormRequest> Request { get; }
}
