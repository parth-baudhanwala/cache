﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFormByIdQuery : IRequest<ApplicationForm>
{
    public GetApplicationFormByIdQuery(int applicationFormId)
    {
        ApplicationFormId = applicationFormId;
    }

    public int ApplicationFormId { get; }
}
