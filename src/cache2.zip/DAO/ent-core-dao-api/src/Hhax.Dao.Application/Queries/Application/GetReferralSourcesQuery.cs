﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetReferralSourcesQuery : IRequest<IEnumerable<ReferralSource>>
{
    public int OfficeId { get; }

    public GetReferralSourcesQuery(int officeId)
        => OfficeId = officeId;
}
