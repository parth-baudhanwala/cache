﻿using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.MailVerification;
using MediatR;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;

namespace Hhax.Dao.Application.Queries.Application;

public class ResentApplicantMailQuery : IRequest<MailVerificationResponse>
{
    public ResentApplicantMailQuery(int applicantId, ApplicantEmailResentRequest request)
    {
        ApplicantId = applicantId;
        Name = request.Name!;
        Email = request.Email!;
        Domain = request.Domain!;
    }

    public int ApplicantId { get; }
    public string Name { get; }
    public string Email { get; }
    public string Domain { get; }
}