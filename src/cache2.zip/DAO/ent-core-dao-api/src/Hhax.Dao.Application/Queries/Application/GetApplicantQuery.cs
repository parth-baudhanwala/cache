﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantQuery : IRequest<Applicant>
{
    public GetApplicantQuery(int applicantId)
    {
        ApplicantId = applicantId;
    }

    public int ApplicantId { get; }
}
