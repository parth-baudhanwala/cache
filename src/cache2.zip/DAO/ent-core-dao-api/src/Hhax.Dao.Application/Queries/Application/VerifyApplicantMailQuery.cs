﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.MailVerification;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class VerifyApplicantMailQuery : IRequest<MailVerificationResponse>
{
    public VerifyApplicantMailQuery(int applicantId, string key)
    {
        ApplicantId = applicantId;
        Key = key;
    }

    public int ApplicantId { get; }
    public string Key { get; }
}