﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetRelationshipsQuery : IRequest<IEnumerable<Relationship>>
{
    public int OfficeId { get; }

    public GetRelationshipsQuery(int officeId)
        => OfficeId = officeId;
}
