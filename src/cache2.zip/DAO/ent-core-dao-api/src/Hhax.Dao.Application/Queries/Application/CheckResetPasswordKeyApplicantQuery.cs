﻿using Hhax.Dao.Application.Abstracts.Responses.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application
{
    public class CheckResetPasswordKeyApplicantQuery : IRequest<CheckResetPasswordKeyApplicantResponse>
    {
        public CheckResetPasswordKeyApplicantQuery(int? applicantId, string? key) 
        { 
            ApplicantId = applicantId;
            Key = key;
        }

        public int? ApplicantId { get; set; }
        public string? Key { get; set; }
    }
}
