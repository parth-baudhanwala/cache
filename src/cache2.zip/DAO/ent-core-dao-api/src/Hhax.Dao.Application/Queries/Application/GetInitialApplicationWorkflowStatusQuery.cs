﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetInitialApplicationWorkflowStatusQuery : IRequest<ApplicationWorkflowStatus?>
{
    public GetInitialApplicationWorkflowStatusQuery(int? vendorId)
    {
        VendorId = vendorId;
    }

    public int? VendorId { get; set; }
}
