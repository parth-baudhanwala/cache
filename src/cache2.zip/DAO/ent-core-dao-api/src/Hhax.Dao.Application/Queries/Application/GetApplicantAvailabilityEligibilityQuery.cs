﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantAvailabilityEligibilityQuery : IRequest<ApplicantEligibility>
{
    public GetApplicantAvailabilityEligibilityQuery(int? applicantId)
    {
        ApplicantId = applicantId;
    }

    public int? ApplicantId { get; set; }
}
