﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantDataStatusQuery : IRequest<ApplicantDataStatus>
{
    public int ApplicantId { get; }
    public int OfficeId { get; }

    public GetApplicantDataStatusQuery(int applicantId, int officeId)
    {
        ApplicantId = applicantId;
        OfficeId = officeId;
    }
}