﻿using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class SearchApplicantsQuery : IRequest<PaginatationResponse<Applicant>>
{
    public SearchApplicantsQuery(PaginationRequest<SearchApplicantsRequest> request)
    {
        Request = request;
    }

    public PaginationRequest<SearchApplicantsRequest> Request { get; }
}
