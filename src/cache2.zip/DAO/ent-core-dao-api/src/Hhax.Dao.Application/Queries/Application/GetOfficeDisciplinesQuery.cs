﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application
{
    public class GetOfficeDisciplinesQuery : IRequest<IEnumerable<OfficeDisciplineResponse>>
    {
        public GetOfficeDisciplinesQuery(int officeId)
        {
            OfficeId = officeId;
        }

        public int OfficeId { get; set; }
    }
}
