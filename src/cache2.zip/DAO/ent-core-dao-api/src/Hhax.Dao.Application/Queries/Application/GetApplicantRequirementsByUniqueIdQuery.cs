﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantRequirementsByUniqueIdQuery : IRequest<IEnumerable<ApplicationFormApplicantRequirement>>
{
    public GetApplicantRequirementsByUniqueIdQuery(Guid uniqueUrlId)
    {
        UniqueUrlId = uniqueUrlId;
    }

    public Guid UniqueUrlId { get; }
}
