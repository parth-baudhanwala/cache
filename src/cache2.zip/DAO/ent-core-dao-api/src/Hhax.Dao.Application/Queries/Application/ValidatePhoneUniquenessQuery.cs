﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class ValidatePhoneUniquenessQuery : IRequest<ValidationResponse>
{
    public int? Id { get; }
    public string Phone { get; }

    public ValidatePhoneUniquenessQuery(string phone, int? id = null)
    {
        Phone = phone;
        Id = id;
    }
}
