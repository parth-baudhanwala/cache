﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application
{
    public class ValidateLoginEmailUniquenessQuery : IRequest<ValidationResponse>
    {
        public ValidateLoginEmailUniquenessQuery(string email)
        {
            Email = email;
        }

        public string Email { get; }
    }
}
