﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantTrainingSchoolsEligibilityQuery : IRequest<ApplicantEligibility>
{
    public GetApplicantTrainingSchoolsEligibilityQuery(int? applicantId)
    {
        ApplicantId = applicantId;
    }

    public int? ApplicantId { get; set; }
}
