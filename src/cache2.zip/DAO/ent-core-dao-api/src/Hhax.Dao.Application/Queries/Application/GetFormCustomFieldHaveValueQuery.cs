﻿using Hhax.Dao.Application.Abstracts.Responses.Common;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetFormCustomFieldHasValueQuery : IRequest<BaseResponse>
{
    public GetFormCustomFieldHasValueQuery(int formCustomFieldId)
    {
        FormCustomFieldId = formCustomFieldId;
    }

    public int FormCustomFieldId { get; set; }
}
