﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFormByUniqueIdQuery : IRequest<ApplicationForm>
{
    public GetApplicationFormByUniqueIdQuery(Guid? uniqueUrlId, int officeId)
    {
        OfficeId = officeId;
        UniqueUrlId = uniqueUrlId;
    }

    public int OfficeId { get; }
    public Guid? UniqueUrlId { get; }
}
