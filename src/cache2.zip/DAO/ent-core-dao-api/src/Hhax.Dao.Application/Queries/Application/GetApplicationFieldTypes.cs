﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFieldTypes : IRequest<IEnumerable<ApplicationFieldType>>
{
}
