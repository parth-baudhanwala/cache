﻿using Hhax.Dao.Domain.Globalization;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetCountriesQuery : IRequest<IEnumerable<Country>>
{
}
