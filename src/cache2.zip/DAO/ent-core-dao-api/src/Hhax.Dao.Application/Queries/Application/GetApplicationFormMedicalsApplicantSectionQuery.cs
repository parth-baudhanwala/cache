﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFormMedicalsApplicantSectionQuery : IRequest<ApplicationFormApplicantSection>
{
    public GetApplicationFormMedicalsApplicantSectionQuery(int?[] officeIds)
    {
        OfficeIds = officeIds;
    }

    public int?[] OfficeIds { get; set; }
}
