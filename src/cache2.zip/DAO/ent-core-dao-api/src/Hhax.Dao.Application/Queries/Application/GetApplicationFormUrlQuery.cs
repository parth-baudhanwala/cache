﻿using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFormUrlQuery : IRequest<string>
{
    public GetApplicationFormUrlQuery(int? officeId)
    {
        OfficeId = officeId;
    }

    public int? OfficeId { get; }
}
