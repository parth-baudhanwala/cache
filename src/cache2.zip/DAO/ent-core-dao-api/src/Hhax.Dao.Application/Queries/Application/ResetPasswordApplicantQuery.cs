﻿using Hhax.Dao.Application.Abstracts.Responses.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application
{
    public class ResetPasswordApplicantQuery : IRequest<ResetPasswordApplicantResponse>
    {
        public ResetPasswordApplicantQuery(int? applicantId, string? key, string? password)
        {
            ApplicantId = applicantId;
            Key = key;
            Password = password;
        }

        public int? ApplicantId { get; }
        public string? Key { get; }
        public string? Password { get; }
    }
}
