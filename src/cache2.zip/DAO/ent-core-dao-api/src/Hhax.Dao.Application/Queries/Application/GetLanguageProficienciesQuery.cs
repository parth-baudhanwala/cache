﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetLanguageProficienciesQuery : IRequest<IEnumerable<LanguageProficiency>>
{
}
