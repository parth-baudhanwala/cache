﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFormComplianceApplicantSectionQuery : IRequest<ApplicationFormApplicantSection>
{
    public GetApplicationFormComplianceApplicantSectionQuery(int?[] officeIds)
    {
        OfficeIds = officeIds;
    }

    public int?[] OfficeIds { get; set; }
}
