﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFormApplicantSectionsQuery : IRequest<IEnumerable<ApplicationFormApplicantSection>>
{
    public GetApplicationFormApplicantSectionsQuery(int?[] officeIds)
    {
        OfficeIds = officeIds;
    }

    public int?[] OfficeIds { get; set; }
}
