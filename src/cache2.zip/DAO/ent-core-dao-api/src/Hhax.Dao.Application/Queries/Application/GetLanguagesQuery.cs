﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetLanguagesQuery : IRequest<IEnumerable<Language>>
{
}
