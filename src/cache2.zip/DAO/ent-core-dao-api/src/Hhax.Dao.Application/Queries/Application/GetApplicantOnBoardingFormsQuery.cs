﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantOnBoardingFormsQuery : IRequest<IEnumerable<ApplicantOnBoardingFormInfo>>
{
    public int ApplicantId { get; set; }
    public int OfficeId { get; set; }
}
