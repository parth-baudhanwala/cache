﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicationFormApplicantRequirementsByOfficeIdQuery : IRequest<IEnumerable<ApplicationFormApplicantRequirement>>
{
    public GetApplicationFormApplicantRequirementsByOfficeIdQuery(int officeId)
    {
        OfficeId = officeId;
    }

    public int OfficeId { get; }
}
