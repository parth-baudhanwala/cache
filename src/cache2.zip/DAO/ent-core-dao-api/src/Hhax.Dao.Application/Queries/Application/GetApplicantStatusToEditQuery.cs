﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantStatusToEditQuery : IRequest<ApplicantStatusToEdit>
{
    public int ApplicantId { get; }

    public GetApplicantStatusToEditQuery(int applicantId)
    {
        ApplicantId = applicantId;
    }
}
