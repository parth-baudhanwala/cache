﻿using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application;

public class GetApplicantEligibilitiesQuery : IRequest<IEnumerable<ApplicantEligibility>>
{
    public GetApplicantEligibilitiesQuery(int? applicantId)
    {
        ApplicantId = applicantId;
    }

    public int? ApplicantId { get; set; }
}
