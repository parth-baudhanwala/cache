﻿using Hhax.Dao.Application.Abstracts.Responses.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.Application
{
    public class ForgotPasswordApplicantQuery : IRequest<ForgotPasswordApplicantResponse>
    {
        public ForgotPasswordApplicantQuery(string? email, string? domain) 
        {
            Email = email;
            Domain = domain;
        }

        public string? Email { get; set; }
        public string? Domain { get; set; }
    }
}
