﻿using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Compliance;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetApplicantComplianceTrainingSchoolQuery : IRequest<PaginatationResponse<ComplianceTrainingSchool>>
{
    public GetApplicantComplianceTrainingSchoolQuery(PaginationRequest<GetApplicantTrainingSchools> request)
    {
        Request = request;
    }

    public PaginationRequest<GetApplicantTrainingSchools> Request { get; }
}
