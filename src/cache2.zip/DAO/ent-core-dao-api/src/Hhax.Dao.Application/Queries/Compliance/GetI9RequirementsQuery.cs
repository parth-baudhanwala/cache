﻿using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetI9RequirementsQuery : IRequest<ComplianceI9Requirement>
{
    public GetI9RequirementsQuery(int applicantId)
    {
        ApplicantId = applicantId;
    }

    public int ApplicantId { get; }
}
