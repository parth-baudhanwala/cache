﻿using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance
{
    public class ValidateOfficeComplianceSetupsQuery : IRequest<CompliancesSetupsValidationResponse>
    {
        public ValidateOfficeComplianceSetupsQuery(int[]? officeIds)
        {
            OfficeIds = officeIds;
        }

        public int[]? OfficeIds { get; }
    }
}
