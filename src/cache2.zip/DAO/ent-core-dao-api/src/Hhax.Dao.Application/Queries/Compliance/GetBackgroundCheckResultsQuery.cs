﻿using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetBackgroundCheckResultsQuery : IRequest<IEnumerable<BackgroundCheckResponse>>
{
    public GetBackgroundCheckResultsQuery(int officeId)
    {
        OfficeId = officeId;
    }

    public int OfficeId { get; }
}
