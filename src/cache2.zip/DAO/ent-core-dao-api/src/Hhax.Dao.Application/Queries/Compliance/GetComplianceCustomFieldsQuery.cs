﻿using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetComplianceCustomFieldsQuery : IRequest<ComplianceCustomFieldModel>
{
    public int ApplicantId { get; }
    public int OfficeId { get; }

    public GetComplianceCustomFieldsQuery(int applicantId, int officeId)
    {
        ApplicantId = applicantId;
        OfficeId = officeId;
    }
}