﻿using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetApplicantComplianceBackgroundCheckQuery : IRequest<IEnumerable<ComplianceBackgroundCheck>>
{
    public GetApplicantComplianceBackgroundCheckQuery(int applicantId)
    {
        ApplicantId = applicantId;
    }

    public int ApplicantId { get; }
}
