﻿using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetCompliancesQuery : IRequest<CompliancesResponse>
{
    public GetCompliancesQuery(int? applicationFormId)
    {
        ApplicationFormId = applicationFormId;
    }
    public int? ApplicationFormId { get; set; }
}

