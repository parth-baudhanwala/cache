﻿using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetColumnAbDocumentsQuery : IRequest<IEnumerable<I9ColumnABDocument>>
{
    public GetColumnAbDocumentsQuery(int officeId)
    {
        OfficeId = officeId;
    }

    public int OfficeId { get; }
}
