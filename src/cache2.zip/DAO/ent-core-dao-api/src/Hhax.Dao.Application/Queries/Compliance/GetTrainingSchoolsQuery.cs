﻿using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetTrainingSchoolsQuery : IRequest<IEnumerable<TrainingSchool>>
{
    public GetTrainingSchoolsQuery(int officeId)
    {
        OfficeId = officeId;
    }

    public int OfficeId { get; }
}
