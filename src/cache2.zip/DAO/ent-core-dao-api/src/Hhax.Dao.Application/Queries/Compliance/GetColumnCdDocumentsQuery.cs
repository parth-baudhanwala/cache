﻿using Hhax.Dao.Domain.Compliance;
using MediatR;

namespace Hhax.Dao.Application.Queries.Compliance;

public class GetColumnCdDocumentsQuery : IRequest<IEnumerable<I9ColumnCDocument>>
{
}
