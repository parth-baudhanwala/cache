﻿using Hhax.Dao.Domain.Availability;
using MediatR;

namespace Hhax.Dao.Application.Queries.Availability;

public class GetApplicantAvailabilityQuery : IRequest<ApplicantAvailability>
{
    public int ApplicantId { get; }

    public GetApplicantAvailabilityQuery(int applicantId)
    {
        ApplicantId = applicantId;
    }
}
