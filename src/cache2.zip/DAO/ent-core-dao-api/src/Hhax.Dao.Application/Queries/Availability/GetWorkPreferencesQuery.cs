﻿using Hhax.Dao.Domain.Availability;
using MediatR;

namespace Hhax.Dao.Application.Queries.Availability;

public class GetWorkPreferencesQuery : IRequest<IEnumerable<WorkPreference>> { }
