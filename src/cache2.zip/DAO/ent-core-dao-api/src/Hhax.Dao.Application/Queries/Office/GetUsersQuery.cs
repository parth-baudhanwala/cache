﻿using Hhax.Dao.Domain.User;
using MediatR;

namespace Hhax.Dao.Application.Queries.Office;

public class GetUsersQuery : IRequest<IEnumerable<UserInfo>>
{
}
