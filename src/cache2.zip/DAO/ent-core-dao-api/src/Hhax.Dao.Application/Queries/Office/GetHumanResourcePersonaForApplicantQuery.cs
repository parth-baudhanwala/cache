﻿using Hhax.Dao.Domain.Office;
using MediatR;

namespace Hhax.Dao.Application.Queries.Office;

public class GetHumanResourcePersonaForApplicantQuery : IRequest<HumanResourcePersona>
{
    public GetHumanResourcePersonaForApplicantQuery(int applicantId)
    {
        ApplicantId = applicantId;
    }

    public int ApplicantId { get; }
}
