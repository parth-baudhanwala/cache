﻿using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Office;
using MediatR;

namespace Hhax.Dao.Application.Queries.Office;

public class GetHumanResourcePersonasQuery : IRequest<PaginatationResponse<HumanResourcePersona>>
{
    public GetHumanResourcePersonasQuery(PaginationRequest<SearchHumanResourcePersonaRequest> request)
    {
        Request = request;
    }

    public PaginationRequest<SearchHumanResourcePersonaRequest> Request { get; }
}
