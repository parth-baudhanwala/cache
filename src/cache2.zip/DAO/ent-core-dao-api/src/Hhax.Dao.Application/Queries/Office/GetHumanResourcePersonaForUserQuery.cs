﻿using Hhax.Dao.Domain.Office;
using MediatR;

namespace Hhax.Dao.Application.Queries.Office;

public class GetHumanResourcePersonaForUserQuery : IRequest<HumanResourcePersona>
{
}
