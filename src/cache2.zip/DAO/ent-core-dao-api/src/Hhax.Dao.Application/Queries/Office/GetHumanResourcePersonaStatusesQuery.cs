﻿using Hhax.Dao.Domain.Office;
using MediatR;

namespace Hhax.Dao.Application.Queries.Office;

public class GetHumanResourcePersonaStatusesQuery : IRequest<IEnumerable<HumanResourcePersonaStatus>>
{
}
