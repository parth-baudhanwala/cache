﻿using Hhax.Dao.Domain.Office;
using MediatR;

namespace Hhax.Dao.Application.Queries.Office;

public class GetOfficesQuery : IRequest<IEnumerable<OfficeHierarchy>>
{ }
