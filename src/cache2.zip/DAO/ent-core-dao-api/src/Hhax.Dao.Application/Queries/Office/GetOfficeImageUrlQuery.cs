﻿using MediatR;

namespace Hhax.Dao.Application.Queries.Office;

public class GetOfficeImageUrlQuery : IRequest<string>
{
    public GetOfficeImageUrlQuery(int officeId, string type)
    {
        OfficeId = officeId;
        Type = type;
    }

    public int OfficeId { get; }

    public string Type { get; }
}
