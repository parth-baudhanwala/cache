﻿using Hhax.Dao.Domain.Office;
using MediatR;

namespace Hhax.Dao.Application.Queries.Office;

public class GetHumanResourcePersonaQuery : IRequest<HumanResourcePersona>
{
    public GetHumanResourcePersonaQuery(int humanResourcePersonaId)
    {
        HumanResourcePersonaId = humanResourcePersonaId;
    }

    public int HumanResourcePersonaId { get; }
}
