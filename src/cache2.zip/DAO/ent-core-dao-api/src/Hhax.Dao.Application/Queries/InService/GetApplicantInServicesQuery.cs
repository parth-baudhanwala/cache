﻿using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.InService;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using MediatR;

namespace Hhax.Dao.Application.Queries.InService;

public class GetApplicantInServicesQuery : IRequest<PaginatationResponse<ApplicantInServiceTableItem>>
{
    public GetApplicantInServicesQuery(PaginationRequest<GetApplicantInServices> request)
    {
        Request = request;
    }
    public PaginationRequest<GetApplicantInServices> Request { get; set; }
}
