﻿using Hhax.Dao.Domain.InService;
using MediatR;

namespace Hhax.Dao.Application.Queries.InService;

public class GetTopicsQuery : IRequest<IEnumerable<InServiceTopic>>
{
    public GetTopicsQuery(int officeId)
    {
        OfficeId = officeId;
    }

    public int OfficeId { get; set; }
}
