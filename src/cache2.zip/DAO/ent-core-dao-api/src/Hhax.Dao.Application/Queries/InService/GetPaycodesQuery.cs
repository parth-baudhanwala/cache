﻿using Hhax.Dao.Domain.InService;
using Hhax.Dao.Infrastructure.Abstracts.Entities.InService;
using MediatR;

namespace Hhax.Dao.Application.Queries.InService;

public class GetPaycodesQuery : IRequest<IEnumerable<InServicePayRate>>
{
    public GetPaycodesQuery(short disciplineId)
    {
        DisciplineId = disciplineId;
    }

    public short DisciplineId { get; set; }
}
