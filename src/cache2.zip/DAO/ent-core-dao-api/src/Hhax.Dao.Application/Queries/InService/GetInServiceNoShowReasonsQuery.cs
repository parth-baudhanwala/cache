﻿using Hhax.Dao.Domain.InService;
using MediatR;

namespace Hhax.Dao.Application.Queries.InService;

public class GetInServiceNoShowReasonsQuery : IRequest<IEnumerable<InServiceNoShowReason>>
{
}
