﻿using Hhax.Dao.Domain.Application;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hhax.Dao.Application.Queries.InService;

public class HasApplicantInServicesQuery : IRequest<HasApplicantInServices>
{
    public HasApplicantInServicesQuery(int applicantId)
    {
        ApplicantId = applicantId;
    }
    public int ApplicantId { get; set; }
}
