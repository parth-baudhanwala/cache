﻿using Hhax.Dao.Api.Client.Host.Interfaces.Resources;

namespace Hhax.Dao.Api.Client.Host.Interfaces;

public interface IDaoApiClient
{
    IApplicantsResource ApplicantsResource { get; }
}
