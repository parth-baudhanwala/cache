﻿using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;

namespace Hhax.Dao.Api.Client.Host.Interfaces.Resources;

public interface IApplicantsResource
{
    Task<BaseResponse> AddApplicantAsync(ApplicantAddRequest request);
    Task UpdateApplicantAsync(int applicantId, ApplicantUpdateRequest request);
    Task DeleteApplicantAsync(int applicantId);
    Task<Applicant> GetApplicantAsync(int applicantId); 
    Task<IEnumerable<Applicant>> SearchApplicantsAsync(PaginationRequest<SearchApplicantsRequest> request);
}
