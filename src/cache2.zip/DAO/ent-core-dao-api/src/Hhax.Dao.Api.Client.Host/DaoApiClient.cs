﻿using Hhax.Dao.Api.Client.Host.Interfaces;
using Hhax.Dao.Api.Client.Host.Interfaces.Resources;

namespace Hhax.Dao.Api.Client.Host;

public class DaoApiClient : IDaoApiClient
{
    public DaoApiClient(IApplicantsResource applicantsResource)
    {
        ApplicantsResource = applicantsResource;
    }

    public IApplicantsResource ApplicantsResource { get; }
}
