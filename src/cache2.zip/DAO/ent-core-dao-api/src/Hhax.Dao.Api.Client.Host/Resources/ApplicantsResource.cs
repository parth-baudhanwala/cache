﻿using Hhax.Dao.Api.Client.Host.Interfaces.Resources;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RestSharp;

namespace Hhax.Dao.Api.Client.Host.Resources;

public class ApplicantsResource : IApplicantsResource
{
    private readonly RestClientOptions _restClientOptions;
    
    private readonly ILogger<ApplicantsResource> _logger;

    public ApplicantsResource(IOptions<RestClientOptions> restClientOptions, ILogger<ApplicantsResource> logger)
    {
        _restClientOptions = restClientOptions.Value;

        _logger = logger;
    }

    public async Task<BaseResponse> AddApplicantAsync(ApplicantAddRequest request)
    {
        _logger.LogInformation($"{nameof(AddApplicantAsync)}.");

        const string contentType = "application/json";
        const string resource = "applicants";

        using var restClient = new RestClient(_restClientOptions);
        var inputRequest = new RestRequest(resource, Method.Post);
        inputRequest.AddParameter(contentType, JsonConvert.SerializeObject(request), ParameterType.RequestBody);

        var result = await restClient.PostAsync<BaseResponse>(inputRequest);

        _logger.LogInformation("Applicant with Id: {Id} was added successfully.", result?.Id);

        return result!;
    }

    public async Task UpdateApplicantAsync(int applicantId, ApplicantUpdateRequest request)
    {
        _logger.LogInformation($"{nameof(UpdateApplicantAsync)} with Id: {applicantId}.");
            
        const string contentType = "application/json";
        var resource = $"applicants/{applicantId}";

        using (var restClient = new RestClient(_restClientOptions))
        {
            var inputRequest = new RestRequest(resource, Method.Put);
            inputRequest.AddParameter(contentType, JsonConvert.SerializeObject(request), ParameterType.RequestBody);

            await restClient.PutAsync(inputRequest);
        }

        _logger.LogInformation("Applicant with Id: {ApplicantId} was updated successfully.", applicantId);
    }

    public async Task DeleteApplicantAsync(int applicantId)
    {
        _logger.LogInformation($"{nameof(DeleteApplicantAsync)} with Id: {applicantId}.");

        var resource = $"applicants/{applicantId}";

        using (var restClient = new RestClient(_restClientOptions))
        {
            var request = new RestRequest(resource, Method.Delete);
            await restClient.DeleteAsync(request);
        }

        _logger.LogInformation("Applicant with Id: {ApplicantId} was deleted successfully.", applicantId);
    }

    public async Task<Applicant> GetApplicantAsync(int applicantId)
    {
        _logger.LogInformation($"{nameof(DeleteApplicantAsync)} with Id: {applicantId}.");

        var resource = $"applicants/{applicantId}";

        using var restClient = new RestClient(_restClientOptions);
        var request = new RestRequest(resource, Method.Get);

        var result = await restClient.GetAsync<Applicant>(request);

        _logger.LogInformation("Applicant with Id: {ApplicantId} was getting successfully.", applicantId);

        return result!;
    }

    public async Task<IEnumerable<Applicant>> SearchApplicantsAsync(PaginationRequest<SearchApplicantsRequest> request)
    {
        _logger.LogInformation($"{nameof(SearchApplicantsAsync)}.");

        var resource = $"applicants?filters.search={request.Filters!.ApplicantName}&page.pageNumber={request.Page?.PageNumber}&page.pageSize={request.Page?.PageSize}";

        using var restClient = new RestClient(_restClientOptions);
        var inputRequest = new RestRequest(resource, Method.Get);

        var result = await restClient.GetAsync<IEnumerable<Applicant>>(inputRequest);

        _logger.LogInformation("Applicants were getting successfully.");

        return result!;
    }
}
