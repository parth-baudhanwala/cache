﻿using Hhax.Dao.Api.Client.Host.Interfaces;
using Hhax.Dao.Api.Client.Host.Interfaces.Resources;
using Hhax.Dao.Api.Client.Host.Resources;
using Hhax.Dao.Application.Abstracts.Configurations;
using Microsoft.Extensions.DependencyInjection;
using RestSharp;

namespace Hhax.Dao.Api.Client.Host.Extensions;

public static class ServicesExtensions
{
    public static void ConfigureDaoApiClient(this IServiceCollection services, ServiceConfiguration serviceConfiguration)
    {
        services.Configure<RestClientOptions>(configure => {
            configure.BaseUrl = new Uri(serviceConfiguration.ServiceUrl!);
            configure.ThrowOnAnyError = true;
        });

        services.AddScoped<IApplicantsResource, ApplicantsResource>();

        services.AddScoped<IDaoApiClient, DaoApiClient>();
    }
}
