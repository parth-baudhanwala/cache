﻿using Microsoft.AspNetCore.Authentication;

namespace Hhax.Dao.Api.IntegrationTests.Authentication;

public static class TestAuthenticationExtensions
{
    public static AuthenticationBuilder AddTestAuth(this AuthenticationBuilder builder, Action<TestAuthenticationOptions> configureOptions)
    {
        const string authenticationScheme = "Test Scheme";
        const string displayName = "Test Auth";

        return builder.AddScheme<TestAuthenticationOptions, TestAuthenticationHandler>(authenticationScheme, displayName, configureOptions);
    }
}
