﻿using Hhax.Dao.Application.Abstracts.Enums;
using Hhax.Dao.Common.Extensions;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace Hhax.Dao.Api.IntegrationTests.Authentication;

public class TestAuthenticationOptions : AuthenticationSchemeOptions
{
    private const string _authenticationType = "test";
    private const string _vendoridType = "vendorid";
    private const string _scopeClaim = "scope";
    private const string _daoScopeValue = "HhaxDaoApi";

    private const int _userId = 42640;
    private const int _vendorId = 691;

    public virtual ClaimsIdentity Identity { get; } = new ClaimsIdentity(new Claim[] {
             new Claim(HhaxPermissions.CanAddApplicationForm.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanAddHR.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanAddWorkflowStatus.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanAssignHRUser.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanContactApplicant.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanEditApplicant.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanEditApplicationForm.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanEditApplicationWorkflow.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanEditHR.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanUpdateStatus.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanViewApplicants.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanViewApplicationForm.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanViewApplicationProcessManagement.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanViewApplicationWorkflow.GetEnumMemberValue(), bool.TrueString),
             new Claim(HhaxPermissions.CanViewHRRepresentatives.GetEnumMemberValue(), bool.TrueString),
             new Claim(_scopeClaim,_daoScopeValue),
             new Claim(_vendoridType.ToString(), _vendorId.ToString()),
             new Claim(ClaimTypes.NameIdentifier, _userId.ToString())
        }, _authenticationType);
}
