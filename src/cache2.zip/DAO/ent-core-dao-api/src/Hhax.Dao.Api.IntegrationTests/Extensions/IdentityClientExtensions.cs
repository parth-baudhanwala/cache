﻿using Hhax.Identity.Api.Client.Abstracts.Interfaces;
using Hhax.Identity.Api.Client.Abstracts.Interfaces.Clients;
using Hhax.Identity.Api.Client.Abstracts.Models.Requests;
using Hhax.Identity.Api.Client.Abstracts.Models.Responses;
using Microsoft.Extensions.DependencyInjection;
using Moq;

namespace Hhax.Dao.Api.IntegrationTests.Extensions;

public static class IdentityClientExtensions
{
    private const string _token = "Bearer ";
    private const string _authorizationHeaderParamName = "Authorization";
    
    public static void ConfigureIdentityApiClient(this IServiceCollection services)
    {
        var usersClient = GetUsersClient();
        var accountsClient = GetAccountsClient();
        var applicantsClient = GetApplicantsClient();
        var validationClientMock = GetValidationClient();
        
        var identityClientMock = new Mock<IIdentityClient>();
        identityClientMock.Setup(x => x.UsersClient).Returns(usersClient.Object);
        identityClientMock.Setup(x => x.AccountsClient).Returns(accountsClient.Object);
        identityClientMock.Setup(x => x.ApplicantsClient).Returns(applicantsClient.Object);
        identityClientMock.Setup(x => x.ValidationClient).Returns(validationClientMock.Object);
        
        services.AddScoped(configure => identityClientMock.Object);
    }

    private static Mock<IUsersClient> GetUsersClient()
    {
        var result = new Mock<IUsersClient>();

        return result;
    }

    private static Mock<IValidationClient> GetValidationClient()
    {
        var result = new Mock<IValidationClient>();
        var headers = new Dictionary<string, string>() { { _authorizationHeaderParamName, _token } };

        result.Setup(x => x.IsUserNameUniqueAsync(It.IsAny<UniqueUserNameRequest>(), headers))
        .ReturnsAsync(true);

        return result;
    }

    private static Mock<IApplicantsClient> GetApplicantsClient()
    {
        var result = new Mock<IApplicantsClient>();
        var headers = new Dictionary<string, string>() { { _authorizationHeaderParamName, _token } };

        result.Setup(x => x.AddApplicantAsync(It.IsAny<AddApplicantRequest>(), headers)).ReturnsAsync(1);

        return result;
    }

    private static Mock<IAccountsClient> GetAccountsClient()
    {
        var result = new Mock<IAccountsClient>();

        result.Setup(x => x.GetTokenWithClientCredentialsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(new TokenResponse());

        return result;
    }
}
