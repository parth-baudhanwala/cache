﻿using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Requests.Compliance;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

public class OfficesControllerTests
{
    private readonly OfficesFixture _officesFixture;

    public OfficesControllerTests()
    {
        _officesFixture = new OfficesFixture();
    }

    [Fact]
    public async Task Office_ShouldUploadImage_Success()
    {
        // Arrange
        const int officeId = 1;
        var request = new UploadOfficeImageRequest
        {
            Type = "Logo",
            Width = 200,
            Height = 200
        };

        var filePath = $"Content{Path.DirectorySeparatorChar}Images{Path.DirectorySeparatorChar}logo.png";
        
        // Action
        var result = await _officesFixture.UploadImageAsync(officeId, request, File.ReadAllBytes(filePath));

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task Office_ShouldGetImage_Success()
    {
        // Arrange
        const int officeId = 1;
        var request = new OfficeImageRequest
        {
            Type = "Logo"
        };

        // Action
        var result = await _officesFixture.GetImageAsync(officeId, request);

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task Office_ShouldGetImageUrl_Success()
    {
        // Arrange
        const int officeId = 1;
        var request = new OfficeImageRequest
        {
            Type = "Logo"
        };

        // Action
        var result = await _officesFixture.GetImageUrlAsync(officeId, request);

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task Office_ShouldGetOffices_Success()
    {
        // Arrange

        // Action
        var result = await _officesFixture.GetOfficesAsync();

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task Office_ShouldValidateOfficeWithOfficeComplianceSetups_Success()
    {
        // Arrange
        var request = new OfficeComplianceRequest { 
            OfficeIds = new[] { 1, 2, 3 }
        };

        // Action
        var result = await _officesFixture.ValidateOfficeComplianceSetupsAsync(request);

        // Assert
        Assert.NotNull(result);
    }
}
