﻿using Hhax.Dao.Api.IntegrationTests.Common.Attributes;
using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Domain.Application;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

[TestCaseOrderer("Hhax.Dao.Api.IntegrationTests.Common.PriorityOrderer", "Hhax.Dao.Api.IntegrationTests")]
public class ApplicantsControllerTests : IClassFixture<ApplicantsFixture>
{
    private readonly ApplicantsFixture _applicantsFixture;
    private static int _applicantId = 131;
    
    public ApplicantsControllerTests()
    {
        _applicantsFixture = new ApplicantsFixture();
    }

    [Fact, TestPriority(1)]
    public async Task Applicant_ShouldAddApplicant_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            ApplicationLanguageId = 1,
            FirstName = "demo",
            LastName = "demo",
            OfficeId = 851,
            FirstEmergencyContactAddress = "test address",
            SecondEmergencyContactAddress = "second address",
            DateOfBirth = DateTime.Now,
            SocialSecurityNumber = "123-45-6789",
            Ethnicity = 3,
            Gender = 1,
            EmploymentTypeIds = new[] { 1, 2, 3 },
            RegistryNumber = "122e45ha8il0ee3pjb",
            RegistryDate = DateTime.Now,
            NationalProviderIdentity = "123p5j78bh",
            ProfessionalLicenseNumber = "212jsjjshaileeparth9i",
            Signatures = new List<Signature>()
            {
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 1
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 2
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 3
                }
            }
        };

        // Action
        var result = await _applicantsFixture.AddApplicantAsync(request);

        _applicantId = result.Id;

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(2)]
    public async Task Applicant_ShouldAddApplicant_Validation_Name_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            ContactEmail = $"demo-{Guid.NewGuid()}@hhaexchange.com",
            FirstName = "more that 50 chars xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            LastName = "demo",
            OfficeId = 851,
            FirstEmergencyContactAddress = "test address",
            SecondEmergencyContactAddress = "second address"
        };

        // Action

        // Assert
        _ = await Assert.ThrowsAsync<ApplicationException>(() => _applicantsFixture.AddApplicantAsync(request));
    }

    [Fact, TestPriority(3)]
    public async Task Applicant_ShouldAddApplicant_Validation_EmergencyPhone_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            ContactEmail = $"demo-{Guid.NewGuid()}@hhaexchange.com",
            FirstName = "demo",
            LastName = "demo",
            OfficeId = 851,
            FirstEmergencyContactAddress = "test address",
            SecondEmergencyContactAddress = "second address",
            FirstEmergencyContactPhone1 = "incorrect phone"
        };

        // Action

        // Assert
        _ = await Assert.ThrowsAsync<ApplicationException>(() => _applicantsFixture.AddApplicantAsync(request));
    }


    [Fact, TestPriority(4)]
    public async Task Applicant_ShouldAddApplicant_Validation_Languages_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            FirstName = "demo",
            LastName = "demo",
            OfficeId = 851,
            FirstEmergencyContactAddress = "test address",
            SecondEmergencyContactAddress = "second address",
            PrimaryLanguageId = 3,
            SecondaryLanguageId = 3 //same language selected twice
        };

        // Action

        // Assert
        _ = await Assert.ThrowsAsync<ApplicationException>(async () => await _applicantsFixture.AddApplicantAsync(request));
    }

    [Fact, TestPriority(5)]
    public async Task Applicant_ShouldUpdateApplicant_Success()
    {
        // Arrange
        string email = $"demo-{Guid.NewGuid()}@hhaexchange.com";
        const string firstName = "test";
        const string lastName = "test";
        const int officeId = 851;
        const string firstEmergencyContactAddress = "new test address";
        const string secondEmergencyContactAddress = "new second address";

        var applicantRequest = new ApplicantUpdateRequest
        {
            Id = _applicantId,
            FirstName = firstName,
            LastName = lastName,
            OfficeId = officeId,
            ContactEmail = email,
            FirstEmergencyContactAddress = firstEmergencyContactAddress,
            SecondEmergencyContactAddress = secondEmergencyContactAddress,
            DateOfBirth = DateTime.UtcNow,
            SocialSecurityNumber = "123-45-6789",
            Ethnicity = 3,
            Gender = 1,
            EmploymentTypeIds = new[] { 1, 2, 3 },
            RegistryNumber = "122e45ha8il0ee3pjb",
            RegistryDate = DateTime.Now,
            NationalProviderIdentity = "123p5j78bh",
            ProfessionalLicenseNumber = "212jsjjshaileeparth9i",
            Signatures = new List<Signature>()
            {
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 1
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 2
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 3
                }
            }
        };

        // Action
        await _applicantsFixture.UpdateApplicantAsync(_applicantId, applicantRequest);

        var result = await _applicantsFixture.GetApplicantAsync(_applicantId);

        // Assert
        Assert.NotNull(result);

        Assert.Equal(_applicantId, result.Id);
        Assert.Equal(email, result.ContactEmail);
        Assert.Equal(firstName, result.FirstName);
        Assert.Equal(lastName, result.LastName);
    }

    [Fact, TestPriority(6)]
    public async Task Applicant_ShouldGetApplicant_Success()
    {
        // Arrange & Action 
        var result = await _applicantsFixture.GetApplicantAsync(_applicantId);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(7)]
    public async Task Applicant_ShouldGetApplicants_Success()
    {
        // Arrange
        var parameters = new PaginationRequest<SearchApplicantsRequest>
        {
            Page = new Page
            {
                PageNumber = 1,
                PageSize = 10
            },
            Filters = new SearchApplicantsRequest
            {
                ApplicantName = "Vadym"
            }
        };

        // Action
        var result = await _applicantsFixture.GetApplicantsAsync(parameters);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(8)]
    public async Task Applicant_ShouldCheckApplicantEligibilities_Success()
    {
        // Arrange & Action & Assert
        _ = await Assert.ThrowsAsync<ApplicationException>(async () => await _applicantsFixture.CheckApplicantEligibilitiesAsync(applicantId: 0));
    }

    [Fact, TestPriority(9)]
    public async Task Applicant_ShouldGetApplicantEligibilities_Success()
    {
        // Arrange & Action
        var response = await _applicantsFixture.GetApplicantEligibilitiesAsync(_applicantId);

        // Assert
        Assert.NotNull(response);
    }

    [Fact, TestPriority(10)]
    public async Task Applicant_ShouldUpdateActivityStatus_Success()
    {
        // Arrange
        bool isActive = false;
        int[] applicantIds = new int[1] { _applicantId };

        // Action
        await _applicantsFixture.UpdateApplicantActivityStatusAsync(isActive, applicantIds);

        // Assert
        Assert.True(true);
    }

    [Fact, TestPriority(11)]
    public async Task Applicant_ShouldDeleteApplicant_Success()
    {
        // Arrange & Action
        await _applicantsFixture.DeleteApplicantAsync(_applicantId);

        // Assert
        Assert.True(true);
    }

    [Fact, TestPriority(12)]
    public async Task Applicant_ShouldGetLanguageProficiencies_Success()
    {
        // Arrange

        // Action
        var result = await _applicantsFixture.GetLanguageProficienciesAsync();

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(13)]
    public async Task Applicant_ShouldAddApplicant_Validation_SSN_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            ContactEmail = $"demo-{Guid.NewGuid()}@hhaexchange.com",
            FirstName = "demo",
            LastName = "demo",
            OfficeId = 851,
            SocialSecurityNumber = "123-456-7890",
        };

        // Action

        // Assert
        _ = await Assert.ThrowsAsync<ApplicationException>(() => _applicantsFixture.AddApplicantAsync(request));
    }

    [Fact, TestPriority(14)]
    public async Task Applicant_ShouldAddApplicant_Validation_NPI_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            ContactEmail = $"demo-{Guid.NewGuid()}@hhaexchange.com",
            FirstName = "demo",
            LastName = "demo",
            OfficeId = 851,
            SocialSecurityNumber = "1234567890pppwswjs",
        };

        // Action

        // Assert
        _ = await Assert.ThrowsAsync<ApplicationException>(() => _applicantsFixture.AddApplicantAsync(request));
    }

    [Fact, TestPriority(15)]
    public async Task Applicant_ShouldGetEthnicity_Success()
    {
        // Action
        var result = await _applicantsFixture.GetEthnicity();

        // Assert
        Assert.NotEmpty(result);
    }

    [Fact, TestPriority(16)]
    public async Task Applicant_ShouldGetGender_Success()
    {
        // Arrange
        int officeId = 851;

        // Action
        var result = await _applicantsFixture.GetGender(officeId);

        // Assert
        Assert.NotEmpty(result);
    }
}
