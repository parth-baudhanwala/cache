﻿using Hhax.Dao.Api.IntegrationTests.Common.Attributes;
using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Domain.Application;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

[TestCaseOrderer("Hhax.Dao.Api.IntegrationTests.Common.PriorityOrderer", "Hhax.Dao.Api.IntegrationTests")]
public class ApplicationFormsControllerTests
{
    private readonly ApplicationFormsFixture _applicationFormsFixture;

    private static int _applicationFormId = 0;

    public ApplicationFormsControllerTests()
    {
        _applicationFormsFixture = new ApplicationFormsFixture();
    }

    [Fact, TestPriority(1)]
    public async Task ApplicationForm_ShouldAddApplicationForm_Success()
    {
        // Arrange
        var request = new ApplicationFormRequest
        {
            OfficeIds = new[] { 1, 2, 3 },
            Name = "Application Form #1",
            ApplicationFormApplicantRequirements = new List<ApplicationFormApplicantRequirement>(),
            IsActive = true
        };

        // Action
        var result = await _applicationFormsFixture.AddApplicationFormAsync(request);

        _applicationFormId = result.Id;

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(2)]
    public async Task ApplicationForm_ShouldUpdateApplicationForm_Success()
    {
        // Arrange
        var parameters = new ApplicationFormRequest
        {
            Id = _applicationFormId,
            IsActive = true,
            OfficeIds = new[] { 1, 2, 3 },
            Name = "Application Form #1",
            ApplicationFormApplicantRequirements = new List<ApplicationFormApplicantRequirement>(),
            ApplicationFormCustomFields = new List<ApplicationFormCustomFieldInfo>()
            {
                new ApplicationFormCustomFieldInfo
                {
                    Id = 0,
                    FieldName = "Are you Batman?",
                    FieldTypeId = 4,
                    ApplicantSectionId = 1,
                    IsActive = true,
                    IsShow = true,
                    IsRequire = true,
                    CanUploadFile = false
                },
                new ApplicationFormCustomFieldInfo
                {
                    Id = -1,
                    FieldName = "Date of Death",
                    FieldTypeId = 3,
                    ApplicantSectionId = 2,
                    IsActive = true,
                    IsShow = false,
                    IsRequire = false,
                    CanUploadFile = true
                },
                new ApplicationFormCustomFieldInfo
                {
                    Id = -2,
                    FieldName = "Name of Partner",
                    FieldTypeId = 5,
                    ApplicantSectionId = 3,
                    IsActive = false,
                    IsShow = true,
                    IsRequire = false,
                    CanUploadFile = false
                },
                new ApplicationFormCustomFieldInfo
                {
                    Id = -3,
                    FieldName = "Your Favourite Countries",
                    FieldTypeId = 2,
                    ApplicantSectionId = 4,
                    IsActive = true,
                    IsShow = true,
                    IsRequire = false,
                    CanUploadFile = false,
                    ApplicationCustomFieldValueMappings = new List<ApplicationCustomFieldValueMappingInfo>()
                    {
                        new ApplicationCustomFieldValueMappingInfo
                        {
                            Id = 0,
                            Value = "Bharat",
                            IsActive = true
                        },
                        new ApplicationCustomFieldValueMappingInfo
                        {
                            Id = -1,
                            Value = "United States",
                            IsActive = true
                        },
                        new ApplicationCustomFieldValueMappingInfo
                        {
                            Id = -2,
                            Value = "Canada",
                            IsActive = false
                        }
                    }
                }
            },
            ApplicationOnBoardingForms = new List<ApplicationOnBoardingFormInfo>()
            {
                new ApplicationOnBoardingFormInfo
                {
                    Id = 0,
                    OnBoardingFormId = 7,
                    Name = "USA Visa L1 Form",
                    Description = "USA Visa for Students.",
                    Category = "Non-Skilled",
                    Version = 8,
                    IsShow = false,
                    IsActive = true
                },
                new ApplicationOnBoardingFormInfo
                {
                    Id = -1,
                    OnBoardingFormId = 7,
                    Name = "USA Visa H1B Form",
                    Description = "USA Visa for Work Permit.",
                    Category = "Skilled",
                    Version = 1,
                    IsShow = true,
                    IsActive = true
                },
                new ApplicationOnBoardingFormInfo
                {
                    Id = -2,
                    OnBoardingFormId = 3,
                    Name = "Parth Baudhanwala",
                    Description = "My Form",
                    Category = "Skilled",
                    Version = 3,
                    IsShow = true,
                    IsActive = false
                }
            }
        };

        // Action
        var result = await _applicationFormsFixture.UpdateApplicationFormAsync(_applicationFormId, parameters);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(3)]
    public async Task ApplicationForm_ShouldGetApplicantRequirements_Success()
    {
        // Arrange
        var getApplicationFormRequest = new PaginationRequest<GetApplicationFormRequest>
        {
            Filters = new GetApplicationFormRequest
            {
                SetupName = string.Empty
            },
            Page = new Page
            {
                PageNumber = 1,
                PageSize = 10
            }
        };

        var applicationForms = await _applicationFormsFixture.GetApplicationFormsAsync(getApplicationFormRequest);

        var applicationForm = applicationForms.Data!.FirstOrDefault();

        // Action
        var result = await _applicationFormsFixture.GetApplicationFormApplicantRequirementsAsync(applicationForm!.UniqueUrlId!.Value);

        // Assert
        Assert.NotNull(result);
    }

    [Fact(Skip = "Need to support DaoDbContext")]
    public async Task ApplicationFormStatus_ShouldGetLinkToApplicationFormByOfficeAsync_Success()
    {
        // Arrange
        const int officeId = 1;

        // Action
        var result = await _applicationFormsFixture.GetLinkToApplicationFormByOfficeAsync(officeId);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(5)]
    public async Task ApplicationForm_ShouldGetApplicantSections_Success()
    {
        // Action
        var result = await _applicationFormsFixture.GetApplicationFormApplicantSectionsAsync();

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(6)]
    public void ApplicationForm_ShouldGetApplicantRequirementsWithoutUniqueUrlId_Failure()
    {
        Assert.ThrowsAsync<ApplicationException>(async () => await _applicationFormsFixture.GetApplicationFormApplicantRequirementsAsync(Guid.NewGuid()));
    }

    [Fact, TestPriority(7)]
    public async Task ApplicationForm_ShouldGetApplicationForm_Success()
    {
        // Action
        var result = await _applicationFormsFixture.GetApplicationFormAsync(_applicationFormId);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(8)]
    public async Task ApplicationForm_ShouldGetOfficesByCompliance_Success()
    {
        // Arrange & Action
        var result = await _applicationFormsFixture.GetOfficesGroupedByComplianceAsync(_applicationFormId);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(9)]
    public async Task ApplicationForm_ShouldDeleteApplicationForm_Success()
    {
        // Arrange & Action
        await _applicationFormsFixture.DeleteApplicationFormAsync(_applicationFormId);

        // Assert
        Assert.True(true);
    }
}
