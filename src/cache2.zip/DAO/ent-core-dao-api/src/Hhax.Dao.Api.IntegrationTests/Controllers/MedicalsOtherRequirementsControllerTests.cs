﻿using Hhax.Dao.Api.IntegrationTests.Common.Attributes;
using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.MedicalsOther;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

[TestCaseOrderer("Hhax.Dao.Api.IntegrationTests.Common.PriorityOrderer", "Hhax.Dao.Api.IntegrationTests")]
public class MedicalsOtherRequirementsControllerTests
{
    private readonly ApplicantsFixture _applicantsFixture;
    private readonly MedicalsOtherRequirementsFixture _medicalsOtherFixture;
    private static int _applicantId = 0;
    private static int _officeId = 851;

    public MedicalsOtherRequirementsControllerTests()
    {
        _applicantsFixture = new ApplicantsFixture();
        _medicalsOtherFixture = new MedicalsOtherRequirementsFixture();
    }

    [Fact, TestPriority(1)]
    public async Task MedicalsOtherRequirements_ShouldAddApplicant_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            ApplicationLanguageId = 1,
            FirstName = "demo",
            LastName = "for m/o requirements",
            DateOfBirth = DateTime.Now,
            OfficeId = _officeId,
            FirstEmergencyContactAddress = "test address",
            SecondEmergencyContactAddress = "second address",
            SocialSecurityNumber = "123-45-6789",
            Ethnicity = 3,
            Gender = 1,
            EmploymentTypeIds = new[] { 1, 2, 3 },
            RegistryNumber = "122e45ha8il0ee3pjb",
            RegistryDate = DateTime.Now,
            NationalProviderIdentity = "123p5j78bh",
            ProfessionalLicenseNumber = "212jsjjshaileeparth9i",
            Signatures = new List<Signature>()
            {
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 1
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 2
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 3
                }
            }
        };

        // Action
        var result = await _applicantsFixture.AddApplicantAsync(request);

        _applicantId = result.Id;

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(2)]
    public async Task MedicalsOtherRequirements_ShouldSaveMedicalsRequirements_Success()
    {
        // Arrange
        MedicalsApplicantValue data = new()
        {
            ApplicantId = _applicantId,
            ComplianceExpItemId = 1,
            Value = "Test value"
        };

        // Action
        var result = await _medicalsOtherFixture.SaveMedicalsRequirements(_applicantId, data);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(3)]
    public async Task MedicalsOtherRequirements_ShouldGetMedicalsRequirements_Success()
    {
        // Action
        var result = await _medicalsOtherFixture.GetMedicalsRequirements(_applicantId, _officeId);

        // Assert
        Assert.NotEmpty(result);
    }

    [Fact, TestPriority(4)]
    public async Task MedicalsOtherRequirements_ShouldSaveOtherRequirements_Success()
    {
        // Arrange
        OtherApplicantValue data = new()
        {
            ApplicantId = _applicantId,
            ComplianceExpItemId = 1,
            Value = "Test value"
        };

        // Action
        var result = await _medicalsOtherFixture.SaveOtherRequirements(_applicantId, data);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(5)]
    public async Task MedicalsOtherRequirements_ShouldGetOtherRequirements_Success()
    {
        // Action
        var result = await _medicalsOtherFixture.GetOtherRequirements(_applicantId, _officeId);

        // Assert
        Assert.NotEmpty(result);
    }
}
