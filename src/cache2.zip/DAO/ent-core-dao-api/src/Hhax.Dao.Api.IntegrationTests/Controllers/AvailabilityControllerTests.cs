﻿using Hhax.Dao.Api.IntegrationTests.Common.Attributes;
using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Availability;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

[TestCaseOrderer("Hhax.Dao.Api.IntegrationTests.Common.PriorityOrderer", "Hhax.Dao.Api.IntegrationTests")]
public class AvailabilityControllerTests
{
    private readonly AvailabilityFixture _availabilityFixture;
    private readonly ApplicantsFixture _applicantsFixture;
    private static int _applicantId = 0;

    public AvailabilityControllerTests()
    {
        _availabilityFixture = new AvailabilityFixture();
        _applicantsFixture = new ApplicantsFixture();
    }

    [Fact, TestPriority(1)]
    public async Task Availability_ShouldAddApplicant_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            ApplicationLanguageId = 2,
            FirstName = "demo",
            LastName = "for availability",
            OfficeId = 851,
            FirstEmergencyContactAddress = "test address",
            SecondEmergencyContactAddress = "second address",
            DateOfBirth = DateTime.Now,
            SocialSecurityNumber = "123-45-6789",
            Ethnicity = 3,
            Gender = 1,
            EmploymentTypeIds = new[] { 1, 2, 3 },
            RegistryNumber = "122e45ha8il0ee3pjb",
            RegistryDate = DateTime.Now,
            NationalProviderIdentity = "123p5j78bh",
            ProfessionalLicenseNumber = "212jsjjshaileeparth9i",
            Signatures = new List<Signature>()
            {
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 1
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 2
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 3
                }
            }
        };

        // Action
        var result = await _applicantsFixture.AddApplicantAsync(request);

        _applicantId = result.Id;

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(2)]
    public async Task Availability_ShouldGetPreferences_Success()
    {
        // Arrange

        // Action
        var result = await _availabilityFixture.GetPreferencesAsync();

        // Assert
        Assert.NotNull(result);
        Assert.NotEmpty(result);
    }

    [Fact, TestPriority(3)]
    public async Task Availability_ShouldSetupApplicantAvailability_Success()
    {
        // Arrange
        IEnumerable<AvailabilityDay> days = new List<AvailabilityDay>
        {
            new(){ DayType = 1, MaxVisits = 2, TimeShifts = new() { new() { PreferenceId = 1, From = "10:00", To = "11:00" } } },
            new(){ DayType = 2, MaxVisits = 4, TimeShifts = new() { new() { PreferenceId = 2, From = "14:00", To = "15:00" } } },
            new(){ DayType = 3, MaxVisits = 6, TimeShifts = new() { new() { PreferenceId = 2, IsLiveIn = true } } },
        };

        ApplicantAvailability availability = new(days)
        {
            Signature = new()
            {
                Value = "Parth B",
                TimeStamp = DateTime.UtcNow
            }
        };

        // Action
        var result = await _availabilityFixture.SetupApplicantAvailabilityAsync(_applicantId, availability);

        // Assert
        Assert.NotNull(result);
        Assert.NotEmpty(result.Ids);
    }

    [Fact, TestPriority(4)]
    public async Task Availability_ShouldGetApplicantAvailability_Success()
    {
        // Arrange

        // Action
        var result = await _availabilityFixture.GetApplicantAvailabilityAsync(_applicantId);

        // Assert
        Assert.NotNull(result);
        Assert.NotEmpty(result.Days);
        Assert.Contains(result.Days, x => x.Id > 0);
    }

    [Fact, TestPriority(5)]
    public async Task Availability_ShouldDeleteApplicant_Success()
    {
        // Arrange & Action
        await _applicantsFixture.DeleteApplicantAsync(_applicantId);

        // Assert
        Assert.True(true);
    }
}
