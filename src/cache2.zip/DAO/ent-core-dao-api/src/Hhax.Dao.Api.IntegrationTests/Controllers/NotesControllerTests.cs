﻿using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Notes;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

public class NotesControllerTests : IClassFixture<NotesFixture>
{
    private static readonly int _applicantId = 911;
    private readonly NotesFixture _notesFixture = new();

    [Fact(Skip = "Table Data Overflow")]
    public async Task Notes_ShouldAddApplicantNotes_Success()
    {
        // Arrange
        AddApplicantNoteRequest request = new()
        {
            ApplicantId = _applicantId,
            Note = "Glorious Purpose - For All Time, Always",
            Status = "OK",
        };

        // Action 
        var result = await _notesFixture.AddApplicantNoteAsync(request);

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task Notes_ShouldGetApplicantNotes_Success()
    {
        // Arrange
        var request = new PaginationRequest<GetApplicantNotesRequest>() { Page = new Page() { PageNumber = 1, PageSize = 5 } };

        // Action 
        var result = await _notesFixture.GetApplicantNotesAsync(_applicantId, request);

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task Notes_ShouldGetNoteSubjects_Success()
    {
        // Action 
        var result = await _notesFixture.GetNoteSubjects();

        // Assert
        Assert.NotNull(result);
    }
}
