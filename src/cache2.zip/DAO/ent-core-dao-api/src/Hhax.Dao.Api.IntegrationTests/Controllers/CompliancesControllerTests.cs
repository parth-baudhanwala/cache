﻿using Hhax.Dao.Api.IntegrationTests.Common.Attributes;
using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Compliance;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

[TestCaseOrderer("Hhax.Dao.Api.IntegrationTests.Common.PriorityOrderer", "Hhax.Dao.Api.IntegrationTests")]
public class CompliancesControllerTests
{
    private readonly ApplicantsFixture _applicantsFixture;
    private readonly CompliancesFixture _compliancesFixture;

    private static int _applicantId = 0;
    private const int _officeId = 851;

    private static IEnumerable<ComplianceCustomFieldApplicantValue>? _fields;

    public CompliancesControllerTests()
    {
        _applicantsFixture = new ApplicantsFixture();
        _compliancesFixture = new CompliancesFixture();
    }

    [Fact, TestPriority(1)]
    public async Task ComplianceCustomFields_ShouldAddApplicant_Success()
    {
        // Arrange
        var request = new ApplicantAddRequest
        {
            LoginEmail = $"demo-{Guid.NewGuid()}@hha.com",
            Password = "passdemo",
            ApplicationLanguageId = 3,
            FirstName = "demo",
            DateOfBirth = DateTime.Now,
            LastName = "for custom fields",
            OfficeId = _officeId,
            FirstEmergencyContactAddress = "test address",
            SecondEmergencyContactAddress = "second address",
            SocialSecurityNumber = "123-45-6789",
            Ethnicity = 3,
            Gender = 1,
            EmploymentTypeIds = new[] { 1, 2, 3 },
            RegistryNumber = "122e45ha8il0ee3pjb",
            RegistryDate = DateTime.Now,
            NationalProviderIdentity = "123p5j78bh",
            ProfessionalLicenseNumber = "212jsjjshaileeparth9i",
            Signatures = new List<Signature>()
            {
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 1
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 2
                },
                new Signature
                {
                    Value = "Parth B",
                    TimeStamp = DateTime.UtcNow,
                    ApplicantSectionId = 3
                }
            }
        };

        // Action
        var result = await _applicantsFixture.AddApplicantAsync(request);

        _applicantId = result.Id;

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(2)]
    public async Task ComplianceCustomFields_ShouldGetCustomFields_Success()
    {
        // Arrange

        // Action
        var result = await _compliancesFixture.GetCustomFieldsAsync(_applicantId, _officeId);

        // Assert
        Assert.NotNull(result);
        Assert.Null(result.Signature);
        Assert.NotEmpty(result.ComplianceCustomFields);

        _fields = result.ComplianceCustomFields;
    }

    [Fact, TestPriority(3)]
    public async Task ComplianceCustomFields_ShouldSaveCustomFields_Success()
    {
        // Arrange
        ComplianceCustomFieldModel customFieldModel = new(_fields!.Take(1))
        {
            Signature = new()
            {
                Value = "Parth B"
            }
        };

        // Action
        var result = await _compliancesFixture.SaveCustomFieldsAsync(_applicantId, customFieldModel);

        // Assert
        Assert.NotNull(result);
    }
}
