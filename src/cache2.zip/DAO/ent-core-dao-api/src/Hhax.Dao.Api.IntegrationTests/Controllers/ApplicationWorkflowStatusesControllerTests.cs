﻿using Hhax.Dao.Api.IntegrationTests.Common.Attributes;
using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

[TestCaseOrderer("Hhax.Dao.Api.IntegrationTests.Common.PriorityOrderer", "Hhax.Dao.Api.IntegrationTests")]
public class ApplicationWorkflowStatusesControllerTests
{
    private readonly ApplicationWorkflowStatusesFixture _applicationWorkflowStatusesFixture;

    private static int _applicationWorkflowStatusId = 0;

    public ApplicationWorkflowStatusesControllerTests()
    {
        _applicationWorkflowStatusesFixture = new ApplicationWorkflowStatusesFixture();
    }

    [Fact, TestPriority(1)]
    public async Task ApplicationWorkflowStatus_ShouldAddApplicationWorkflowStatus_Success()
    {
        // Arrange
        var paginationRequest = new PaginationRequest<SearchApplicationWorkflowStatusRequest>
        {
            Page = new Page { PageNumber = 1, PageSize = 100 },
            Filters = new SearchApplicationWorkflowStatusRequest()
        };

        var applicationWorkflowStatuses = await _applicationWorkflowStatusesFixture.GetApplicationWorkflowStatusesAsync(paginationRequest);

        var applicationWorkflowStatusesIds = applicationWorkflowStatuses.Data!.Select(x => x.Id).ToArray();
        
        var request = new ApplicationWorkflowStatusRequest
        {
            Name = "NewTestName",
            ColorId = 1,
            NextApplicationWorkflowStatusIds = applicationWorkflowStatusesIds
        };

        // Action
        var result = await _applicationWorkflowStatusesFixture.AddApplicationWorkflowStatusAsync(request);

        _applicationWorkflowStatusId = result.Id;

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(2)]
    public async Task ApplicationWorkflowStatus_ShouldUpdateApplicationWorkflowStatus_Success()
    {
        // Arrange
        var paginationRequest = new PaginationRequest<SearchApplicationWorkflowStatusRequest>
        {
            Page = new Page { PageNumber = 1, PageSize = 100 },
            Filters = new SearchApplicationWorkflowStatusRequest()
        };

        var applicationWorkflowStatuses = await _applicationWorkflowStatusesFixture.GetApplicationWorkflowStatusesAsync(paginationRequest);

        var applicationWorkflowStatusesIds = applicationWorkflowStatuses.Data!.Where(x => x.Id != _applicationWorkflowStatusId).Select(x => x.Id).ToArray();

        var request = new ApplicationWorkflowStatusRequest
        {
            Name = "NewTestName",
            ColorId = 1,
            NextApplicationWorkflowStatusIds = applicationWorkflowStatusesIds
        };

        // Action
        var result = await _applicationWorkflowStatusesFixture.UpdateApplicationWorkflowStatusAsync(_applicationWorkflowStatusId, request);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(3)]
    public async Task ApplicationWorkflowStatus_ShouldGetApplicationWorkflowStatus_Success()
    {
        // Arrange
        
        // Action
        var result = await _applicationWorkflowStatusesFixture.GetApplicationWorkflowStatusAsync(_applicationWorkflowStatusId);
        
        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(4)]
    public async Task ApplicationWorkflowStatus_ShouldGetApplicationWorkflowStatuses_Success()
    {
        // Arrange
        var request = new PaginationRequest<SearchApplicationWorkflowStatusRequest>
        {
            Page = new Page { PageNumber = 1, PageSize = 100 },
            Filters = new SearchApplicationWorkflowStatusRequest
            {
                Name = "Test",
                AgencyId = 1
            }
        };

        // Action
        var result = await _applicationWorkflowStatusesFixture.GetApplicationWorkflowStatusesAsync(request);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(5)]
    public async Task ApplicationWorkflowStatus_ShouldGetApplicationWorkflowStatusBadgeColors_Success()
    {
        // Arrange & Action
        var result = await _applicationWorkflowStatusesFixture.GetApplicationWorkflowStatusBadgeColorsAsync();

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(7)]
    public async Task ApplicationWorkflowStatus_ShouldDeleteApplicationWorkflowStatus_Success()
    {
        // Arrange & Action & Assert
        await _applicationWorkflowStatusesFixture.DeleteApplicationWorkflowStatusAsync(_applicationWorkflowStatusId);
    }
}
