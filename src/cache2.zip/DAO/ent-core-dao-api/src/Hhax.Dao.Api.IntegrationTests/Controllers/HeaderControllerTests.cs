﻿using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers
{
    public class HeaderControllerTests
    {
        private readonly HeaderFixture _featuresFixture;

        public HeaderControllerTests()
        {
            _featuresFixture = new HeaderFixture();
        }

        [Fact]
        public async Task GetSkinInfo_Success()
        {
            var result = await _featuresFixture.GetSkinInfoAsync();

            Assert.NotNull(result);
            Assert.NotNull(result.ENTUrl);
        }

        [Fact]
        public async Task GetNotificationsDetail_Success()
        {
            var result = await _featuresFixture.GetNotificationsDetailAsync();

            Assert.NotNull(result);
            Assert.NotNull(result.UserNotificationMsgCount);
            Assert.NotNull(result.UserNotificationMsgColor);
            Assert.NotNull(result.UserMsgCount);
            Assert.NotNull(result.UserMessageColor);
            Assert.NotNull(result.UserToDoMsgCount);
            Assert.NotNull(result.UserToDoMsgColor);
            Assert.NotNull(result.OpenCaseMsgCount);
            Assert.NotNull(result.OpenCaseMsgColor);
            Assert.NotNull(result.OpenCaseURL);
        }
    }
}
