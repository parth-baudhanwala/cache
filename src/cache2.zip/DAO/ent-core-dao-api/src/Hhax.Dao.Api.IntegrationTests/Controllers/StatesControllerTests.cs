﻿using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Globalization;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

public class StatesControllerTests
{
    private readonly StatesFixture _statesFixture;

    public StatesControllerTests()
    {
        _statesFixture = new StatesFixture();
    }

    [Fact]
    public async Task States_ShouldGetStates_Success()
    {
        // Arrange

        // Action
        var result = await _statesFixture.GetStatesAsync();

        // Assert
        Assert.NotNull(result);
        Assert.NotEmpty(result);
    }

    [Fact]
    public async Task States_ShouldGetCitiesForState_Success()
    {
        // Arrange
        const string stateName = "NY";
        var request = new PaginationRequest<SearchCitiesRequest>
        {
            Filters = new SearchCitiesRequest {
                StateName = stateName
            }
        };

        // Action
        var result = await _statesFixture.GetCitiesForStateAsync(request);

        // Assert
        Assert.NotNull(result);
        Assert.NotEmpty(result);
    }

    [Fact]
    public async Task States_ShouldGetCitiesByName_Success()
    {
        // Arrange
        var request = new PaginationRequest<SearchCitiesRequest> {
             Filters = new SearchCitiesRequest {
                 CityName = "New"
             }
        };

        // Action
        var result = await _statesFixture.GetCitiesByNameAsync(request);

        // Assert
        Assert.NotNull(result);
        Assert.NotEmpty(result);
    }

    [Fact]
    public async Task States_ShouldGetCityByZipCode_Success()
    {
        // Arrange
        const string zipCodeNewYork = "10001";

        var request = new PaginationRequest<SearchCitiesByZipCodeRequest> {
            Filters = new SearchCitiesByZipCodeRequest {
                ZipCode = zipCodeNewYork
            }
        };

        // Action
        var result = await _statesFixture.GetCityByZipAsync(request);

        // Assert
        Assert.NotNull(result);
    }
}
