﻿using Hhax.Dao.Api.IntegrationTests.Common.Attributes;
using Hhax.Dao.Api.IntegrationTests.Fixtures;
using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Xunit;

namespace Hhax.Dao.Api.IntegrationTests.Controllers;

[TestCaseOrderer("Hhax.Dao.Api.IntegrationTests.Common.PriorityOrderer", "Hhax.Dao.Api.IntegrationTests")]
public class HumanResourcePersonasControllerTests
{
    private readonly HumanResourcePersonasFixture _hrPersonasFixture;

    private static int _humanResourcePersonasId = 0;

    public HumanResourcePersonasControllerTests()
    {
        _hrPersonasFixture = new HumanResourcePersonasFixture();
    }

    [Fact, TestPriority(1)]
    public async Task HumanResourcePersona_ShouldAddHumanResourcePersona_Success()
    {
        // Arrange
        var request = new HumanResourcePersonaRequest
        {
            Name = "TestName",
            StatusId = 1,
            UserId = 2,
            Offices = "Offices",
            OfficeIds = new int[] { 1, 2}
        };
        // Action
        var result = await _hrPersonasFixture.AddHumanResourcePersonaAsync(request);

        _humanResourcePersonasId = result.Id;

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(2)]
    public async Task HumanResourcePersona_ShouldUpdateHumanResourcePersona_Success()
    {
        // Arrange

        var parameters = new HumanResourcePersonaRequest
        {
            Name = "TestNameTest",
            StatusId = 1,
            UserId = 3,
            Offices = "Offices",
            OfficeIds = new int[] { 2, 3 }
        };

        // Action
        var result = await _hrPersonasFixture.UpdateHumanResourcePersonaAsync(_humanResourcePersonasId, parameters);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(3)]
    public async Task HumanResourcePersona_ShouldGetHumanResourcePersona_Success()
    {
        // Arrange
       
        // Action
        var result = await _hrPersonasFixture.GetHumanResourcePersonaAsync(_humanResourcePersonasId);
       
        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(4)]
    public async Task HumanResourcePersona_ShouldGetHumanResourcePersonas_Success()
    {
        // Arrange
        var request = new PaginationRequest<SearchHumanResourcePersonaRequest>
        {
            Page = new Page { PageNumber = 1, PageSize = 100 },
            Filters = new SearchHumanResourcePersonaRequest
            {
                Name = "Test",
                StatusId = 1,
                Offices = "2, 4"
            }
        };

        // Action
        var result = await _hrPersonasFixture.GetHumanResourcePersonasAsync(request);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(5)]
    public async Task HumanResourcePersona_ShouldGetHumanResourcePersonaStatuses_Success()
    {
        // Action
        var result = await _hrPersonasFixture.GetHumanResourcePersonaStatusesAsync();

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(6)]
    public async Task HumanResourcePersona_ShouldGetUsersAsync_Success()
    {
        // Arrange
        const int agencyId = 691;

        // Action
        var result = await _hrPersonasFixture.GetUsersAsync(agencyId);

        // Assert
        Assert.NotNull(result);
    }

    [Fact, TestPriority(7)]
    public async Task HumanResourcePersona_ShouldDeleteHumanResourcePersona_Success()
    {
        // Arrange & Action & Assert
        await _hrPersonasFixture.DeleteHumanResourcePersonaStatuseAsync(_humanResourcePersonasId);
    }
}
