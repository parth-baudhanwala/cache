﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Compliance;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class CompliancesFixture : ApplicationFixture
{
    public async Task<ComplianceCustomFieldModel> GetCustomFieldsAsync(int applicantId, int officeId)
    {
        var requestUri = $"/api/v1/compliances/custom-fields/{applicantId}?officeId={officeId}";

        ComplianceCustomFieldModel? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<ComplianceCustomFieldModel>();
        }

        return result!;
    }

    public async Task<BaseRangeResponse> SaveCustomFieldsAsync(int applicantId, ComplianceCustomFieldModel customFieldModel)
    {
        var requestUri = $"/api/v1/compliances/custom-fields/{applicantId}";

        BaseRangeResponse? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PutAsJsonAsync(requestUri, customFieldModel);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseRangeResponse>();
        }

        return result!;
    }
}
