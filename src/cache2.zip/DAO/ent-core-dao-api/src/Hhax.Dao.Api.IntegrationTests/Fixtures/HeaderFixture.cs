﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Responses.Feature;
using Hhax.Dao.Application.Abstracts.Responses.Header;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures
{
    internal class HeaderFixture : ApplicationFixture
    {
        public async Task<SkinFeatureInfoResponse> GetSkinInfoAsync()
        {
            var requestUri = $"/api/v1/header/skin-info";

            SkinFeatureInfoResponse? result;

            using (var client = CreateHttpClient())
            {
                var response = await client.GetAsync(requestUri);

                if (!response.IsSuccessStatusCode)
                {
                    var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                    throw new ApplicationException(errorInfo?.Message);
                }

                result = await response.Content.ReadFromJsonAsync<SkinFeatureInfoResponse>();
            }

            return result!;
        }

        public async Task<NotificationsDetailResponse> GetNotificationsDetailAsync()
        {
            var requestUri = $"/api/v1/header/notifications";

            NotificationsDetailResponse? result;

            using (var client = CreateHttpClient())
            {
                var response = await client.GetAsync(requestUri);

                if (!response.IsSuccessStatusCode)
                {
                    var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                    throw new ApplicationException(errorInfo?.Message);
                }

                result = await response.Content.ReadFromJsonAsync<NotificationsDetailResponse>();
            }

            return result!;
        }
    }
}
