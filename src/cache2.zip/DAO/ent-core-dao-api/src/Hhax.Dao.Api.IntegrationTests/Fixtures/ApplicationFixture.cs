﻿using Hhax.Dao.Api.IntegrationTests.Authentication;
using Hhax.Dao.Api.IntegrationTests.Extensions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class ApplicationFixture : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        const string defaultScheme = "Test Scheme";

        base.ConfigureWebHost(builder);

        builder.ConfigureTestServices(servicesConfiguration =>
        {
            servicesConfiguration.AddAuthentication(configure =>
            {
                configure.DefaultAuthenticateScheme = defaultScheme;
                configure.DefaultChallengeScheme = defaultScheme;
            }).AddTestAuth(configure => { });
            servicesConfiguration.ConfigureIdentityApiClient();
        });
    }

    protected HttpClient CreateHttpClient()
    {
        const string baseAddress = "https://localhost:17442";

        var client = Server.CreateClient();
        client.BaseAddress = new Uri(baseAddress);

        return client;
    }
}
