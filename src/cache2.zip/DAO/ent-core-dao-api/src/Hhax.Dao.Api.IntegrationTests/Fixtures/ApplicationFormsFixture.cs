using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Compliance;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Common;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class ApplicationFormsFixture : ApplicationFixture
{
    public async Task<BaseEntity> AddApplicationFormAsync(ApplicationFormRequest request)
    {
        const string requestUri = "/api/v1/application-forms";

        BaseEntity? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PostAsJsonAsync(requestUri, request);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseEntity>();
        }

        return result!;
    }

    public async Task<BaseEntity> UpdateApplicationFormAsync(int applicationFormId, ApplicationFormRequest request)
    {
        var requestUri = $"/api/v1/application-forms/{applicationFormId}";

        BaseEntity? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PutAsJsonAsync(requestUri, request);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseEntity>();
        }

        return result!;
    }

    public async Task<ApplicationForm> GetApplicationFormAsync(int applicationFormId)
    {
        var requestUri = $"/api/v1/application-forms/{applicationFormId}";

        ApplicationForm? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<ApplicationForm>();
        }

        return result!;
    }

    public async Task DeleteApplicationFormAsync(int applicationFormId)
    {
        var requestUri = $"/api/v1/application-forms/{applicationFormId}";

        using var client = CreateHttpClient();
        var response = await client.DeleteAsync(requestUri);

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        await response.Content.ReadAsStringAsync();
    }

    public async Task<IEnumerable<ApplicationForm>> GetApplicationFormStatusesAsync()
    {
        const string requestUri = "/api/v1/application-forms/statuses";

        IEnumerable<ApplicationForm>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<ApplicationForm>>();
        }

        return result!;
    }

    public async Task<CompliancesResponse> GetOfficesGroupedByComplianceAsync(int applicationFormId)
    {
        var requestUri = $"/api/v1/application-forms/compliances?applicationFormId={applicationFormId}";

        CompliancesResponse? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<CompliancesResponse>();
        }

        return result!;
    }

    public async Task<string> GetLinkToApplicationFormByOfficeAsync(int officeId)
    {
        var requestUri = $"/api/v1/application-forms/link/{officeId}";

        var result = string.Empty;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadAsStringAsync();
        }

        return result;
    }

    public async Task<PaginatationResponse<ApplicationFormInfo>> GetApplicationFormsAsync(PaginationRequest<GetApplicationFormRequest> parameters)
    {
        var requestUri = $"/api/v1/application-forms?page.pageNumber={parameters?.Page?.PageNumber}&page.pageSize={parameters?.Page?.PageSize}&filters.setupName={parameters?.Filters?.SetupName}";

        PaginatationResponse<ApplicationFormInfo>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<PaginatationResponse<ApplicationFormInfo>>();
        }

        return result!;
    }

    public async Task<IEnumerable<ApplicationFormApplicantSection>> GetApplicationFormApplicantSectionsAsync()
    {
        const string requestUri = "/api/v1/application-forms/applicant-sections";

        IEnumerable<ApplicationFormApplicantSection>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<ApplicationFormApplicantSection>>();
        }

        return result!;
    }

    public async Task<IEnumerable<ApplicationFormApplicantRequirement>> GetApplicationFormApplicantRequirementsAsync(Guid uniqueUrlId)
    {
        var requestUri = $"/api/v1/application-forms/applicant-requirements/{uniqueUrlId}";

        IEnumerable<ApplicationFormApplicantRequirement>? result;

        using var client = CreateHttpClient();
        var response = await client.GetAsync(requestUri);

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        result = await response.Content.ReadFromJsonAsync<IEnumerable<ApplicationFormApplicantRequirement>>();

        return result!;
    }
}
