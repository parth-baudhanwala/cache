﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Notes;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Notes;
using Newtonsoft.Json;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class NotesFixture : ApplicationFixture
{
    public async Task<BaseResponse> AddApplicantNoteAsync(AddApplicantNoteRequest request)
    {
        string requestUri = "/api/v1/notes/applicant-notes";

        BaseResponse response;
        HttpResponseMessage httpResponse;

        using (var client = CreateHttpClient())
        {
            httpResponse = await client.PostAsJsonAsync(requestUri, request);
        }

        if (!httpResponse.IsSuccessStatusCode)
        {
            var errorInfo = await httpResponse.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        using (var content = httpResponse.Content)
        {
            string responseString = await content.ReadAsStringAsync();
            response = JsonConvert.DeserializeObject<BaseResponse>(responseString) ?? new();
        }

        return response;
    }

    public async Task<PaginatationResponse<ApplicantNoteInfo>> GetApplicantNotesAsync(int applicantId, PaginationRequest<GetApplicantNotesRequest> request)
    {
        var requestUri = $"/api/v1/notes/applicant-notes/{applicantId}?page.pageNumber={request!.Page!.PageNumber}&page.pageSize={request.Page.PageSize}";

        PaginatationResponse<ApplicantNoteInfo> result;
        HttpResponseMessage httpResponse;

        using (var client = CreateHttpClient())
        {
            httpResponse = await client.GetAsync(requestUri);
        }

        if (!httpResponse.IsSuccessStatusCode)
        {
            var errorInfo = await httpResponse.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        using (var content = httpResponse.Content)
        {
            string responseString = await content.ReadAsStringAsync();
            result = JsonConvert.DeserializeObject<PaginatationResponse<ApplicantNoteInfo>>(responseString) ?? new();
        }

        return result;
    }

    public async Task<IEnumerable<NoteSubject>> GetNoteSubjects()
    {
        string requestUri = "/api/v1/notes/note-subjects";

        IEnumerable<NoteSubject> result;
        HttpResponseMessage httpResponse;

        using (var client = CreateHttpClient())
        {
            httpResponse = await client.GetAsync(requestUri);
        }

        if (!httpResponse.IsSuccessStatusCode)
        {
            var errorInfo = await httpResponse.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        using (var content = httpResponse.Content)
        {
            string responseString = await content.ReadAsStringAsync();
            result = JsonConvert.DeserializeObject<IEnumerable<NoteSubject>>(responseString) ?? Enumerable.Empty<NoteSubject>();
        }

        return result;
    }
}
