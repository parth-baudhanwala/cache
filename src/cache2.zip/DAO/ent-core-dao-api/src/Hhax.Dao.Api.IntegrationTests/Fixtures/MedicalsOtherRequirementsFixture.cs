﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.MedicalsOther;
using MimeKit;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class MedicalsOtherRequirementsFixture : ApplicationFixture
{
    public async Task<BaseResponse> SaveMedicalsRequirements(int applicantId, MedicalsApplicantValue data)
    {
        const string contentType = "multipart/form-data";

        var requestUri = $"/api/v1/medicals-other-requirements/medicals/{applicantId}";
        BaseResponse? result;

        using (var client = CreateHttpClient())
        {
            using var multipartFormContent = new MultipartFormDataContent
            {
                { new StringContent(data.Id.ToString(), Encoding.UTF8, contentType), "id" },
                { new StringContent(data.Value!, Encoding.UTF8, contentType), "value" },
                { new StringContent(data.ComplianceExpItemId.ToString(), Encoding.UTF8, contentType), "complianceExpItemId" }
            };

            var response = await client.PutAsync(requestUri, multipartFormContent);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseResponse>();
        }

        return result!;
    }

    public async Task<IEnumerable<MedicalsApplicantValue>> GetMedicalsRequirements(int applicantId, int officeId)
    {
        var requestUri = $"/api/v1/medicals-other-requirements/medicals/{applicantId}?officeId={officeId}";

        IEnumerable<MedicalsApplicantValue>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<MedicalsApplicantValue>>();
        }

        return result!;
    }

    public async Task<BaseResponse> SaveOtherRequirements(int applicantId, OtherApplicantValue data)
    {
        const string contentType = "multipart/form-data";

        var requestUri = $"/api/v1/medicals-other-requirements/other/{applicantId}";
        BaseResponse? result;

        using (var client = CreateHttpClient())
        {
            using var multipartFormContent = new MultipartFormDataContent
            {
                { new StringContent(data.Id.ToString(), Encoding.UTF8, contentType), "id" },
                { new StringContent(data.Value!, Encoding.UTF8, contentType), "value" },
                { new StringContent(data.ComplianceExpItemId.ToString(), Encoding.UTF8, contentType), "complianceExpItemId" }
            };

            var response = await client.PutAsync(requestUri, multipartFormContent);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseResponse>();
        }

        return result!;
    }

    public async Task<IEnumerable<OtherApplicantValue>> GetOtherRequirements(int applicantId, int officeId)
    {
        var requestUri = $"/api/v1/medicals-other-requirements/other/{applicantId}?officeId={officeId}";

        IEnumerable<OtherApplicantValue>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<OtherApplicantValue>>();
        }

        return result!;
    }
}
