﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Availability;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class AvailabilityFixture : ApplicationFixture
{
    public async Task<IEnumerable<WorkPreference>> GetPreferencesAsync()
    {
        var requestUri = $"/api/v1/availability/work-preferences";

        IEnumerable<WorkPreference>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<WorkPreference>>();
        }

        return result!;
    }

    public async Task<ApplicantAvailability> GetApplicantAvailabilityAsync(int applicantId)
    {
        var requestUri = $"/api/v1/availability/{applicantId}";

        ApplicantAvailability? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<ApplicantAvailability>();
        }

        return result!;
    }

    public async Task<BaseRangeResponse> SetupApplicantAvailabilityAsync(int applicantId, ApplicantAvailability availability)
    {
        var requestUri = $"/api/v1/availability/{applicantId}/days";

        BaseRangeResponse? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PutAsJsonAsync(requestUri, availability);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseRangeResponse>();
        }

        return result!;
    }
}
