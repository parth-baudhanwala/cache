﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Compliance;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Abstracts.Responses.Compliance;
using Hhax.Dao.Domain.Office;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class OfficesFixture : ApplicationFixture
{
    public async Task<IEnumerable<OfficeInfo>> GetOfficesAsync()
    {
        const string requestUri = "/api/v1/offices";

        IEnumerable<OfficeInfo>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<OfficeInfo>>();
        }

        return result!;
    }

    public async Task<ComplianceSetupsValidationResponse> ValidateOfficeComplianceSetupsAsync(OfficeComplianceRequest request)
    {
        const string requestUri = "/api/v1/offices/compliances/setups/validate";

        ComplianceSetupsValidationResponse? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PostAsJsonAsync(requestUri, request);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<ComplianceSetupsValidationResponse>();
        }

        return result!;
    }

    public async Task<byte[]> GetImageAsync(int officeId, OfficeImageRequest request)
    {
        var requestUri = $"/api/v1/Offices/{officeId}/image?Type={request.Type}";

        byte[] result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadAsByteArrayAsync();
        }

        return result;
    }

    public async Task<string> GetImageUrlAsync(int officeId, OfficeImageRequest request)
    {
        var requestUri = $"/api/v1/Offices/{officeId}/image-url?Type={request.Type}";

        var result = string.Empty;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadAsStringAsync();
        }

        return result;
    }

    public async Task<string> UploadImageAsync(int officeId, UploadOfficeImageRequest request, byte[] file)
    {
        var requestUri = $"/api/v1/Offices/{officeId}/image?type={request.Type}&height={request.Height}&width={request.Width}";

        var result = string.Empty;

        using (var client = CreateHttpClient())
        {
            using var multipartFormContent = new MultipartFormDataContent();

            var byteArrayContent = new ByteArrayContent(file);
            byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("image/png");
            multipartFormContent.Add(byteArrayContent, name: "file", fileName: "logo.png");

            var jsonPart = new StringContent(JsonSerializer.Serialize(request).ToString());
            jsonPart.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await client.PostAsync(requestUri, multipartFormContent);
            response.EnsureSuccessStatusCode();

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadAsStringAsync();
        }

        return result;
    }
}
