﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Office;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Domain.Office;
using Hhax.Dao.Domain.User;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class HumanResourcePersonasFixture : ApplicationFixture
{
    public async Task<BaseEntity> AddHumanResourcePersonaAsync(HumanResourcePersonaRequest request)
    {
        const string requestUri = "/api/v1/human-resource-personas";

        BaseEntity? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PostAsJsonAsync(requestUri, request);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseEntity>();
        }

        return result!;
    }

    public async Task<BaseEntity> UpdateHumanResourcePersonaAsync(int humanResourcePersonaId, HumanResourcePersonaRequest request)
    {
        string requestUri = $"/api/v1/human-resource-personas/{humanResourcePersonaId}";

        BaseEntity? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PutAsJsonAsync(requestUri, request);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseEntity>();
        }

        return result!;
    }

    public async Task<HumanResourcePersona> GetHumanResourcePersonaAsync(int humanResourcePersonaId)
    {
        string requestUri = $"/api/v1/human-resource-personas/{humanResourcePersonaId}";

        HumanResourcePersona? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<HumanResourcePersona>();
        }

        return result!;
    }

    public async Task<PaginatationResponse<HumanResourcePersona>> GetHumanResourcePersonasAsync(PaginationRequest<SearchHumanResourcePersonaRequest> request)
    {

        var requestUri = $"/api/v1/human-resource-personas?page.pageNumber={request!.Page!.PageNumber}&page.pageSize={request.Page.PageSize}" +
            $"&filters.name={request.Filters!.Name}&filters.StatusId={request.Filters!.StatusId}&filters.Offices={request.Filters!.Offices}";

        PaginatationResponse<HumanResourcePersona>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<PaginatationResponse<HumanResourcePersona>>();
        }

        return result!;
    }

    public async Task<IEnumerable<HumanResourcePersonaStatus>> GetHumanResourcePersonaStatusesAsync()
    {
        const string requestUri = "/api/v1/human-resource-personas/statuses";

        IEnumerable<HumanResourcePersonaStatus>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<HumanResourcePersonaStatus>>();
        }

        return result!;
    }

    public async Task<IEnumerable<UserInfo>> GetUsersAsync(int agencyId)
    {
        string requestUri = $"/api/v1/human-resource-personas/users?agencyId={agencyId}";

        IEnumerable<UserInfo>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<UserInfo>>();
        }

        return result!;
    }

    public async Task DeleteHumanResourcePersonaStatuseAsync(int humanResourcePersonaId)
    {
        var requestUri = $"/api/v1/human-resource-personas/{humanResourcePersonaId}";

        using var client = CreateHttpClient();
        var response = await client.DeleteAsync(requestUri);

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        await response.Content.ReadAsStringAsync();
    }
}
