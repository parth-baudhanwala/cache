﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Common;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class ApplicationWorkflowStatusesFixture : ApplicationFixture
{
    public async Task<BaseEntity> AddApplicationWorkflowStatusAsync(ApplicationWorkflowStatusRequest request)
    {
        const string requestUri = "/api/v1/application-workflow-statuses";

        BaseEntity? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PostAsJsonAsync(requestUri, request);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseEntity>();
        }

        return result!;
    }

    public async Task<BaseEntity> UpdateApplicationWorkflowStatusAsync(int applicationWorkflowStatusId, ApplicationWorkflowStatusRequest request)
    {
        string requestUri = $"/api/v1/application-workflow-statuses/{applicationWorkflowStatusId}";

        BaseEntity? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PutAsJsonAsync(requestUri, request);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseEntity>();
        }

        return result!;
    }

    public async Task<ApplicationWorkflowStatus> GetApplicationWorkflowStatusAsync(int applicationWorkflowStatusId)
    {
        string requestUri = $"/api/v1/application-workflow-statuses/{applicationWorkflowStatusId}";

        ApplicationWorkflowStatus? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<ApplicationWorkflowStatus>();
        }

        return result!;
    }

    public async Task<PaginatationResponse<ApplicationWorkflowStatus>> GetApplicationWorkflowStatusesAsync(PaginationRequest<SearchApplicationWorkflowStatusRequest> request)
    {
        var requestUri = $"/api/v1/application-workflow-statuses?page.pageNumber={request?.Page?.PageNumber}&page.pageSize={request?.Page?.PageSize}" +
            $"&filters.name={request?.Filters?.Name}&filters.agencyId={request?.Filters?.AgencyId}";

        PaginatationResponse<ApplicationWorkflowStatus>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<PaginatationResponse<ApplicationWorkflowStatus>>();
        }

        return result!;
    }

    public async Task<IEnumerable<ApplicationWorkflowStatusBadgeColor>> GetApplicationWorkflowStatusBadgeColorsAsync()
    {
        const string requestUri = "/api/v1/application-workflow-statuses/colors";

        IEnumerable<ApplicationWorkflowStatusBadgeColor>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<ApplicationWorkflowStatusBadgeColor>>();
        }

        return result!;
    }


    public async Task DeleteApplicationWorkflowStatusAsync(int applicationWorkflowStatusId)
    {
        var requestUri = $"/api/v1/application-workflow-statuses/{applicationWorkflowStatusId}";

        using var client = CreateHttpClient();
        var response = await client.DeleteAsync(requestUri);

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        await response.Content.ReadAsStringAsync();
    }
}
