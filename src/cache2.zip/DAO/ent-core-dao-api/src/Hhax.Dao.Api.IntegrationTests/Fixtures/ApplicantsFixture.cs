﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Application;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Responses.Common;
using Hhax.Dao.Domain.Application;
using Hhax.Dao.Domain.Common;
using Hhax.Dao.Domain.Globalization;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class ApplicantsFixture : ApplicationFixture
{
    public async Task<BaseEntity> AddApplicantAsync(ApplicantAddRequest request)
    {
        const string requestUri = "/api/v1/applicants";

        BaseEntity? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.PostAsJsonAsync(requestUri, request);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<BaseEntity>();
        }

        return result!;
    }

    public async Task UpdateApplicantAsync(int applicantId, ApplicantUpdateRequest request)
    {
        var requestUri = $"/api/v1/applicants/{applicantId}";

        using var client = CreateHttpClient();
        var response = await client.PutAsJsonAsync(requestUri, request);

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        await response.Content.ReadAsStringAsync();
    }

    public async Task DeleteApplicantAsync(int applicantId)
    {
        var requestUri = $"/api/v1/applicants/{applicantId}";

        using var client = CreateHttpClient();
        var response = await client.DeleteAsync(requestUri);

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        await response.Content.ReadAsStringAsync();
    }

    public async Task<Applicant> GetApplicantAsync(int applicantId)
    {
        var requestUri = $"/api/v1/applicants/{applicantId}";

        Applicant? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<Applicant>();
        }

        return result!;
    }

    public async Task<PaginatationResponse<Applicant>> GetApplicantsAsync(PaginationRequest<SearchApplicantsRequest> request)
    {
        var requestUri = $"/api/v1/applicants?page.pageNumber={request!.Page!.PageNumber}&page.pageSize={request.Page.PageSize}&filters.search={request.Filters!.ApplicantName}";

        PaginatationResponse<Applicant>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<PaginatationResponse<Applicant>>();
        }

        return result!;
    }

    public async Task CheckApplicantEligibilitiesAsync(int applicantId)
    {
        var requestUri = $"/api/v1/applicants/{applicantId}/applicant-eligibilities";

        using var client = CreateHttpClient();
        var response = await client.PostAsync(requestUri, new StringContent(string.Empty));

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }
    }

    public async Task<IEnumerable<ApplicantEligibility>> GetApplicantEligibilitiesAsync(int applicantId)
    {
        var requestUri = $"/api/v1/applicants/{applicantId}/applicant-eligibilities";

        IEnumerable<ApplicantEligibility>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<ApplicantEligibility>>();
        }

        return result!;
    }

    public async Task<IEnumerable<LanguageProficiency>> GetLanguageProficienciesAsync()
    {
        var requestUri = "/api/v1/applicants/language-proficiencies";

        IEnumerable<LanguageProficiency>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<LanguageProficiency>>();
        }

        return result!;
    }

    public async Task<IEnumerable<Ethnicity>> GetEthnicity()
    {
        var requestUri = "/api/v1/applicants/ethnicity";

        IEnumerable<Ethnicity>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<Ethnicity>>();
        }

        return result!;
    }

    public async Task<IEnumerable<Gender>> GetGender(int officeId)
    {
        var requestUri = $"/api/v1/applicants/gender?officeId={officeId}";

        IEnumerable<Gender>? result;

        using (var client = CreateHttpClient())
        {
            var response = await client.GetAsync(requestUri);

            if (!response.IsSuccessStatusCode)
            {
                var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
                throw new ApplicationException(errorInfo?.Message);
            }

            result = await response.Content.ReadFromJsonAsync<IEnumerable<Gender>>();
        }

        return result!;
    }

    public async Task UpdateApplicantActivityStatusAsync(bool isActive, int[] applicantIds)
    {
        string requestUri = $"/api/v1/applicants/set-activity-status/{isActive}";

        using var client = CreateHttpClient();
        var response = await client.PutAsJsonAsync(requestUri, applicantIds);

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }
    }
}
