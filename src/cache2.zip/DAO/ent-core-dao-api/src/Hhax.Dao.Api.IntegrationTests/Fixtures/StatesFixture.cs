﻿using Hhax.Dao.Application.Abstracts.Common;
using Hhax.Dao.Application.Abstracts.Requests.Common;
using Hhax.Dao.Application.Abstracts.Requests.Globalization;
using Hhax.Dao.Domain.Globalization;
using Newtonsoft.Json;
using System.Net.Http.Json;

namespace Hhax.Dao.Api.IntegrationTests.Fixtures;

internal class StatesFixture : ApplicationFixture
{
    public async Task<IEnumerable<State>> GetStatesAsync()
    {
        var requestUri = $"/api/v1/states";

        IEnumerable<State> result;
        HttpResponseMessage response;

        using (var client = CreateHttpClient())
        {
            response = await client.GetAsync(requestUri);
        }

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        using (var content = response.Content)
        {
            string responseString = await content.ReadAsStringAsync();
            result = JsonConvert.DeserializeObject<IEnumerable<State>>(responseString) ?? Enumerable.Empty<State>();
        }

        return result;
    }

    public async Task<IEnumerable<City>> GetCitiesForStateAsync(PaginationRequest<SearchCitiesRequest> request)
    {
        var requestUri = $"/api/v1/states/cities?filters.StateName={request?.Filters?.StateName}";

        IEnumerable<City> result;
        HttpResponseMessage response;

        using (var client = CreateHttpClient())
        {
            response = await client.GetAsync(requestUri);
        }

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        using (var content = response.Content)
        {
            string responseString = await content.ReadAsStringAsync();
            result = JsonConvert.DeserializeObject<IEnumerable<City>>(responseString) ?? Enumerable.Empty<City>();
        }

        return result;
    }

    public async Task<IEnumerable<City>> GetCitiesByNameAsync(PaginationRequest<SearchCitiesRequest> request)
    {
        var requestUri = $"/api/v1/states/cities?filters.CityName={request?.Filters?.CityName}";

        IEnumerable<City> result;
        HttpResponseMessage response;

        using (var client = CreateHttpClient())
        {
            response = await client.GetAsync(requestUri);
        }

        if (!response.IsSuccessStatusCode)
        {
            var errorInfo = await response.Content.ReadFromJsonAsync<ErrorInfo>();
            throw new ApplicationException(errorInfo?.Message);
        }

        using (var content = response.Content)
        {
            string responseString = await content.ReadAsStringAsync();
            result = JsonConvert.DeserializeObject<IEnumerable<City>>(responseString) ?? Enumerable.Empty<City>();
        }

        return result;
    }

    public async Task<IEnumerable<City>> GetCityByZipAsync(PaginationRequest<SearchCitiesByZipCodeRequest> request)
    {
        var requestUri = $"/api/v1/states/cities?filters.ZipCode={request?.Filters?.ZipCode}";

        IEnumerable<City> result;
        HttpResponseMessage response;

        using (var client = CreateHttpClient())
        {
            try
            {
                response = await client.GetAsync(requestUri);
            }
            catch
            {
                return Enumerable.Empty<City>();
            }

            response.EnsureSuccessStatusCode();

            using var content = response.Content;

            if (content.Headers.ContentLength.GetValueOrDefault() == 0)
            {
                return Enumerable.Empty<City>();
            }

            result = await content.ReadFromJsonAsync<IEnumerable<City>>() ?? Enumerable.Empty<City>();
        }

        return result;
    }
}
