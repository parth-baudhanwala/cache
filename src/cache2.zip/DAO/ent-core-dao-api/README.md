# Table of contents
- [Table of contents](#table-of-contents)
- [Deploy to Production](#deploy-to-production)
  - [New Deployment Strategy](#new-deployment-strategy)
  - [Old Deployment Strategy](#old-deployment-strategy)

# Deploy to Production

## New Deployment Strategy

> :exclamation: New Deployment Strategy is not stable. Please use old approach, described below.

To release new version and deploy it to production need to:

1. Create new release branch based on qa branch (e.g. release/22.02.2023).![New Release Branch](./docs/images/new-release-1.png)
2. Choose 'New Deployment' workflow in GitHub Actions section. https://github.com/HHAeXchange/ent-core-dao-api/actions/workflows/release.yml 
3. Run a workflow with appropriate release branch and "sandbox" environment. And make sure that new changes is deployed successfully to all sandbox environments (cloudsandbox, sandbox, app2sandbox). ![New Deployment](./docs/images/new-release-2.png)
4. After testing new version on sandbox repeat step 3 for deployment to production and implemenation environments.

> If some bugs were found during testing — create new hotfix branch based on appropriate release branch and make necessary changes. 

> :exclamation: After new version was deployed and tested successfully on production — create new release on GitHub. Use your release branch as target and version of the release as tag.

1. Go to https://github.com/HHAeXchange/ent-core-dao-api/releases
2. Click on `Draft a new release` ![New Release Button](./docs/images/release-1.png)
3. Create new TAG and pickup branch from where a new RELEASE should be created ![New Release Button](./docs/images/new-release-3.png)
4. Name a RELEASE the same as a TAG name, Generate release notes and click `Publish release` ![Create Release](./docs/images/new-release-4.png)


## Old Deployment Strategy

To release new version and deploy it to production need to:

1. Go to https://github.com/HHAeXchange/ent-core-dao-api/releases
2. Click on `Draft a new release` ![New Release Button](./docs/images/release-1.png)
3. Create new TAG and pickup branch from where a new RELEASE should be created ![New Release Button](./docs/images/release-2.png)
4. Name a RELEASE the same as a TAG name, Generate release notes and click `Publish release` ![Create Release](./docs/images/release-3.png)

5. Deployment pipeline will start automatically once Release and Tag created. IT can be viewed in https://github.com/HHAeXchange/ent-core-dao-api/actions/workflows/prod.yml ![View Pipelines](./docs/images/release-4.png)
