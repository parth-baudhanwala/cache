﻿using Microsoft.Extensions.Primitives;
using System;

namespace HHAExchange.Opsworklist.Core
{
    public static class StringExtensions
    {
        public static string UppercaseFirst(this string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }

            char[] a = s.ToCharArray();

            a[0] = char.ToUpper(a[0]);

            return new string(a);
        }

        public static bool IsNull(this string str)
        {
            return string.IsNullOrEmpty(str) || string.IsNullOrWhiteSpace(str);
        }

        public static int ToInt(this string str)
        {
            _ = int.TryParse(str, out int result);
            return result;
        }

        public static int ToInt(this StringValues strValues)
        {
            string str = (string)strValues ?? string.Empty;
            if (strValues.Count > 1)
            {
                str = strValues[0];
            }
            return str.ToInt();
        }

        public static DateTime ToDateTime(this string str, string format = null)
        {
            _ = DateTime.TryParse(str, out DateTime result);
            if (!format.IsNull())
            {
                result = result.ToString(format).ToDateTime();
            }
            return result;
        }
    }
}
