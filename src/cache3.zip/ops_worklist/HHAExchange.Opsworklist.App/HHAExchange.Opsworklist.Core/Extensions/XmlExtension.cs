﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace HHAExchange.Opsworklist.Core
{
    public static class XmlExtension
    {
        public static string ToXmlString<T>(this T value, bool omitXmlDeclaration = false, bool removeDefaultXmlNamespaces = false) where T : class
        {
            XmlSerializerNamespaces namespaces = removeDefaultXmlNamespaces ? new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty }) : new XmlSerializerNamespaces();
            if (!removeDefaultXmlNamespaces)
            {
                namespaces.Add("soap12", "http://www.w3.org/2003/05/soap-envelope");
                namespaces.Add("xsi", "http://www.w3.org/2001/XMLSchema-instance");
                namespaces.Add("xsd", "http://www.w3.org/2001/XMLSchema");
            }

            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.OmitXmlDeclaration = omitXmlDeclaration;
            settings.CheckCharacters = false;
            settings.Encoding = Encoding.UTF8;

            using MemoryStream stream = new MemoryStream();
            using var writer = XmlWriter.Create(stream, settings);
            var serializer = new XmlSerializer(value.GetType());
            serializer.Serialize(writer, value, namespaces);

            var xmlString = Encoding.UTF8.GetString(stream.ToArray());
            string _byteOrderMarkUtf8 = Encoding.UTF8.GetString(Encoding.UTF8.GetPreamble());
            if (xmlString.StartsWith(_byteOrderMarkUtf8, StringComparison.Ordinal))
            {
                xmlString = xmlString.Remove(0, _byteOrderMarkUtf8.Length);
            }

            return xmlString;
        }
    }
}
