﻿using HHAExchange.Opsworklist.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;

namespace HHAExchange.Opsworklist.Core
{
    public static class ListExtensions
    {
        public static DataTable ToDataTable<T>(this List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in props)
            {
                //Defining type of data column gives proper data table 
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, type);
            }

            foreach (T item in items)
            {
                var values = new object[props.Length];
                for (int i = 0; i < props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        public static DataTable CreateDataTable(IEnumerable<int> ids)
        {
            DataTable table = new DataTable();
            table.Columns.Add("ID", typeof(long));
            table.Columns.Add("Text", typeof(string));

            if (ids == null)
            {
                return null;
            }

            foreach (int id in ids)
            {
                table.Rows.Add(id, "");
            }

            return table;
        }

        public static DataSet ConvertXMLToDataSet(string xmlData)
        {
            System.IO.StringReader stream = null;
            XmlTextReader reader = null;
            try
            {
                DataSet xmlDS = new DataSet();
                stream = new StringReader(xmlData);
                reader = new XmlTextReader(stream);
                xmlDS.ReadXml(reader, XmlReadMode.InferSchema);

                if (xmlDS.Tables.Count > 1 && xmlDS.Tables[1].Rows.Count > 0)
                {
                    xmlDS = ConvertXMLToDataSet(xmlDS.Tables[1].Rows[0][0].ToString());
                }

                return xmlDS;
            }
            catch (Exception ex)
            {
                throw new InvalidCastException(ex.Message);
            }
            finally
            {
                if (reader != null) reader.Close();
            }
        }

        public static DataTable ConvertListToDataTable(string val = "")
        {
            List<CommonFilterModel> lstCommonFilter = new List<CommonFilterModel>();
            try
            {

                if (val == null || val.ToLower() == "null" || (val == "-1"))
                {
                    return null;
                }

                List<string> lstString = val.Split(',').ToList();

                if (lstString != null && lstString.Count > 0)
                {
                    foreach (string value in lstString)
                    {
                        CommonFilterModel commonFilterModel = new CommonFilterModel();
                        commonFilterModel.ID = value.ToInt();
                        commonFilterModel.Text = "";
                        lstCommonFilter.Add(commonFilterModel);
                    }
                }
                return lstCommonFilter.ToDataTable();
            }
            catch (Exception ex)
            {
                throw new InvalidCastException(ex.Message);
            }
        }
        public static DataTable ConvertArrayToDataTable(int[] arrayList)
        {
            List<CommonFilterModel> lstCommonFilter = new List<CommonFilterModel>();
            try
            {
                if (arrayList == null || arrayList.Length == 0)
                {
                    return null;
                }
                foreach (var value in arrayList)
                {
                    CommonFilterModel commonFilterModel = new CommonFilterModel();
                    commonFilterModel.ID = value;
                    commonFilterModel.Text = "";
                    lstCommonFilter.Add(commonFilterModel);
                }
                return lstCommonFilter.ToDataTable();
            }
            catch (Exception ex)
            {
                throw new InvalidCastException(ex.Message);
            }
        }
    }
}
