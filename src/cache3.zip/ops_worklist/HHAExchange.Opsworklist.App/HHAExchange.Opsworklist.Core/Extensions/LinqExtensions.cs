﻿using HHAExchange.Opsworklist.Domain;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace HHAExchange.Opsworklist.Core
{
    public static class LinqExtensions
    {
        public static IQueryable<T> AddCondition<T>(this IQueryable<T> queryable, Func<bool> predicate, Expression<Func<T, bool>> filter)
        {
            if (predicate())
                return queryable.Where(filter);
            else
                return queryable;
        }

        public static IQueryable<T> AddOrderBy<T, R>(this IQueryable<T> queryable, Func<bool> predicate, SortDirection Dir, Expression<Func<T, R>> filter)
        {
            if (predicate())
                return SortDirection.Descending.Equals(Dir) ? queryable.OrderByDescending(filter) : queryable.OrderBy(filter);
            else
                return queryable;
        }

        public static PaginationResult<T> GetPaged<T>(this IQueryable<T> query,
                                         PageRequest Page) where T : class
        {
            var result = new PaginationResult<T>();
            result.pageInfo = new PageInfo
            {
                totalRecordCount = query.Count()
            };
            var pageNumber = Page != null ? Page.PageNumber : 1;
            int pageSize = 10;
            if (Page != null)
            {
                if (Page.PageSize == -1)
                {
                    pageSize = result.pageInfo.totalRecordCount;
                }
                else
                {
                    pageSize = Page.PageSize;
                }
            }
            var skip = (pageNumber - 1) * pageSize;
            result.data = query.Skip(skip).Take(pageSize).ToList();

            return result;
        }
    }
}
