﻿using HHAExchange.AWSSecretsManager.Common;
using HHAExchange.Opsworklist.Core.Enums;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.DataContracts;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace HHAExchange.Opsworklist.Core.AmazonServices
{
    public static class SecretManagerService
    {
        private static IConfiguration configuration;
        private static readonly StringBuilder logInformation = new StringBuilder();

        public static IConfiguration AddSecretsFromSecretManager(IConfigurationBuilder builder)
        {
            configuration = builder.Build();

            bool isAwsSeretManagerEnabled = configuration.GetValue<bool>("AWSSecretsManager:EnableAWSSecretManager");
            bool isConnectionStringSecretNameExist = configuration.GetSection("AWSSecretsManager:ConnectionStringSecretName").Exists();

            if (configuration == null || !isAwsSeretManagerEnabled || !isConnectionStringSecretNameExist)
            {
                return configuration;
            }

            logInformation.AppendLine($"{configuration.GetValue<string>("ApplicationName")} : Secret manager is enabled.");
            var secretConnectionStringConfig = configuration.GetSection("AWSSecretsManager:ConnectionStringSecretName").GetChildren().GetEnumerator();
            List<SecretConnectionStringRelationModel> secretConnectionStringRelationModelsList = new List<SecretConnectionStringRelationModel>();

            while (secretConnectionStringConfig.MoveNext())
            {
                secretConnectionStringRelationModelsList.Add(new SecretConnectionStringRelationModel()
                {
                    ConnectionStringName = "ConnectionStrings:" + secretConnectionStringConfig.Current.Key,
                    SecretName = secretConnectionStringConfig.Current.Value
                });
            }

            if (secretConnectionStringRelationModelsList.Any())
            {
                logInformation.AppendLine("Executing extension method.");

                configuration = builder.AddSecretsManager(configurator: options =>
                {
                    if (configuration.GetSection("AWSSecretsManager:SecretName").Exists())
                    {
                        options.AcceptedSecretArns = new List<string> { configuration.GetValue<string>("AWSSecretsManager:SecretName") };
                    }

                    options.AcceptedConnectionStringsSecretArns = secretConnectionStringRelationModelsList;
                    options.ConfigureConnectionStringMapping = (connectionStringSecretValues, secretConnectionStringRelationModel) =>
                    {
                        return GetConnectionStringFormat(connectionStringSecretValues);
                    };
                }).Build();

                logInformation.AppendLine("Extension method is successfully executed.");
                CheckStatus();
            }

            LogToAppInsight(logInformation.ToString());

            return configuration;
        }

        private static string GetConnectionStringFormat(Dictionary<string, string> connectionStringSecretValues)
        {
            string format = "Server={0};Database={1};User Id={2};Password={3};";

            string connectionString = string.Format(format, connectionStringSecretValues["host"],
                                                            connectionStringSecretValues["dbname"],
                                                            connectionStringSecretValues["username"],
                                                            connectionStringSecretValues["password"]);

            if (connectionStringSecretValues["engine"].Equals("postgres"))
            {
                connectionString += $"Application Name={AppNameEnum.Npgsql};";
            }
            else
            {
                connectionString += $"Application Name={AppNameEnum.SqlServer};";
            }

            return connectionString;
        }

        private static void CheckStatus()
        {
            if (SecretsManagerConnectionState.ConnectionState == SecretsManagerConnectionStateEnum.Connected)
            {
                logInformation.AppendLine("AWS Secret Manager was connected succesfully.");

                if (configuration.GetValue<bool>("AWSSecretsManager:EnableVerifyConnectionString"))
                {
                    VerifyConnectionString();
                }
            }
            else if (SecretsManagerConnectionState.ConnectionState == SecretsManagerConnectionStateEnum.NoCredentialsLocated)
            {
                logInformation.AppendLine("Credentials file is not found in excepted USERPROFILE.");
                logInformation.AppendLine(SecretsManagerConnectionState.ConnectionException.ToString());
            }
            else if (SecretsManagerConnectionState.ConnectionState == SecretsManagerConnectionStateEnum.ConnectionError)
            {
                logInformation.AppendLine($"Connection exception is {SecretsManagerConnectionState.ConnectionException.Message}");
                logInformation.AppendLine($"Connection inner exception is {SecretsManagerConnectionState.ConnectionException.InnerException.Message}");
            }
        }

        private static void VerifyConnectionString()
        {
            logInformation.AppendLine($"Verification of connection strings is started at {DateTime.Now}.");
            var secretConnectionStringConfig = configuration.GetSection("AWSSecretsManager:ConnectionStringSecretName").GetChildren().GetEnumerator();

            while (secretConnectionStringConfig.MoveNext())
            {
                try
                {
                    string connectionString = configuration.GetConnectionString(secretConnectionStringConfig.Current.Key);

                    if (connectionString.Contains(AppNameEnum.Npgsql))
                    {
                        using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                        {
                            connection.Open();
                            logInformation.AppendLine($"Connected successfully for {secretConnectionStringConfig.Current.Key}.");
                        }
                    }
                    else
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();
                            logInformation.AppendLine($"Connected successfully for {secretConnectionStringConfig.Current.Key}.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    logInformation.AppendLine($"Connection is failed for {secretConnectionStringConfig.Current.Key}. Exception is {ex.Message}");
                }
            }

            logInformation.AppendLine($"Verification of connection strings is completed at {DateTime.Now}.");
        }

        private static void LogToAppInsight(string logInformation)
        {
            TelemetryClient telemetryClient = new TelemetryClient(new TelemetryConfiguration
            {
                ConnectionString = configuration.GetValue<string>("ApplicationInsights:ConnectionString")
            });

            telemetryClient.Context.Cloud.RoleName = configuration.GetValue<string>("ApplicationInsights:CloudRoleName");
            telemetryClient.TrackTrace(logInformation, SeverityLevel.Information);
            telemetryClient.Flush();
            LogToSerilog(logInformation);
        }
        private static void LogToSerilog(string logInformation)
        {
            Serilog.Log.Information(configuration.GetValue<string>("ApplicationName") + " is called");
            Serilog.Log.Information(logInformation);
        }
    }
}
