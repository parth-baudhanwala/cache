﻿using HHAExchange.Opsworklist.Domain;
using Microsoft.Extensions.Configuration;

namespace HHAExchange.Opsworklist.Core
{
    public class DataAccess
    {
        private readonly IConfiguration _configuration;

        public DataAccess(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnectionString(string SectionName)
        {
            return _configuration.GetConnectionString(SectionName);
        }

        public CommandInfo GetCommandDetails(string key)
        {
            return new CommandInfo
            {
                SPName = _configuration["StoredProcedures:" + key + ":Mappings:SPName"],
                Timeout = _configuration["StoredProcedures:" + key + ":Mappings:Timeout"].ToInt(),
                ConnectionString = _configuration["ConnectionStrings:" + _configuration["StoredProcedures:" + key + ":Mappings:ConnectionString"] + ""]
            };
        }
    }
}
