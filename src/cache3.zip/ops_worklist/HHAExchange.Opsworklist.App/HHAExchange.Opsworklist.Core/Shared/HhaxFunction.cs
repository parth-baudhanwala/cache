﻿using HHAExchange.Opsworklist.Domain;

namespace HHAExchange.Opsworklist.Core.Shared
{
    public static class HhaxFunction
    {
        public static string GetOfficeXml(string officeIds)
        {
            if (string.IsNullOrWhiteSpace(officeIds)) return null;

            Offices offices = new Offices();
            List<OfficesOffice> list = new List<OfficesOffice>();

            foreach (string id in officeIds.Split(new char[] { ',' }).ToList())
            {
                list.Add(new OfficesOffice { ID = id });
            }

            offices.Office = list.ToArray();
            return offices.ToXmlString(true, true);
        }
    }
}
