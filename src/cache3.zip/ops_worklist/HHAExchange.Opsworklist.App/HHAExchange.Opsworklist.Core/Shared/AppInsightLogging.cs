﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Events;

namespace HHAExchange.Opsworklist.Core.Shared
{
    public class AppInsightLogging
    {
        private readonly IConfiguration _configuration;

        public AppInsightLogging(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void LogToAppInsight(Exception exception)
        {
            TelemetryClient telemetryClient = new(new TelemetryConfiguration
            {
                ConnectionString = _configuration.GetValue<string>("ApplicationInsights:ConnectionString")
            });

            telemetryClient.Context.Cloud.RoleName = _configuration.GetValue<string>("ApplicationInsights:CloudRoleName");
            telemetryClient.TrackException(exception);
            telemetryClient.Flush();
            LogToSerilog(exception);
        }

        private static void LogToSerilog(Exception exception)
        {
            Log.Error(exception, LogEventLevel.Error.ToString());
        }
    }
}
