﻿using System.Runtime.Serialization;

namespace HHAExchange.Opsworklist.Core.Exceptions
{
    [Serializable]
    public class AppSettingsValueNotFoundException : Exception
    {
        public AppSettingsValueNotFoundException() { }

        public AppSettingsValueNotFoundException(string message) : base(message) { }

        public AppSettingsValueNotFoundException(string message, Exception innerException) : base(message, innerException) { }

        protected AppSettingsValueNotFoundException(SerializationInfo serializationInfo, StreamingContext streamingContext) : base(serializationInfo, streamingContext)
        {
            throw new NotImplementedException();
        }
    }
}
