﻿namespace HHAExchange.Opsworklist.Core.Enums;

public enum UserRoleName
{
    CaregiverChat
}
