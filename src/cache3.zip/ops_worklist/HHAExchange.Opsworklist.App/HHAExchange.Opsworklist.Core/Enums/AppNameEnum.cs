﻿namespace HHAExchange.Opsworklist.Core.Enums
{
    public static class AppNameEnum
    {
        public static readonly string Npgsql = "OpsWorklistApp.Npgsql";
        public static readonly string SqlServer = "OpsWorklistApp.SqlServer";
    }
}
