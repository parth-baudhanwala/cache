﻿namespace HHAExchange.Opsworklist.Core.Enums
{
    public enum Status
    {
        Default,
        Edited,
        Deleted,
        New,
        Missed
    }
}
