﻿namespace HHAExchange.Opsworklist.Core.Enums
{
    public enum BroadCastMessageTypeID
    {
        MobileandText = 2,
        Email = 3,
        Mobile = 4,
        OnlyText = 5
    }

    public enum DeliveryMessageTypeID
    {
        Email = 1
    }
}
