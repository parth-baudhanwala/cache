﻿using System;
using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;

namespace HHAExchange.Opsworklist.API.Config
{
    public class CloudRoleNameInitializer : ITelemetryInitializer
    {
        private readonly string roleName;

        public CloudRoleNameInitializer(string roleName)
        {
            this.roleName = roleName ?? throw new ArgumentNullException(nameof(roleName));
        }

        public void Initialize(ITelemetry telemetry)
        {
            telemetry.Context.Cloud.RoleName = roleName;
        }
    }
}
