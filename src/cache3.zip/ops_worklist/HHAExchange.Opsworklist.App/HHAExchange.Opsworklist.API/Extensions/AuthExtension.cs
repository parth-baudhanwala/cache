﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.IdentityModel.Tokens;
using System.Security.Cryptography.X509Certificates;

namespace HHAExchange.Opsworklist.API.Extensions
{
    public static class AuthExtension
    {
        public static IServiceCollection AddDataProtectionServices(
            this IServiceCollection services,
            IConfiguration configuration,
            X509Certificate2 signingCertificate)
        {
            string keyStorePath = !string.IsNullOrEmpty(configuration["SharedDirectory"]) ? configuration["SharedDirectory"] : configuration["Certificate:Path"];

            var dataProtectionBuilder = services
                                            .AddDataProtection()
                                            .SetApplicationName(configuration["Identity:IdentityServerName"])
                                            .PersistKeysToFileSystem(new DirectoryInfo(keyStorePath));

            int isProdEnvironment = configuration.GetValue<int>("IsProdEnvironment");

            if (isProdEnvironment == 0)
            {
                if (OperatingSystem.IsWindows())
                {
                    dataProtectionBuilder.ProtectKeysWithDpapi();
                }
            }
            else
            {
                if (signingCertificate != null)
                {
                    dataProtectionBuilder
                        .ProtectKeysWithCertificate(signingCertificate)
                        .UnprotectKeysWithAnyCertificate(signingCertificate);
                }
            }

            return services;
        }

        public static IServiceCollection AddAuthenticationServices(this IServiceCollection services,
            IConfiguration configuration,
            X509Certificate2 signingCertificate)
        {
            services.AddAuthorization(options =>
            {
            });
            services.AddHttpContextAccessor();
            services.AddTransient<IAuthorizationPolicyProvider, UserPermissionPolicyProvider>();
            services.AddSingleton<IAuthorizationHandler, UserPermissionHandler>();
            services.AddAuthentication(OpenIdConnectDefaults.AuthenticationScheme)
                    .AddOpenIdConnect(options =>
                    {
                        options.ForwardDefaultSelector = c => JwtBearerDefaults.AuthenticationScheme;

                        options.Authority = configuration["Identity:Authority"];
                        options.ClientId = configuration["Identity:ClientId"];
                        options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                        options.SignOutScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                    })
                    .AddCookie()
                    .AddJwtBearer("Bearer", options =>
                    {
                        var tokenValidationParameters = new TokenValidationParameters
                        {
                            ValidateIssuerSigningKey = true,
                            IssuerSigningKey = new X509SecurityKey(signingCertificate),
                            ValidateIssuer = false,
                            ValidateAudience = false,
                            ValidateLifetime = true,
                            ClockSkew = System.TimeSpan.Zero
                        };

                        options.Authority = configuration["Identity:Authority"];
                        options.RequireHttpsMetadata = false;
                        options.TokenValidationParameters = tokenValidationParameters;
                        options.Events = new JwtBearerEvents
                        {
                            OnMessageReceived = context =>
                            {
                                var accessToken = context.Request.Query["access_token"];
                                var path = context.HttpContext.Request.Path;

                                context.Token = accessToken;
                                context.HttpContext.Request.Path = path;
                                return Task.CompletedTask;
                            }
                        };
                    });

            return services;
        }
    }
}
