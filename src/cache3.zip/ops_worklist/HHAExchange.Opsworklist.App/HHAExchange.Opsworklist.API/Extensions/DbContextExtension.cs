﻿using HHAExchange.Opsworklist.Infra.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace HHAExchange.Opsworklist.API.Extensions
{
    public static class DbContextExtension
    {
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContextPool<OpsWorklistDBContext>(
               options => options.UseNpgsql(
                   configuration.GetConnectionString("OpsworkslistConnectionString")
                   )
               );

            services.AddDbContextPool<HhaDbContext>(
                options => options.UseSqlServer(
                    configuration.GetConnectionString("hha")
                    )
                );

            services.AddDbContextPool<HhaReadDbContext>(
                options => options.UseSqlServer(
                    configuration.GetConnectionString("HHAMirrorReadConnectionString")
                    )
                );

            services.AddDbContextPool<HhaClinicalDbContext>(
                options => options.UseSqlServer(
                    configuration.GetConnectionString("HHAClinicalConnectionString")
                    )
                );

            return services;
        }
    }
}
