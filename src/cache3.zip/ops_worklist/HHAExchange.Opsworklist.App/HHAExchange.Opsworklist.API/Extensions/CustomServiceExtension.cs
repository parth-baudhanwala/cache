﻿using HHAExchange.Opsworklist.Handler;
using HHAExchange.Opsworklist.Infra;
using HHAExchange.Opsworklist.Infra.Interfaces;
using HHAExchange.Opsworklist.Infra.Interfaces.Common;
using HHAExchange.Opsworklist.Infra.Interfaces.MasterLayout;
using HHAExchange.Opsworklist.Infra.Repositories.MasterLayout;
using HHAExchange.Opsworklist.Infra.Services;
using HHAExchange.Opsworklist.Rules.Adapter;
using Microsoft.Extensions.DependencyInjection;
using NRules.Extensibility;

namespace HHAExchange.Opsworklist.API.Extensions
{
    public static class CustomServiceExtension
    {
        public static IServiceCollection AddCustomServices(this IServiceCollection services)
        {
            services.AddTransient<IWlTaskRepository, WlTaskRepository>();
            services.AddTransient<IOfficeRepository, OfficeRepository>();
            services.AddTransient<ILocationForOfficeRepository, LocationForOfficeRepository>();
            services.AddTransient<IBranchForOfficeRepository, BranchForOfficeRepository>();
            services.AddTransient<ICaregiverSearchRepository, CaregiverSearchRepository>();
            services.AddTransient<IPatientSearchRepository, PatientSearchRepository>();
            services.AddTransient<IUsersRepository, UsersRepository>();
            services.AddTransient<IBroadcastRepository, BroadcastRepository>();
            services.AddTransient<IPatientRepository, PatientRepository>();
            services.AddTransient<IMasterLayoutRepository, MasterLayoutRepository>();

            services.AddScoped<IWlTaskNoteRepository, WlTaskNoteRepository>();
            services.AddScoped<IFileRepository, FileRepository>();
            services.AddScoped<IWlTaskExpiringAuthRepository, WlTaskExpiringAuthRepository>();
            services.AddScoped<IWlTaskMedicalCompExpRepository, WlTaskMedicalCompExpRepository>();
            services.AddScoped<IWlTaskUnstaffedVisitRepository, WlTaskUnstaffedVisitRepository>();
            services.AddScoped<IWlTaskMissingExpiringMWScheduleRepository, WlTaskMissingExpiringMWScheduleRepository>();
            services.AddScoped<IWlTaskExpiringCertificationRepository, WlTaskExpiringCertificationRepository>();
            services.AddScoped<IWorklistSetupRepository, WorklistSetupRepository>();
            services.AddScoped<IPatientMasterWeekInfoRepository, PatientMasterWeekInfoRepository>();
            services.AddScoped<ICompleteTaskHandler, CompleteTaskHandler>();

            services.AddSingleton<ITimeZoneService, TimeZoneService>();
            services.AddSingleton<IDependencyResolver, RulesScopedServiceResolver>();
            services.AddSingleton<IRulesAdapter, RulesAdapter>();
            services.AddSingleton<IRedisConnectionService, RedisConnectionService>();

            return services;
        }
    }
}
