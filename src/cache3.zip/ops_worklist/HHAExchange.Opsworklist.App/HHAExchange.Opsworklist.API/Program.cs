using HHAExchange.Opsworklist.Core.AmazonServices;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using Serilog;

namespace HHAExchange.Opsworklist.API
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
            Log.Logger = new LoggerConfiguration().WriteTo.Console().CreateBootstrapLogger();
            Log.Information("Start Logging Opsworklist");
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) => Host.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration(x => x.AddConfiguration(GetConfiguration()))
            .UseSerilog((hostingContext, loggerConfiguration) =>
            {
                loggerConfiguration
                    .Enrich.FromLogContext()
                    .Enrich.WithProperty("ApplicationContext", hostingContext.Configuration["ApplicationName"])
                    .WriteTo.Console()
                    .ReadFrom.Configuration(hostingContext.Configuration);
            })
            //.UseSerilog((hostingContext, loggerConfiguration) =>
            //{
            //    TelemetryConfiguration telemetryConfiguration = new()
            //    {
            //        ConnectionString = hostingContext.Configuration["ApplicationInsights:ConnectionString"]
            //    };
            //    loggerConfiguration
            //        .ReadFrom.Configuration(hostingContext.Configuration)
            //        .Enrich.FromLogContext()
            //        .WriteTo.ApplicationInsights(telemetryConfiguration, TelemetryConverter.Events);
            //})
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Startup>();
            });

        private static IConfiguration GetConfiguration()
        {
            IConfigurationBuilder builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile("storedprocedures.json", optional: false, reloadOnChange: true)
                .AddJsonFile("TimeZoneData.json", optional: false, reloadOnChange: true);

            IConfiguration configuration = SecretManagerService.AddSecretsFromSecretManager(builder);

            return configuration;
        }
    }
}
