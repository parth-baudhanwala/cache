﻿global using HHAExchange.Opsworklist.Core;
global using HHAExchange.Opsworklist.Domain;
global using HHAExchange.Opsworklist.Infra;
global using Microsoft.AspNetCore.Mvc;
global using System.Net;