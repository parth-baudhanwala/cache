﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace HHAExchange.Opsworklist.API
{
    public class UserPermissionPolicyProvider : DefaultAuthorizationPolicyProvider
    {
        private readonly AuthorizationOptions _options;
        private static object _syncLock = new object();

        public UserPermissionPolicyProvider(IOptions<AuthorizationOptions> options) : base(options)
        {
            _options = options.Value;
        }

        public override async Task<AuthorizationPolicy> GetPolicyAsync(string policyName)
        {
            var policy = await base.GetPolicyAsync(policyName);

            if (policy == null)
            {
                lock (_syncLock)
                {
                    policy = new AuthorizationPolicyBuilder()
                    .AddRequirements(ToRequirement(policyName))
                    .Build();

                    _options.AddPolicy(policyName, policy);
                }
            }

            return policy;
        }

        private static UserPermissionRequirement ToRequirement(string policyName)
        {
            if (string.IsNullOrWhiteSpace(policyName))
            {
                throw new ArgumentException("Policy is empty.");
            }
                        
            string permissionName = policyName;
            return new UserPermissionRequirement(permissionName);
        }
    }
}
