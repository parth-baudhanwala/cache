﻿using Microsoft.AspNetCore.Authorization;

namespace HHAExchange.Opsworklist.API
{
    public class UserPermissionRequirement : IAuthorizationRequirement
    {
        public UserPermissionRequirement(string permissionName)
        {
            Permission = permissionName;
        }

        public string Permission { get; private set; }
    }
}
