﻿using Microsoft.AspNetCore.Authorization;

namespace HHAExchange.Opsworklist.API
{
    public class UserPermissionAttribute : AuthorizeAttribute
    {       
        public UserPermissionAttribute(string name)
        {
            PermissionName = name;
        }

        string name;

        public string PermissionName
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                Policy = value;                
            }
        }
    }
}
