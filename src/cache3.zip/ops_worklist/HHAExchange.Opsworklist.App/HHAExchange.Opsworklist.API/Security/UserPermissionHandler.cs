﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using HHAExchange.Opsworklist.Infra.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    public class UserPermissionHandler : AuthorizationHandler<UserPermissionRequirement>
    {
        private readonly IUsersRepository _usersRepository;
        private readonly IRedisConnectionService _redisConnectionService;
        private readonly IConfiguration _configuration;

        public UserPermissionHandler(IUsersRepository usersRepository, IRedisConnectionService redisConnectionService, IConfiguration configuration)
        {
            _usersRepository = usersRepository;
            _redisConnectionService = redisConnectionService;
            _configuration = configuration;
        }

        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, UserPermissionRequirement requirement)
        {
            if (context.User == null || !context.User.HasClaim(x => x.Type.Equals(ClaimTypes.NameIdentifier)))
            {
                context.Fail();
                return;
            }

            int userID = Convert.ToInt32(context.User.Claims
                .Where(x => x.Type.Equals(ClaimTypes.NameIdentifier))
                .Select(x => x.Value).FirstOrDefault());

            bool hasPermission = false;

            UserPermissionsParams permissionDetailsParams = new UserPermissionsParams
            {
                UserID = userID,
                MenuList = new List<string> { requirement.Permission }
            };

            if (_redisConnectionService.IsRedisCacheEnabled)
            {
                string userAuthHashKey = _configuration["UserAuth:UserAuthHashKey"];
                string userPermissionRedisKeyFeature = _configuration["UserAuth:CaregiverUserPermissionRedisKeyFeature"];
                int userAuthRedisKeyExpiryInMinutes = _configuration.GetValue<int>("UserAuth:UserAuthRedisKeyExpiryInMinutes");

                string permission = requirement.Permission.Replace(" ", "");

                string hashField = userPermissionRedisKeyFeature.Replace("{permission}", permission).Replace("{userid}", userID.ToString());

                string redisValue = await _redisConnectionService.GetRedisHashCache(userAuthHashKey, hashField);

                if (!string.IsNullOrEmpty(redisValue))
                {
                    bool hasAccess = Convert.ToBoolean(redisValue);

                    if (hasAccess)
                    {
                        context.Succeed(requirement);
                    }
                    else
                    {
                        context.Fail();
                    }

                    return;
                }

                hasPermission = await HasPermission(permissionDetailsParams);

                if (hasPermission)
                {
                    context.Succeed(requirement);
                }
                else
                {
                    context.Fail();
                }

                string value = Convert.ToString(hasPermission);
                await _redisConnectionService.SaveRedisHashCache(userAuthHashKey, hashField, value, userAuthRedisKeyExpiryInMinutes);

                return;
            }

            hasPermission = await HasPermission(permissionDetailsParams);

            if (hasPermission)
            {
                context.Succeed(requirement);
            }
            else
            {
                context.Fail();
            }
        }

        private async Task<bool> HasPermission(UserPermissionsParams permissionsParams)
        {
            OpsworklistDetailsParams opsworklistDetailsParams = new OpsworklistDetailsParams
            {
                UserID = permissionsParams.UserID
            };

            var versionDetails = await _usersRepository.GetOpsworklistDetails(opsworklistDetailsParams);

            if (versionDetails == null || !versionDetails.Any())
            {
                return false;
            }

            permissionsParams.AppVersion = versionDetails[0].AppName;
            permissionsParams.Version = versionDetails[0].Version;
            permissionsParams.MinorVersion = versionDetails[0].MinorVersion;

            var permissionDetails = _usersRepository.GetPermissions(permissionsParams);

            if (permissionDetails != null && permissionDetails.Any() && permissionDetails.First().HasAccess)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
