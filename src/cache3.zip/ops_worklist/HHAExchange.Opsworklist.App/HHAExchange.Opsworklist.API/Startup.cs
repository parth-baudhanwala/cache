using Hangfire;
using Hangfire.SqlServer;
using HHAExchange.Opsworklist.API.Config;
using HHAExchange.Opsworklist.API.Extensions;
using HHAExchange.Opsworklist.Infra.Utility;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.OpenApi.Models;
using Serilog;
using System.Globalization;
using System.Security.Cryptography.X509Certificates;

namespace HHAExchange.Opsworklist.API
{
    public class Startup
    {
        private readonly IConfiguration _configuration;
        private readonly string HHAX_CORS = "HHAX_CORS";

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseSerilogRequestLogging();
            app.UseForwardedHeaders();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCookiePolicy();
            app.UseHangfireDashboard();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseCors(HHAX_CORS);
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("./swagger/v1/swagger.json", "OpsWorklist API V1");
                c.RoutePrefix = string.Empty;
            });
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvcCore(config =>
            {
                config.Filters.Add(new AuthorizeFilter());
                config.EnableEndpointRouting = false;
            }).AddNewtonsoftJson(options =>
                    {
                        options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                    })
                    .AddApiExplorer();
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });
            services.AddCors(i => i.AddPolicy(HHAX_CORS, builder =>
            {
                builder.WithOrigins("http://localhost:4200", "http://localhost", "https://localhost:4200", "https://localhost")
                                .AllowAnyHeader()
                                .AllowAnyMethod()
                                .AllowAnyOrigin();
            }));
            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders =
                    ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });

            var contentRoot = _configuration.GetValue<string>(WebHostDefaults.ContentRootKey);
            var certPath = Path.Combine(contentRoot, _configuration["Certificate:Name"]);
            var signingCertificate = new X509Certificate2(certPath, _configuration["Certificate:Password"]);
            services.AddDataProtectionServices(_configuration, signingCertificate);
            services.AddAuthenticationServices(_configuration, signingCertificate);

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "OpsWorklist.API", Version = "v1" });
                c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
                {
                    Type = SecuritySchemeType.OAuth2,
                    Flows = new OpenApiOAuthFlows
                    {
                        ClientCredentials = new OpenApiOAuthFlow
                        {
                            TokenUrl = new Uri(_configuration["Identity:TokenUrl"].ToString(CultureInfo.CurrentCulture), UriKind.Absolute),
                            Scopes = new Dictionary<string, string>
                            {
                                { "all:read", "Access read operations" },
                                { "write:aggregator", "Aggregator access" },
                            },
                        },
                    },
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "oauth2" },
                        },
                        new[] { "readAccess" }
                    },
                });
                c.OperationFilter<AuthorizeCheckOperationFilter>();
            });

            services.AddApplicationInsightsTelemetry();

            services.AddSingleton<ITelemetryInitializer>(new CloudRoleNameInitializer(_configuration["ApplicationInsights:CloudRoleName"]));

            TelemetryConfiguration telemetryConfiguration = new TelemetryConfiguration
            {
                ConnectionString = _configuration["ApplicationInsights:ConnectionString"]
            };

            services.AddSingleton(new TelemetryClient(telemetryConfiguration));

            services.AddSingleton<DataAccess>(x => new DataAccess(_configuration));
            services.AddSingleton<IDapperContext>(x => new DapperContext(_configuration));

            services.AddAutoMapper(this.GetType().Assembly);
            services.AddAutoMapper(typeof(Startup));

            services.AddHangfire(x => x.UseSqlServerStorage(
                _configuration.GetConnectionString("HangfireAutoProcessConnectionString"), new SqlServerStorageOptions { SchemaName = "OpsApi" }
                ));

            services.AddHangfireServer(options =>
            {
                options.Queues = new[] { "opsapi-parallel" };
                options.ServerName = "OpsworklistApi";
            });

            services.AddControllers();

            services.AddCustomServices();

            services.AddCustomDbContext(_configuration);

            services.AddHttpContextAccessor();

            services.AddCors(i => i.AddPolicy("HHAX_Enable_CORS", builder =>
            {
                builder.AllowAnyOrigin()
                .AllowAnyHeader()
                .AllowAnyMethod();
            }));
        }
    }
}
