﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.WorklistTask;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Controller.Common
{
    [Route("Common")]
    public class SearchFieldsController : BaseController
    {
        private readonly ICaregiverSearchRepository _caregiverTeamRepository;
        private readonly IWlTaskExpiringAuthRepository _wlTaskExpiringAuthRepository;
        private readonly IWlTaskUnstaffedVisitRepository _wlTaskUnstaffedVisitRepository;
        private readonly IWlTaskMissingExpiringMWScheduleRepository _wlTaskMissingExpiringMWScheduleRepository;
        private readonly IWlTaskExpiringCertificationRepository _wlTaskExpiringCertificationRepository;

        public SearchFieldsController(ICaregiverSearchRepository caregiverTeamRepository, IWlTaskExpiringAuthRepository wlTaskExpiringAuthRepository,
            IWlTaskUnstaffedVisitRepository wlTaskUnstaffedVisitRepository, IWlTaskMissingExpiringMWScheduleRepository wlTaskMissingExpiringMWScheduleRepository,
            IWlTaskExpiringCertificationRepository wlTaskExpiringCertificationRepository)
        {
            _caregiverTeamRepository = caregiverTeamRepository;
            _wlTaskExpiringAuthRepository = wlTaskExpiringAuthRepository;
            _wlTaskUnstaffedVisitRepository = wlTaskUnstaffedVisitRepository;
            _wlTaskMissingExpiringMWScheduleRepository = wlTaskMissingExpiringMWScheduleRepository;
            _wlTaskExpiringCertificationRepository = wlTaskExpiringCertificationRepository;
        }

        [HttpPost]
        [Route("GetCommunicationScript")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<List<CommunicationScriptModel>>> GetCommunicationScript([FromBody] CommunicationScriptRequest scriptRequest)
        {
            List<CommunicationScriptModel> scriptList = await _caregiverTeamRepository.GetCommunicationScript(scriptRequest);
            return BuildResponse(scriptList, System.Net.HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("GetTemplateDetailsbyID")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<List<ScriptTemplateModel>>> GetTemplateDetailsbyID([FromBody] CommuncationTemplateRequest scriptRequest)
        {
            List<ScriptTemplateModel> scriptList = await _caregiverTeamRepository.GetTemplateDetailsByID(scriptRequest);
            return BuildResponse(scriptList, System.Net.HttpStatusCode.OK);
        }

        [HttpGet]
        [Route("GetPatient")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<AutoFillDataModel>> AutoWlPatientDetails([FromQuery] AutoSuggestPatientDetails autoSuggestPatientDetails)
        {
            if (string.IsNullOrEmpty(autoSuggestPatientDetails.worklistPath) || string.IsNullOrEmpty(autoSuggestPatientDetails.patient)) return BadRequest();
            if (autoSuggestPatientDetails.worklistPath == "ExpiringAuthorization")
            {
                return Ok(await _wlTaskExpiringAuthRepository.GetPatients(autoSuggestPatientDetails));
            }
            else if (autoSuggestPatientDetails.worklistPath == "UnstaffedVisits")
            {
                return Ok(await _wlTaskUnstaffedVisitRepository.GetPatients(autoSuggestPatientDetails));
            }
            else if (autoSuggestPatientDetails.worklistPath == "MasterWeek")
            {
                return Ok(await _wlTaskMissingExpiringMWScheduleRepository.GetPatients(autoSuggestPatientDetails));
            }
            else if (autoSuggestPatientDetails.worklistPath == "ExpiringCertificationPeriod")
            {
                return Ok(await _wlTaskExpiringCertificationRepository.GetPatients(autoSuggestPatientDetails));
            }
            else
            {
                return NoContent();
            }
        }

        [HttpGet]
        [Route("GetPhysicians")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<AutoFillDataModel>> AutoECPPhysician([FromQuery] string physician, string worklistPath)
        {
            if (string.IsNullOrEmpty(worklistPath) || string.IsNullOrEmpty(physician)) return BadRequest();

            else if (worklistPath == "ExpiringCertificationPeriod")
            {
                return Ok(await _wlTaskExpiringCertificationRepository.GetPhysicians(physician));
            }
            else
            {
                return NoContent();
            }
        }
    }
}
