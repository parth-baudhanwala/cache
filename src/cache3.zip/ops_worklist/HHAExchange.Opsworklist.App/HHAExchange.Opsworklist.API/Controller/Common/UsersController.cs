﻿using AutoMapper;
using HHAExchange.Opsworklist.Core.Enums;
using HHAExchange.Opsworklist.Infra.Services;

namespace HHAExchange.Opsworklist.API
{
    [Route("Common")]
    [ApiController]
    public class UsersController : BaseController
    {
        private readonly IUsersRepository _wlUserRepository;
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly IOfficeRepository _officeRepository;
        private readonly IRedisConnectionService _redisConnectionService;

        public UsersController(IMapper mapper, IConfiguration configuration, IUsersRepository wlUserRepository, IOfficeRepository officeRepository, IRedisConnectionService redisConnectionService)
        {
            _wlUserRepository = wlUserRepository;
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _configuration = configuration;
            _officeRepository = officeRepository;
            _redisConnectionService = redisConnectionService;
        }

        [HttpGet]
        [Route("GetUsersByWorklistID")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<IEnumerable<WorklistTasksToAssignUsers>>> GetUsersByWorklistID([FromQuery] WorklistUsersForOfficeModel usersByOfficeIDModel)
        {
            var users = await _wlUserRepository.GetUsersByWorklistID(usersByOfficeIDModel);

            if (users != null && users.Count > 0)
            {
                return Ok(_mapper.Map<List<WorklistTasksToAssignUsers>>(users));
            }
            else
            {
                return NoContent();
            }
        }

        [HttpGet]
        [Route("GetUserProfile")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<OpsworklistDetailsModel>> GetUserProfile([FromQuery] OpsworklistDetailsParams opsworklistDetailsParams)
        {
            opsworklistDetailsParams.ENTMainAppversionID = _configuration.GetValue<int>("ApplicationSettings:EntMainAppVersionId");
            opsworklistDetailsParams.HHAWSENTAppversionID = _configuration.GetValue<int>("ApplicationSettings:HHAWSENTAppVersionID");
            opsworklistDetailsParams.ENTPAppversionID = _configuration.GetValue<int>("ApplicationSettings:EntPAppVersionId");
            opsworklistDetailsParams.ProviderAppversionID = _configuration.GetValue<int>("ApplicationSettings:ProviderAppversionID");
            opsworklistDetailsParams.ENTAPIAppVersionID = _configuration.GetValue<int>("ApplicationSettings:ENTAPIAppVersionID");
            opsworklistDetailsParams.MobileChatAppVersionID = _configuration.GetValue<int>("ApplicationSettings:MobileChatAppVersionID");

            var providerURLDetails = await _wlUserRepository.GetOpsworklistDetails(opsworklistDetailsParams);

            if (providerURLDetails == null || providerURLDetails.Count == 0)
            {
                return NoContent();
            }
            else
            {
                var worklistsByUser = await _wlUserRepository.GetPermissionsByUserID(opsworklistDetailsParams);
                var userOffices = await _officeRepository.GetOfficesByQVE(opsworklistDetailsParams.UserID);

                providerURLDetails[0].WorkLists = worklistsByUser;
                providerURLDetails[0].UserOffices = userOffices;
                providerURLDetails[0].InstrumentationKey = _configuration.GetValue<string>("ApplicationInsights:InstrumentationKey");
                providerURLDetails[0].Appsecret = _configuration.GetValue<string>("ApplicationSettings:Appsecret");

                UserPermissionsParams userPermissionsParams = new()
                {
                    UserID = opsworklistDetailsParams.UserID,
                    ProviderID = providerURLDetails[0].AgencyID,
                    MenuList = new List<string> { UserRoleName.CaregiverChat.ToString() },
                    AppVersion = providerURLDetails[0].AppName,
                    Version = providerURLDetails[0].Version,
                    MinorVersion = providerURLDetails[0].MinorVersion
                };

                var chatAccess = _wlUserRepository.GetPermissions(userPermissionsParams);

                if (chatAccess != null && chatAccess.Any() && chatAccess[0].HasAccess)
                {
                    providerURLDetails[0].MobileChatAccess = await _wlUserRepository.CheckCaregiverChatAccess(userPermissionsParams.UserID, userPermissionsParams.ProviderID);
                }
                else
                {
                    providerURLDetails[0].MobileChatAccess = false;
                }

                return Ok(_mapper.Map<OpsworklistDetailsModel>(providerURLDetails[0]));
            }
        }

        [HttpGet]
        [Route("GetUserAuthenticationDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<UserAuthenticationModel>> GetUserAuthenticationDetails([FromQuery] UserDetailsParams userDetailsParams)
        {
            if (userDetailsParams.UserID == 0 || string.IsNullOrEmpty(userDetailsParams.SessionID))
            {
                return NoContent();
            }

            UserAuthenticationModel userAuthentication;

            if (_redisConnectionService.IsRedisCacheEnabled)
            {
                string userAuthHashKey = _configuration.GetValue<string>("UserAuth:UserAuthHashKey");
                string userAuthRedisKeyFeature = _configuration.GetValue<string>("UserAuth:UserAuthRedisKeyFeature");
                int userAuthRedisKeyExpiryInMinutes = _configuration.GetValue<int>("UserAuth:UserAuthRedisKeyExpiryInMinutes");

                if (string.IsNullOrEmpty(userAuthRedisKeyFeature))
                {
                    return NoContent();
                }

                string hashField = userAuthRedisKeyFeature.Replace("{userid}", userDetailsParams.UserID.ToString());

                userAuthentication = await _redisConnectionService.GetRedisHashCache<UserAuthenticationModel>(userAuthHashKey, hashField);

                if (userAuthentication != null)
                {
                    return Ok(_mapper.Map<UserAuthenticationModel>(userAuthentication));
                }

                userAuthentication = await _wlUserRepository.GetUserAuthenticationDetails(userDetailsParams);

                if (userAuthentication == null || !userAuthentication.IsUserLoggedIn)
                {
                    return NoContent();
                }

                await _redisConnectionService.SaveRedisHashCache(userAuthHashKey, hashField, userAuthentication, userAuthRedisKeyExpiryInMinutes);

                return Ok(_mapper.Map<UserAuthenticationModel>(userAuthentication));
            }

            UserAuthenticationModel userDetails = await _wlUserRepository.GetUserAuthenticationDetails(userDetailsParams);

            if (userDetails == null)
            {
                return NoContent();
            }

            return Ok(_mapper.Map<UserAuthenticationModel>(userDetails));
        }

        [HttpDelete]
        [Route("DeleteUserAuthenticationFromCache")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult> DeleteUserAuthenticationFromCache([FromQuery] int userId)
        {
            string userAuthHashKey = _configuration.GetValue<string>("UserAuth:UserAuthHashKey");
            string userAuthRedisKeyFeature = _configuration.GetValue<string>("UserAuth:UserAuthRedisKeyFeature");

            if (!_redisConnectionService.IsRedisCacheEnabled || string.IsNullOrEmpty(userAuthRedisKeyFeature))
            {
                return NoContent();
            }

            string hashField = userAuthRedisKeyFeature.Replace("{userid}", userId.ToString());

            bool isDeleted = await _redisConnectionService.DeleteRedisHashKey(userAuthHashKey, hashField);

            if (isDeleted)
            {
                return Ok();
            }

            return NoContent();
        }
    }
}
