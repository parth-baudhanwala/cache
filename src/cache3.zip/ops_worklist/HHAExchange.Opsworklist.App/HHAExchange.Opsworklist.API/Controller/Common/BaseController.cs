﻿using HHAExchange.Opsworklist.Domain;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;

namespace HHAExchange.Opsworklist.API
{
    public abstract class BaseController : ControllerBase
    {
        protected string result { set; get; }
        protected DataSet resultSet { set; get; }

        public Response<T> BuildResponse<T>(T data, HttpStatusCode httpStatusCode, string Reason = null, string Token = null)
        {
            Response<T> apiResponse = new Response<T>();
            apiResponse.HttpStatusCode = httpStatusCode;
            apiResponse.ResponseBody = data;
            return apiResponse;
        }

        protected ActionResult GetResult<T>(IEnumerable<T> responseObject) where T : class
        {
            var responseState = responseObject?.Any();
            ActionResult actionResult = NoContent();
            if (responseState.HasValue && responseState.Value)
            {
                actionResult = Ok(responseObject);
            }              
            return actionResult;
        }

        protected ActionResult GetResult<T>(T responseObject) where T : class
        {
            ActionResult actionResult = NoContent();
            if (responseObject != default)
            {
                actionResult = Ok(responseObject);
            }
            return actionResult;
        }
    }
}
