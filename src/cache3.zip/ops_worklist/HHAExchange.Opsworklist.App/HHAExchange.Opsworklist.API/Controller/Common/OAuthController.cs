﻿using HHAExchange.Opsworklist.API;
using HHAExchange.Opsworklist.Infra.Services;
using HHAExchange.Opsworklist.Infra.Utility;
using IdentityModel.Client;

namespace HHAExchange.Provider.API.Common
{
    [Route("[controller]")]
    [ApiController]
    public class OAuthController : BaseController
    {
        private readonly IConfiguration _configuration;
        private readonly IRedisConnectionService _redisConnectionService;

        public OAuthController(IConfiguration configuration, IRedisConnectionService redisConnectionService)
        {
            _configuration = configuration;
            _redisConnectionService = redisConnectionService;
        }

        [HttpGet]
        [Route("GetTokenForMobileChatApi")]
        public async Task<ActionResult<string>> GetTokenForMobileChatApi()
        {
            string keyName = _configuration["Token:MobileChatApiKeyName"];
            ClientConnection clientConnection = new ClientConnection(_configuration, _redisConnectionService);
            ClientCredentialsTokenRequest tokenRequest = new ClientCredentialsTokenRequest
            {
                Address = _configuration["Identity:TokenUrl"],
                ClientId = _configuration["MobileChat:ClientID"],
                ClientSecret = _configuration["MobileChat:ClientSecret"],
                Scope = _configuration["MobileChat:Scope"]
            };
            string credentials = await clientConnection.GetToken(keyName, tokenRequest).ConfigureAwait(false);

            if (string.IsNullOrEmpty(credentials))
            {
                return NoContent();
            }

            return Ok(credentials);
        }
    }
}
