﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    [Route("Common")]
    [ApiController]
    public class TaskActionsController : BaseController
    {
        private readonly IWlTaskRepository _wlTaskRepository;

        public TaskActionsController(IWlTaskRepository wlTaskRepository)
        {
            _wlTaskRepository = wlTaskRepository;
        }

        [HttpPost("UpdateTask")]
        public async Task<Response<string>> UpdateTask([FromQuery] string action, [FromBody] UpdateTaskRequest updateTask)
        {
            int Result = await _wlTaskRepository.UpdateTask(action, updateTask);
            return Result >= 1 ? BuildResponse("Number of records updated " + Result, System.Net.HttpStatusCode.OK) :
                BuildResponse("No records found ", System.Net.HttpStatusCode.NotFound);
        }

        [HttpGet]
        [Route("GetWlTaskStatusCount")]
        public async Task<ActionResult<List<WlTaskStatusCountModel>>> GetWlTaskStatusCount([FromQuery] int userID, int providerID)
        {
            List<WlTaskStatusCountModel> taskCounts = await _wlTaskRepository.GetOpenWorklistCountByUser(userID, providerID);
            return Ok(taskCounts);
        }
    }
}
