﻿namespace HHAExchange.Opsworklist.API
{
    [Route("[controller]")]
    [ApiController]
    [UserPermission("Ops Worklist Setup")]
    public class WorklistSetupController : BaseController
    {
        private readonly IWorklistSetupRepository _worklistSetupRepository;

        public WorklistSetupController(IWorklistSetupRepository worklistSetupRepository)
        {
            _worklistSetupRepository = worklistSetupRepository;
        }

        [HttpGet]
        [Route("GetAuthorizationSetup")]
        public async Task<ActionResult<AuthorizationSetupResponseModel>> GetAuthorizationSetup([FromQuery] int ProviderId)
        {
            AuthorizationSetupResponseModel authorizationSetupResponseModel = await _worklistSetupRepository.GetAuthorizationSetup(ProviderId);
            if (authorizationSetupResponseModel == null)
            {
                return NoContent();
            }
            return Ok(authorizationSetupResponseModel);
        }

        [HttpPut]
        [Route("SaveAuthorizationSetup")]
        public async Task<ActionResult<int>> SaveAuthorizationSetup(AuthorizationSetupRequestModel authorizationSetupRequestModel)
        {
            int isSaved = await _worklistSetupRepository.SaveAuthorizationSetup(authorizationSetupRequestModel);
            if (isSaved > 0)
            {
                return Ok();
            }
            return NoContent();
        }

        [HttpGet]
        [Route("GetMedicalComplianceSetup")]
        public async Task<ActionResult<MedicalComplianceSetupModel>> GetMedicalComplianceSetup([FromQuery] int providerId)
        {
            MedicalComplianceSetupModel complianceSetupModel = await _worklistSetupRepository.GetMedicalComplianceSetup(providerId);

            if (complianceSetupModel == null)
            {
                return NoContent();
            }

            return Ok(complianceSetupModel);
        }

        [HttpPut]
        [Route("SaveMedicalComplianceSetup")]
        public async Task<ActionResult<int>> SaveMedicalComplianceSetup(MedicalComplianceSetupModel medicalComplianceSetupModel)
        {
            int totalSavedRecords = await _worklistSetupRepository.SaveMedicalComplianceSetup(medicalComplianceSetupModel);

            if (totalSavedRecords > 0)
            {
                return Ok();
            }

            return NoContent();
        }

        [HttpGet]
        [Route("GetMasterWeekSetup")]
        public async Task<ActionResult<MasterWeekSetupResponseModel>> GetMasterWeekSetup([FromQuery] int providerId)
        {
            MasterWeekSetupResponseModel masterWeekSetupResponseModel = await _worklistSetupRepository.GetMasterWeekSetup(providerId);
            if (masterWeekSetupResponseModel == null)
            {
                return NoContent();
            }
            return Ok(masterWeekSetupResponseModel);
        }

        [HttpPut]
        [Route("SaveMasterWeekSetup")]
        public async Task<ActionResult<int>> SaveMasterWeekSetup(MasterWeekSetupRequestModel masterWeekSetupRequestModel)
        {
            int isSaved = await _worklistSetupRepository.SaveMasterWeekSetup(masterWeekSetupRequestModel);
            if (isSaved > 0)
            {
                return Ok();
            }
            return NoContent();
        }

        [HttpGet]
        [Route("GetUnscheduledVisitsSetup")]
        public async Task<ActionResult<UnscheduledVisitsSetupModel>> GetUnscheduledVisitsSetup([FromQuery] int providerId)
        {
            UnscheduledVisitsSetupModel unscheduledVisitsSetupModel = await _worklistSetupRepository.GetUnscheduledVisitsSetup(providerId);

            if(unscheduledVisitsSetupModel == null)
            {
                return NoContent();
            }

            return Ok(unscheduledVisitsSetupModel);
        }

        [HttpPut]
        [Route("SaveUnscheduledVisitsSetup")]
        public async Task<ActionResult<int>> SaveUnscheduledVisitsSetup(UnscheduledVisitsSetupModel unscheduledVisitsSetupModel)
        {
            int totalSavedRecords = await _worklistSetupRepository.SaveUnscheduledVisitsSetup(unscheduledVisitsSetupModel);

            if(totalSavedRecords > 0)
            {
                return Ok();
            }

            return NoContent();
        }

        [HttpGet]
        [Route("GetCertificationSetup")]
        public async Task<ActionResult<CertificationSetupResponseModel>> GetCertificationSetup([FromQuery] int providerId)
        {
            CertificationSetupResponseModel certificationSetupResponseModel = await _worklistSetupRepository.GetCertificationSetup(providerId);
            if (certificationSetupResponseModel == null)
            {
                return NoContent();
            }
            return Ok(certificationSetupResponseModel);
        }

        [HttpPut]
        [Route("SaveCertificationSetup")]
        public async Task<ActionResult<int>> SaveCertificationSetup(CertificationSetupRequestModel certificationSetupRequestModel)
        {
            int isSaved = await _worklistSetupRepository.SaveCertificationSetup(certificationSetupRequestModel);
            if (isSaved > 0)
            {
                return Ok();
            }
            return NoContent();
        }
    }
}
