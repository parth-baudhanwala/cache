﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace HHAExchange.Opsworklist.API
{
    [Route("SearchField")]
    [ApiController]   
    public class CaregiverFieldsController : BaseController
    {
        private readonly ICaregiverSearchRepository _caregiverSearchRepository;
        private readonly IOfficeRepository _officeRepository;
        private readonly ILocationForOfficeRepository _locationForOfficeRepository;
        private readonly IBranchForOfficeRepository _branchForOfficeRepository;

        public CaregiverFieldsController(IOfficeRepository officeRepository,
            ILocationForOfficeRepository locationForOfficeRepository, IBranchForOfficeRepository branchForOfficeRepository,
            ICaregiverSearchRepository caregiverSearchRepository)
        {
            _officeRepository = officeRepository;
            _locationForOfficeRepository = locationForOfficeRepository;
            _branchForOfficeRepository = branchForOfficeRepository;
            _caregiverSearchRepository = caregiverSearchRepository;
        }


        [HttpGet]
        [Route("GetAllOffices")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [UserPermission("Operation Worklist")]
        public async Task<Response<List<OfficeModel>>> GetAllOffices([FromQuery] OfficeModelParam requestParamOfficeModel)
        {
            var allOffices = await _officeRepository.GetAllOffices(requestParamOfficeModel);
            return BuildResponse(allOffices, HttpStatusCode.OK);
        }

        [HttpGet]
        [Route("GetBranchForOffice")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<List<BranchForOfficeModel>>> GetBranchForOffice([FromQuery] SearchFieldParams branchForOfficeParams)
        {
            var branchForOffice = await _branchForOfficeRepository.GetAllBranchForOffice(branchForOfficeParams);
            return BuildResponse(branchForOffice, HttpStatusCode.OK);
        }

        [HttpGet]
        [Route("GetCaregiverDisciplinesForOffice")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<List<CaregiverDisciplineForOfficeModel>>> GetCaregiverDisciplinesForOffice([FromQuery] DisciplineForOfficeParams disciplineForOfficeParams)
        {
            var caregiverDisciplinesForOffice = await _caregiverSearchRepository.GetCaregiverDisciplinesForOffice(disciplineForOfficeParams);
            return BuildResponse(caregiverDisciplinesForOffice, HttpStatusCode.OK);
        }

        [HttpGet]
        [Route("GetLocationForOffice")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<List<LocationForOfficeModel>>> GetLocationForOffice([FromQuery] SearchFieldParams locationForOfficeParams)
        {
            var locationForOffice = await _locationForOfficeRepository.GetAllLocationForOffice(locationForOfficeParams);
            return BuildResponse(locationForOffice, HttpStatusCode.OK);
        }

        [HttpGet("GetCaregiverTeam")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<IEnumerable<CaregiverTeamModel>>> GetCaregiverTeam([FromQuery] SearchFieldParams caregiverTeamParams)
        {
            var caregiverTeam = await _caregiverSearchRepository.GetAllCaregiverTeam(caregiverTeamParams);
            return GetResult(caregiverTeam);
        }

        [HttpGet("GetCaregiverComplianceExpItem")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<List<CaregiverComplianceExpItemModel>>> GetCaregiverComplianceExpItem([FromQuery] SearchFieldParams requestCaregiverComplianceExpItemParams)
        {
            var caregiverComplianceExpItem = await _caregiverSearchRepository.GetCaregiverComplianceExpItem(requestCaregiverComplianceExpItemParams);
            return BuildResponse(caregiverComplianceExpItem, HttpStatusCode.OK);
        }

        [HttpGet("GetLanguages")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<List<LanguageModel>>> GetLanguages()
        {
            List<LanguageModel> LanguageModels = await _caregiverSearchRepository.GetLanguages();
            return BuildResponse(LanguageModels, HttpStatusCode.OK);
        }
    }
}
