﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.Patient;
using HHAExchange.Opsworklist.Infra.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace HHAExchange.Opsworklist.API
{
    [Route("SearchField")]
    [ApiController]
    public class PatientFieldsController : BaseController
    {
        private readonly IPatientSearchRepository _patientSearchRepository;

        public PatientFieldsController(IPatientSearchRepository patientSearchRepository)
        {
            _patientSearchRepository = patientSearchRepository;
        }

        [HttpGet("GetCoordinatorsByID")]
        public async Task<Response<List<CoordinatorResponseModel>>> GetCoordinatorsByID([FromQuery] CoordinatorRequestModel coordinatorModel)
        {
            var result = await this._patientSearchRepository.GetCoordinatorsByID(coordinatorModel);
            return BuildResponse(result, System.Net.HttpStatusCode.OK);
        }

        [HttpGet("GetContractDetail")]
        public async Task<Response<List<ContractResponseModel>>> GetContractDetail([FromQuery] SearchFieldParams searchFieldParams)
        {
            var result = await this._patientSearchRepository.GetContractDetailsByVendorId(searchFieldParams);
            return BuildResponse(result, System.Net.HttpStatusCode.OK);
        }

        [HttpGet("GetPatientTeam")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<List<PatientTeamOptionModel>>> GetPatientTeam([FromQuery] SearchFieldParams searchFieldParams)
        {
            var caregiverTeam = await _patientSearchRepository.GetAllGetPatientTeam(searchFieldParams);
            return GetResult(caregiverTeam);
        }

        [HttpGet("GetNurseDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<List<PatientsNurseResponseModel>>> GetPatientsByNurseID([FromQuery] SearchFieldParams searchFieldParams)
        {
            var nurseDetails = await _patientSearchRepository.GetNurseDetails(searchFieldParams);
            return GetResult(nurseDetails);
        }
    }
}