﻿using Hangfire;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Struct;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    [Route("BroadCast")]
    [ApiController]
    public class BroadCastController : BaseController
    {
        private readonly IBroadcastRepository _broadcastRepository;
        private readonly IWlTaskNoteRepository _wlTaskNoteRepository;

        public BroadCastController(IBroadcastRepository broadcastRepository, IWlTaskNoteRepository wlTaskNoteRepository)
        {
            _broadcastRepository = broadcastRepository;
            _wlTaskNoteRepository = wlTaskNoteRepository;
        }

        [HttpPost]
        [Route("SendBroadCastDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<BroadcastModelStruct>> SendBroadCastDetails([FromBody] BroadCastParams broadcastrequest)
        {
            if (broadcastrequest.IsBulkTaskDetail)
            {
                var broadcast = new BroadcastModelStruct();
                BackgroundJob.Enqueue(() => SendBulkBroadCast(broadcastrequest));
                broadcast.broadCastID = -10;        //Caller can identify that the Response is from bulk task detail.
                return BuildResponse(broadcast, HttpStatusCode.OK);
            }
            else
            {
                var broadcast = await _broadcastRepository.SendBroadCastDetails(broadcastrequest);
                return BuildResponse(broadcast, HttpStatusCode.OK);
            }
        }

        [NonAction]
        [Queue("opsapi-parallel")]
        public async Task SendBulkBroadCast(BroadCastParams broadcastrequest)
        {
            int UserID = broadcastrequest.UserID;
            foreach (var caregiver in broadcastrequest.Taskdetails)
            {
                NotesController notesController = new NotesController(_wlTaskNoteRepository);
                broadcastrequest.Message = caregiver.taskDetail;
                broadcastrequest.AideID.Clear();
                broadcastrequest.AideID.Add(caregiver.aideID);
                broadcastrequest.UserID = UserID;
                var broadcast = await _broadcastRepository.SendBroadCastDetails(broadcastrequest);
                if (Convert.ToInt32(broadcast.broadCastID) > 0)
                {
                    TaskNotesRequest notesModel;
                    notesModel = broadcastrequest.NotesModel;
                    notesModel.WorklistTaskIds = caregiver.WorklistTaskIds;
                    notesModel.OfficeID = caregiver.officeID;
                    await notesController.AddNotes(notesModel);
                }
            }
        }
    }
}
