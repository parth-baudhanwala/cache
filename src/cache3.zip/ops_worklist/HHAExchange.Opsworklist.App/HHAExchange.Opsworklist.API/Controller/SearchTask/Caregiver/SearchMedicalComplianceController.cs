﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.WorklistTask;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    [Route("SearchTask")]
    [ApiController]
    public class SearchMedicalComplianceController : BaseController
    {
        private readonly IWlTaskMedicalCompExpRepository _wlTaskMedicalCompExpRepository;

        public SearchMedicalComplianceController(IWlTaskMedicalCompExpRepository wlTaskMedicalCompExpRepository)
        {
            _wlTaskMedicalCompExpRepository = wlTaskMedicalCompExpRepository;
        }

        [HttpGet]
        [Route("MedicalCompliance")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<PaginationResult<MedicalComplianceModel>>> Get([FromQuery] SearchWorklistQueryModel SearchWorklistQueryModel)
        {
            return Ok(await _wlTaskMedicalCompExpRepository.SearchTasks(SearchWorklistQueryModel));
        }

        [HttpGet]
        [Route("GetCaregiver")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<AutoFillDataModel>> AutoWlCaregiverDetails([FromQuery] AutoSuggestCaregiverDetails autoSuggestCaregiverDetails)
        {
            return Ok(await _wlTaskMedicalCompExpRepository.AutoWlCaregiverDetails(autoSuggestCaregiverDetails));
        }
    }
}
