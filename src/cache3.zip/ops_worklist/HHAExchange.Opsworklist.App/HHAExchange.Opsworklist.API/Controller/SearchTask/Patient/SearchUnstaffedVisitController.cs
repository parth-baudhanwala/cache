﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    [Route("SearchTask")]
    [ApiController]
    public class SearchUnstaffedVisitController : BaseController
    {
        private readonly IWlTaskUnstaffedVisitRepository _wlTaskUnstaffedVisitRepository;

        public SearchUnstaffedVisitController(IWlTaskUnstaffedVisitRepository wlTaskUnstaffedVisitRepository)
        {
            _wlTaskUnstaffedVisitRepository = wlTaskUnstaffedVisitRepository;
        }

        [HttpGet]
        [Route("UnstaffedVisits")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<PaginationResult<UnstaffedVisitTaskModel>>> Get([FromQuery] SearchUnstaffedVisitQueryModel Request)
        {
            return Ok(await _wlTaskUnstaffedVisitRepository.SearchTasks(Request));
        }
    }
}
