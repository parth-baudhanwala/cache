﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Controller.SearchTask.Patient
{
    [Route("SearchTask")]
    [ApiController]
    public class SearchExpiringCertificationController : BaseController
    {
        private readonly IWlTaskExpiringCertificationRepository _wlTaskExpiringCertificationRepository;

        public SearchExpiringCertificationController(IWlTaskExpiringCertificationRepository wlTaskExpiringCertificationRepository)
        {
            _wlTaskExpiringCertificationRepository = wlTaskExpiringCertificationRepository;
        }

        [HttpGet]
        [Route("ExpiringCertificationPeriod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<PaginationResult<ExpiringCertificationPeriodTaskModel>>> Get([FromQuery] SearchExpiringCertificationPeriodQueryModel Request)
        {
            return Ok(await _wlTaskExpiringCertificationRepository.SearchTasks(Request));            
        }
    }
}
