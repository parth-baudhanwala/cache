﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Controller.SearchTask
{
    [Route("SearchTask")]
    [ApiController]
    public class SearchMissingExpiringMWScheduleController : BaseController
    {
        private readonly IWlTaskMissingExpiringMWScheduleRepository _wlTaskMissingExpiringMWScheduleRepository;

        public SearchMissingExpiringMWScheduleController(IWlTaskMissingExpiringMWScheduleRepository wlTaskMissingExpiringMWScheduleRepository)
        {
            _wlTaskMissingExpiringMWScheduleRepository = wlTaskMissingExpiringMWScheduleRepository;
        }

        [HttpGet]
        [Route("MasterWeek")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<PaginationResult<MissingExpiringMWScheduleModel>>> Get([FromQuery] SearchMissingExpiringMWScheduleModel SearchWorklistQueryModel)
        {
            return Ok(await _wlTaskMissingExpiringMWScheduleRepository.SearchTasks(SearchWorklistQueryModel));
        }
    }
}
