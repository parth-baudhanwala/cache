﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    [Route("SearchTask")]
    [ApiController]
    public class SearchExpiringAuthorizationController : BaseController
    {
        private readonly IWlTaskExpiringAuthRepository _wlTaskExpiringAuthRepository;

        public SearchExpiringAuthorizationController(IWlTaskExpiringAuthRepository wlTaskExpiringAuthRepository)
        {
            _wlTaskExpiringAuthRepository = wlTaskExpiringAuthRepository;
        }

        [HttpGet]
        [Route("ExpiringAuthorization")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<PaginationResult<ExpiringAuthorizationTaskModel>>> Get([FromQuery] SearchExpiringAuthorizationQueryModel Request)
        {
            return Ok(await _wlTaskExpiringAuthRepository.SearchTasks(Request));
        }
    }
}
