﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    [Route("[controller]")]
    [ApiController]
    public class NotesController : BaseController
    {
        private readonly IWlTaskNoteRepository _wlTaskNoteRepository;

        public NotesController(IWlTaskNoteRepository wlTaskNoteRepository)
        {
            _wlTaskNoteRepository = wlTaskNoteRepository;
        }

        [HttpGet]
        [Route("GetAllNotesByTaskID")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public ActionResult<IEnumerable<TaskNoteModel>> GetAllNotesByTaskId([FromQuery] int WorklistTaskId, int primaryOfficeID, string ENTAPIURL)
        {
            var Notes = _wlTaskNoteRepository.GetNotesByTaskID(WorklistTaskId, primaryOfficeID, ENTAPIURL);
            
            if (Notes.Result.Count > 0)
            {
                return Ok(Notes);
            }
            
            return NoContent();
        }

        [HttpPost]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<int>> AddNotes([FromBody] TaskNotesRequest notesModel)
        {
            var Result = await _wlTaskNoteRepository.AddNotes(notesModel);
            if (Result > 0 && notesModel.CopyNotesTo.Equals("caregiver"))
            {
                await _wlTaskNoteRepository.SaveAideNotes(notesModel);
            }
            else if (Result > 0 && notesModel.CopyNotesTo.Equals("patient"))
            {
                await _wlTaskNoteRepository.SavePatientNotes(notesModel);
            }
            return BuildResponse(Result, HttpStatusCode.OK);
        }

        [HttpGet]
        [Route("GetSubjectItems")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<Response<List<NotesSubjectModel>>> GetNotesSubject([FromQuery] NotesSubjectRequestModel notesSubjetModel)
        {
            var result = await _wlTaskNoteRepository.GetNotesSubject(notesSubjetModel);
            return BuildResponse(result, HttpStatusCode.OK);
        }
    }
}
