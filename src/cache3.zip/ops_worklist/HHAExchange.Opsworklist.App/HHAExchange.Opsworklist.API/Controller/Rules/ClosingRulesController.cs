﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models;
using HHAExchange.Opsworklist.Handler;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Controller.Rules
{
    [Route("[controller]/CloseTask")]
    [ApiController]
    public class ClosingRulesController : BaseController
    {
        private readonly ICompleteTaskHandler _completeTaskHandler;
        public ClosingRulesController(ICompleteTaskHandler completeTaskHandler)
        {
            _completeTaskHandler = completeTaskHandler;
        }

        [HttpPost("MedicalCompliance")]
        public async Task<Response<string>> MedicalCompliance(RequestModel condition)
        {
            await _completeTaskHandler.ClosingConditionForMedicalCompliances(condition);
            return BuildResponse("Closing condition performed.", System.Net.HttpStatusCode.OK);
        }

        [HttpPost("ExpiringAuthorization")]
        public async Task<Response<string>> ExpiringAuthorization(RequestModel condition)
        {
            await _completeTaskHandler.ClosingConditionForExpiringAuthorization(condition);
            return BuildResponse("Closing condition performed.", System.Net.HttpStatusCode.OK);
        }

        [HttpPost("UnstaffedVisits")]
        public async Task<Response<string>> UnstaffedVisits(RequestModel condition)
        {
            await _completeTaskHandler.ClosingConditionForUnstaffedVisits(condition);
            return BuildResponse("Closing condition performed.", System.Net.HttpStatusCode.OK);
        }

        [HttpPost("MasterWeek")]
        public async Task<Response<string>> MasterWeek(RequestModel condition)
        {
            await _completeTaskHandler.ClosingConditionForMasterWeek(condition);
            return BuildResponse("Closing condition performed.", System.Net.HttpStatusCode.OK);
        }

        [HttpPost("ExpiringCertificationPeriod")]
        public async Task<Response<string>> ExpiringCertificationPeriod(RequestModel condition)
        {
            await _completeTaskHandler.ExpiringCertificationPeriod(condition);
            return BuildResponse("Closing condition performed.", System.Net.HttpStatusCode.OK);
        }
    }
}
