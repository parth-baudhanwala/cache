﻿using HHAExchange.Opsworklist.Core;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    [Route("File")]
    [ApiController]
    public class FileUploadController : ControllerBase
    {
        private readonly IFileRepository _fileRepository;
        private readonly IConfiguration _configuration;

        public FileUploadController(IConfiguration configuration, IFileRepository fileRepository)
        {
            _configuration = configuration;
            _fileRepository = fileRepository;
        }

        /// <summary>
        /// Upload a document with releveant feature
        /// </summary>
        /// <returns></returns>
        [HttpPost, DisableRequestSizeLimit]
        [Route("UploadDocument")]
        public async Task<List<FileUploadResponseModel>> UploadDocument()
        {
            List<FileUploadResponseModel> fileUploadResponseDetails = new List<FileUploadResponseModel>();
            try
            {
                var requesthttp = Request.Form.Files[0];
                if (requesthttp.FileName.Length > 0)
                {
                    #region File Upload Details
                    FileUploadData uploadData = new FileUploadData();
                    uploadData.Module = Request.Form["Module"];
                    uploadData.ModuleID = Request.Form["ModuleID"].ToInt();
                    uploadData.FeatureID = Request.Form["FeatureID"].ToInt();
                    uploadData.Feature = Request.Form["Feature"];
                    uploadData.Agency = Request.Form["Agency"];
                    uploadData.AgencyID = Request.Form["AgencyID"].ToInt();
                    uploadData.AppSecret = Request.Form["AppSecret"];
                    uploadData.AppName = Request.Form["AppName"];
                    uploadData.FileGUID = Request.Form["FileGUID"];
                    int UserID = 0;
                    UserID = Request.Form["UserID"].ToInt();
                    string HHAWSURL = Request.Form["HHAWSURL"];
                    string FileName = requesthttp.FileName;
                    string MethodType = Request.Form["MethodType"];
                    if (!FileName.IsNull())
                    {
                        string extension = System.IO.Path.GetExtension(FileName);
                        int PostedFileLength = (int)requesthttp.Length;
                        #endregion

                        #region File Validation and File Processing

                        fileUploadResponseDetails = await ValidateAndGetResponseDetail(uploadData, UserID, HHAWSURL, FileName, MethodType, extension, PostedFileLength);

                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                fileUploadResponseDetails = new List<FileUploadResponseModel> { new FileUploadResponseModel { UploadMessage = "Unexpected error occurred while uploading file. Please contact admin..!!" + ex.Message.ToString(), isfileUploadedSucessfully = false } };

            }
            return fileUploadResponseDetails;
        }

        private async Task<List<FileUploadResponseModel>> ValidateAndGetResponseDetail(FileUploadData uploadData, int UserID, string HHAWSURL, string FileName, string MethodType, string extension, int PostedFileLength)
        {
            List<FileUploadResponseModel> fileUploadResponseDetails;
            if (_fileRepository.ValidateFileType(extension, _configuration.GetValue<string>("ValidationSupportTypes:fileTypes")))
            {
                fileUploadResponseDetails = await HandleExceededFile(uploadData, HHAWSURL, PostedFileLength);

                switch (MethodType)
                {
                    case "validate":
                        fileUploadResponseDetails = new List<FileUploadResponseModel> { new FileUploadResponseModel { UploadMessage = "", isfileUploadedSucessfully = true } };
                        break;
                    case "save":
                        fileUploadResponseDetails = await SaveFileChanges(fileUploadResponseDetails, uploadData, UserID, HHAWSURL, FileName, PostedFileLength);
                        break;
                }
            }
            else
            {
                fileUploadResponseDetails = new List<FileUploadResponseModel> { new FileUploadResponseModel { UploadMessage = "The selected file has an invalid/unsupported extension.", isfileUploadedSucessfully = false } };
            }

            return fileUploadResponseDetails;
        }

        private async Task<List<FileUploadResponseModel>> HandleExceededFile(FileUploadData uploadData, string HHAWSURL, int PostedFileLength)
        {
            List<FileUploadResponseModel> fileUploadResponseDetails = new List<FileUploadResponseModel> { new FileUploadResponseModel { UploadMessage = "Unexpected error occurred while uploading file. Please contact admin..!!", isfileUploadedSucessfully = false } };
            var (issucceeded, objHHAXResult) = await _fileRepository.GetTotalFileSizeLimit(uploadData.AppName, uploadData.AppSecret, uploadData.AgencyID, PostedFileLength, HHAWSURL);
            if (!issucceeded && objHHAXResult.Status.Equals("filelimitexceed", StringComparison.OrdinalIgnoreCase))
            {

                fileUploadResponseDetails = new List<FileUploadResponseModel>
                {
                    new FileUploadResponseModel
                    {
                        UploadMessage = "Your agency has reached its overall storage limit for uploading files to HHAeXchange. No additional uploads will be permitted unless files are removed or your agency’s storage limit is increased.  Please contact HHAeXchange Technical Support for more information on increasing your agency’s storage limit.",
                        isfileUploadedSucessfully = false
                    }
                };

            }
            return fileUploadResponseDetails;
        }

        private async Task<List<FileUploadResponseModel>> SaveFileChanges(List<FileUploadResponseModel> fileUploadResponseDetails, FileUploadData uploadData, int UserID, string HHAWSURL, string FileName, int PostedFileLength)
        {
            byte[] buffer = null;
            using (var binaryReader = new BinaryReader(Request.Form.Files[0].OpenReadStream()))
            {
                buffer = binaryReader.ReadBytes(PostedFileLength);
                string strFileStream = Convert.ToBase64String(buffer, Base64FormattingOptions.InsertLineBreaks);
                HhaxWsResult hhaxWsResult = new HhaxWsResult();
                bool issucceeded = true;

                if (!string.IsNullOrEmpty(uploadData.FileGUID))
                {
                    (issucceeded, hhaxWsResult) = await _fileRepository.DeleteFile(uploadData.AppName, uploadData.AppSecret, uploadData.FileGUID, HHAWSURL);
                }


                #region Save File
                if (issucceeded)
                {
                    (issucceeded, hhaxWsResult) = await _fileRepository.SaveFile(uploadData, FileName, strFileStream, PostedFileLength, HHAWSURL);
                    if (!issucceeded) // Need to check file length in existing
                    {
                        fileUploadResponseDetails = new List<FileUploadResponseModel> { new FileUploadResponseModel { UploadMessage = "Unexpected error occurred while uploading file. Please contact admin..!!", isfileUploadedSucessfully = false } };
                    }
                    else
                    {
                        uploadData.FileGUID = hhaxWsResult.Result[0].Value;
                        #region Conexus BroadCast Update/File Successfull Upload
                        if (uploadData.Feature.Trim().ToUpper() == "CONEXUSEMAIL")
                        {
                            if ((await _fileRepository.UpdateBroadCastAttachmentDetails(UserID, uploadData.AgencyID, uploadData.FeatureID, uploadData.FileGUID)) > 0)
                            {
                                fileUploadResponseDetails = new List<FileUploadResponseModel> { new FileUploadResponseModel { UploadMessage = "", isfileUploadedSucessfully = true } };
                            }
                            else
                            {
                                fileUploadResponseDetails = new List<FileUploadResponseModel> { new FileUploadResponseModel { UploadMessage = "Unexpected error occurred while uploading file. Please contact admin..!!", isfileUploadedSucessfully = false } };
                            }
                        }
                        else
                        {
                            fileUploadResponseDetails = new List<FileUploadResponseModel> { new FileUploadResponseModel { UploadMessage = "", isfileUploadedSucessfully = true, FileGUID = uploadData.FileGUID } };
                        }
                        #endregion
                    }
                }
            }
            #endregion

            return fileUploadResponseDetails;
        }
    }
}
