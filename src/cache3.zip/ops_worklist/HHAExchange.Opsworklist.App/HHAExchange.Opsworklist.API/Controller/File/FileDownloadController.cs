﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API
{
    [Route("File")]
    [ApiController]
    public class FileDownloadController : ControllerBase
    {
        private readonly IFileRepository _fileRepository;

        public FileDownloadController(IFileRepository fileRepository)
        {
            _fileRepository = fileRepository;
        }

        [HttpGet]
        [Route("Download")]
        public async Task<IActionResult> Download([FromQuery] FileUploadData fileData)
        {
            FileContentResult fcr = null;
            var (issucceeded, objHHAXResult) = await _fileRepository.GetFile(fileData.AppName, fileData.AppSecret, fileData.FileGUID, fileData.HHAWSURL);
            if (issucceeded)
            {
                fcr = new FileContentResult(Convert.FromBase64String(objHHAXResult.Result[2].Value), objHHAXResult.Result[0].Value);
                Response.Headers.Add("x-file-content-type", objHHAXResult.Result[0].Value);
            }
            return fcr;
        }
    }
}
