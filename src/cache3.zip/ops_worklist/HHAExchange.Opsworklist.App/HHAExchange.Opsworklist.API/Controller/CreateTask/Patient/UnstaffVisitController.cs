﻿using HHAExchange.Opsworklist.Domain.PollerModel;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Controller.CreateTask.Patient
{
    [Route("[controller]/UnstaffVisit")]
    [ApiController]
    public class UnstaffVisitController : BaseController
    {
        private readonly IWlTaskUnstaffedVisitRepository _wlTaskUnstaffedVisitRepository;

        public UnstaffVisitController(IWlTaskUnstaffedVisitRepository iWlTaskUnstaffedVisitRepository)
        {
            _wlTaskUnstaffedVisitRepository = iWlTaskUnstaffedVisitRepository;
        }

        [HttpPost("InsertUnstaffVisit")]
        public async Task<int> InsertUnstaffVisit(List<UnstaffedVisitJobModel> records)
        {
            var insertStatus = await _wlTaskUnstaffedVisitRepository.InsertUnstaffVisit(records);
            return insertStatus;
        }
    }
}
