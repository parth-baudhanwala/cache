﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.Common.Patient;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Controller
{
    [Route("common")]
    [ApiController]
    public class PatientMasterWeekInfoContoller : BaseController
    {
        private readonly IPatientMasterWeekInfoRepository _mwInfoRepository;

        public PatientMasterWeekInfoContoller(IPatientMasterWeekInfoRepository mwInfoRepository)
        {
            _mwInfoRepository = mwInfoRepository;
        }

        [HttpGet]
        [Route("GetPatientMasterWeekInfo")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<MasterWeekInfoResponse>> GetPatientMasterWeekInfo([FromQuery] PatientMasterWeekInfoRequestModel request)
        {
            var masterWeekInfo = await _mwInfoRepository.GetPatientMasterWeekInfo(request);
            return GetResult(masterWeekInfo);
        }

        [HttpGet]
        [Route("GetUPRPatientMasterWeekInfo")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<ActionResult<MasterWeekInfoResponse>> GetUPRPatientMasterWeekInfo([FromQuery] PatientMasterWeekInfoRequestModel request)
        {
            var masterWeekInfo = await _mwInfoRepository.GetUPRPatientMasterWeekInfo(request);
            return GetResult(masterWeekInfo);
        }
    }
}
