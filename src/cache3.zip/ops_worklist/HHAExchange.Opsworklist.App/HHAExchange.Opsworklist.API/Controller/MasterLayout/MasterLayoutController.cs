﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.MasterLayout;
using HHAExchange.Opsworklist.Infra.Interfaces.MasterLayout;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Controller.MasterLayout
{
    [Route("[controller]")]
    [ApiController]
    public class MasterLayoutController : BaseController
    {
        private readonly IMasterLayoutRepository _masterLayoutRepository;

        public MasterLayoutController(IMasterLayoutRepository masterLayoutRepository)
        {
            _masterLayoutRepository = masterLayoutRepository;
        }

        [HttpGet]
        [Route("GetMachineInfo")]
        public ActionResult<MachineInfo> GetMachineInfo()
        {
            MachineInfo machineInfo = new MachineInfo();
            StringBuilder timeZone = new StringBuilder();
            string timeZoneStandardName = TimeZoneInfo.Local.StandardName;

            if (!string.IsNullOrEmpty(timeZoneStandardName))
            {
                string[] words = timeZoneStandardName.Split(" ");

                foreach (var word in words)
                {
                    timeZone.Append(word[0]);
                }
            }

            machineInfo.MachineDateTime = DateTime.Now.ToString("MM/dd HH:mm").Replace("-", "/") + " " + timeZone.ToString();
            machineInfo.MachineName = Environment.MachineName;

            return Ok(machineInfo);
        }

        [HttpGet]
        [Route("GetMenuList")]
        public async Task<ActionResult<IEnumerable<MenuDetails>>> GetMenuList([FromQuery] DefaultParam param)
        {
            if (param.UserID == 0)
            {
                return BadRequest();
            }

            IEnumerable<MenuDetails> menuDetails = await _masterLayoutRepository.GetMenuDetails(param);

            if (menuDetails == null || !menuDetails.Any())
            {
                return NoContent();
            }

            return Ok(menuDetails);
        }

        [HttpGet]
        [Route("GetNotifications")]
        public async Task<ActionResult<NotificationDetails>> GetNotifications([FromQuery] DefaultParam param)
        {
            if (param.UserID == 0 || param.ProviderID == 0)
            {
                return BadRequest();
            }

            NotificationDetails notification = await _masterLayoutRepository.GetNotifications(param);

            if (notification == null)
            {
                return NoContent();
            }

            return Ok(notification);
        }
    }
}
