﻿using AutoMapper;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class TaskActionsControllerTest
    {

        private TaskActionsController _taskActionsController;
        private Mock<IWlTaskRepository> _taskActionService;
        private IMapper _iMapper;

        [SetUp]
        public void Setup()
        {
            _iMapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<UpdateTaskRequest, string>();
                cfg.CreateMap<WlTaskStatusCountModel, int>();
            }).CreateMapper();

            _taskActionService = new Mock<IWlTaskRepository>();
            _taskActionsController = new TaskActionsController(_taskActionService.Object);
        }

        [Test]
        public async Task Test_UpdateStatus_CheckResults()
        {
            //Arrange
            int lstResponse = 1;
            var requestData = new UpdateTaskRequest();
            //Act
            _taskActionService.Setup(x => x.UpdateTask(It.IsAny<string>(), It.IsAny<UpdateTaskRequest>())).ReturnsAsync(lstResponse);
            Response<string> response = await _taskActionsController.UpdateTask("test", requestData);
            //Assert
            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.HttpStatusCode);
        }
        [Test]
        public async Task Test_UpdateStatus_CheckNoResults()
        {
            //Arrange
            int lstResponse = 0;
            var requestData = new UpdateTaskRequest();
            //Act
            _taskActionService.Setup(x => x.UpdateTask(It.IsAny<string>(), It.IsAny<UpdateTaskRequest>())).ReturnsAsync(lstResponse);
            Response<string> response = await _taskActionsController.UpdateTask("test", requestData);

            //Assert
            Assert.AreEqual(System.Net.HttpStatusCode.NotFound, response.HttpStatusCode);
        }
        [Test]
        public async Task Test_GetWlTaskStatusCount_CheckNoResults()
        {
            //Arrange
            var lstResponse = new List<WlTaskStatusCountModel>();
            lstResponse.Add(new WlTaskStatusCountModel
            {
                WorklistID = 1,
                TaskCount = 5
            });

            //Act
            _taskActionService.Setup(x => x.GetOpenWorklistCountByUser(It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(lstResponse);
            ActionResult<List<WlTaskStatusCountModel>> response = await _taskActionsController.GetWlTaskStatusCount(27389, 691);

            //Assert
            var result = response.Result as OkObjectResult;
            List<WlTaskStatusCountModel> value = (List<WlTaskStatusCountModel>)result.Value;
            Assert.AreEqual(1, value[0].WorklistID);
            Assert.AreEqual(5, value[0].TaskCount);
        }


    }
}
