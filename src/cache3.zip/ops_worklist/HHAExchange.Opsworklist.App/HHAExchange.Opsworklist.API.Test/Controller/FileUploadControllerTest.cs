﻿using AutoMapper;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class FileUploadControllerTest : BaseTest
    {
        private FileUploadController _fileUploadController;
        private Mock<IFileRepository> _fileRepository;
        private IConfiguration _configuration;
        private IMapper _iMapper;

        [SetUp]
        public void Setup()
        {
            _iMapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<FileUploadResponseModel, FileUploadResponseModel>();
                cfg.CreateMap<FileUploadData, FileUploadData>();

            }).CreateMapper();
            _configuration = GetConfiguration();
            _fileRepository = new Mock<IFileRepository>();
            _fileUploadController = new FileUploadController(_configuration, _fileRepository.Object);

        }
        [Test]
        public async Task Test_UploadDocument_CheckNoContentResult()
        {
            var uploadData = new FileUploadData();
            uploadData.AgencyID = 0;
            uploadData.FeatureID = 0;
            uploadData.FileGUID = "";
            ActionResult<IEnumerable<FileUploadResponseModel>> response = await _fileUploadController.UploadDocument();
            var result = response.Result as NoContentResult;
        }

    }
}
