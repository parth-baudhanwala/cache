﻿using AutoMapper;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class NotesControllerTest : BaseTest
    {
        private NotesController _notesController;
        private Mock<IWlTaskNoteRepository> _wlTaskNoteRepository;
        private Mock<IWlTaskExpiringAuthRepository> _wlTaskExpiringAuthRepository;
        private Mock<IWlTaskRepository> _IWlTaskRepository;
        private IConfiguration _configuration;
        private IMapper _iMapper;

        [SetUp]
        public void Setup()
        {
            _iMapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<TaskNoteModel, TaskNoteModel>();
                cfg.CreateMap<TaskNotesRequest, TaskNotesRequest>();
                cfg.CreateMap<NotesSubjectModel, NotesSubjectRequestModel>();
            }).CreateMapper();
            _configuration = GetConfiguration();
            _wlTaskNoteRepository = new Mock<IWlTaskNoteRepository>();
            _IWlTaskRepository = new Mock<IWlTaskRepository>();
            _wlTaskExpiringAuthRepository = new Mock<IWlTaskExpiringAuthRepository>();
            _notesController = new NotesController(_wlTaskNoteRepository.Object);
        }

        [Test]
        public void Test_GetAllNotesByTaskId_CheckNoContentResult()
        {
            var lstResponse = new List<TaskNoteModel>();

            _wlTaskNoteRepository.Setup(x => x.GetNotesByTaskID(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).ReturnsAsync(lstResponse);
            ActionResult<IEnumerable<TaskNoteModel>> response = _notesController.GetAllNotesByTaskId(0, 0, "");

            //Assert            
            var result = response.Result as NoContentResult;
        }

        [Test]
        public void Test_GetAllNotesByTaskId_CheckOkContentResult()
        {
            var lstResponse = new List<TaskNoteModel>();
            lstResponse.Add(new TaskNoteModel
            {
                Note = "Test",
                Subject = "Subject Test",
                CreatedBy = 27398,
                CreatedByUser = "Shek",
                WorklistTaskId = 1
            });

            int WorklistTaskId = 1;
            _wlTaskNoteRepository.Setup(x => x.GetNotesByTaskID(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).ReturnsAsync(lstResponse);
            ActionResult<IEnumerable<TaskNoteModel>> response = _notesController.GetAllNotesByTaskId(WorklistTaskId, 0, "");

            //Assert            
            var result = response.Result as OkObjectResult;

        }

        [Test]
        public async Task Test_GetNotesSubject_CheckNoContentResult()
        {
            var lstResponse = new List<NotesSubjectModel>();
            lstResponse.Add(new NotesSubjectModel
            {
                ReasonID = 1235,
                Active = 1,
                Status = "Open",
                Reason = "Test",
                ReasonDescription = "Test",
                ReasonLocation = "Hyderabad",
                ReasonType = 1254,
                NonCompliant = 1,
                OMIGEnabled = 1
            });
            var model = new NotesSubjectRequestModel();
            model.UserID = 27839;
            model.IsActive = 1;
            model.ReasonType = 1254;
            model.AppVersion = "ENT";
            model.Version = 21;
            model.MinorVersion = 1;

            //Act
            _wlTaskNoteRepository.Setup(x => x.GetNotesSubject(It.IsAny<NotesSubjectRequestModel>())).ReturnsAsync(lstResponse);
            Response<List<NotesSubjectModel>> response = await _notesController.GetNotesSubject(model);

            //Assert
            var result = response.ResponseBody;
            List<NotesSubjectModel> value = (List<NotesSubjectModel>)result;
            Assert.AreEqual(1235, value[0].ReasonID);
            Assert.AreEqual("Open", value[0].Status);
            Assert.AreEqual("Test", value[0].Reason);
        }

        [Test]
        public void Test_SaveAideNotes_CheckOkContentResult()
        {

            int lstResponse = 1;
            var model = new TaskNotesRequest();
            model.UserID = 27839;
            model.OfficeID = 851;
            model.ProviderID = 691;
            model.CopyNotesTo = "caregiver";
            model.PatientIDs = "1941774,3198315";
            model.AideIDs = "978947,954701";
            model.MinorVersion = 1;
            //Act
            _wlTaskNoteRepository.Setup(x => x.AddNotes(It.IsAny<TaskNotesRequest>())).ReturnsAsync(lstResponse);
            var response = _notesController.AddNotes(model);

            //Assert
            var result = response.Result.ResponseBody;
            Assert.AreEqual(result, 1);
        }

        [Test]
        public void Test_SavePatientNotes_CheckOkContentResult()
        {
            int lstResponse = 1;
            var model = new TaskNotesRequest();
            model.UserID = 27839;
            model.OfficeID = 851;
            model.ProviderID = 691;
            model.CopyNotesTo = "patient";
            model.PatientIDs = "1941774,3198315";
            model.AideIDs = "978947,954701";
            model.MinorVersion = 1;

            //Act
            _wlTaskNoteRepository.Setup(x => x.AddNotes(It.IsAny<TaskNotesRequest>())).ReturnsAsync(lstResponse);
            var response = _notesController.AddNotes(model);

            //Assert
            var result = response.Result.ResponseBody;
            Assert.AreEqual(result, 1);
        }

    }
}
