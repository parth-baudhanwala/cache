﻿using AutoMapper;
using HHAExchange.Opsworklist.API.Controller.SearchTask;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    class SearchMissingExpiringMWScheduleControllerTest
    {
        private SearchMissingExpiringMWScheduleController searchMissingExpiringMWScheduleController;
        private Mock<IWlTaskMissingExpiringMWScheduleRepository> wlTaskMissingExpiringMWScheduleRepository;
        private IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            _mapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<MissingExpiringMWScheduleModel, SearchMissingExpiringMWScheduleModel>();

            }).CreateMapper();
            wlTaskMissingExpiringMWScheduleRepository = new Mock<IWlTaskMissingExpiringMWScheduleRepository>();
            searchMissingExpiringMWScheduleController = new SearchMissingExpiringMWScheduleController(wlTaskMissingExpiringMWScheduleRepository.Object);
        }

        [Test]
        public async Task Test_GetMWSchedule_CheckNoContentResult()
        {
            SearchMissingExpiringMWScheduleModel request = new SearchMissingExpiringMWScheduleModel();

            ActionResult<PaginationResult<MissingExpiringMWScheduleModel>> response = await searchMissingExpiringMWScheduleController.Get(request);

            //Assert
            var result = response.Result as NoContentResult;

        }

    }
}
