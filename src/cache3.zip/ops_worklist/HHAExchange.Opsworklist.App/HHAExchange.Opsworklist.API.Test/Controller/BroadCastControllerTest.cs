﻿using AutoMapper;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Struct;
using HHAExchange.Opsworklist.Infra;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class BroadCastControllerTest
    {
        private BroadCastController _broadCastController;
        private Mock<IBroadcastRepository> _broadcastRepository;
        private Mock<IWlTaskNoteRepository> _wlTaskNoteRepository;
        private IMapper _iMapper;

        [SetUp]
        public void Setup()
        {
            _iMapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<BroadCastParams, BroadCastParams>();
                cfg.CreateMap<BroadcastModel, BroadcastModel>();
            }).CreateMapper();

            _broadcastRepository = new Mock<IBroadcastRepository>();
            _wlTaskNoteRepository = new Mock<IWlTaskNoteRepository>();
            _broadCastController = new BroadCastController(_broadcastRepository.Object, _wlTaskNoteRepository.Object);
        }

        [Test]
        public async Task Test_SendBroadCastDetails_NoContentResult()
        {
            //Arrange
            var lstResponse = new BroadcastModelStruct();
            _broadcastRepository.Setup(x => x.SendBroadCastDetails(It.IsAny<BroadCastParams>())).ReturnsAsync(lstResponse);

            //Act
            var model = new BroadCastParams();
            Response<BroadcastModelStruct> response = await _broadCastController.SendBroadCastDetails(model);
            //Assert
            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.HttpStatusCode);

        }

        [Test]
        public async Task Test_SendBroadCastDetails_CheckOkContentResult()
        {
            //Arrange
            var lstResponse = new BroadcastModelStruct();
            lstResponse.broadCastID = 0;

            var model = new BroadCastParams();
            model.UserID = 27398;
            model.ProviderID = 691;
            List<int> AideID = new List<int>(2) { 978944, 978945 };
            model.AideID = AideID;
            model.BroadCastType = 1;
            model.DeliveryOption = 1;
            model.Name = "Email_Testing";
            model.Subject = "Email_Testing";
            model.BCC = "sdavalbhakt@hhaexchange.com";
            model.Message = "Email_Testing_Message";
            model.PriorityType = 3;
            model.MessageTypeID = 3;
            model.TemplateID = 3846;
            model.MinorVersion = 2;
            model.Version = 21;
            model.AppVersion = "ENT";
            model.IsScheduled = 1;


            //Act
            _broadcastRepository.Setup(x => x.SendBroadCastDetails(It.IsAny<BroadCastParams>())).ReturnsAsync(lstResponse);
            Response<BroadcastModelStruct> response = await _broadCastController.SendBroadCastDetails(model);

            //Assert         
            BroadcastModelStruct value = (BroadcastModelStruct)response.ResponseBody;
            Assert.AreEqual(0, value.broadCastID);

        }


    }
}
