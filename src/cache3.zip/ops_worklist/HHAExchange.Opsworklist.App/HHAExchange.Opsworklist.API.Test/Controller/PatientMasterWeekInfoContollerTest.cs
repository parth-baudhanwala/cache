﻿using HHAExchange.Opsworklist.API.Controller;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.Common.Patient;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class PatientMasterWeekInfoContollerTest
    {
        private PatientMasterWeekInfoContoller patientMasterWeekInfoContoller;
        private Mock<IPatientMasterWeekInfoRepository> patientMasterWeekInfoRepository;

        [SetUp]
        public void Setup()
        {
            patientMasterWeekInfoRepository = new Mock<IPatientMasterWeekInfoRepository>();
            patientMasterWeekInfoContoller = new PatientMasterWeekInfoContoller(patientMasterWeekInfoRepository.Object);
        }
        [Test]
        public async Task Test_GetPatientMasterWeekInfo_CheckOKContentResult()
        {
            //Arrange
            var lstResponse = new MasterWeekInfoResponse();

            patientMasterWeekInfoRepository.Setup(x => x.GetPatientMasterWeekInfo(It.IsAny<PatientMasterWeekInfoRequestModel>())).ReturnsAsync(lstResponse);
            ActionResult<MasterWeekInfoResponse> response = await patientMasterWeekInfoContoller.GetPatientMasterWeekInfo(null);
            var result = response.Result as NoContentResult;

        }
        [Test]
        public async Task Test_GetPatientMasterWeekInfo_CheckNoContentResult()
        {
            //Arrange
            var lstResponse = new MasterWeekUprInfoResponse();

            patientMasterWeekInfoRepository.Setup(x => x.GetUPRPatientMasterWeekInfo(It.IsAny<PatientMasterWeekInfoRequestModel>())).ReturnsAsync(lstResponse);
            ActionResult<MasterWeekInfoResponse> response = await patientMasterWeekInfoContoller.GetPatientMasterWeekInfo(null);
            var result = response.Result as NoContentResult;

        }

        [Test]
        public async Task Test_GetUPRPatientMasterWeekInfo_CheckOKContentResult()
        {
            //Arrange
            var lstResponse = new MasterWeekUprInfoResponse();

            patientMasterWeekInfoRepository.Setup(x => x.GetUPRPatientMasterWeekInfo(It.IsAny<PatientMasterWeekInfoRequestModel>())).ReturnsAsync(lstResponse);
            ActionResult<MasterWeekInfoResponse> response = await patientMasterWeekInfoContoller.GetUPRPatientMasterWeekInfo(null);
            var result = response.Result as NoContentResult;

        }
        [Test]
        public async Task Test_GetUPRPatientMasterWeekInfo_CheckNoContentResult()
        {
            //Arrange
            var lstResponse = new MasterWeekInfoResponse();

            patientMasterWeekInfoRepository.Setup(x => x.GetPatientMasterWeekInfo(It.IsAny<PatientMasterWeekInfoRequestModel>())).ReturnsAsync(lstResponse);
            ActionResult<MasterWeekInfoResponse> response = await patientMasterWeekInfoContoller.GetUPRPatientMasterWeekInfo(null);
            var result = response.Result as NoContentResult;

        }

    }
}
