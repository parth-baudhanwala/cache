﻿using AutoMapper;
using HHAExchange.Opsworklist.API.Controller.Common;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.WorklistTask;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class SearchFieldsControllerTest
    {
        private SearchFieldsController _searchFieldsController;
        private Mock<ICaregiverSearchRepository> _caregiverTeamRepository;
        private Mock<IWlTaskExpiringAuthRepository> _IWlTaskExpiringAuthRepository;
        private Mock<IWlTaskUnstaffedVisitRepository> _IWlTaskUnstaffedVisitRepository;
        private Mock<IWlTaskMissingExpiringMWScheduleRepository> _IWlTaskMissingExpiringMWScheduleRepository;
        private Mock<IWlTaskExpiringCertificationRepository> _IWlTaskExpiringCertificationRepository;

        private IMapper _iMapper;

        public AutoSuggestCaregiverDetails AutoSuggestPatientDetails { get; private set; }

        [SetUp]
        public void Setup()
        {
            _iMapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ScriptTemplateModel, CommuncationTemplateRequest>();
                cfg.CreateMap<AutoFillDataModel, AutoFillDataModel>();
                cfg.CreateMap<SearchExpiringAuthorizationQueryModel, SearchExpiringAuthorizationQueryModel>();

            }).CreateMapper();

            _caregiverTeamRepository = new Mock<ICaregiverSearchRepository>();
            _IWlTaskExpiringAuthRepository = new Mock<IWlTaskExpiringAuthRepository>();
            _IWlTaskUnstaffedVisitRepository = new Mock<IWlTaskUnstaffedVisitRepository>();
            _IWlTaskMissingExpiringMWScheduleRepository = new Mock<IWlTaskMissingExpiringMWScheduleRepository>();
            _IWlTaskExpiringCertificationRepository = new Mock<IWlTaskExpiringCertificationRepository>();

            _searchFieldsController = new SearchFieldsController(_caregiverTeamRepository.Object, _IWlTaskExpiringAuthRepository.Object,
                _IWlTaskUnstaffedVisitRepository.Object, _IWlTaskMissingExpiringMWScheduleRepository.Object, _IWlTaskExpiringCertificationRepository.Object);
        }
        [Test]
        public async Task Test_GetTemplateDetailsbyID_CheckOkContentResult()
        {
            //Arrange
            var getTemplateDetailsModel = new ScriptTemplateModel
            {
                TemplateID = 12354,
                TemplateTypeId = 691,
                Subject = "27389",
                Message = "Test Message",
                Priority = 2,
                Type = 1
            };

            var userModel = new CommuncationTemplateRequest();
            userModel.TemplateID = 12354;
            userModel.AgencyId = 691;
            userModel.UserID = 27389;
            userModel.AppVersion = "ENT";
            userModel.Version = 21;
            userModel.MinorVersion = 1;
            userModel.CallerInfo = "Test Case : GetTemplateDetailsbyID";

            var lstResponse = new List<ScriptTemplateModel>();
            lstResponse.Add(getTemplateDetailsModel);
            _caregiverTeamRepository.Setup(x => x.GetTemplateDetailsByID(It.IsAny<CommuncationTemplateRequest>())).ReturnsAsync(lstResponse);

            //Act
            Response<List<ScriptTemplateModel>> response = await _searchFieldsController.GetTemplateDetailsbyID(userModel);


            //Assert
            var result = response.ResponseBody;
            List<ScriptTemplateModel> value = (List<ScriptTemplateModel>)result;
            Assert.AreEqual(12354, value[0].TemplateID);
            Assert.AreEqual(691, value[0].TemplateTypeId);
            Assert.AreEqual("27389", value[0].Subject);
            Assert.AreEqual("Test Message", value[0].Message);
        }


        [Test]
        public async Task Test_GetCommunicationScript_CheckOkContentResult()
        {
            //Arrange
            var getTemplateDetailsModel = new CommunicationScriptModel
            {
                TemplateId = 12354,
                Description = "Test Message"
            };

            var userModel = new CommunicationScriptRequest();
            userModel.OfficeIDs = "851,852";
            userModel.ProviderID = 691;
            userModel.UserID = 27389;
            userModel.TemplateType = 1;
            userModel.CallerInfo = "Test Case : GetTemplateDetailsbyID";

            var lstResponse = new List<CommunicationScriptModel>();
            lstResponse.Add(getTemplateDetailsModel);
            _caregiverTeamRepository.Setup(x => x.GetCommunicationScript(It.IsAny<CommunicationScriptRequest>())).ReturnsAsync(lstResponse);

            //Act
            Response<List<CommunicationScriptModel>> response = await _searchFieldsController.GetCommunicationScript(userModel);

            //Assert
            var result = response.ResponseBody;
            List<CommunicationScriptModel> value = (List<CommunicationScriptModel>)result;
            Assert.AreEqual(12354, value[0].TemplateId);
            Assert.AreEqual("Test Message", value[0].Description);
        }

        [Test]
        public async Task Test_AutoWlPatient_CheckNoContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            AutoSuggestPatientDetails autoSuggestPatientDetails = new AutoSuggestPatientDetails
            {
                patient = "test",
                ProviderID = 691,
                OfficeID = "851,852",
                worklistPath = "ExpiringAuthorization"
            };
            _IWlTaskExpiringAuthRepository.Setup(x => x.GetPatients(autoSuggestPatientDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoWlPatientDetails(autoSuggestPatientDetails);
            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_AutoWlPatinetDetails_CheckNoContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            AutoSuggestPatientDetails autoSuggestPatientDetails = new AutoSuggestPatientDetails
            {
                patient = null,
                ProviderID = 0,
                OfficeID = null,
                worklistPath = null
            };
            _IWlTaskExpiringAuthRepository.Setup(x => x.GetPatients(autoSuggestPatientDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoWlPatientDetails(autoSuggestPatientDetails);
            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_AutoWlCaregiverDetails_CheckNoContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            AutoSuggestPatientDetails autoSuggestPatientDetails = new AutoSuggestPatientDetails
            {
                patient = "test",
                ProviderID = 691,
                OfficeID = "851,852",
                worklistPath = "UnstaffedVisits"
            };
            _IWlTaskUnstaffedVisitRepository.Setup(x => x.GetPatients(autoSuggestPatientDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoWlPatientDetails(autoSuggestPatientDetails);
            var result = response.Result as NoContentResult;
        }
        [Test]
        public async Task Test_AutoWlMasterWeekDetails_CheckOkContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            AutoSuggestPatientDetails autoSuggestPatientDetails = new AutoSuggestPatientDetails
            {
                patient = "te",
                ProviderID = 691,
                OfficeID = "851",
                worklistPath = "UnstaffedVisits"
            };
            _IWlTaskUnstaffedVisitRepository.Setup(x => x.GetPatients(autoSuggestPatientDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoWlPatientDetails(autoSuggestPatientDetails);
            var result = response.Result as NoContentResult;
        }
        [Test]
        public async Task Test_AutoWlUnstaffedVisitsDetails_CheckOKContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            AutoSuggestPatientDetails autoSuggestPatientDetails = new AutoSuggestPatientDetails
            {
                patient = "te",
                ProviderID = 691,
                OfficeID = "851",
                worklistPath = "UnstaffedVisits"
            };
            _IWlTaskUnstaffedVisitRepository.Setup(x => x.GetPatients(autoSuggestPatientDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoWlPatientDetails(autoSuggestPatientDetails);
            var result = response.Result as NoContentResult;
        }
        [Test]
        public async Task Test_AutoWlMasterWeekDetails_CheckOKContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            AutoSuggestPatientDetails autoSuggestPatientDetails = new AutoSuggestPatientDetails
            {
                patient = "te",
                ProviderID = 691,
                OfficeID = "851",
                worklistPath = "UnstaffedVisits"
            };
            _IWlTaskUnstaffedVisitRepository.Setup(x => x.GetPatients(autoSuggestPatientDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoWlPatientDetails(autoSuggestPatientDetails);
            var result = response.Result as NoContentResult;
        }
        [Test]
        public async Task Test_AutoWlExpiringCertificationPeriodDetails_CheckOKContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            AutoSuggestPatientDetails autoSuggestPatientDetails = new AutoSuggestPatientDetails
            {
                patient = "te",
                ProviderID = 691,
                OfficeID = "851",
                worklistPath = "UnstaffedVisits"
            };
            _IWlTaskUnstaffedVisitRepository.Setup(x => x.GetPatients(autoSuggestPatientDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoWlPatientDetails(autoSuggestPatientDetails);
            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_GetPatientsByPhysician_CheckBadRequestResult()
        {
            var lstResponse = new List<AutoFillDataModel>();

            _IWlTaskExpiringCertificationRepository.Setup(x => x.GetPhysicians(It.IsAny<string>())).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoECPPhysician(null, null);

            var result = response.Result as NoContentResult;

        }

        [Test]
        public async Task Test_GetPatientsByPhysician_CheckOkContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            _IWlTaskExpiringCertificationRepository.Setup(x => x.GetPhysicians(It.IsAny<string>())).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoECPPhysician("Test", "ExpiringCertificationPeriod");
            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_GetPatientsByPhysician_CheckNoContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            _IWlTaskExpiringCertificationRepository.Setup(x => x.GetPhysicians(It.IsAny<string>())).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await _searchFieldsController.AutoECPPhysician("Test", "test");
            var result = response.Result as NoContentResult;
        }


    }
}
