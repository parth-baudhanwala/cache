﻿using AutoMapper;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.WorklistTask;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class SearchMedicalComplianceControllerTest
    {
        private SearchMedicalComplianceController searchMedicalComplianceController;
        private Mock<IWlTaskMedicalCompExpRepository> wlTaskMedicalCompExpRepository;
        private IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            _mapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<MedicalComplianceModel, MedicalComplianceModel>();
                cfg.CreateMap<AutoFillDataModel, AutoFillDataModel>();
                cfg.CreateMap<SearchWorklistQueryModel, SearchWorklistQueryModel>();

            }).CreateMapper();
            wlTaskMedicalCompExpRepository = new Mock<IWlTaskMedicalCompExpRepository>();
            searchMedicalComplianceController = new SearchMedicalComplianceController(wlTaskMedicalCompExpRepository.Object);
        }

        [Test]
        public async Task Test_AutoWlCaregiverDetails_CheckNoContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            AutoSuggestCaregiverDetails autoSuggestCaregiverDetails = null;
            wlTaskMedicalCompExpRepository.Setup(x => x.AutoWlCaregiverDetails(autoSuggestCaregiverDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await searchMedicalComplianceController.AutoWlCaregiverDetails(null);
            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_AutoWlCaregiverDetails_CheckOkContentResult()
        {
            var lstResponse = new List<AutoFillDataModel>();
            lstResponse.Add(new AutoFillDataModel
            {
                Id = "Test",
                Name = "Test"
            });

            AutoSuggestCaregiverDetails autoSuggestCaregiverDetails = new AutoSuggestCaregiverDetails()
            {
                caregiver = "test",
                OfficeID = "851,852",
                ProviderID = 691
            };
            wlTaskMedicalCompExpRepository.Setup(x => x.AutoWlCaregiverDetails(autoSuggestCaregiverDetails)).ReturnsAsync(lstResponse);
            ActionResult<AutoFillDataModel> response = await searchMedicalComplianceController.AutoWlCaregiverDetails(autoSuggestCaregiverDetails);

            //Assert
            var result = response.Result as OkObjectResult;
            List<AutoFillDataModel> value = (List<AutoFillDataModel>)result.Value;
            Assert.AreEqual("Test", value[0].Id);
            Assert.AreEqual("Test", value[0].Name);
        }

        [Test]
        public async Task Test_GetMedicalCompliance_CheckNoContentResult()
        {
            SearchWorklistQueryModel request = new SearchWorklistQueryModel();

            ActionResult<PaginationResult<MedicalComplianceModel>> response = await searchMedicalComplianceController.Get(request);

            //Assert
            var result = response.Result as NoContentResult;

        }
    }
}
