﻿using HHAExchange.Opsworklist.API.Controller.CreateTask.Patient;
using HHAExchange.Opsworklist.Domain.PollerModel;
using HHAExchange.Opsworklist.Infra;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class UnstaffVisitControllerTest
    {
        private UnstaffVisitController _unstaffVisitController;
        private Mock<IWlTaskUnstaffedVisitRepository> _iWlTaskUnstaffedVisitRepository;

        [SetUp]
        public void Setup()
        {
            _iWlTaskUnstaffedVisitRepository = new Mock<IWlTaskUnstaffedVisitRepository>();
            _unstaffVisitController = new UnstaffVisitController(_iWlTaskUnstaffedVisitRepository.Object);
        }

        [Test]
        public async Task Test_UnstaffVisit_InsertRecord()
        {
            int count = 0;
            List<UnstaffedVisitJobModel> unstaffedVisitJobModel = new List<UnstaffedVisitJobModel>();
            _iWlTaskUnstaffedVisitRepository.Setup(x => x.InsertUnstaffVisit(It.IsAny<List<UnstaffedVisitJobModel>>()))
                .ReturnsAsync(count);

            var insertCount = await _unstaffVisitController.InsertUnstaffVisit(unstaffedVisitJobModel);

            Assert.AreEqual(0, insertCount);
        }
    }
}