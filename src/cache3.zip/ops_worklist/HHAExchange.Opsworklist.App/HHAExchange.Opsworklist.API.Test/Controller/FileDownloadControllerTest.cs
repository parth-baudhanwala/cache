﻿using AutoMapper;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class FileDownloadControllerTest : ControllerBase
    {
        private FileDownloadController _fileDownloadController;
        private Mock<IFileRepository> _fileRepository;
        private IMapper _iMapper;

        [SetUp]
        public void Setup()
        {
            _iMapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<FileContentResult, FileUploadData>();
                cfg.CreateMap<FileContentResult, FileUploadData>();

            }).CreateMapper();

            _fileRepository = new Mock<IFileRepository>();
            _fileDownloadController = new FileDownloadController(_fileRepository.Object);

        }

        [Test]
        public async Task Test_DownloadDocument_CheckOkContentResult()
        {
            // Arrange           
            HhaxWsResult objHHAXResult = new HhaxWsResult();
            var uploadData = new FileUploadData();

            uploadData.AppName = "ENT";
            uploadData.AppSecret = "12546332";
            uploadData.FileGUID = "ab2bd817-98cd-4cf3-a80a-53ea0cd9c200";
            uploadData.HHAWSURL = "https://uat.hhaexchange.com/HHAWSENT221010000/";

            // Act            
            FileContentResult fcr = (FileContentResult)(await _fileDownloadController.Download(uploadData));

            IActionResult result = fcr;

            //Assert            
            var okObjectResult = result as NoContentResult;
            Assert.IsNull(okObjectResult);
        }
    }
}
