﻿using Microsoft.Extensions.Configuration;
using System.IO;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class BaseTest
    {
        protected static IConfiguration GetConfiguration()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile("StoredProcedures.json", optional: false, reloadOnChange: true);
            return builder.Build();
        }
    }
}
