﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.Patient;
using HHAExchange.Opsworklist.Infra.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class ExpiringAuthorizationControllerTest
    {
        private PatientFieldsController patientFieldsController;
        private Mock<IPatientSearchRepository> expiringAuthRepository;

        [SetUp]
        public void Setup()
        {
            expiringAuthRepository = new Mock<IPatientSearchRepository>();
            patientFieldsController = new PatientFieldsController(expiringAuthRepository.Object);
        }

        [Test]
        public async Task Test_GetCoordinatorsByID_CheckNoContentResult()
        {
            var lstResponse = new List<CoordinatorResponseModel>();
            expiringAuthRepository.Setup(x => x.GetCoordinatorsByID(It.IsAny<CoordinatorRequestModel>())).ReturnsAsync(lstResponse);
            Response<List<CoordinatorResponseModel>> response = await patientFieldsController.GetCoordinatorsByID(null);

            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.HttpStatusCode);
        }

        [Test]
        public async Task Test_GetContractDetailsByVendorId_CheckNoContentResult()
        {
            var lstResponse = new List<ContractResponseModel>();

            expiringAuthRepository.Setup(x => x.GetContractDetailsByVendorId(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            Response<List<ContractResponseModel>> response = await patientFieldsController.GetContractDetail(null);

            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.HttpStatusCode);

        }

        [Test]
        public async Task Test_GetCoordinatorsByID_CheckOkContentResult()
        {
            var lstResponse = new List<CoordinatorResponseModel>();
            lstResponse.Add(new CoordinatorResponseModel
            {
                CoordinatorID = 27389,
                CoordinatorName = "test"
            });
            var userModel = new CoordinatorRequestModel();
            userModel.UserID = 27389;
            userModel.OfficeID = "851,852";
            userModel.MinorVersion = 1;
            userModel.AppVersion = "ENT";
            userModel.Version = 21;

            expiringAuthRepository.Setup(x => x.GetCoordinatorsByID(It.IsAny<CoordinatorRequestModel>())).ReturnsAsync(lstResponse);
            Response<List<CoordinatorResponseModel>> response = await patientFieldsController.GetCoordinatorsByID(userModel);

            //Assert
            List<CoordinatorResponseModel> value = (List<CoordinatorResponseModel>)response.ResponseBody;
            Assert.AreEqual(27389, value[0].CoordinatorID);
            Assert.AreEqual("test", value[0].CoordinatorName);

        }
        [Test]
        public async Task Test_GetContractDetailsByVendorId_CheckOkContentResult()
        {
            var lstResponse = new List<ContractResponseModel>();
            lstResponse.Add(new ContractResponseModel
            {
                SourceID = 27389,
                SourceName = "test"
            });
            var userModel = new SearchFieldParams();
            userModel.UserID = 27389;
            userModel.OfficeID = "851,852";
            userModel.MinorVersion = 1;
            userModel.AppVersion = "ENT";
            userModel.Version = 21;

            expiringAuthRepository.Setup(x => x.GetContractDetailsByVendorId(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            Response<List<ContractResponseModel>> response = await patientFieldsController.GetContractDetail(userModel);

            //Assert
            List<ContractResponseModel> value = (List<ContractResponseModel>)response.ResponseBody;
            Assert.AreEqual(27389, value[0].SourceID);
            Assert.AreEqual("test", value[0].SourceName);
        }
        [Test]
        public async Task Test_GetGetPatientTeam_CheckNoContentResult()
        {
            var lstResponse = new List<PatientTeamOptionModel>();
            var request = new SearchFieldParams();
            expiringAuthRepository.Setup(x => x.GetAllGetPatientTeam(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            ActionResult<List<PatientTeamOptionModel>> response = await patientFieldsController.GetPatientTeam(request);

            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_GetGetPatientTeam_CheckOkContentResult()
        {
            var lstResponse = new List<PatientTeamOptionModel>();
            lstResponse.Add(new PatientTeamOptionModel
            {
                PatientTeam = "Test",
                PatientTeamID = 2545
            });

            var request = new SearchFieldParams();
            request.UserID = 25789;
            request.VendorID = 691;
            request.AppVersion = "ENT";
            request.Version = 21;
            request.MinorVersion = 1;
            expiringAuthRepository.Setup(x => x.GetAllGetPatientTeam(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            ActionResult<List<PatientTeamOptionModel>> response = await patientFieldsController.GetPatientTeam(null);

            //Assert
            var result = response.Result as OkObjectResult;
            List<PatientTeamOptionModel> value = (List<PatientTeamOptionModel>)result.Value;
            Assert.AreEqual(2545, value[0].PatientTeamID);
            Assert.AreEqual("Test", value[0].PatientTeam);
        }

        [Test]
        public async Task Test_GetNurseDetails_CheckNoContentResult()
        {
            var lstResponse = new List<PatientsNurseResponseModel>();

            expiringAuthRepository.Setup(x => x.GetNurseDetails(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            ActionResult<List<PatientsNurseResponseModel>> response = await patientFieldsController.GetPatientsByNurseID(null);

            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_GetNurseDetails_CheckOkContentResult()
        {
            var lstResponse = new List<PatientsNurseResponseModel>();
            lstResponse.Add(new PatientsNurseResponseModel
            {
                NurseID = 981549,
                NurseName = "Test"
            });
            var request = new SearchFieldParams();
            request.UserID = 25789;
            request.AppVersion = "ENT";
            request.Version = 21;
            request.MinorVersion = 1;

            expiringAuthRepository.Setup(x => x.GetNurseDetails(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            ActionResult<List<PatientsNurseResponseModel>> response = await patientFieldsController.GetPatientsByNurseID(request);

            //Assert
            var result = response.Result as OkObjectResult;
            List<PatientsNurseResponseModel> value = (List<PatientsNurseResponseModel>)result.Value;
            Assert.AreEqual(981549, value[0].NurseID);
            Assert.AreEqual("Test", value[0].NurseName);
        }

    }
}
