﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class MedicalComplianceControllerTest
    {
        private CaregiverFieldsController medicalComplianceController;
        private Mock<ICaregiverSearchRepository> caregiverSearchRepository;
        private Mock<IOfficeRepository> officeRepository;
        private Mock<ILocationForOfficeRepository> locationForOfficeRepository;
        private Mock<IBranchForOfficeRepository> branchForOfficeRepository;

        [SetUp]
        public void Setup()
        {
            officeRepository = new Mock<IOfficeRepository>();
            branchForOfficeRepository = new Mock<IBranchForOfficeRepository>();
            locationForOfficeRepository = new Mock<ILocationForOfficeRepository>();
            caregiverSearchRepository = new Mock<ICaregiverSearchRepository>();
            medicalComplianceController = new CaregiverFieldsController(officeRepository.Object, locationForOfficeRepository.Object, branchForOfficeRepository.Object,
                                                        caregiverSearchRepository.Object);
        }

        [Test]
        public async Task Test_GetAllOffices_CheckNoContentResult()
        {
            var lstResponse = new List<OfficeModel>();
            officeRepository.Setup(x => x.GetAllOffices(It.IsAny<OfficeModelParam>())).ReturnsAsync(lstResponse);
            Response<List<OfficeModel>> response = await medicalComplianceController.GetAllOffices(null);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.HttpStatusCode);

        }

        [Test]
        public async Task Test_GetBranchForOffice_CheckNoContentResult()
        {
            var lstResponse = new List<BranchForOfficeModel>();
            branchForOfficeRepository.Setup(x => x.GetAllBranchForOffice(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            Response<List<BranchForOfficeModel>> response = await medicalComplianceController.GetBranchForOffice(null);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.HttpStatusCode);
        }

        [Test]
        public async Task Test_GetLocationForOffice_CheckNoContentResult()
        {
            var lstResponse = new List<LocationForOfficeModel>();
            locationForOfficeRepository.Setup(x => x.GetAllLocationForOffice(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            Response<List<LocationForOfficeModel>> response = await medicalComplianceController.GetLocationForOffice(null);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.HttpStatusCode);
        }

        [Test]
        public async Task Test_GetCaregiverDisciplinesForOffice_CheckNoContentResult()
        {
            var lstResponse = new List<CaregiverDisciplineForOfficeModel>();
            caregiverSearchRepository.Setup(x => x.GetCaregiverDisciplinesForOffice(It.IsAny<DisciplineForOfficeParams>())).ReturnsAsync(lstResponse);
            Response<List<CaregiverDisciplineForOfficeModel>> response = await medicalComplianceController.GetCaregiverDisciplinesForOffice(null);
            Assert.AreEqual(System.Net.HttpStatusCode.OK, response.HttpStatusCode);
        }

        [Test]
        public async Task Test_GetAllOffices_CheckOkContentResult()
        {
            var lstResponse = new List<OfficeModel>();
            lstResponse.Add(new OfficeModel
            {
                OfficeID = 27389,
                OfficeName = "test"
            });

            var userModel = new OfficeModelParam();
            userModel.UserID = 27389;
            userModel.VendorID = "691";
            userModel.AppVersion = "ENT";
            userModel.MinorVersion = 21;
            userModel.Version = 2;

            officeRepository.Setup(x => x.GetAllOffices(It.IsAny<OfficeModelParam>())).ReturnsAsync(lstResponse);
            Response<List<OfficeModel>> response = await medicalComplianceController.GetAllOffices(userModel);

            //Assert
            List<OfficeModel> value = (List<OfficeModel>)response.ResponseBody;
            Assert.AreEqual(27389, value[0].OfficeID);
            Assert.AreEqual("test", value[0].OfficeName);


        }

        [Test]
        public async Task Test_GetCaregiverTeam_CheckOkContentResult()
        {
            var lstResponse = new List<BranchForOfficeModel>();
            lstResponse.Add(new BranchForOfficeModel
            {
                BranchID = 27389,
                BranchName = "test"
            });

            var userModel = new SearchFieldParams();
            userModel.UserID = 27389;
            userModel.VendorID = 691;
            userModel.AppVersion = "ENT";
            userModel.MinorVersion = 21;
            userModel.Version = 2;
            branchForOfficeRepository.Setup(x => x.GetAllBranchForOffice(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            Response<List<BranchForOfficeModel>> response = await medicalComplianceController.GetBranchForOffice(userModel);

            //Assert
            List<BranchForOfficeModel> value = (List<BranchForOfficeModel>)response.ResponseBody;
            Assert.AreEqual(27389, value[0].BranchID);
            Assert.AreEqual("test", value[0].BranchName);
        }

        [Test]
        public async Task Test_GetLocationForOffice_CheckOkContentResult()
        {
            var lstResponse = new List<LocationForOfficeModel>();
            lstResponse.Add(new LocationForOfficeModel
            {
                LocationID = 27389,
                Location = "test"
            });

            var userModel = new SearchFieldParams();
            userModel.UserID = 27389;
            userModel.VendorID = 691;
            userModel.AppVersion = "ENT";
            userModel.MinorVersion = 21;
            userModel.Version = 2;
            locationForOfficeRepository.Setup(x => x.GetAllLocationForOffice(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            Response<List<LocationForOfficeModel>> response = await medicalComplianceController.GetLocationForOffice(userModel);


            //Assert
            List<LocationForOfficeModel> value = (List<LocationForOfficeModel>)response.ResponseBody;
            Assert.AreEqual(27389, value[0].LocationID);
            Assert.AreEqual("test", value[0].Location);
        }

        [Test]
        public async Task Test_GetCaregiverDisciplinesForOffice_CheckOkContentResult()
        {
            var lstResponse = new List<CaregiverDisciplineForOfficeModel>();

            lstResponse.Add(new CaregiverDisciplineForOfficeModel
            {
                DisciplineID = 27389,
                Discipline = "test"
            });

            var userModel = new DisciplineForOfficeParams();
            userModel.UserID = 27389;
            userModel.AppVersion = "ENT";
            userModel.MinorVersion = 21;
            userModel.Version = 2;

            caregiverSearchRepository.Setup(x => x.GetCaregiverDisciplinesForOffice(It.IsAny<DisciplineForOfficeParams>())).ReturnsAsync(lstResponse);
            Response<List<CaregiverDisciplineForOfficeModel>> response = await medicalComplianceController.GetCaregiverDisciplinesForOffice(userModel);

            //Assert
            List<CaregiverDisciplineForOfficeModel> value = (List<CaregiverDisciplineForOfficeModel>)response.ResponseBody;
            Assert.AreEqual(27389, value[0].DisciplineID);
            Assert.AreEqual("test", value[0].Discipline);
        }
        //GetCaregiverTeam
        [Test]
        public async Task Test_GetCaregiverTeam_CheckNoContentResult()
        {
            var lstResponse = new List<CaregiverTeamModel>();

            caregiverSearchRepository.Setup(x => x.GetAllCaregiverTeam(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            ActionResult<IEnumerable<CaregiverTeamModel>> response = await medicalComplianceController.GetCaregiverTeam(null);
            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_GetAllCaregiverTeam_CheckOkContentResult()
        {
            //Arrange
            var lstResponse = new List<CaregiverTeamModel>();
            lstResponse.Add(new CaregiverTeamModel
            {
                CaregiverTeam = "test",
                CaregiverTeamID = 2245
            });

            var userModel = new SearchFieldParams();
            userModel.UserID = 27389;
            userModel.AppVersion = "ENT";
            userModel.MinorVersion = 21;
            userModel.Version = 2;
            userModel.OfficeID = "851";
            userModel.VendorID = 691;

            //Act
            caregiverSearchRepository.Setup(x => x.GetAllCaregiverTeam(It.IsAny<SearchFieldParams>())).ReturnsAsync(lstResponse);
            ActionResult<IEnumerable<CaregiverTeamModel>> response = await medicalComplianceController.GetCaregiverTeam(userModel);

            //Assert
            var result = response.Result as OkObjectResult;
            List<CaregiverTeamModel> value = (List<CaregiverTeamModel>)result.Value;
            Assert.AreEqual(2245, value[0].CaregiverTeamID);
            Assert.AreEqual("test", value[0].CaregiverTeam);
        }
    }
}
