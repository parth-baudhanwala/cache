﻿using AutoMapper;
using HHAExchange.Opsworklist.API.Controller.SearchTask.Patient;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class SearchExpiringAuthorizationControllerTest
    {
        private SearchExpiringAuthorizationController searchExpiringAuthorizationController;
        private Mock<IWlTaskExpiringAuthRepository> wlTaskExpiringAuthRepository;
        private SearchExpiringCertificationController searchExpiringCertificationController;
        private Mock<IWlTaskExpiringCertificationRepository> wlTaskExpiringCertificationRepository;
        private IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            _mapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<ExpiringAuthorizationTaskModel, ExpiringAuthorizationTaskModel>();
                cfg.CreateMap<AutoFillDataModel, AutoFillDataModel>();
                cfg.CreateMap<SearchExpiringAuthorizationQueryModel, SearchExpiringAuthorizationQueryModel>();
                cfg.CreateMap<ExpiringCertificationPeriodTaskModel, SearchExpiringCertificationController>();

            }).CreateMapper();
            wlTaskExpiringAuthRepository = new Mock<IWlTaskExpiringAuthRepository>();
            searchExpiringAuthorizationController = new SearchExpiringAuthorizationController(wlTaskExpiringAuthRepository.Object);
            wlTaskExpiringCertificationRepository = new Mock<IWlTaskExpiringCertificationRepository>();
            searchExpiringCertificationController = new SearchExpiringCertificationController(wlTaskExpiringCertificationRepository.Object);
        }

        [Test]
        public async Task Test_GetExpiringAuthorizations_CheckNoContentResult()
        {
            var lstResponse = new List<ExpiringAuthorizationTaskModel>();
            var request = new SearchExpiringAuthorizationQueryModel();

            ActionResult<PaginationResult<ExpiringAuthorizationTaskModel>> response = await searchExpiringAuthorizationController.Get(request);

            //Assert
            var result = response.Result as NoContentResult;

        }
        [Test]
        public async Task Test_GetTaskExpiringCertification_CheckNoContentResult()
        {
            var lstResponse = new List<ExpiringCertificationPeriodTaskModel>();
            var request = new SearchExpiringCertificationPeriodQueryModel();

            ActionResult<PaginationResult<ExpiringCertificationPeriodTaskModel>> response = await searchExpiringCertificationController.Get(request);

            //Assert
            var result = response.Result as NoContentResult;

        }
    }
}
