﻿using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    static class TestResultHelper
    {
        public static Task<List<OpsworklistDetailsModel>> GetOpsworklistDetailsExpectedResult()
        {
            List<OpsworklistDetailsModel> providerInfoDetails = null;
            return Task.Run<List<OpsworklistDetailsModel>>(() =>
            {
                providerInfoDetails = new List<OpsworklistDetailsModel>();
                return providerInfoDetails;
            });
        }

        public static Task<List<OpsworklistDetailsModel>> GetOpsworklistDetailsTestData()
        {
            List<OpsworklistDetailsModel> providerInfoDetails = null;
            return Task.Run<List<OpsworklistDetailsModel>>(() =>
            {
                providerInfoDetails = new List<OpsworklistDetailsModel>();
                providerInfoDetails.Add(new OpsworklistDetailsModel
                {
                    UserName = "Test"
                });
                return providerInfoDetails;
            });
        }

        public static Task<List<UserWorklistPermissions>> GetPermissionsByUserIDTestData()
        {
            List<UserWorklistPermissions> userWorklistPermissions = null;
            return Task.Run<List<UserWorklistPermissions>>(() =>
            {
                userWorklistPermissions = new List<UserWorklistPermissions>();
                userWorklistPermissions.Add(new UserWorklistPermissions
                {
                    UserName = "Test"
                });
                return userWorklistPermissions;
            });
        }

        public static Task<List<OfficeDetail>> GetOfficesByQVETestData()
        {
            List<OfficeDetail> officeDetail = null;
            return Task.Run<List<OfficeDetail>>(() =>
            {
                officeDetail = new List<OfficeDetail>();
                return officeDetail;
            });
        }

        public static Task<RequestModel> GetMedicalComplianceTestData()
        {
            RequestModel requestModel = null;
            return Task.Run<RequestModel>(() =>
            {
                var items = new List<string>();
                items.Add("1");
                requestModel = new RequestModel
                {
                    EntKeys = items,
                    ProviderID = 10
                };

                return requestModel;
            });
        }

        public static Task<RequestModel> GetExpiringCertificationPeriod()
        {
            RequestModel requestModel = null;
            return Task.Run<RequestModel>(() =>
            {
                var items = new List<string>();
                items.Add("1");
                requestModel = new RequestModel
                {
                    EntKeys = items,
                    ProviderID = 10
                };

                return requestModel;
            });
        }
    }
}
