﻿using AutoMapper;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class SearchUnstaffedVisitControllerTest
    {
        private SearchUnstaffedVisitController searchUnstaffedVisitController;
        private Mock<IWlTaskUnstaffedVisitRepository> wlTaskUnstaffedVisitRepository;
        private IMapper _mapper;

        [SetUp]
        public void Setup()
        {
            _mapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<UnstaffedVisitTaskModel, SearchUnstaffedVisitQueryModel>();
                cfg.CreateMap<AutoFillDataModel, AutoFillDataModel>();

            }).CreateMapper();
            wlTaskUnstaffedVisitRepository = new Mock<IWlTaskUnstaffedVisitRepository>();
            searchUnstaffedVisitController = new SearchUnstaffedVisitController(wlTaskUnstaffedVisitRepository.Object);
        }

        [Test]
        public async Task Test_GetUnstaffedVisits_CheckNoContentResult()
        {
            SearchUnstaffedVisitQueryModel request = new SearchUnstaffedVisitQueryModel();

            ActionResult<PaginationResult<UnstaffedVisitTaskModel>> response = await searchUnstaffedVisitController.Get(request);

            //Assert
            var result = response.Result as NoContentResult;

        }

    }
}
