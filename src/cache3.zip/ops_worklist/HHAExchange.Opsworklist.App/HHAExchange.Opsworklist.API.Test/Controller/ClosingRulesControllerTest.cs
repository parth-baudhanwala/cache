﻿using HHAExchange.Opsworklist.API.Controller.Rules;
using HHAExchange.Opsworklist.Domain.Models;
using HHAExchange.Opsworklist.Handler;
using Moq;
using NUnit.Framework;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class ClosingRulesControllerTest : BaseTest
    {
        private ClosingRulesController _closingRulesController;
        private Mock<ICompleteTaskHandler> _iCompleteTaskHandler;

        [SetUp]
        public void Setup()
        {
            _iCompleteTaskHandler = new Mock<ICompleteTaskHandler>();
            _closingRulesController = new ClosingRulesController(_iCompleteTaskHandler.Object);
        }

        [Test]
        public async Task Test_MedicalCompliance_ClosingCondition()
        {
            RequestModel condition = new RequestModel();
            var requestModelData = _iCompleteTaskHandler.Setup(x => x.ClosingConditionForMedicalCompliances(It.IsAny<RequestModel>()))
                .Returns(TestResultHelper.GetMedicalComplianceTestData());

            var insertCount = await _closingRulesController.MedicalCompliance(condition);

            Assert.Pass("Closing condition for MedicalCompliance succeseded");
        }

        [Test]
        public async Task Test_ExpiringAuthorization_ClosingCondition()
        {
            RequestModel condition = new RequestModel();
            var requestModelData = _iCompleteTaskHandler.Setup(x => x.ClosingConditionForExpiringAuthorization(It.IsAny<RequestModel>()))
                .Returns(TestResultHelper.GetMedicalComplianceTestData());

            var insertCount = await _closingRulesController.ExpiringAuthorization(condition);

            Assert.Pass("Closing condition for ExpiringAuthorization succeseded");
        }

        [Test]
        public async Task Test_UnstaffedVisits_ClosingCondition()
        {
            RequestModel condition = new RequestModel();
            var requestModelData = _iCompleteTaskHandler.Setup(x => x.ClosingConditionForUnstaffedVisits(It.IsAny<RequestModel>()))
                .Returns(TestResultHelper.GetMedicalComplianceTestData());

            var insertCount = await _closingRulesController.UnstaffedVisits(condition);

            Assert.Pass("Closing condition for UnstaffedVisits succeseded");
        }

        [Test]
        public async Task Test_MasterWeek_ClosingCondition()
        {
            RequestModel condition = new RequestModel();
            var requestModelData = _iCompleteTaskHandler.Setup(x => x.ClosingConditionForMasterWeek(It.IsAny<RequestModel>()))
                .Returns(TestResultHelper.GetMedicalComplianceTestData());

            var insertCount = await _closingRulesController.MasterWeek(condition);

            Assert.Pass("Closing condition for MasterWeek succeseded");
        }
        [Test]
        public async Task Test_ExpiringCertificationPeriod_ClosingCondition()
        {
            RequestModel condition = new RequestModel();
            var requestModelData = _iCompleteTaskHandler.Setup(x => x.ExpiringCertificationPeriod(It.IsAny<RequestModel>()))
                .Returns(TestResultHelper.GetExpiringCertificationPeriod());

            var insertCount = await _closingRulesController.ExpiringCertificationPeriod(condition);

            Assert.Pass("Closing condition for ExpiringCertificationPeriod succeseded");
        }
    }
}