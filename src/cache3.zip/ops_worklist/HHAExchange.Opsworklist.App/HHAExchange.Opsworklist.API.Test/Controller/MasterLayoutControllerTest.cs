﻿using HHAExchange.Opsworklist.API.Controller.MasterLayout;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Domain.Models.MasterLayout;
using HHAExchange.Opsworklist.Infra.Interfaces.MasterLayout;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    public class MasterLayoutControllerTest
    {
        private Mock<IMasterLayoutRepository> _masterLayoutRepository;
        private MasterLayoutController _masterLayoutController;

        [SetUp]
        public void Setup()
        {
            _masterLayoutRepository = new Mock<IMasterLayoutRepository>();
            _masterLayoutController = new MasterLayoutController(_masterLayoutRepository.Object);
        }

        [Test]
        public void Test_GetMachineInfo_CheckOkResult()
        {
            //Act
            ActionResult<MachineInfo> actionResult = _masterLayoutController.GetMachineInfo();
            ObjectResult result = (ObjectResult)actionResult.Result;

            //Assert
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Test]
        public async Task Test_GetMenuList_CheckBadRequest()
        {
            //Arrange
            DefaultParam defaultParam = new DefaultParam
            {
                UserID = 0
            };

            //Act
            var actionResult = await _masterLayoutController.GetMenuList(defaultParam);
            var result = (BadRequestResult)actionResult.Result;

            //Assert
            Assert.AreEqual((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Test]
        public async Task Test_GetMenuList_CheckOkResult()
        {
            //Arrange
            DefaultParam defaultParam = new DefaultParam
            {
                UserID = 40628,
                ProviderID = 691,
                AppVersion = "ENT",
                Version = 22.10M,
                MinorVersion = 1.0M
            };

            List<MenuDetails> menuDetails = new List<MenuDetails>
            {
                new MenuDetails
                {
                    Id = 1,
                    Name = "Caregiver",
                    ParentId = 0,
                    URL = "",
                    IsPopup = false,
                    WindowFeatures = ""
                }
            };

            //Act
            _masterLayoutRepository.Setup(x => x.GetMenuDetails(It.IsAny<DefaultParam>())).ReturnsAsync(menuDetails);
            var actionResult = await _masterLayoutController.GetMenuList(defaultParam);
            var result = (ObjectResult)actionResult.Result;

            //Assert
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Test]
        public async Task Test_GetMenuList_CheckNoContentResult()
        {
            //Arrange
            DefaultParam defaultParam = new DefaultParam
            {
                UserID = 40628,
                ProviderID = 691,
                AppVersion = "ENT",
                Version = 22.10M,
                MinorVersion = 1.0M
            };

            List<MenuDetails> menuDetails1 = null;
            List<MenuDetails> menuDetails2 = new List<MenuDetails>();

            //Act
            _masterLayoutRepository.Setup(x => x.GetMenuDetails(It.IsAny<DefaultParam>())).ReturnsAsync(menuDetails1);
            var actionResult1 = await _masterLayoutController.GetMenuList(defaultParam);
            var result1 = (NoContentResult)actionResult1.Result;

            _masterLayoutRepository.Setup(x => x.GetMenuDetails(It.IsAny<DefaultParam>())).ReturnsAsync(menuDetails2);
            var actionResult2 = await _masterLayoutController.GetMenuList(defaultParam);
            var result2 = (NoContentResult)actionResult2.Result;

            //Assert
            Assert.AreEqual((int)HttpStatusCode.NoContent, result1.StatusCode);
            Assert.AreEqual((int)HttpStatusCode.NoContent, result2.StatusCode);
        }

        [Test]
        public async Task Test_GetNotifications_CheckBadRequest()
        {
            //Arrange
            DefaultParam defaultParam1 = new DefaultParam
            {
                UserID = 0
            };

            DefaultParam defaultParam2 = new DefaultParam
            {
                ProviderID = 0
            };

            DefaultParam defaultParam3 = new DefaultParam
            {
                UserID = 0,
                ProviderID = 0
            };

            //Act
            var actionResult1 = await _masterLayoutController.GetNotifications(defaultParam1);
            var result1 = (BadRequestResult)actionResult1.Result;

            var actionResult2 = await _masterLayoutController.GetNotifications(defaultParam2);
            var result2 = (BadRequestResult)actionResult2.Result;

            var actionResult3 = await _masterLayoutController.GetNotifications(defaultParam3);
            var result3 = (BadRequestResult)actionResult1.Result;

            //Assert
            Assert.AreEqual((int)HttpStatusCode.BadRequest, result1.StatusCode);
            Assert.AreEqual((int)HttpStatusCode.BadRequest, result2.StatusCode);
            Assert.AreEqual((int)HttpStatusCode.BadRequest, result3.StatusCode);
        }

        [Test]
        public async Task Test_GetNotifications_CheckOkResult()
        {
            //Arrange
            DefaultParam defaultParam = new DefaultParam
            {
                UserID = 40628,
                ProviderID = 691,
                AppVersion = "ENT",
                Version = 22.10M,
                MinorVersion = 1.0M
            };

            NotificationDetails notification = new NotificationDetails
            {
                OpenCaseMsgCnt = 0,
                OpenCaseURL = "/open-case",
                UserMessagesCnt = 3,
                UserNotifMsgCnt = 300,
                UserToDosMsgCnt = 10
            };

            //Act
            _masterLayoutRepository.Setup(x => x.GetNotifications(It.IsAny<DefaultParam>())).ReturnsAsync(notification);
            var actionResult = await _masterLayoutController.GetNotifications(defaultParam);
            var result = (ObjectResult)actionResult.Result;

            //Assert
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Test]
        public async Task Test_GetNotifications_CheckNoContentResult()
        {
            //Arrange
            DefaultParam defaultParam = new DefaultParam
            {
                UserID = 40628,
                ProviderID = 691,
                AppVersion = "ENT",
                Version = 22.10M,
                MinorVersion = 1.0M
            };

            NotificationDetails notification = null;

            //Act
            _masterLayoutRepository.Setup(x => x.GetNotifications(It.IsAny<DefaultParam>())).ReturnsAsync(notification);
            var actionResult = await _masterLayoutController.GetNotifications(defaultParam);
            var result = (NoContentResult)actionResult.Result;

            //Assert
            Assert.AreEqual((int)HttpStatusCode.NoContent, result.StatusCode);
        }
    }
}
