﻿using AutoMapper;
using HHAExchange.Opsworklist.Domain;
using HHAExchange.Opsworklist.Infra;
using HHAExchange.Opsworklist.Infra.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HHAExchange.Opsworklist.API.Test.Controller
{
    class UsersContollerTest : BaseTest
    {
        private UsersController usersController;
        private Mock<IUsersRepository> _wlUserRepository;
        private IMapper _mapper;
        private IConfiguration _configuration;
        private Mock<IOfficeRepository> _officeRepository;
        private Mock<IRedisConnectionService> _redisRepository;

        [SetUp]
        public void Setup()
        {
            _configuration = GetConfiguration();
            _mapper = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.CreateMap<OpsworklistDetailsModel, OpsworklistDetailsModel>();
                cfg.CreateMap<WorklistTasksToAssignUsers, WorklistTasksToAssignUsers>();

            }).CreateMapper();
            _wlUserRepository = new Mock<IUsersRepository>();
            _officeRepository = new Mock<IOfficeRepository>();
            _redisRepository = new Mock<IRedisConnectionService>();
            usersController = new UsersController(_mapper, _configuration, _wlUserRepository.Object, _officeRepository.Object, _redisRepository.Object);
        }

        [Test]
        public async Task Test_GetUsersByWorklistID_CheckNoContentResult()
        {
            var lstResponse = new List<WorklistTasksToAssignUsers>();
            _wlUserRepository.Setup(x => x.GetUsersByWorklistID(It.IsAny<WorklistUsersForOfficeModel>())).ReturnsAsync(lstResponse);
            ActionResult<IEnumerable<WorklistTasksToAssignUsers>> response = await usersController.GetUsersByWorklistID(null);
            var result = response.Result as NoContentResult;
        }

        [Test]
        public async Task Test_GetUsersByWorklistID_CheckOkContentResult()
        {
            var lstResponse = new List<WorklistTasksToAssignUsers>();
            lstResponse.Add(new WorklistTasksToAssignUsers
            {
                FirstName = "test",
                UserID = 27389
            });
            var userModel = new WorklistUsersForOfficeModel();
            userModel.WorklistID = 1;
            userModel.OfficeIDs = "851,852";

            _wlUserRepository.Setup(x => x.GetUsersByWorklistID(It.IsAny<WorklistUsersForOfficeModel>())).ReturnsAsync(lstResponse);
            ActionResult<IEnumerable<WorklistTasksToAssignUsers>> response = await usersController.GetUsersByWorklistID(userModel);

            var result = response.Result as OkObjectResult;
            List<WorklistTasksToAssignUsers> value = (List<WorklistTasksToAssignUsers>)result.Value;
            Assert.AreEqual("test", value[0].FirstName);
        }

        [Test]
        public async Task Test_GetUserProfile_CheckNoContentResult()
        {
            // Arrange

            OpsworklistDetailsParams OpsworklistDetailsParams = new OpsworklistDetailsParams();
            _wlUserRepository.Setup(x => x.GetOpsworklistDetails(It.IsAny<OpsworklistDetailsParams>()))
                .Returns(TestResultHelper.GetOpsworklistDetailsExpectedResult());

            // Act

            var taskOpsworklistDetailsModel = await usersController.GetUserProfile(OpsworklistDetailsParams);

            //  Assert

            if (taskOpsworklistDetailsModel.Result == null || taskOpsworklistDetailsModel.Value == null)
                Assert.Pass("Test pass for NoContent");
            else
                Assert.Fail("Test failed for NoContent");
        }

        [Test]
        public async Task Test_GetUserProfile_CheckOkContentResult()
        {
            // Arrange

            OpsworklistDetailsParams OpsworklistDetailsParams = new OpsworklistDetailsParams();
            var providerURLDetails = _wlUserRepository.Setup(x => x.GetOpsworklistDetails(It.IsAny<OpsworklistDetailsParams>()))
                .Returns(TestResultHelper.GetOpsworklistDetailsTestData());

            var WorklistsByUser = _wlUserRepository.Setup(x => x.GetPermissionsByUserID(It.IsAny<OpsworklistDetailsParams>()))
                .Returns(TestResultHelper.GetPermissionsByUserIDTestData());

            var UserOffices = _officeRepository.Setup(x => x.GetOfficesByQVE(It.IsAny<int>()))
                .Returns(TestResultHelper.GetOfficesByQVETestData());

            // Act

            var taskOpsworklistDetailsModel = await usersController.GetUserProfile(OpsworklistDetailsParams);


            //  Assert

            var opsworklistDetailsModelResult = taskOpsworklistDetailsModel.Result as OkObjectResult;
            OpsworklistDetailsModel opsworklistDetailsModel = (OpsworklistDetailsModel)opsworklistDetailsModelResult.Value;
            Assert.AreEqual("Test", opsworklistDetailsModel.UserName);
        }
    }
}