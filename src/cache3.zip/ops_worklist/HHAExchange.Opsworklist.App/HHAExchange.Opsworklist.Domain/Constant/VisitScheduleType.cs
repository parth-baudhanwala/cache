﻿namespace HHAExchange.Opsworklist.Domain.Constant
{
    public static class VisitScheduleType
    {
        public static readonly string DailyFixed = "Daily Fixed";
        public static readonly string DailyVariable = "Daily Variable";
        public static readonly string WeeklyVariable = "Weekly Variable";
        public static readonly string NoSchedule = "No Schedule";
    }
}
