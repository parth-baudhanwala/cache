﻿namespace HHAExchange.Opsworklist.Domain
{
    public class CommandInfo
    {
        public string ConnectionString { get; set; }
        public string SPName { get; set; }
        public int Timeout { get; set; }
    }
}
