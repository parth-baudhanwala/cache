﻿
namespace HHAExchange.Opsworklist.Domain.Models.WorklistTask
{
    public class SearchWorklistQueryModel : DefaultSearchParams
    {
        public string caregiverID { get; set; }
        public string caregiverCode { get; set; }
        public int UserID { get; set; }
        public string caregiver { get; set; }
        public string teamID { get; set; }
        public string branchID { get; set; }
        public string locationID { get; set; }
        public string disciplineID { get; set; }
        public string caregiverStatusID { get; set; }
        public string languageID { get; set; }
        public string expirationDuration { get; set; } = "30";
        public string expirationItem { get; set; }
    }

    public class AutoSuggestCaregiverDetails : DefaultSearchParams
    {
        public string caregiver { get; set; }
    }

    public class AutoSuggestPatientDetails : DefaultSearchParams
    {
        public string worklistPath { get; set; }
        public string patient { get; set; }
    }
}
