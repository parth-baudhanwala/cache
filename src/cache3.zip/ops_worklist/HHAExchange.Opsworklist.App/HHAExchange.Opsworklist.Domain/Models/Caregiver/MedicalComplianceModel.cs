﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class MedicalComplianceModel : DefaultWorklistModel
    {

        public string ExpirationItemType { get; set; }
        public string ExpirationItem { get; set; }
        public DateTime DueDate { get; set; }
        public string CareGiverCode { get; set; }
        public int? CareGiverId { get; set; }
        public int? CareGiverTeamId { get; set; }
        public string CareGiverFirstname { get; set; }
        public string CareGiverLastname { get; set; }
        public string CareGiverMiddlename { get; set; }

        public string CareGiverFullName
        {
            get
            {
                string fullName = "";

                if (!string.IsNullOrEmpty(CareGiverFirstname)) fullName = CareGiverFirstname + " ";
                if (!string.IsNullOrEmpty(CareGiverLastname)) fullName = fullName + CareGiverLastname + " ";
                if (!string.IsNullOrEmpty(CareGiverMiddlename)) fullName = fullName + CareGiverMiddlename + " ";

                return fullName.Trim();
            }
        }
    }
}
