﻿namespace HHAExchange.Opsworklist.Domain
{
    public class CaregiverTeamModel
    {
        public int CaregiverTeamID { get; set; }
        public string CaregiverTeam { get; set; }
    }
}
