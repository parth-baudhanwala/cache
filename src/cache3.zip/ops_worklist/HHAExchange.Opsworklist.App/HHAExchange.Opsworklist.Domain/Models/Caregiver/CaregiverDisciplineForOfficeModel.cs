﻿
namespace HHAExchange.Opsworklist.Domain
{
    public class CaregiverDisciplineForOfficeModel
    {
        public int DisciplineID { get; set; }
        public string Discipline { get; set; }

    }
}
