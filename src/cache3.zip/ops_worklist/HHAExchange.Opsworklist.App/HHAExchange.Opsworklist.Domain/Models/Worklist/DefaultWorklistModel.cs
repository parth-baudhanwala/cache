﻿namespace HHAExchange.Opsworklist.Domain
{
    public class DefaultWorklistModel
    {
        public int WorklistTaskId { get; set; }
        public int WorklistId { get; set; }
        public int? OfficeId { get; set; }
        public int? AssignedBy { get; set; }
        public int? AssignedTo { get; set; }
        public string AssignedByUser { get; set; }
        public string AssignedToUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Status { get; set; }
        public LastNotes LastNotes { get; set; }
        public string WorklistEntKey { get; set; }
    }
}
