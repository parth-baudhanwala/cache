﻿using System.Collections.Generic;

namespace HHAExchange.Opsworklist.Domain
{
    public class OpsworklistDetailsModel
    {
        public string AppName { get; set; }
        public decimal Version { get; set; }
        public decimal MinorVersion { get; set; }
        public string VendorName { get; set; }
        public string UserName { get; set; }
        public int AgencyID { get; set; }
        public string ENTMainURL { get; set; }
        public string ENTPURL { get; set; }
        public List<UserWorklistPermissions> WorkLists { get; set; }
        public List<OfficeDetail> UserOffices { get; set; }
        public string InstrumentationKey { get; set; }
        public string Appsecret { get; set; }
        public string HHAWSENTURL { get; set; }
        public string OpsworklistAPIURL { get; set; }
        public string ProviderAppURL { get; set; }
        public string ENTAPIURL { get; set; }
        public string MobileChatUrl { get; set; }
        public bool MobileChatAccess { get; set; }
    }
}
