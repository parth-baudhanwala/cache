﻿namespace HHAExchange.Opsworklist.Domain
{
    public class OpsworklistDetailsParams : DefaultParam
    {
        public int ENTMainAppversionID { get; set; }
        public int ENTPAppversionID { get; set; }
        public int OpsworklistAPIAppversionID { get; set; }
        public int HHAWSENTAppversionID { get; set; }
        public int ProviderAppversionID { get; set; }
        public int ENTAPIAppVersionID { get; set; }
        public int MobileChatAppVersionID { get; set; }
    }
}
