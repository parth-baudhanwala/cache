﻿namespace HHAExchange.Opsworklist.Domain
{
    public partial class WlTaskStatusCountModel
    {
        public int WorklistID { get; set; }
        public int TaskCount { get; set; }
    }
}
