﻿namespace HHAExchange.Opsworklist.Domain
{
    public class UpdateTaskRequest
    {
        public string WlTaskId { get; set; }
        public string Status { get; set; }
        public int AssignedBy { get; set; }
        public int AssignedTo { get; set; }
        public string AssignedByUser { get; set; }
        public string AssignedToUser { get; set; }
        public int UpdatedBy { get; set; }
        public string UpdatedByUser { get; set; }
    }
}
