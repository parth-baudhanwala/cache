﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class LastNotes
    {
        public string Note { get; set; }
        public string Subject { get; set; }
        public string FileGuid { get; set; }
        public string FileName { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedByUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime CreatedDateUtc { get; set; }
    }
}
