﻿namespace HHAExchange.Opsworklist.Domain
{
    public partial class NotesSubjectModel
    {
        public int ReasonID { get; set; }
        public string Reason { get; set; }
        public string ReasonDescription { get; set; }
        public int ReasonType { get; set; }
        public string ReasonLocation { get; set; }
        public int Active { get; set; }
        public int NonCompliant { get; set; }
        public string Status { get; set; }
        public int OMIGEnabled { get; set; }
        public int SortOrder { get; set; }


    }
}
