﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class TaskNotesRequest : DefaultParam
    {
        public string WorklistTaskIds { get; set; }
        public string Subject { get; set; }
        public string SubjectText { get; set; }
        public string Note { get; set; }
        public string AttachmentName { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedByUser { get; set; }
        public int Result { get; set; }
        public string PatientIDs { get; set; }
        public string AideIDs { get; set; }
        public int OfficeID { get; set; }
        public string CopyNotesTo { get; set; }
        public bool? IsInternalNote { get; set; }
        public string FileAttachmentGUID { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime CreatedDateUtc { get; set; }
    }
}
