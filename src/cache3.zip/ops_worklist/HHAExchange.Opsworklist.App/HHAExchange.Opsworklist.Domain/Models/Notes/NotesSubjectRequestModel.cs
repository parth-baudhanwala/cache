﻿namespace HHAExchange.Opsworklist.Domain
{
    public partial class NotesSubjectRequestModel : DefaultParam
    {
        public int IsActive { get; set; }
        public int ReasonType { get; set; }
    }
}
