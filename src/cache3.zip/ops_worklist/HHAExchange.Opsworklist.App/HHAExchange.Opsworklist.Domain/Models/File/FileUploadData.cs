﻿namespace HHAExchange.Opsworklist.Domain
{
    public class FileUploadData
    {
        public int ModuleID { get; set; }
        public int FeatureID { get; set; }
        public int AgencyID { get; set; }
        public string Module { get; set; }
        public string Feature { get; set; }
        public string Agency { get; set; }
        public string FileGUID { get; set; }
        public string AppSecret { get; set; }
        public string AppName { get; set; }
        public string HHAWSURL { get; set; }
    }
}
