﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class FileDownloadResponse
    {
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public Byte[] FileData { get; set; }        
        public string DownloadMessage { get; set; }
        public Boolean FileStatus { get; set; }
    }
}
