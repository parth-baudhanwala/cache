﻿namespace HHAExchange.Opsworklist.Domain
{
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://tempuri.org")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org", IsNullable = false)]
    public partial class DeleteFile
    {

        /// <remarks/>
        public string appName { get; set; }

        /// <remarks/>
        public string appSecret { get; set; }

        /// <remarks/>
        public string fileGUID { get; set; }
    }
}