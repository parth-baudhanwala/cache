﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class FileUploadResponseModel
    {
        public string UploadMessage { get; set; }
        public string FileGUID { get; set; }
        public Boolean isfileUploadedSucessfully { get; set; }
    }
}
