﻿namespace HHAExchange.Opsworklist.Domain
{
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://tempuri.org/")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org/", IsNullable = false)]
    public partial class SaveFile
    {
        /// <remarks/>
        public string appName { get; set; }

        /// <remarks/>
        public string appSecret { get; set; }

        /// <remarks/>
        public string fileName { get; set; }

        /// <remarks/>
        public string fileData { get; set; }

        /// <remarks/>
        public string module { get; set; }

        /// <remarks/>
        public int moduleID { get; set; }

        /// <remarks/>
        public string feature { get; set; }

        /// <remarks/>
        public int featureID { get; set; }

        /// <remarks/>
        public string agencyType { get; set; }

        /// <remarks/>
        public int agencyTypeID { get; set; }

        /// <remarks/>
        public int FileSize { get; set; }
    }
}