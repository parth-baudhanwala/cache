﻿namespace HHAExchange.Opsworklist.Domain
{
    public class HhaxWsResult
    {
        public HhaxWsResult()
        {
            this.ErrorDetails = new List<ErrorInfo>();
        }

        public string Status { get; set; }
        public List<WSData> Result { get; set; }
        public List<ErrorInfo> ErrorDetails { get; set; }
    }

    public class ErrorInfo
    {
        public string ErrorNumber { get; set; }
        public string Message { get; set; }
    }

    public class WSData
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
