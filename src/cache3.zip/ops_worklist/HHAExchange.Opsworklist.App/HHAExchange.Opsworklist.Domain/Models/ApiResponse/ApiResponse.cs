﻿using System.Collections.Generic;
using System.Net;

namespace HHAExchange.Opsworklist.Domain
{
    public class Response<T>
    {
        public T ResponseBody { set; get; }
        public HttpStatusCode HttpStatusCode { set; get; }
    }

    public class ApiResponse<T>
    {
        public T Result { get; set; }
        public List<ResponseMessage> ErrorMessage { get; set; } = new List<ResponseMessage>();
    }

    public class ResponseMessage
    {
        public string Key { get; set; }
        public string Code { get; set; }
        public string Message { get; set; }
        public string Exception { get; set; }
    }
}
