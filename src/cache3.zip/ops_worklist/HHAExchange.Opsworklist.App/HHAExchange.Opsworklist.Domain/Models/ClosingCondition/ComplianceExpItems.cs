﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class ComplianceExpItems : BaseFact
    {
        public Nullable<DateTime> DateCompleted { set; get; }
        public string Result { set; get; }
        public string Status { set; get; }

    }
}
