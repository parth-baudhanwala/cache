﻿using HHAExchange.Opsworklist.Domain.Entity;
using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class ExpiringAuthorizationItems : BaseFact
    {
        public int AuthorizationNumber { set; get; }
        public long PatientID { set; get; }
        public int ProviderID { set; get; }
        public long AdmissionID { set; get; }
        public DateTime ExpiringDate { set; get; }
        public DateTime? DischargeDate { set; get; }
        public WorklistTask Task { set; get; }
    }
}
