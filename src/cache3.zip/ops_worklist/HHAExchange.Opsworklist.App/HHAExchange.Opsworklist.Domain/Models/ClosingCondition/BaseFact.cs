﻿namespace HHAExchange.Opsworklist.Domain
{
    public class BaseFact
    {
        public string EntKey { set; get; }
        public int WorklistId { set; get; }
        public int UpdatedBy { set; get; }
        public string UpdatedByUser { set; get; }
    }
}
