﻿using System.Collections.Generic;

namespace HHAExchange.Opsworklist.Domain.Models
{
    public class RequestModel
    {
        public List<string> EntKeys { set; get; }
        public int UserID { get; set; }
        public int ProviderID { get; set; }
        public int WorklistId { get; set; }
        public string CallerInfo { set; get; }
        public string UpdatedByUser { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsFromOpsWorklist { get; set; }
    }
}
