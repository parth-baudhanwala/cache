﻿namespace HHAExchange.Opsworklist.Domain
{
    public class UnstaffedVisitFact : BaseFact
    {
        public int AideID { set; get; }        
        public bool Deleted { set; get; }
        public bool PermanentDelete { set; get; }        
    }
}
