﻿using HHAExchange.Opsworklist.Domain.Entity;
using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class ExpiringMasterWeekFact : BaseFact
    {
        public DateTime MasterWeekEndDate { get; set; }
        public WorklistTask Task { set; get; }
    }
}
