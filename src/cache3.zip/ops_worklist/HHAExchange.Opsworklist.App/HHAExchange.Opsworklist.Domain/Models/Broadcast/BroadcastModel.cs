﻿using System;
using System.Collections.Generic;

namespace HHAExchange.Opsworklist.Domain
{
    public class BroadcastModel
    {
        public int AideID { get; set; }
        public string AideCode { get; set; }
        public string AideName { get; set; }
        public string NotificationPreference { get; set; }
    }
    public class UserDetailModel
    {
        public int UserID { get; set; }
    }

    public class BroadCastNotoficationModel
    {
        public int AideID { get; set; }
        public string NotificationEmail { get; set; }
        public string NotificationTextNumber { get; set; }
        public int? UniqueMobileID { get; set; }
        public string NotificationVoiceMail { get; set; }
    }

    public class AideEmployeeModel
    {
        public int AideID { get; set; }
        public int EmployeeID { get; set; }
    }

    public class ConexusDetail
    {
        public int BroadcastDetailID { get; set; }
        public string Phone { get; set; }
        public string TimeZone { get; set; }

    }
    public class ConexusHeader
    {
        public int BroadcastHeaderID { get; set; }
        public int VendorID { get; set; }
        public string MessageText { get; set; }
        public DateTime ScheduleStartTime { get; set; }
        public DateTime ScheduleEndTime { get; set; }
        public List<ConexusDetail> ConexusDetails { get; set; }
    }
    public class ConexusHeaderDetail
    {
        public int VendorID { get; set; }
        public string VoiceMessage { get; set; }
        public DateTime ScheduleStartTime { get; set; }
        public DateTime ScheduleToTime { get; set; }
    }
}
