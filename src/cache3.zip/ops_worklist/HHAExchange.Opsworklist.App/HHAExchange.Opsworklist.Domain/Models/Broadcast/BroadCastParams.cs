﻿using System.Collections.Generic;

namespace HHAExchange.Opsworklist.Domain
{
    public class BroadCastParams : DefaultParam
    {
        public List<int> AideID { get; set; }
        public long BroadCastID { get; set; }
        public long Result { get; set; }
        public short BroadCastType { get; set; } // chk for this -- currently pass 1
        public short MessageTypeID { get; set; } // for text passing 2
        public short IsScheduled { get; set; } // Now or Scheduled , if now then send 1
        public short PriorityType { get; set; } // 1,2,3 Type
        public int Status { get; set; } // chk for this from conexus appplication
        public int DeliveryOption { get; set; } // chk for this currently 1 is going to be passed
        public string AttachmentFileName { get; set; }
        public string Name { get; set; } // it will be added lateron
        public string Subject { get; set; }
        public string Message { get; set; } // Text Message
        public string BCC { get; set; } // Text Message
        public string ScheduledFromTime { get; set; } // Timing
        public string ScheduleDate { get; set; } //
        public int TemplateID { get; set; } // script template ID
        public string EmailAttachmentGUID { get; set; }
        public string AppSecret { get; set; }
        public string AppName { get; set; }
        public string HHAWSURL { get; set; }

        public List<TaskDetailsModel> Taskdetails { get; set; }
        public bool IsBulkTaskDetail { get; set; }
        public TaskNotesRequest NotesModel { get; set; }
    }
    public class TaskDetailsModel
    {
        public int aideID { get; set; }
        public string taskDetail { get; set; }
        public int officeID { get; set; }
        public string WorklistTaskIds { get; set; }
    }
}