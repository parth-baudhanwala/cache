﻿namespace HHAExchange.Opsworklist.Domain
{
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://tempuri.org/")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "http://tempuri.org/", IsNullable = false)]
    public partial class SaveConexusBroadcast
    {
        /// <remarks/>
        public string appName { get; set; }

        /// <remarks/>
        public string appSecret { get; set; }

        /// <remarks/>
        public SaveConexusBroadcastConexusData conexusData { get; set; }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://tempuri.org/")]
    public partial class SaveConexusBroadcastConexusData
    {

        /// <remarks/>
        public long BroadcastHeaderID { get; set; }

        /// <remarks/>
        public int VendorID { get; set; }

        /// <remarks/>
        public string MessageText { get; set; }

        /// <remarks/>
        public string ScheduleStartTime { get; set; }

        /// <remarks/>
        public string ScheduleEndTime { get; set; }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("ConexusDetail", IsNullable = false)]
        public SaveConexusBroadcastConexusDataConexusDetail[] ConexusDetails { get; set; }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "http://tempuri.org/")]
    public partial class SaveConexusBroadcastConexusDataConexusDetail
    {

        /// <remarks/>
        public int BroadcastDetailID { get; set; }

        /// <remarks/>
        public string Phone { get; set; }

        /// <remarks/>
        public string TimeZone { get; set; }
    }
}