﻿namespace HHAExchange.Opsworklist.Domain
{
    public class CommunicationScriptModel
    {
        public int TemplateId { get; set; }
        public string Description { get; set; }
    }

    public class CommunicationScriptRequest
    {
        public int UserID { get; set; }
        public int ProviderID { get; set; }
        public int TemplateType { get; set; }
        public string OfficeIDs { get; set; }
        public string CallerInfo { get; set; }
    }
    public class CommuncationTemplateRequest : DefaultParam
    {
        public long TemplateID { get; set; }
        public int AgencyId { get; set; }
        public string CallerInfo { get; set; }

    }
}
