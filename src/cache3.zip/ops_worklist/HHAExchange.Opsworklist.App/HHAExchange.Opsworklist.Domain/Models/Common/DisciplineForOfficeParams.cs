﻿namespace HHAExchange.Opsworklist.Domain
{
    public class DisciplineForOfficeParams : DefaultParam
    {
        public string OfficeXml { get; set; }
    }
}
