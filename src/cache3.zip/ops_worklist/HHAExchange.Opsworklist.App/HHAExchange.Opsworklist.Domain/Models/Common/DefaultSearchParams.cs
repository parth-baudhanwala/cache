﻿namespace HHAExchange.Opsworklist.Domain
{
    public abstract class DefaultSearchParams
    {
        public SortRequest Sort { get; set; }

        public PageRequest Page { get; set; }

        public string Status { get; set; }
        public string Assignee { get; set; }
        public int ProviderID { get; set; }
        public string OfficeID { get; set; }
    }

    public class SortRequest
    {
        public SortDirection Direction { get; set; }

        public string DirectionText
        {
            get
            {
                return Direction == SortDirection.Ascending
                    ? "ASC"
                    : "DESC";
            }
        }

        public string Item { get; set; }
    }

    public enum SortDirection
    {
        Ascending,
        Descending
    }

    public class PageRequest
    {
        public int PageSize { get; set; } = 10;
        public int PageNumber { get; set; } = 1;
    }
}
