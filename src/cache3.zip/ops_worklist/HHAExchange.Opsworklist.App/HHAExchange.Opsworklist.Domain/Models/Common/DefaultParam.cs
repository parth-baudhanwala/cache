﻿
namespace HHAExchange.Opsworklist.Domain
{
    public class DefaultParam
    {
        public string AppVersion { get; set; }
        public decimal Version { get; set; }
        public decimal MinorVersion { get; set; }
        public int UserID { get; set; }
        public int ProviderID { get; set; }
       
    }
}
