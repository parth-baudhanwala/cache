﻿
namespace HHAExchange.Opsworklist.Domain
{
    public partial class AutoFillDataModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
