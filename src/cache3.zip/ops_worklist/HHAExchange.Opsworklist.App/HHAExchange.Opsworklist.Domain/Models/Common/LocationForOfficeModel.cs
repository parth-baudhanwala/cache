﻿
namespace HHAExchange.Opsworklist.Domain
{
    public class LocationForOfficeModel
    {
        public int LocationID { get; set; }
        public string Location { get; set; }
    }
}
