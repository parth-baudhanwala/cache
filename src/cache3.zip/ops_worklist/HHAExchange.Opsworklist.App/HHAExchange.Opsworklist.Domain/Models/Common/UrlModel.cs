﻿namespace HHAExchange.Opsworklist.Domain
{
    public class UrlModel
    {
        public string URL { get; set; }
        public string RCUrl { get; set; }
    }
}
