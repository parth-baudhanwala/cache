﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class ScriptTemplateModel
    {
        public long TemplateID { get; set; }
        public long TemplateTypeId { get; set; }
        public string Description { get; set; }
        public string Message { get; set; }
        public string Subject { get; set; }
        public string BCC { get; set; }
        public short Format { get; set; }
        public string Attachment { get; set; }
        public short Priority { get; set; }
        public long Language { get; set; }
        public short Type { get; set; }
        public Boolean IsIVRVoiceFile { get; set; }
        public string VoiceFilePath { get; set; }
        public System.Guid EmailAttachmentGUID { get; set; }
    }
}
