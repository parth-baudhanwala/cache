﻿using System.Collections.Generic;

namespace HHAExchange.Opsworklist.Domain
{
    public class PaginationResult<T>
    {
        public PageInfo pageInfo { get; set; }
        public ICollection<T> data { get; set; }
    }

    public class PageInfo
    {
        public int totalRecordCount { get; set; }
    }
}
