﻿
namespace HHAExchange.Opsworklist.Domain
{
    public class LanguageModel
    {
        public int LanguageID { get; set; }
        public string Language { get; set; }
    }
}
