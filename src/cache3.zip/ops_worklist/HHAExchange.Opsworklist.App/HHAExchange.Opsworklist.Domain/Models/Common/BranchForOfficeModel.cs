﻿
namespace HHAExchange.Opsworklist.Domain
{
    public class BranchForOfficeModel
    {
        public int BranchID { get; set; }
        public string BranchName { get; set; }
    }
}
