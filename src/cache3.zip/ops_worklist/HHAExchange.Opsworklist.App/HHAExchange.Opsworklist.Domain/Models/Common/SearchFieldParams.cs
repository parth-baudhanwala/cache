﻿namespace HHAExchange.Opsworklist.Domain
{
    public class SearchFieldParams : DefaultParam
    {
        public string OfficeID { get; set; }
        public int VendorID { get; set; }
    }
}
