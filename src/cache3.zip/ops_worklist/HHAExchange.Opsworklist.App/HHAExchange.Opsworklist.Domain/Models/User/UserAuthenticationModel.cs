﻿namespace HHAExchange.Opsworklist.Domain
{
    public class UserAuthenticationModel
    {
        public int OfficeID { get; set; }
        public bool IsUserLoggedIn { get; set; }
    }
    public class UserInformation
    {
        public string SName { get; set; }
        public string SValue { get; set; }
    }
}
