﻿namespace HHAExchange.Opsworklist.Domain
{
    public class UserDetailsParams : DefaultParam
    {
        public string SessionID { get; set; }
    }
}
