﻿using System.Collections.Generic;

namespace HHAExchange.Opsworklist.Domain
{
    public class UserPermissionsParams : DefaultParam
    {
        public string MenuText { get; set; }
        public List<string> MenuList { get; set; }
    }
}
