﻿namespace HHAExchange.Opsworklist.Domain
{
    public class UserPermissionsModel
    {
        public string MenuText { get; set; }
        public bool HasAccess { get; set; }
    }
}
