﻿namespace HHAExchange.Opsworklist.Domain
{
    public class UserWorklistPermissions
    {
        public string UserName { get; set; }
        public int WorklistId { get; set; }
        public string WorklistName { get; set; }
        public string CanManuallyCloseWorklistTask { get; set; }
        public string CanAssignWorklistTask { get; set; }
        public string IsOpsWorklistLandingPage { get; set; }
        public int AssignedDefaultWorklist { get; set; }
        public string WorklistPath { get; set; }
    }
}
