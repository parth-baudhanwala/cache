﻿namespace HHAExchange.Opsworklist.Domain
{
    public class SearchExpiringCertificationPeriodQueryModel : DefaultSearchParams
    {
        public int AdmissionID { get; set; }
        public int PatientID { get; set; }
        public int UserID { get; set; }
        public string Patient { get; set; }
        public string NurseID { get; set; }
        public string NurseName { get; set; }
        public string PhysicianID { get; set; }        
        public string Physician { get; set; }
        public string CertificationPeriod { get; set; }
        public string PatientStatusID { get; set; }
    }
}
