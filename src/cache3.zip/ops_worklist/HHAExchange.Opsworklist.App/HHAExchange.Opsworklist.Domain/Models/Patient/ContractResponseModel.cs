﻿namespace HHAExchange.Opsworklist.Domain
{
    public partial class ContractResponseModel
    {
        public int SourceID { get; set; }
        public string SourceName { get; set; }

    }
}
