﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class ExpiringAuthorizationTaskModel : DefaultWorklistModel
    {
        public DateTime DueDate { get; set; }
        public string Patient { get; set; }
        public int? PatientId { get; set; }
        public string ContractName { get; set; }
        public string CoordinatorName { get; set; }
        public string AdmissionId { get; set; }
        public string PatientFirstname { get; set; }
        public string PatientLastname { get; set; }
        public string PatientMiddlename { get; set; }
        public bool isInternalPatient { get; set; }
        public bool IsInternalNote { get; set; }
        public string AuthorizationNumber { get; set; }
        public string PatientFullname
        {
            get
            {
                string fullName = "";

                if (!string.IsNullOrEmpty(PatientFirstname)) fullName = PatientFirstname + " ";
                if (!string.IsNullOrEmpty(PatientLastname)) fullName = fullName + PatientLastname + " ";
                if (!string.IsNullOrEmpty(PatientMiddlename)) fullName = fullName + PatientMiddlename + " ";

                return fullName.Trim();
            }
        }
    }
}
