﻿namespace HHAExchange.Opsworklist.Domain
{
    public class UnstaffedVisitTaskModel : DefaultWorklistModel
    {
        public DateTime VisitDate { get; set; }
        public string VisitTime { get; set; }
        public string Patient { get; set; }
        public int? PatientId { get; set; }
        public int? DisciplineId { get; set; }
        public int? CoordinatorID { set; get; }
        public int? ContractID { set; get; }
        public string ContractName { get; set; }

        public string CoordinatorName { set; get; }

        public string AdmissionId { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string CrossStreet { get; set; }
        public string ScheduledTime { get; set; }

        public string DisciplineName { get; set; }
        public string PatientFirstname { get; set; }
        public string PatientLastname { get; set; }
        public bool IsInternalPatient { get; set; }
        public bool IsInternalNote { get; set; }
        public string PatientMiddlename { get; set; }
        public string PatientFullname
        {
            get
            {
                string fullName = "";

                if (!string.IsNullOrEmpty(PatientFirstname)) fullName = PatientFirstname + " ";
                if (!string.IsNullOrEmpty(PatientLastname)) fullName = fullName + PatientLastname + " ";
                if (!string.IsNullOrEmpty(PatientMiddlename)) fullName = fullName + PatientMiddlename + " ";

                return fullName.Trim();
            }
        }

        public string ScheduleType { get; set; }
    }
}
