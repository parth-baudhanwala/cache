﻿namespace HHAExchange.Opsworklist.Domain
{
    public class PatientsPhysicianModel
    {
        public int? PhysicianID { get; set; }
        public string PhysicianName { get; set; }
    }
}
