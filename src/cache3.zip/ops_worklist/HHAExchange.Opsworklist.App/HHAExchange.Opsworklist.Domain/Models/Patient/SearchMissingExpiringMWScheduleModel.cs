﻿namespace HHAExchange.Opsworklist.Domain
{
    public class SearchMissingExpiringMWScheduleModel : DefaultSearchParams
    {

        public int UserID { get; set; }

        public string Patient { get; set; }
        public string CoordinatorID { get; set; }
        public string DisciplineID { get; set; }
        public string ContractID { get; set; }
        public string MasterWeekDate { get; set; }
        public string PatientStatusID { get; set; }
    }
}
