﻿using HHAExchange.Opsworklist.Domain.Models.Common.Patient;
using System;
using System.Collections.Generic;

namespace HHAExchange.Opsworklist.Domain
{
    public class MwInfoDetailsBase
    {
        public IDictionary<int, MwContractInfo> mwContractInfo { get; set; }
        public List<MwpocInfo> mwPOCInfo { get; set; }
        public List<MwFutureVisits> mwFutureVisits { get; set; }
        public IDictionary<string, MwContractAndOtherInfo> mwContractAndOtherInfo { get; set; }
    }

    public class MwInfoDetails : MwInfoDetailsBase
    {
        public MasterWeekInfoResponse masterWeekInfoResponse { get; set; }
    }

    public class MwContractInfo
    {
        public int ContractID { get; set; }
        public string ContractName { get; set; }
        public int DefaultServiceCodeID { get; set; }
        public string ContractType { get; set; }
    }
    public class MwWeekdayInfo
    {
        public int PatientID { get; set; }
        public int VendorID { get; set; }
        public int MasterWeekHeaderID { get; set; }
        public int Status { get; set; }
        public string MonFromTime { get; set; }
        public string MonToTime { get; set; }
        public string MonAideID { get; set; }
        public string MonPOC { get; set; }
        public string MonAssignmentID { get; set; }
        public string MonAideCode { get; set; }
        public string MonAideName { get; set; }
        public string MonContractHoursFrom { get; set; }
        public string MonContractHoursTo { get; set; }
        public string MonContractID1 { get; set; }
        public string MonRateID1 { get; set; }
        public string MonRateType1 { get; set; }
        public string MonIncludeMileageExpense { get; set; }
        public string MondayScheduleType { get; set; }

        public string TueFromTime { get; set; }
        public string TueToTime { get; set; }
        public string TueAideID { get; set; }
        public string TuePOC { get; set; }
        public string TueAssignmentID { get; set; }
        public string TueAideCode { get; set; }
        public string TueAideName { get; set; }
        public string TueContractHoursFrom { get; set; }
        public string TueContractHoursTo { get; set; }
        public string TueContractID1 { get; set; }
        public string TueRateID1 { get; set; }
        public string TueRateType1 { get; set; }
        public string TueIncludeMileageExpense { get; set; }
        public string TuesdayScheduleType { get; set; }

        public string WedFromTime { get; set; }
        public string WedToTime { get; set; }
        public string WedAideID { get; set; }
        public string WedPOC { get; set; }
        public string WedAssignmentID { get; set; }
        public string WedAideCode { get; set; }
        public string WedAideName { get; set; }
        public string WedContractHoursFrom { get; set; }
        public string WedContractHoursTo { get; set; }
        public string WedContractID1 { get; set; }
        public string WedRateID1 { get; set; }
        public string WedRateType1 { get; set; }
        public string WedIncludeMileageExpense { get; set; }
        public string WednesdayScheduleType { get; set; }

        public string ThuFromTime { get; set; }
        public string ThuToTime { get; set; }
        public string ThuAideID { get; set; }
        public string ThuPOC { get; set; }
        public string ThuAssignmentID { get; set; }
        public string ThuAideCode { get; set; }
        public string ThuAideName { get; set; }
        public string ThuContractHoursFrom { get; set; }
        public string ThuContractHoursTo { get; set; }
        public string ThuContractID1 { get; set; }
        public string ThuRateID1 { get; set; }
        public string ThuRateType1 { get; set; }
        public string ThuIncludeMileageExpense { get; set; }
        public string ThursdayScheduleType { get; set; }

        public string FriFromTime { get; set; }
        public string FriToTime { get; set; }
        public string FriAideID { get; set; }
        public string FriPOC { get; set; }
        public string FriAssignmentID { get; set; }
        public string FriAideCode { get; set; }
        public string FriAideName { get; set; }
        public string FriContractHoursFrom { get; set; }
        public string FriContractHoursTo { get; set; }
        public string FriContractID1 { get; set; }
        public string FriRateID1 { get; set; }
        public string FriRateType1 { get; set; }
        public string FriIncludeMileageExpense { get; set; }
        public string FridayScheduleType { get; set; }

        public string SatFromTime { get; set; }
        public string SatToTime { get; set; }
        public string SatAideID { get; set; }
        public string SatPOC { get; set; }
        public string SatAssignmentID { get; set; }
        public string SatAideCode { get; set; }
        public string SatAideName { get; set; }
        public string SatContractHoursFrom { get; set; }
        public string SatContractHoursTo { get; set; }
        public string SatContractID1 { get; set; }
        public string SatRateID1 { get; set; }
        public string SatRateType1 { get; set; }
        public string SatIncludeMileageExpense { get; set; }
        public string SaturdayScheduleType { get; set; }

        public string SunFromTime { get; set; }
        public string SunToTime { get; set; }
        public string SunAideID { get; set; }
        public string SunPOC { get; set; }
        public string SunAssignmentID { get; set; }
        public string SunAideCode { get; set; }
        public string SunAideName { get; set; }
        public string SunContractHoursFrom { get; set; }
        public string SunContractHoursTo { get; set; }
        public string SunContractID1 { get; set; }
        public string SunRateID1 { get; set; }
        public string SunRateType1 { get; set; }
        public string SunIncludeMileageExpense { get; set; }
        public string SundayScheduleType { get; set; }
    }
    public class MwpocInfo
    {
        public int POCHeaderID { get; set; }
        public DateTime POCStartDate { get; set; }
        public DateTime POCStopDate { get; set; }
        public int CompanyID { get; set; }
        public string CompanyType { get; set; }
    }
    public class MwFutureVisits
    {
        public bool HaveFutureVisits { get; set; }
    }
    public class MwContractAndOtherInfo
    {
        public int ContractID { get; set; }
        public int ContractRateID { get; set; }
        public string ServiceCode { get; set; }
        public string RateType { get; set; }
        public string Discipline { get; set; }
        public int DisciplineID { get; set; }
        public string DisciplineType { get; set; }
        public int ServiceCodeID { get; set; }
    }

    
    public class MwUprInfoDetailsBase
    {
        public IDictionary<int, MwChhaInfo> mwChhaInfo { get; set; }
        public List<MwpocInfo> mwPOCInfo { get; set; }
        public List<MwOverTimeInfo> mwOverTimeInfo { get; set; }
        public IDictionary<string, MwServiceInfo> mwServiceInfo { get; set; }
    }

    public class MwChhaInfo
    {
        public int ChhaID { get; set; }
        public string ChhaName { get; set; }
        public bool VendorMileageExpenseEnabled { get; set; }
    }

    public class MwOverTimeInfo
    {
        public int ValidateScheduleOvertime { get; set; }
        public string OvertimePassword { get; set; }
    }

    public class MwServiceInfo
    {
        public int ServiceCodeID { get; set; }
        public string ServiceCodeText { get; set; }
        public string ServiceCode { get; set; }
        public bool IsServiceCodeMutual { get; set; }
        public bool AllowPatientShiftOverlap { get; set; }
        public int ServiceTypeID { get; set; }
        public string ServiceType { get; set; }
        public int ServiceCategoryID { get; set; }
        public string Category { get; set; }
        public string RateType { get; set; }
        public bool NonBillableCode { get; set; }
    }

    public class MwUprWeekdayInfo
    {
        public int PatientID { get; set; }
        public int MasterWeekHeaderID { get; set; }
        public int Status { get; set; }
        public string MondayFromTime { get; set; }
        public string MondayToTime { get; set; }
        public string MondayAideID { get; set; }
        public string MondayPOC { get; set; }
        public string MondayAssignmentID { get; set; }
        public string MondayAideCode { get; set; }
        public string MondayAideName { get; set; }
        public string MonPayerHoursFrom { get; set; }
        public string MonPayerHoursTo { get; set; }
        public string MonRateID1 { get; set; }
        public string MonRateType1 { get; set; }
        public string MonIncludeMileageExpense { get; set; }

        public string TuesdayFromTime { get; set; }
        public string TuesdayToTime { get; set; }
        public string TuesdayAideID { get; set; }
        public string TuesdayPOC { get; set; }
        public string TuesdayAssignmentID { get; set; }
        public string TuesdayAideCode { get; set; }
        public string TuesdayAideName { get; set; }
        public string TuePayerHoursFrom { get; set; }
        public string TuePayerHoursTo { get; set; }
        public string TueRateID1 { get; set; }
        public string TueRateType1 { get; set; }
        public string TueIncludeMileageExpense { get; set; }

        public string WednesdayFromTime { get; set; }
        public string WednesdayToTime { get; set; }
        public string WednesdayAideID { get; set; }
        public string WednesdayPOC { get; set; }
        public string WednesdayAssignmentID { get; set; }
        public string WednesdayAideCode { get; set; }
        public string WednesdayAideName { get; set; }
        public string WedPayerHoursFrom { get; set; }
        public string WedPayerHoursTo { get; set; }
        public string WedRateID1 { get; set; }
        public string WedRateType1 { get; set; }
        public string WedIncludeMileageExpense { get; set; }

        public string ThursdayFromTime { get; set; }
        public string ThursdayToTime { get; set; }
        public string ThursdayAideID { get; set; }
        public string ThursdayPOC { get; set; }
        public string ThursdayAssignmentID { get; set; }
        public string ThursdayAideCode { get; set; }
        public string ThursdayAideName { get; set; }
        public string ThuPayerHoursFrom { get; set; }
        public string ThuPayerHoursTo { get; set; }
        public string ThuRateID1 { get; set; }
        public string ThuRateType1 { get; set; }
        public string ThuIncludeMileageExpense { get; set; }

        public string FridayFromTime { get; set; }
        public string FridayToTime { get; set; }
        public string FridayAideID { get; set; }
        public string FridayPOC { get; set; }
        public string FridayAssignmentID { get; set; }
        public string FridayAideCode { get; set; }
        public string FridayAideName { get; set; }
        public string FriPayerHoursFrom { get; set; }
        public string FriPayerHoursTo { get; set; }
        public string FriRateID1 { get; set; }
        public string FriRateType1 { get; set; }
        public string FriIncludeMileageExpense { get; set; }

        public string SaturdayFromTime { get; set; }
        public string SaturdayToTime { get; set; }
        public string SaturdayAideID { get; set; }
        public string SaturdayPOC { get; set; }
        public string SaturdayAssignmentID { get; set; }
        public string SaturdayAideCode { get; set; }
        public string SaturdayAideName { get; set; }
        public string SatPayerHoursFrom { get; set; }
        public string SatPayerHoursTo { get; set; }
        public string SatRateID1 { get; set; }
        public string SatRateType1 { get; set; }
        public string SatIncludeMileageExpense { get; set; }

        public string SundayFromTime { get; set; }
        public string SundayToTime { get; set; }
        public string SundayAideID { get; set; }
        public string SundayPOC { get; set; }
        public string SundayAssignmentID { get; set; }
        public string SundayAideCode { get; set; }
        public string SundayAideName { get; set; }
        public string SunPayerHoursFrom { get; set; }
        public string SunPayerHoursTo { get; set; }
        public string SunRateID1 { get; set; }
        public string SunRateType1 { get; set; }
        public string SunIncludeMileageExpense { get; set; }
    }

    public class MwUprInfoDetails : MwUprInfoDetailsBase
    {
        public MasterWeekUprInfoResponse masterWeekUPRInfoResponse { get; set; }
    }
}
