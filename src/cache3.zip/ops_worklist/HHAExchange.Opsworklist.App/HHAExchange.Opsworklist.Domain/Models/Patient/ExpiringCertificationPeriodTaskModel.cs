﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class ExpiringCertificationPeriodTaskModel : DefaultWorklistModel
    {
        public DateTime? CertificationPeriod { get; set; }
        public string Patient { get; set; }
        public int? PatientId { get; set; }
        public string NurseName { get; set; }
        public string PhysicianName { get; set; }
        public int? NurseID { get; set; }
        public int? PhysicianID { get; set; }
        public string AdmissionId { get; set; }
        public string AuthorizationID { get; set; }
        public string PatientFullname { get; set; }
    }
}
