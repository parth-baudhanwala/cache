﻿namespace HHAExchange.Opsworklist.Domain
{
    public class CoordinatorRequestModel : DefaultParam
    {
        public int SequenceID { set; get; }
        public int Table { set; get; }
        public int Active { set; get; }
        public int VendorID { set; get; }
        public string OfficeID { set; get; }
    }
}
