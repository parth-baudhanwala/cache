﻿namespace HHAExchange.Opsworklist.Domain
{
    public class CoordinatorResponseModel
    {
        public int CoordinatorID { get; set; }
        public string CoordinatorName { get; set; }             
        
    }
}
