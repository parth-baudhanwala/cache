﻿namespace HHAExchange.Opsworklist.Domain
{
    public class SearchExpiringAuthorizationQueryModel : DefaultSearchParams
    {

        public int AuthorizationNumber { get; set; }
        public int AdmissionID { get; set; }
        public int PatientID { get; set; }
        public int UserID { get; set; }
        public string Patient { get; set; }
        public string ContractID { get; set; }
        public string ContractName { get; set; }
        public string CoordinatorID { get; set; }
        public string CoordinatorName { get; set; }
        public string ExpirationDuration { get; set; }
        public string DisciplineID { get; set; }
        public string PatientStatusID { get; set; }
    }
}
