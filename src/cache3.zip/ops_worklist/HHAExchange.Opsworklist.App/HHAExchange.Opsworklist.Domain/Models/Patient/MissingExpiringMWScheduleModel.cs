﻿using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class MissingExpiringMWScheduleModel : DefaultWorklistModel
    {
        public DateTime MasterWeekEndDate { get; set; }
        public string MasterWeekSchedule { get; set; }
        public string Patient { get; set; }
        public int? PatientId { get; set; }
        public string CaregiverNames { get; set; }

        public int? ContractID { get; set; }
        public string ContractNames { get; set; }

        public string AdmissionId { get; set; }
        public string PatientFirstname { get; set; }
        public string PatientLastname { get; set; }
        public string PatientMiddlename { get; set; }
        public string PatientFullname
        {
            get
            {
                string fullName = "";

                if (!string.IsNullOrEmpty(PatientFirstname)) fullName = PatientFirstname + " ";
                if (!string.IsNullOrEmpty(PatientLastname)) fullName = fullName + PatientLastname + " ";
                if (!string.IsNullOrEmpty(PatientMiddlename)) fullName = fullName + PatientMiddlename + " ";

                return fullName.Trim();
            }
        }
        public bool isInternalPatient { get; set; }
    }
}
