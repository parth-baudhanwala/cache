﻿namespace HHAExchange.Opsworklist.Domain.Models.Patient
{
    public class PatientTeamOptionModel
    {
        public int PatientTeamID { get; set; }
        public string PatientTeam { get; set; }
    }
}
