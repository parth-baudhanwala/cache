﻿using HHAExchange.Opsworklist.Domain.PollerModel;
using System;

namespace HHAExchange.Opsworklist.Domain.Models
{
    public class ExpiringCertificationModel : DefaultJobModel
    {
        public int VendorID { set; get; }
        public int PatientID { set; get; }
        public string AdmissionId { set; get; }
        public DateTime StartDate { set; get; }
        public DateTime EndDate { set; get; }
        public int OfficeId { set; get; }
        public int? NurseId { set; get; }
        public string NurseName { set; get; }
        public int PhysicianID { set; get; }
        public string PhysicianName { set; get; }
        public string PatientFirstname { get; set; }
        public string PatientLastname { get; set; }
        public string PatientMiddlename { get; set; }
        public string PatientFullname
        {
            get
            {
                string fullName = "";

                if (!string.IsNullOrEmpty(PatientFirstname)) fullName = PatientFirstname + " ";
                if (!string.IsNullOrEmpty(PatientLastname)) fullName = fullName + PatientLastname + " ";
                if (!string.IsNullOrEmpty(PatientMiddlename)) fullName = fullName + PatientMiddlename + " ";

                return fullName.Trim();
            }
        }
    }
}
