﻿namespace HHAExchange.Opsworklist.Domain.Models.Common.Patient
{
    public class MasterWeekInfoResponse
    {
        public WeekDayInfo Sunday { get; set; }
        public WeekDayInfo Monday { get; set; }
        public WeekDayInfo Tuesday { get; set; }
        public WeekDayInfo Wednesday { get; set; }
        public WeekDayInfo Thursday { get; set; }
        public WeekDayInfo Friday { get; set; }
        public WeekDayInfo Saturday { get; set; }
    }

    public class WeekDayInfo
    {
        public string ScheduledTime { get; set; }
        public string Caregiver { get; set; }
        public string AssignmentID { get; set; }
        public string PayCode { get; set; }
        public string POC { get; set; }
        public string PrimaryBillTo { get; set; }
        public string ScheduledHours { get; set; }
        public string ServiceCode { get; set; }
        public string RateType { get; set; }
        public string IncludeinMileage { get; set; }
        public string ScheduleType { get; set; }
    }

    public class MasterWeekUprInfoResponse
    {
        public UprWeekDayInfo Sunday { get; set; }
        public UprWeekDayInfo Monday { get; set; }
        public UprWeekDayInfo Tuesday { get; set; }
        public UprWeekDayInfo Wednesday { get; set; }
        public UprWeekDayInfo Thursday { get; set; }
        public UprWeekDayInfo Friday { get; set; }
        public UprWeekDayInfo Saturday { get; set; }
    }

    public class UprWeekDayInfo
    {
        public string ScheduledTime { get; set; }
        public string Caregiver { get; set; }
        public string AssignmentID { get; set; }
        public string PayCode { get; set; }
        public string ScheduledHours { get; set; }
        public string ServiceCode { get; set; }
        public string POC { get; set; }
        public string RateType { get; set; }
        public string IncludeinMileage { get; set; }
    }

}
