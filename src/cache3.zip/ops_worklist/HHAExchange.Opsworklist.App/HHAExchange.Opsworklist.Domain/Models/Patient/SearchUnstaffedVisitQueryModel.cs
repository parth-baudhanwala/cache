﻿namespace HHAExchange.Opsworklist.Domain
{
    public class SearchUnstaffedVisitQueryModel : DefaultSearchParams
    {
        public int UnstaffedVisitID { get; set; }
        public int AdmissionID { get; set; }
        public int PatientID { get; set; }
        public int UserID { get; set; }
        public string Patient { get; set; }
        public string ContractID { get; set; }
        public string ContractName { get; set; }
        public string CoordinatorID { get; set; }
        public string CoordinatorName { get; set; }
        public string VisitDate { get; set; }
        public string DisciplineID { get; set; }
        public string TeamID { get; set; }
        public bool IsInternalNote { get; set; }
        public string LocationID { get; set; }
        public string BranchID { get; set; }
        public string PatientStatusID { get; set; }

    }
}
