﻿namespace HHAExchange.Opsworklist.Domain.Models.Patient
{
    public class PatientsNurseResponseModel
    {
        public int NurseID { get; set; }
        public string NurseName { get; set; }
    }
}
