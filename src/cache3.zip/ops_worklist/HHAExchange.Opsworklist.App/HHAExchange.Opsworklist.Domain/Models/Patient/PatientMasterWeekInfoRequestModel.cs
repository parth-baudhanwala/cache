﻿namespace HHAExchange.Opsworklist.Domain
{
    public class PatientMasterWeekInfoRequestModel : DefaultParam
    {
        public int PatientID { get; set; }
        public int MasterWeekHeaderID { get; set; }
    }
}
