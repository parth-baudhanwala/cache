﻿namespace HHAExchange.Opsworklist.Domain.Models.MasterLayout
{
    public class MachineInfo
    {
        public string MachineDateTime { get; set; }
        public string MachineName { get; set; }
    }
}
