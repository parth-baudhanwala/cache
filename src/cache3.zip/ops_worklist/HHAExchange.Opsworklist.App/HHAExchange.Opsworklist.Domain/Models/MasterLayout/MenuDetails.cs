﻿namespace HHAExchange.Opsworklist.Domain.Models.MasterLayout
{
    public class MenuDetails
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int ParentId { get; set; }
        public string URL { get; set; }
        public bool IsPopup { get; set; }
        public string WindowFeatures { get; set; }
    }
}
