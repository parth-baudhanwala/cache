﻿namespace HHAExchange.Opsworklist.Domain.Models.MasterLayout
{
    public class NotificationDetails
    {
        public int UserNotifMsgCnt { get; set; }
        public int UserMessagesCnt { get; set; }
        public int UserToDosMsgCnt { get; set; }
        public int OpenCaseMsgCnt { get; set; }
        public string OpenCaseURL { get; set; }
    }
}
