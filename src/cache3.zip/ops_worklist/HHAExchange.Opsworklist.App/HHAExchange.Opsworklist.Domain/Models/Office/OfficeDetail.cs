﻿namespace HHAExchange.Opsworklist.Domain
{
    public class OfficeDetail
    {
        public int OfficeID { get; set; }
        public string OfficeName { get; set; }
        public bool IsPrimary { get; set; }
    }
}
