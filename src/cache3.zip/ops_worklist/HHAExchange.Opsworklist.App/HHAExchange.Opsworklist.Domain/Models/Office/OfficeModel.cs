﻿namespace HHAExchange.Opsworklist.Domain
{
    public class OfficeModel
    {
        public string OfficeName { get; set; }
        public int Office { get; set; }
        public int OfficeID { get; set; }
        public int ParentID { get; set; }
        public int isLeaf { get; set; }
        public int Level { get; set; }
        public int HirarchyLevel { get; set; }
        public int Type { get; set; }
        public string Parent { get; set; }
        public int SortOrder { get; set; }
    }
}
