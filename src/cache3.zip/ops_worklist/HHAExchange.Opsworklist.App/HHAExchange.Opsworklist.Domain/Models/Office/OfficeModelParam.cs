﻿namespace HHAExchange.Opsworklist.Domain
{
    public class OfficeModelParam : DefaultParam
    {
        public string VendorID { get; set; }
        public string OfficeName { get; set; }
        public string OfficeGroup { get; set; }
        public int Active { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
        public string SortItem { get; set; }
        public string CallerInfo { get; set; }
        public string PermissionName { get; set; }
        public string PayrollSetupID { get; set; }
        public string SelectedOfficeID { get; set; }
    }
}
