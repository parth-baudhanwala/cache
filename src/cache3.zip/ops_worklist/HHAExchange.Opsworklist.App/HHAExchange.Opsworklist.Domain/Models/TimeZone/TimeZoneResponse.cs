﻿namespace HHAExchange.Opsworklist.Domain.TimeZone
{
    public class TimeZoneResponse
    {
        public int OfficeID { get; set; }
        public string TimeZone { get; set; }
    }
}
