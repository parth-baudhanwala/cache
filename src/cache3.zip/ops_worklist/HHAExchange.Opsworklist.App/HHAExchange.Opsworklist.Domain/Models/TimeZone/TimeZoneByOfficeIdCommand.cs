﻿using System.Collections.Generic;

namespace HHAExchange.Opsworklist.Domain.TimeZone
{
    public class TimeZoneByOfficeIdCommand
    {
        public List<TimeZoneByOfficeId> OfficeIDs { get; set; }
    }

    public class TimeZoneByOfficeId
    {
        public int OfficeID { get; set; }
    }
}
