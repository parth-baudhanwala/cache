﻿namespace HHAExchange.Opsworklist.Domain.Entity
{
    public partial class PatientAuthorization
    {
        public int PatientAuthorizationId { get; set; }
        public long PatientId { get; set; }
        public int? AuthProviderId { get; set; }
        public int? PayerId { get; set; }     
    }
}
