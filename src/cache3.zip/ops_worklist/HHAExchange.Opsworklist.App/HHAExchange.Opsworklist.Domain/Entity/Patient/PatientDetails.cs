﻿using HHAExchange.Opsworklist.Domain.PollerModel;

namespace HHAExchange.Opsworklist.Domain
{
    public class PatientBaseDetails : TableAuditDetails
    {
        public PatientBaseDetails() { }

        public PatientBaseDetails(DefaultJobModel record) : base(record) { }
        public string AdmissionId { get; set; }
        public int? PatientId { get; set; }
    }
    public class PatientDetails : PatientBaseDetails
    {
        public PatientDetails() { }

        public PatientDetails(DefaultJobModel record) : base(record) { }
        public string PatientFirstname { get; set; }
        public string PatientLastname { get; set; }
        public string PatientMiddlename { get; set; }
    }
}
