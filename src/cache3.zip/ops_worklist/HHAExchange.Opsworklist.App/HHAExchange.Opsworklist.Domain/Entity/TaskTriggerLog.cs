﻿using HHAExchange.Opsworklist.Domain.PollerModel;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HHAExchange.Opsworklist.Domain.Entity
{
    public class TaskTriggerLog
    {
        [Key]
        public int TaskTriggerLogId { get; set; }
        public string TriggerName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        [NotMapped]
        public JobLoaderDetail TriggerConfig { get; set; }
        public int? TotalRecords { get; set; }
        public int? TotalRecordsInserted { get; set; }
        public int? TotalRecordsUpdated { get; set; }
        public string Status { get; set; }
        public string JobId { get; set; }
        public int? RetryAttempt { get; set; }
        public int ProviderId { get; set; }
        public string Error { get; set; }
    }
}
