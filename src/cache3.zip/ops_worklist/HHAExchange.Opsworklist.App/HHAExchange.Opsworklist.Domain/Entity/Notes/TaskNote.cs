﻿using HHAExchange.Opsworklist.Domain.Entity;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace HHAExchange.Opsworklist.Domain
{
    public partial class TaskNote : TableAuditDetails
    {
        public TaskNote() : base()
        {

        }

        [Key]
        public int TaskNoteId { get; set; }
        public int TaskId { get; set; }
        public string Subject { get; set; }
        public string Note { get; set; }
        public string FileGuid { get; set; }
        public string FileName { get; set; }
        public virtual WorklistTask Task { get; set; }
    }
}
