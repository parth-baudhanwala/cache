﻿using HHAExchange.Opsworklist.Domain.Entity;
using HHAExchange.Opsworklist.Domain.PollerModel;
using System;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace HHAExchange.Opsworklist.Domain
{
    public partial class TaskExpiringAuthorization : PatientDetails
    {
        public TaskExpiringAuthorization()
        {

        }
        public TaskExpiringAuthorization(ExpiringAuthModel record) : base(record)
        {
            AdmissionId = record.AdmissionID;
            AuthorizationNumber = record.AuthorizationNumber;
            ContractId = record.ContractID;
            ContractName = record.ContractName;
            CoordinatorId = record.CoordinatorID;
            CoordinatorName = record.CoordinatorName;
            ExpiringDate = record.ExpiringDate;
            PatientId = record.PatientID;
            PatientFirstname = record.PatientFirstname;
            PatientLastname = record.PatientLastname;
            PatientMiddlename = record.PatientMiddlename;
            if (record.InternalPatient == 1)
                isInternalPatient = true;
            else
                isInternalPatient = false;
        }

        [Key]
        public int TaskExpiringAuthorizationId { get; set; }
        public int TaskId { get; set; }
        public string ContractName { get; set; }
        public string CoordinatorName { get; set; }
        public string AuthorizationNumber { get; set; }
        public int? ContractId { get; set; }
        public int? CoordinatorId { get; set; }

        public DateTime ExpiringDate { get; set; }
        public bool isInternalPatient { get; set; }
        public virtual WorklistTask Task { get; set; }
    }
}
