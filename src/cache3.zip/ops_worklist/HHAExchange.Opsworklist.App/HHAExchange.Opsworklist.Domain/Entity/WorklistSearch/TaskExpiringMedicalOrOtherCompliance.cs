﻿using HHAExchange.Opsworklist.Domain.Entity;
using HHAExchange.Opsworklist.Domain.PollerModel;
using System;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace HHAExchange.Opsworklist.Domain
{
    public partial class TaskExpiringMedicalOrOtherCompliance : TableAuditDetails
    {
        public TaskExpiringMedicalOrOtherCompliance()
        {

        }
        public TaskExpiringMedicalOrOtherCompliance(MedicalCompliancesModel record) : base(record)
        {
            BranchId = record.BranchID;
            CareGiverCode = record.OfficeAideCode;
            CareGiverFirstname = record.FirstName;
            CareGiverLastname = record.LastName;
            CareGiverMiddlename = record.MiddleName;
            CareGiverId = record.CaregiverID;
            CareGiverTeamId = record.CaregiverTeamID;
            DueDate = record.DueDate;
            ExpirationItem = record.ExpirationItem;
            ExpirationItemType = record.ExpirationItemType;
            LocationId = record.LocationID;
        }
        [Key]
        public int TaskExpiringMedicalOtherComplianceId { get; set; }
        public int TaskId { get; set; }
        public string ExpirationItemType { get; set; }
        public string ExpirationItem { get; set; }
        public DateTime DueDate { get; set; }
        public int? CareGiverId { get; set; }
        public int? CareGiverTeamId { get; set; }
        public string CareGiverFirstname { get; set; }
        public string CareGiverLastname { get; set; }
        public string CareGiverMiddlename { get; set; }
        public int? BranchId { get; set; }
        public int? LocationId { get; set; }
        public string CareGiverCode { get; set; }
        public virtual WorklistTask Task { get; set; }
    }
}
