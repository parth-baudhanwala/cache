﻿using HHAExchange.Opsworklist.Domain.PollerModel;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace HHAExchange.Opsworklist.Domain.Entity
{
    public partial class WorklistTask : TableAuditDetails
    {
        public WorklistTask()
        {

        }
        public WorklistTask(DefaultJobModel record) : base(record)
        {
            TaskNotes = null;
            WorklistId = record.WorklistID;
            EntKey = record.EntKey;
            Status = "Open";
            ProviderId = record.ProviderID;
            OfficeId = record.OfficeID;
            TaskExpiringAuthorization = null;
            TaskExpiringMedicalOrOtherCompliance = null;
            TaskUnstaffedVisit = null;
            TaskMissingExpiringMWSchedule = null;
        }

        [Key]
        public int TaskId { get; set; }
        public string EntKey { get; set; }
        public string Status { get; set; }
        public int WorklistId { get; set; }
        public int ProviderId { get; set; }
        public int OfficeId { get; set; }

        [NotMapped]
        public LastNotes LastNotes { get; set; }
        public int? AssignedBy { get; set; }
        public int? AssignedTo { get; set; }
        public string AssignedByUser { get; set; }
        public string AssignedToUser { get; set; }

        public virtual TaskExpiringAuthorization TaskExpiringAuthorization { get; set; }
        public virtual TaskExpiringMedicalOrOtherCompliance TaskExpiringMedicalOrOtherCompliance { get; set; }
        public virtual TaskUnstaffedVisit TaskUnstaffedVisit { get; set; }
        public virtual TaskMissingExpiringMWSchedule TaskMissingExpiringMWSchedule { get; set; }
        public virtual TaskExpiringCertificationPeriod TaskExpiringCertificationPeriod { get; set; }
        public virtual ICollection<TaskNote> TaskNotes { get; set; }
    }
}
