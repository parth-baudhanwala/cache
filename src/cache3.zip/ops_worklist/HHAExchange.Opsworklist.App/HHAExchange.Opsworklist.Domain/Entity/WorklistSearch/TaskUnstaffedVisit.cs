﻿using HHAExchange.Opsworklist.Domain.Entity;
using HHAExchange.Opsworklist.Domain.PollerModel;
using System.ComponentModel.DataAnnotations;

namespace HHAExchange.Opsworklist.Domain
{
    public partial class TaskUnstaffedVisit : PatientDetails
    {
        public TaskUnstaffedVisit()
        {

        }
        public TaskUnstaffedVisit(UnstaffedVisitJobModel record) : base(record)
        {
            AdmissionId = record.AdmissionID;
            ContractId = record.ContractID;
            CoordinatorId = record.CoordinatorID;
            DisciplineId = record.DisciplineId;
            PatientId = record.PatientID;
            PatientTeamId = record.PatientTeamID;
            LocationId = record.LocationID;
            BranchId = record.BranchID;

            VisitDate = record.VisitDate;
            ScheduledTime = record.ScheduledTime;

            Address1 = record.Address1;
            Address2 = record.Address2;
            City = record.City;
            State = record.State;
            ZipCode = record.ZipCode;

            ContractName = record.ContractName;
            DisciplineName = record.DisciplineName;
            PatientFirstname = record.PatientFirstname;
            PatientLastname = record.PatientLastname;
            PatientMiddlename = record.PatientMiddlename;

            if (record.InternalPatient == 1)
                IsInternalPatient = true;
            else
                IsInternalPatient = false;

            ScheduleType = record.ScheduleType;

        }
        [Key]
        public int TaskUnstaffedVisitId { get; set; }
        public int TaskId { get; set; }
        public string ContractName { get; set; }
        public string DisciplineName { get; set; }
        public int? DisciplineId { get; set; }
        public int? ContractId { get; set; }
        public int? CoordinatorId { get; set; }
        public int PatientTeamId { get; set; }
        public int LocationId { get; set; }
        public int BranchId { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public DateTime VisitDate { get; set; }
        public string ScheduledTime { get; set; }
        public bool IsInternalPatient { get; set; }
        public string ScheduleType { get; set; }
        public virtual WorklistTask Task { get; set; }
    }
}
