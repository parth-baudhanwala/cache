﻿using HHAExchange.Opsworklist.Domain.Entity;
using HHAExchange.Opsworklist.Domain.PollerModel;
using System;
using System.ComponentModel.DataAnnotations;

namespace HHAExchange.Opsworklist.Domain
{
    public partial class TaskMissingExpiringMWSchedule : PatientDetails
    {
        public TaskMissingExpiringMWSchedule()
        {

        }
        public TaskMissingExpiringMWSchedule(MasterWeekModel record) : base(record)
        {
            AdmissionId = record.AdmissionID;
            CoordinatorID = record.CoordinatorID;
            MasterWeekEndDate = record.MasterWeekEndDate;
            MasterWeekSchedule = record.MasterWeekSchedule;
            PatientId = record.PatientID;
            PatientFirstname = record.PatientFirstname;
            PatientLastname = record.PatientLastname;
            PatientMiddlename = record.PatientMiddlename;
            PayerContractID = record.CHHAID;
            SundayContractID = record.SundayContractID;
            MondayContractID = record.MondayContractID;
            TuesdayContractID = record.TuesdayContractID;
            WednesdayContractID = record.WednesdayContractID;
            ThursdayContractID = record.ThursdayContractID;
            FridayContractID = record.FridayContractID;
            SaturdayContractID = record.SaturdayContractID;
            ContractNames = record.ContractNames;
            CaregiverNames = record.CaregiverNames;
            if (record.InternalPatient == 1)
                isInternalPatient = true;
            else
                isInternalPatient = false;
        }
        [Key]

        public int TaskMissingExpiringMWScheduleId { get; set; }
        public int TaskId { get; set; }
        public string MasterWeekSchedule { get; set; }
        public DateTime MasterWeekEndDate { get; set; }
        public int? CoordinatorID { get; set; }
        public int? PayerContractID { get; set; }
        public int? SundayContractID { get; set; }
        public int? MondayContractID { get; set; }
        public int? TuesdayContractID { get; set; }
        public int? WednesdayContractID { get; set; }
        public int? ThursdayContractID { get; set; }
        public int? FridayContractID { get; set; }
        public int? SaturdayContractID { get; set; }
        public string ContractNames { get; set; }
        public string CaregiverNames { get; set; }
        public bool? isInternalPatient { get; set; }
        public virtual WorklistTask Task { get; set; }
    }
}

