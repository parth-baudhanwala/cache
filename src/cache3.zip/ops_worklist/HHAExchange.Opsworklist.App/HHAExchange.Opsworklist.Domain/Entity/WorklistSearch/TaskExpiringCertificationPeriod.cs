﻿using HHAExchange.Opsworklist.Domain.Models;
using System;
using System.ComponentModel.DataAnnotations;

#nullable disable

namespace HHAExchange.Opsworklist.Domain.Entity
{
    public partial class TaskExpiringCertificationPeriod : PatientBaseDetails
    {
        public TaskExpiringCertificationPeriod()
        {

        }
        public TaskExpiringCertificationPeriod(ExpiringCertificationModel expiringCertificationModel) : base()
        {
            TaskId = expiringCertificationModel.WorklistID;
            PatientId = expiringCertificationModel.PatientID;
            PatientFullname = expiringCertificationModel.PatientFullname;
            AdmissionId = expiringCertificationModel.AdmissionId;
            StartDate = expiringCertificationModel.StartDate;
            EndDate = expiringCertificationModel.EndDate;
            NurseId = expiringCertificationModel.NurseId;
            NurseName = expiringCertificationModel.NurseName;
            PhysicianId = expiringCertificationModel.PhysicianID;
            PhysicianName = expiringCertificationModel.PhysicianName;
        }
        [Key]
        public int TaskExpiringCertificationPeriodId { get; set; }
        public int? TaskId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? NurseId { get; set; }
        public string NurseName { get; set; }
        public int? PhysicianId { get; set; }
        public string PhysicianName { get; set; }
        public string PatientFullname { get; set; }
        public virtual WorklistTask Task { get; set; }
    }
}
