﻿namespace HHAExchange.Opsworklist.Domain.Entity
{
    public partial class AuthorizationSetup
    {
        public int AuthorizationSetupId { get; set; }
        public int ProviderId { get; set; }
        public bool TempAuthorizationFlag { get; set; }
        public int TaskCreationDays { get; set; }
        public string PatientStatusIds { get; set; }
        public string PatientStatus { get; set; }
        public bool AutomaticallyAssignTasks { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedByUserName { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime CreatedUTCDate { get; set; }
        public int? UpdatedBy { get; set; }
        public string UpdatedByUserName { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public DateTime? UpdatedUTCDate { get; set; }
    }
}
