﻿using HHAExchange.Opsworklist.Domain.PollerModel;
using System;

namespace HHAExchange.Opsworklist.Domain
{
    public class TableAuditDetails
    {
        public TableAuditDetails()
        {
            CreatedDate = DateTime.Now;
            CreatedDateUtc = DateTime.UtcNow;
        }
        public TableAuditDetails(DefaultJobModel record)
        {
            CreatedDate = DateTime.Now;
            CreatedDateUtc = DateTime.UtcNow;
            CreatedBy = record.CreatedBy;
            CreatedByUser = record.CreatedByUser;
        }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public string CreatedByUser { get; set; }
        public string UpdatedByUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public DateTime CreatedDateUtc { get; set; }
        public DateTime UpdatedDateUtc { get; set; }

        public static void AddUpdateAuditDetails(TableAuditDetails details, int UpdatedBy, string UpdatedByUser)
        {
            details.UpdatedDate = DateTime.Now;
            details.UpdatedDateUtc = DateTime.UtcNow;
            details.UpdatedBy = UpdatedBy;
            details.UpdatedByUser = UpdatedByUser;
        }
    }
}
