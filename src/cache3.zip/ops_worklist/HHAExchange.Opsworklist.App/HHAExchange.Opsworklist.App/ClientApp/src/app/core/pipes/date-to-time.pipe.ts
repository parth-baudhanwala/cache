import { Pipe, PipeTransform } from '@angular/core';
import moment from 'moment';

@Pipe({
  name: 'dateToTime'
})
export class DateToTimePipe implements PipeTransform {
  transform(value: Date, defaultStr: string = ""): string {
    return value != null ? moment(value).format('LT') : defaultStr
  }
}
