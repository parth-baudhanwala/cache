import { Component } from '@angular/core';


@Component({
    selector: 'hha-auth-callback',
    template: ''
})
export class AuthCallbackComponent {
    constructor() { }
}
