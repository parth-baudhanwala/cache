import {
  Component,
  ElementRef,
  HostListener,
  Input,
  QueryList,
  ViewChild,
  ViewChildren,
} from "@angular/core";
import { Key } from "ts-key-enum";
import { ActionButton } from "../../model";

@Component({
  selector: "hhax-column-action",
  templateUrl: "./column-action.component.html",
  styleUrls: ["./column-action.component.scss"],
})
export class ColumnActionComponent {
  @Input() actions: ActionButton<any>[];
  @Input() row: any;

  public isDropdownShown: boolean = false;

  private _selectedAction: number = 0;
  private _dropdownJustOpened: boolean = false;

  @ViewChild("mainButton", { read: ElementRef })
  private _mainButton: ElementRef;
  @ViewChildren("actionItem", { read: ElementRef })
  private _actions: QueryList<ElementRef>;

  constructor(public elementRef: ElementRef) {}

  @HostListener("document:click", ["$event.target"])
  public onClick(targetElement: HTMLElement): void {
    if (!targetElement || !this.isDropdownShown) {
      return;
    }

    const clickedInside = this.elementRef.nativeElement.contains(targetElement);
    if (!clickedInside) {
      this.isDropdownShown = false;
    }
  }

  @HostListener("keyup", ["$event"]) keyup(event) {
    // Element doesn't exist on keydown so focusing on keyup
    if (event.key === Key.ArrowDown && this._dropdownJustOpened) {
      this._actions.toArray()[this._selectedAction].nativeElement.focus();
      this._dropdownJustOpened = false;
    }
  }

  toggleDropdownKey(event: KeyboardEvent) {
    if (event.key === Key.ArrowDown && !this.isDropdownShown) {
      this.isDropdownShown = true;
      this._selectedAction = 0;
      this._dropdownJustOpened = true;
    }
    if (event.key === Key.Escape && this.isDropdownShown) {
      this.isDropdownShown = false;
      this._mainButton.nativeElement.focus();
    }
  }

  toggleDropdown() {
    this.isDropdownShown = !this.isDropdownShown;
  }

  actionNavigation(event: KeyboardEvent) {
    if (event.key === Key.ArrowDown) {
      if (this._selectedAction < this._actions.length - 1) {
        this._actions.toArray()[this._selectedAction].nativeElement.focus();
        this._selectedAction++;
      }
    }
    if (event.key === Key.Tab && event.shiftKey === false) {
      if (this._selectedAction < this._actions.length - 1) {
        this._actions.toArray()[this._selectedAction].nativeElement.focus();
        this._selectedAction++;
      } else if (this._selectedAction === this._actions.length - 1) {
        this.isDropdownShown = false;
        this._selectedAction = 0;
        this._mainButton.nativeElement.focus();
      }
    }
    if (event.key === Key.Tab && event.shiftKey === true) {
      if (this._selectedAction <= this._actions.length - 1) {
        if (this._selectedAction > 0) {
          this._selectedAction--;
          this._actions.toArray()[this._selectedAction].nativeElement.focus();
        } else {
          this._selectedAction = 0;
          this.isDropdownShown = false;
          this._mainButton.nativeElement.autoFocus = true;
        }
      }
    }
    if (event.key === Key.ArrowUp) {
      if (this._selectedAction > 0) {
        this._selectedAction--;
        this._actions.toArray()[this._selectedAction].nativeElement.focus();
      } else {
        this.isDropdownShown = false;
        this._mainButton.nativeElement.focus();
      }
    }
    if (event.key === Key.Escape) {
      this.isDropdownShown = false;
      this._mainButton.nativeElement.focus();
    }

    if (event.key === Key.Enter) {
      this._actions.toArray()[this._selectedAction].nativeElement.click();
    }
  }

  onActionItemClick(action, row) {
    this._selectedAction = 0;
    action.handler(row.data);
  }
}
