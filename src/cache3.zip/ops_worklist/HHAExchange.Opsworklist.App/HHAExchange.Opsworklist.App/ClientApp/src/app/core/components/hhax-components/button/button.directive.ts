import { Directive, HostBinding, Input } from '@angular/core';

/**
 * Sets the button as a company button.
 */
@Directive({
  selector: 'button[hhaxButton]',
})
export class HhaxButtonDirective {
  /**
   * Applies the button class to the host button.
   */
  @HostBinding('class.button') baseButtonClass = true;

  /**
   * Sets the size class of the button based on the size input.
   */
  @HostBinding('class') get sizeClass() {
    return this.size;
  }

  /**
   * Determines the size of the button. Defaults to 'regular'.
   */
  @Input() size: 'large' | 'regular' | 'small' | 'tiny' = 'regular';
}

/**
 * Turns the button into a primary button.
 */
@Directive({
  selector: 'button[hhaxButtonPrimary], button[hxBtnPrimary]',
})
export class HhaxPrimaryButtonDirective extends HhaxButtonDirective {
  /**
   * Applies the primary class to the host button.
   */
  @HostBinding('class') primaryClass = 'primary';

  constructor() {
    super();
  }
}

/**
 * Turns the button into a clear button.
 */
@Directive({
  selector: 'button[hhaxButtonClear], button[hxBtnClear]',
})
export class HhaxClearButtonDirective extends HhaxButtonDirective {
  /**
   * Applies the primary class to the host button.
   */
  @HostBinding('class') primaryClass = 'clear';

  constructor() {
    super();
  }
}

/**
 * Turns the button into a clear button.
 */
@Directive({
  selector: 'button[hhaxButtonAlert], button[hxBtnAlert]',
})
export class HhaxAlertButtonDirective extends HhaxButtonDirective {
  /**
   * Applies the primary class to the host button.
   */
  @HostBinding('class') primaryClass = 'alert';

  constructor() {
    super();
  }
}

/**
 * Turns the button into a success button.
 */
@Directive({
  selector: 'button[hhaxButtonSuccess], button[hxBtnSuccess]',
})
export class HhaxSuccessButtonDirective extends HhaxButtonDirective {
  /**
   * Applies the success class to the host button.
   */
  @HostBinding('class') primaryClass = 'success';

  constructor() {
    super();
  }
}

/**
 * Turns the button into a success button.
 */
@Directive({
  selector: 'button[hxBtnHollow]',
})
export class HxHollowButtonDirective extends HhaxButtonDirective {
  /**
   * Applies the success class to the host button.
   */
  @HostBinding('class') primaryClass = 'hollow';

  constructor() {
    super();
  }
}