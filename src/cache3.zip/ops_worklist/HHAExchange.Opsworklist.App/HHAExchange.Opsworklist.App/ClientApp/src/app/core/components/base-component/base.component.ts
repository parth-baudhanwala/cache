import { Component, Input, OnInit, Output, EventEmitter, ElementRef, ViewChild } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { HHAUserService } from "@app/core/authentication/user.service";
import { MasterWeekModal } from "@app/core/components/modals/master-week-schedule/master-week-schedule.component";
import { AddNoteComponent } from "@app/core/components/modals/add-note-modal/add-note-modal.component";
import { AssignTaskComponent } from "@app/core/components/modals/assign-task-modal/assign-task-modal.component";
import { IframeModalComponent } from "@app/core/components/modals/iframe-modal/iframe-modal.component";
import { SendMessageModalComponent } from "@app/core/components/modals/send-message-modal/send-message-modal.component";
import { Subject } from 'rxjs';
import {
  expiringAuthColumns,
  medicalColumns,
  unstaffedVisitsColumns,
  statusOptions,
  caregiverStatusOptions,
  masterWeekColumns,
  certificationPeriodColumns,
  patienStatusOptions
} from "@app/core/config/static-options";
import {
  closingConditionParams,
  IDisciplineModel,
  IGetCaregiverTeamModel,
  IGetLocationForOfficeModel,
  IPutResponse,
  UpdateTaskRequest,
  Worklist,
  WorklistDetail,
  IPatientTeamModel,
  INurseModel,
  ILanguageModel,
  LanguageResponseBody,
  IUserDetailsModel,
} from "@app/core/models/common.model";
import { Events } from "@app/core/models/constant.model";
import {
  assignTaskModel,
  getUsersByWorklistIDData,
  TaskNotes,
} from "@app/core/models/notes.model";
import { Office } from "@app/core/models/office.model";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { FileService } from "@app/core/services/file.service";
import { SearchFieldsService } from "@app/core/services/search-fields.service";
import { WorkslistService } from "@app/core/services/workslist.service";
import { NotesService } from "@app/core/services/notes.service";
import * as FileSaver from "file-saver";
import {
  ComponentColours,
  MultiSelectOption,
  ToastrAlertService,
} from "hhax-components";
import { IGetAllNotesByTaskID, IGetAllNotesByTaskIDResult } from "@app/core/models/notes.model";
import { TreeviewConfig } from "@app/core/components/ngx-treeview-dropdown/models/treeview-config";
import { TreeviewItem } from "@app/core/components/ngx-treeview-dropdown/models/treeview-item";
import popup from "@app/lib/popup";
import { SessionStorageService, SessionStorageKeyNames } from "../../services/session-storage.service";
import isEqual from "lodash/fp/isEqual";
import { ComplianceExpItem } from "@app/core/models/ComplianceExpItem.model";
import { Observable } from 'rxjs';
import { LocalStorageKeyNames } from '../../services/local-storage.service';
import { GetRequest, SortDirection } from "@app/core/components/hhax-components/data-table/datasource/model/transport";
import { DatePipe } from '@angular/common';
import { VisitScheduleType } from "../../models/schedule-type.enum";
import { isBlank } from "../../../lib/utils";

const CSV_EXTENSION = '.csv';
const CSV_SEPARATOR = ',';
const CSV_TYPE = 'text/plain;charset=utf-8';

@Component({
  selector: "app-base",
  template: ` <p>base component</p> `,
})
export class BaseComponent implements OnInit {
  @ViewChild("ref", { read: ElementRef }) ref: ElementRef;
  @Input() worklistDetail: WorklistDetail;
  @Output() worklistEvents = new EventEmitter<Events>();
  getUrl: string;
  getParams = {};
  gridPageSize: number;
  getExportParams = {};
  statusOptions = statusOptions;
  caregiverStatusOptions = caregiverStatusOptions;
  medicalColumns = medicalColumns;
  expiringAuthColumns = expiringAuthColumns;
  unstaffedVisitsColumns = unstaffedVisitsColumns;
  masterWeekColumns = masterWeekColumns;
  certificationPeriodColumns = certificationPeriodColumns;
  patienStatusOptions = patienStatusOptions;
  config = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400,
  });
  configMulti = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: false,
    decoupleChildFromParent: false,
    maxHeight: 400,
  });
  appConfig: any;
  itemsOffice: TreeviewItem[] = [];
  officeList: Office[];
  isfromENTMLApp: boolean = false;
  valuesOffice: number[] = [];
  assigneeOptions: MultiSelectOption[];
  disciplineOptions: MultiSelectOption[];
  workListGroup: FormGroup;
  locationOptions: MultiSelectOption[];
  teamOptions: MultiSelectOption[];
  branchOptions: MultiSelectOption[];
  contractOptions: MultiSelectOption[];
  coordinatorOptions: MultiSelectOption[];
  physicianOptions: MultiSelectOption[];
  nurseOptions: MultiSelectOption[];
  userDetails: IUserDetailsModel;
  params: {
    UserID: number;
    LocationID: number;
    Active: number;
    PatientID: number;
    AideID: number;
    OfficeXml: null;
    AppVersion: string;
    Version: number;
    MinorVersion: number;
    VendorID: number;
    OfficeId: string;
  };
  AuthParams:
    {
      UserID: number;
      SessionID: string,
      AppVersion: string;
      Version: number;
      MinorVersion: number;
    };
  // params: any;
  noteAfterClosedStatus: number;
  closingConditionParams: closingConditionParams;
  taskNotesCount: number;
  lastTaskDateTime: any;
  lastNoteEntered: string;
  notes: string;
  maxDate: string = "9999-12-31";
  previouslySelectedOffices: number | number[];
  onInit: boolean;
  complianceExpItemList: ComplianceExpItem[];
  complianceExpOptions: TreeviewItem[] = [];
  languageList: LanguageResponseBody[];
  languageOptions: TreeviewItem[] = [];
  exportColumnNames: string[];
  exportFileName: string;
  vendor12HoursFlag: boolean;
  isUserInNewSkin: boolean;

  constructor(
    public _config: ConfigurationService,
    public _searchservice: SearchFieldsService,
    public _alert: ToastrAlertService,
    public _common: CommonService,
    public _dialogModal: MatDialog,
    public _worklist: WorkslistService,
    public _userService: HHAUserService,
    public _fileService: FileService,
    public _notesService: NotesService,
    public storage: SessionStorageService,
    public _datePipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.getUrl = `SearchTask/${this.worklistDetail.worklistPath}`;
    this.appConfig = this._config.appConfiguration;
    this.isUserInNewSkin = this._userService.getIsUserNewskin();
    this.vendor12HoursFlag = this._userService.getVendor12HoursFlag();

    var sessionID = JSON.parse(localStorage.getItem(LocalStorageKeyNames.sessionID));
    this.AuthParams = {
      SessionID: sessionID,
      UserID: this.appConfig.userId,
      AppVersion: this.appConfig.appName,
      Version: this.appConfig.version,
      MinorVersion: this.appConfig.minorVersion,
    };
    let userOfficeId: number[] | number;
    if (this.appConfig && this.appConfig.userOffices) {
      userOfficeId =
        this.appConfig.userOffices.length > 1
          ? this.appConfig.userOffices
            .filter((obj) => obj.isPrimary)
            .map((obj) => obj.officeID)
          : this.appConfig.userOffices[0].officeID;
    }

    this.params = {
      UserID: this.appConfig.userId,
      LocationID: -1,
      Active: -1,
      PatientID: -1,
      AideID: -1,
      OfficeXml: null,
      AppVersion: this.appConfig.appName,
      Version: this.appConfig.version,
      MinorVersion: this.appConfig.minorVersion,
      VendorID: this.appConfig.agencyID,
      OfficeId: Array.isArray(userOfficeId)
        ? userOfficeId.join(",")
        : userOfficeId.toString(),
    };
    this.getOffices(this.params);
    this.onInit = true;
  }

  getAssignees(payload) {
    const key = `${payload.WorklistID}_${payload.OfficeIDs}`;
    let cachedOfficeData: any = this.storage.getItem(
      SessionStorageKeyNames.usersByWorklistID
    );
    if (cachedOfficeData && cachedOfficeData[key]) {
      this.assigneeOptions = cachedOfficeData[key].map((obj) => ({
        text: `${obj.firstName} ${obj.lastName} (${obj.userName})`,
        value: obj.userID,
      }));
      this.workListGroup.patchValue({
        assignee: [this.appConfig.userId],
      });
    } else {
      this._common
        .GetUsersByWorklistID(payload)
        .subscribe((res: getUsersByWorklistIDData[]) => {
          if (res && Array.isArray(res)) {
            if (!cachedOfficeData) cachedOfficeData = {};
            cachedOfficeData[key] = res;
            this.storage.setItem(
              SessionStorageKeyNames.usersByWorklistID,
              cachedOfficeData
            );
            this.assigneeOptions = res.map((obj) => ({
              text: `${obj.firstName} ${obj.lastName} (${obj.userName})`,
              value: obj.userID,
            }));
            this.workListGroup.patchValue({
              assignee: [this.appConfig.userId],
            });
          }
        });
    }
  }

  handleKeydown(event: any, callback: Function = undefined) {
    if (event && event.key === "Enter") {
      if (event.target) {
        event.preventDefault();
      }

      if (callback) callback(event);
    }
  }

  handleOfficeKeyboardAccessibility(event: any) {
    if (event && event.target) {
      event.target.click();
    }
  }

  getDiscipline(officeIds: number[]) {
    if (this.isUserInNewSkin) {
      this.getDisciplinesForNewSkin(officeIds);
    } else {
      this.getDisciplinesForOldSkin();
    }
  }

  getDisciplinesForNewSkin(officeIds: number[]) {
    const distinctDisciplines = {};
    const providerAdminAPIUrl = JSON.parse(localStorage.getItem(LocalStorageKeyNames.providerAdminAPIUrl));
    const officeIdBatchSize = parseInt(localStorage.getItem(LocalStorageKeyNames.maxProviderDisciplinesOfficeResponseCount));
    let uniqueDisciplines = [];

    this._searchservice.getOfficesDisciplines(officeIds, providerAdminAPIUrl, officeIdBatchSize).subscribe((result) => {
      result.payload.office.forEach((office) => {
        office.officeDisciplines.forEach((discipline) => {
          if (discipline.selected && !distinctDisciplines[discipline.disciplineId]) {
            distinctDisciplines[discipline.disciplineId] = {
              disciplineId: discipline.disciplineId,
              discipline: discipline.discipline,
            };
          }
        });
      });

      uniqueDisciplines = Object.values(distinctDisciplines);

      this.disciplineOptions = uniqueDisciplines.map((discipline) => ({
        text: discipline.discipline,
        value: discipline.disciplineId
      }));

      this.workListGroup.patchValue({
        disciplineID: [-1, ...this.disciplineOptions.map((obj) => obj.value)]
      });
    });
  }

  getDisciplinesForOldSkin() {
    const cachedData: IDisciplineModel = this.storage.getItem(SessionStorageKeyNames.cargeGiverDiscipline);

    if (cachedData) {
      this.disciplineOptions = cachedData.responseBody.map((obj: any) => ({
        text: obj.discipline,
        value: obj.disciplineID,
      }));
      this.workListGroup.patchValue({
        disciplineID: [-1, ...this.disciplineOptions.map((obj) => obj.value)],
      });
    } else {
      this._searchservice
        .getDiscipline(this.params)
        .subscribe((res: IDisciplineModel) => {
          if (res && res.httpStatusCode === 200) {
            this.storage.setItem(SessionStorageKeyNames.cargeGiverDiscipline, res);

            this.disciplineOptions = res.responseBody.map((obj: any) => ({
              text: obj.discipline,
              value: obj.disciplineID,
            }));

            this.workListGroup.patchValue({
              disciplineID: [-1, ...this.disciplineOptions.map((obj) => obj.value)]
            });
          }
        });
    }
  }

  getLanguages() {
    this.languageList = [{
      languageID: -1,
      language: "Unspecified"
    }];
    const cachedData: ILanguageModel = this.storage.getItem(
      SessionStorageKeyNames.language
    );
    if (!!cachedData) {
      this.languageList.push(...cachedData.responseBody);
      this.languageOptions = Helper.languagesToTreeViewItem(this.languageList);
    } else {
      this._searchservice.getLanguageData().subscribe(
        (result: any) => {
          if (result && result.httpStatusCode === 200) {
            this.storage.setItem(SessionStorageKeyNames.language, result);
          }
          this.languageList.push(...<LanguageResponseBody[]>result.responseBody);
          this.languageOptions = Helper.languagesToTreeViewItem(this.languageList);
        },
        (error) => {
          this._alert.error(
            "error",
            "There was error while fetching Language(s)."
          );
        }
      );
    }
  }

  checkAuthentication(authParams: any): Observable<boolean> {
    var subject = new Subject<boolean>();
    var isvalid = true; // By default set to True

    if (authParams != null) {
      if (authParams.SessionID != null) {
        (this._common.getUserAuthentication(authParams)).subscribe(
          (res: IUserDetailsModel) => {
            if (!(res.isUserLoggedIn)) {
              this._userService.logoutUser();
              isvalid = false;
            } else {
              isvalid = true;
              localStorage.setItem(LocalStorageKeyNames.userPrimaryOfficeID, res.officeID);
            }
            subject.next(isvalid);
          },
          (error) => {
            this._alert.error("error", "There was error while performing the authentication.");
          }
        );
      }
    }
    return subject.asObservable();
  }

  async getOffices(params): Promise<void> {
    const cachedOfficeData: {
      responseBody: any[];
      httpStatusCode: number;
      httpStatusMessage?: any;
      authenticationToken?: any;
    } = this.storage.getItem(SessionStorageKeyNames.officeData);
    if (!!cachedOfficeData) {
      this.officeList = <Office[]>cachedOfficeData.responseBody;
      this.getTreeviewOffice();
    } else {
      this._searchservice.getOfficeData(params).subscribe(
        (result: any) => {
          if (result && result.httpStatusCode === 200) {
            this.storage.setItem(SessionStorageKeyNames.officeData, result);
          }
          this.officeList = <Office[]>result.responseBody;
          this.getTreeviewOffice();
        },
        (error) => {
          this._alert.error(
            "error",
            "There was error while fetching Office(s)."
          );
        }
      );
    }
  }

  getTreeviewOffice() {
    let primaryOfficeID: number;
    this._config.appConfiguration.userOffices.forEach((userOffice) => {
      if (userOffice.isPrimary === true) primaryOfficeID = userOffice.officeID;
    });
    this.itemsOffice = Helper.OfficeToTreeViewItem(
      this.officeList,
      this.isfromENTMLApp,
      primaryOfficeID
    );
    this.valuesOffice = this.officeList.map((i) => {
      return i.officeID;
    });
  }

  officeSelectedChange(selectedOfficeIds): void {
    if (selectedOfficeIds.length === 0) {
      this.disciplineOptions = [];
      this.workListGroup.patchValue({
        disciplineID: [[]]
      });
    } else {
      this.getDiscipline(selectedOfficeIds);
    }

    this.workListGroup.patchValue({
      officeID: [...selectedOfficeIds],
    });
    switch (this.worklistDetail.worklistPath) {
      case Worklist.MEDICAL_COMPLIANCE:
        this.clearComplianceExpItem();
        this.clearTeamBranchLocation(selectedOfficeIds);
        break;
      case Worklist.EXPIRING_AUTHORIZATION:
        this.clearCoordinatorAndContract(selectedOfficeIds);
        break;
      case Worklist.UNSTAFFED_VISITS:
        this.clearTeamBranchLocation(selectedOfficeIds, true);
        this.clearCoordinatorAndContract(selectedOfficeIds);
        break;
      case Worklist.MASTER_WEEK:
        this.clearCoordinatorAndContract(selectedOfficeIds);
        break;
      case Worklist.CERTIFICATION_PERIOD:
        this.clearNurse(selectedOfficeIds);
        break;
    }
    this.previouslySelectedOffices = selectedOfficeIds;
  }

  setDisciplineIds(submittedDisciplioneIds) {
    if (submittedDisciplioneIds[0] == -1) {
      return [...submittedDisciplioneIds.slice(1)];
    } else if (isBlank(submittedDisciplioneIds)) {
      return [...this.disciplineOptions.map((obj) => obj.value)];
    } else {
      return submittedDisciplioneIds;
    }
  }

  clearNurse($event) {
    if (this.workListGroup.value.officeID.length === 0) {
      this.physicianOptions = [];
      this.nurseOptions = [];
      this.workListGroup.patchValue({
        physicianID: [],
        nurseID: [],
      });
    }
    const params = {
      UserID: this.appConfig.userId,
      VendorID: this.appConfig.agencyID,
      OfficeId: Array.isArray($event) ? $event.join(",") : $event.toString(),
      AppVersion: this.appConfig.appName,
      Version: this.appConfig.version,
      MinorVersion: this.appConfig.minorVersion,
    };

    this.changeOfficeDependentFields($event, params);
  }

  clearCoordinatorAndContract($event) {
    if (this.workListGroup.value.officeID.length === 0) {
      this.contractOptions = [];
      this.coordinatorOptions = [];
      this.workListGroup.patchValue({
        contractID: [],
        coordinatorID: [],
      });
    }
    const params = {
      UserID: this.appConfig.userId,
      AppVersion: this.appConfig.appName,
      Version: this.appConfig.version,
      MinorVersion: this.appConfig.minorVersion,
      OfficeId: Array.isArray($event) ? $event.join(",") : $event.toString(),
    };

    this.changeOfficeDependentFields($event, params);
  }

  clearComplianceExpItem() {
    if (this.workListGroup.value.officeID.length === 0) {
      this.complianceExpOptions = [];
    }
  }

  clearTeamBranchLocation($event, isUnstaffedVisits = false) {
    if (this.workListGroup.value.officeID.length === 0) {
      this.teamOptions = [];
      this.branchOptions = [];
      this.locationOptions = [];
    }
    const params = {
      UserID: this.appConfig.userId,
      LocationID: -1,
      Active: -1,
      PatientID: -1,
      AideID: -1,
      OfficeXml: null,
      AppVersion: this.appConfig.appName,
      Version: this.appConfig.version,
      MinorVersion: this.appConfig.minorVersion,
      VendorID: this.appConfig.agencyID,
      OfficeId: Array.isArray($event) ? $event.join(",") : $event.toString(),
    };
    this.workListGroup.patchValue({
      teamID: [],
      branchID: [],
      locationID: [],
    });
    if (!isUnstaffedVisits) this.changeOfficeDependentFields($event, params);
  }

  changeOfficeDependentFields($event, params) {
    if (this.onInit && params.OfficeId) {
      this.onInit = false;
      this.officeDependentSearchFields(params);
    }

    if (!isEqual(this.previouslySelectedOffices, $event)) {
      if (params.OfficeId) {
        this.officeDependentSearchFields(params);
      }
    }
  }

  async officeDependentSearchFields(params): Promise<void> {
    if (params.OfficeId) {
      switch (this.worklistDetail.worklistPath) {
        case Worklist.MEDICAL_COMPLIANCE:
          this.getCaregiverComplianceExpItem(params);
          this.getCaregiverTeamOptions(params);
          this.getBranchAndLocationOptions(params);
          break;
        case Worklist.EXPIRING_AUTHORIZATION:
          this.getCoordinatorAndContractOptions(params);
          break;
        case Worklist.UNSTAFFED_VISITS:
          this.getPatientTeamOptions(params);
          this.getBranchAndLocationOptions(params);
          this.getCoordinatorAndContractOptions(params);
          break;
        case Worklist.MASTER_WEEK:
          this.getCoordinatorAndContractOptions(params);
          break;
        case Worklist.CERTIFICATION_PERIOD:
          this.getNurseOptions(params);
          break;
      }
    }
  }

  getCaregiverComplianceExpItem(params) {
    this._searchservice.getCaregiverComplianceExpItemData(params).subscribe(
      (result: any) => {
        this.complianceExpItemList = <ComplianceExpItem[]>result.responseBody;
        this.complianceExpOptions = Helper.ComplianceExpItemToTreeViewItem(
          this.complianceExpItemList
        );
      },
      (error) => {
        this._alert.error("error", "There was error while fetching Compliance Expiration Item(s).");
      }
    );
  }

  getCaregiverTeamOptions(params) {
    this._searchservice
      .getCaregiverTeamData(params)
      .subscribe((res: IGetCaregiverTeamModel[]) => {
        if (res && Array.isArray(res)) {
          this.teamOptions = res.map((obj: IGetCaregiverTeamModel) => ({
            text: obj.caregiverTeam,
            value: obj.caregiverTeamID,
          }));
        }
      });
  }

  getPatientTeamOptions(params) {
    this._searchservice
      .getPatientTeamData(params)
      .subscribe((res: IPatientTeamModel[]) => {
        if (res && Array.isArray(res)) {
          this.teamOptions = res.map((obj: IPatientTeamModel) => ({
            text: obj.patientTeam,
            value: obj.patientTeamID,
          }));
        }
      });
  }

  getBranchAndLocationOptions(params) {
    this._searchservice.getLocationData(params).subscribe((res: any) => {
      this.locationOptions = res.responseBody.map((obj: any) => ({
        text: obj.location,
        value: obj.locationID,
      }));
    });
    this._searchservice
      .getBranchData(params)
      .subscribe((res: IGetLocationForOfficeModel) => {
        this.branchOptions = res.responseBody.map((obj: any) => ({
          text: obj.branchName,
          value: obj.branchID,
        }));
      });
  }

  getCoordinatorAndContractOptions(params) {
    this._searchservice.getCoordinatorOptions(params).subscribe((res: any) => {
      this.coordinatorOptions = res.responseBody.map((obj: any) => ({
        text: obj.coordinatorName,
        value: obj.coordinatorID,
      }));
      this.workListGroup.patchValue({
        coordinatorID: [-1, ...this.coordinatorOptions.map((obj) => obj.value)],
      });
    });
    this._searchservice.getContractOptions(params).subscribe((res: any) => {
      this.contractOptions = res.responseBody.map((obj: any) => ({
        text: obj.sourceName,
        value: obj.sourceID,
      }));
      this.workListGroup.patchValue({
        contractID: [-1, ...this.contractOptions.map((obj) => obj.value)],
      });
    });
  }

  getNurseOptions(params) {
    this._searchservice
      .getNurseOptions(params)
      .subscribe((res: INurseModel[]) => {
        if (res) {
          this.nurseOptions = res.map((obj) => ({
            text: obj.nurseName,
            value: obj.nurseID,
          }));
          this.workListGroup.patchValue({
            nurseID: [-1, ...this.nurseOptions.map((obj) => obj.value)],
          });
        }
      });
  }

  assignAutoCompleteValue(key: string, event): void {
    (this.workListGroup.get(key) as FormControl).setValue(event.id);
  }

  getStatusColor(status: string): ComponentColours {
    if (status === "Open") {
      return ComponentColours.warning;
    }
    if (status === "Closed") {
      return ComponentColours.success;
    }
    if (status === "Completed") {
      return ComponentColours.success;
    }
    if (status === "In-Progress") {
      return ComponentColours.info;
    }

    return ComponentColours.none;
  }

  async openWeekScheduleModal(
    record,
    callback: Function,
    isClosedStatus = false
  ): Promise<void> {
    const masterWeekScheduleModal = this._dialogModal.open(MasterWeekModal, {
      width: "75%",
      disableClose: false,
      autoFocus: false,
      data: {
        record: record,
        worklistPath: this.worklistDetail.worklistPath,
        taskName: record.masterWeekSchedule,
      },
    });
    masterWeekScheduleModal.afterClosed().subscribe((result) => {
      if (result && result.httpStatusCode === 200) {
        if (isClosedStatus === true) {
          this.updateStatus(record, "Closed", callback);
        } else {
          this._alert.success("success", "Note saved successfully");
          if (callback) callback();
        }
      }
    });
  }
  async openAddNoteDialog(
    record,
    callback: Function,
    isClosedStatus = false
  ): Promise<void> {
    const noteTaskModal = this._dialogModal.open(AddNoteComponent, {
      width: "90%",
      disableClose: false,
      autoFocus: false,
      data: {
        record: record,
        title: "View/Add Notes",
        subject: "",
        notes: "",
        attachment: "",
        showViewAllNotes: !Array.isArray(record),
        worklistPath: this.worklistDetail.worklistPath,
        taskName: record.expirationItem,
      },
    });
    noteTaskModal.afterClosed().subscribe((result) => {
      if (result && result.httpStatusCode === 200) {
        if (isClosedStatus === true) {
          this.updateStatus(record, "Closed", callback);
        } else {
          this._alert.success("success", "Note saved successfully");
          if (callback) callback();
        }
      }
    });
  }

  async refreshRecords(
    selectedRecords,
    worklist: Worklist,
    callback: Function
  ): Promise<void> {
    this.closingConditionParams = new closingConditionParams(this._config);
    this.closingConditionParams.entKeys = [];
    this.closingConditionParams.worklistId = this.worklistDetail.worklistId;
    this.closingConditionParams.UpdatedByUser = `${this._userService.getUserFullName()} (${this._userService.getUserName()})`;
    if (Array.isArray(selectedRecords)) {
      selectedRecords.forEach((obj) =>
        this.closingConditionParams.entKeys.push(obj.worklistEntKey)
      );
    } else {
      this.closingConditionParams.entKeys.push(selectedRecords.worklistEntKey);
    }
    this._worklist
      .closingCondition(worklist, this.closingConditionParams)
      .subscribe((result) => {
        if (result && result.httpStatusCode === 200) {
          this._alert.success("success", "Refresh completed successfully");
          if (callback) callback();
        }
      });
  }

  async openIFrame(
    x: any,
    url: string,
    refreshTableCb: Function
  ): Promise<void> {
    this.closingConditionParams = new closingConditionParams(this._config);
    this.closingConditionParams.entKeys = [];
    this.closingConditionParams.entKeys.push(x.data.worklistEntKey);
    this.closingConditionParams.worklistId = this.worklistDetail.worklistId;
    const iFramedata: {
      title: string;
      url?: string;
      path: string;
      closingConditionParams: closingConditionParams;
    } = {
      title: this.worklistDetail.worklistName,
      url,
      closingConditionParams: this.closingConditionParams,
      path: this.worklistDetail.worklistPath,
    };
    const iframeModal = this._dialogModal.open(IframeModalComponent, {
      width: "100%",
      height: "100%",
      maxWidth: "90vw",
      maxHeight: "100vh",
      disableClose: false,
      autoFocus: false,
      data: iFramedata,
    });
    iframeModal.afterClosed().subscribe((result) => {
      if (result) {
        this._alert.success("success", "Refresh completed successfully");
        if (refreshTableCb) refreshTableCb();
      }
    });
  }

  async openWindowPopUp(
    url: string,
    x: any,
    worklist: Worklist,
    callback: Function
  ): Promise<void> {
    popup(url, window.screen.width - 100, window.screen.height - 200, () =>
      this.onPopUpClose(x, worklist, callback)
    );
  }

  onPopUpClose(x: any, worklist: Worklist, callback: Function) {
    this.closingConditionParams = new closingConditionParams(this._config);
    this.closingConditionParams.entKeys = [x.data.worklistEntKey.toString()];
    this.closingConditionParams.worklistId = x.data.worklistId;
    this.closingConditionParams.UpdatedByUser = `${this._userService.getUserFullName()} (${this._userService.getUserName()})`;
    this._worklist
      .closingCondition(worklist, this.closingConditionParams)
      .subscribe((result) => {
        if (result && result.httpStatusCode === 200) {
          this._alert.success("success", "Refresh completed successfully");
          if (callback) callback();
        }
      });
  }

  async updateStatus(
    userData,
    status,
    callback: Function = () => { }
  ): Promise<void> {
    let payload: UpdateTaskRequest;
    if (Array.isArray(userData)) {
      payload = {
        WlTaskId: userData.map((obj) => obj.worklistTaskId).join(","),
        Status: status,
        UpdatedBy: this._userService.getUserID(),
        UpdatedByUser: this._userService.getUserName(),
      };
    } else {
      payload = {
        WlTaskId: userData.worklistTaskId.toString(),
        Status: status,
        UpdatedBy: this._userService.getUserID(),
        UpdatedByUser: this._userService.getUserName(),
      };
    }
    this._common
      .updateTask(payload, "Status")
      .subscribe((result: IPutResponse) => {
        if (result.httpStatusCode === 200) {
          if (status === "Closed") {
            this.worklistEvents.emit(Events.REFRESH_WORKLIST_COUNT);
          } else {
            this.autoGenerateNotes(
              userData,
              callback,
              `Status changed to ${payload.Status}.`
            );
          }
          this._alert.success("success", "Task status updated successfully");
          if (callback) callback();
        }
      });
  }

  async updateClosedStatus(userData: any, callback: Function): Promise<void> {
    this.openAddNoteDialog(userData, callback, true);
  }

  async sendMessageModal(x, callback: Function): Promise<void> {
    const sendMessageModal = this._dialogModal.open(SendMessageModalComponent, {
      width: "60%",
      disableClose: false,
      autoFocus: false,
      data: {
        title: "Send Message",
        record: x,
        refreshTable: callback,
      },
    });
    sendMessageModal.afterClosed().subscribe((result) => {
      if (result && result.action.httpStatusCode === 200) {
        if (callback) callback();
      }
    });
  }

  autoGenerateNotes(records, callback, note) {
    let taskNote = new TaskNotes(this._config);
    taskNote.CreatedBy = this._userService.getUserID().toString();
    taskNote.CreatedByUser = `${this._userService.getUserFullName()} (${this._userService.getUserName()})`;
    taskNote.SubjectText = null;
    taskNote.Note = note;
    taskNote.WorklistTaskIds = "";
    taskNote.CopyNotesTo = "";
    if (Array.isArray(records)) {
      //bulk actions, multiple records
      for (let record of records) {
        taskNote.WorklistTaskIds = record.worklistTaskId.toString();
        taskNote.OfficeID = record.officeId;
        this._notesService.SaveNotes(taskNote).subscribe((res) => {
          if (res) {
            callback();
          }
        });
      }
    } else {
      // single record
      taskNote.WorklistTaskIds = records.worklistTaskId.toString();
      taskNote.OfficeID = records.officeId;
      this._notesService.SaveNotes(taskNote).subscribe((res) => {
        if (res) callback();
      });
    }
  }

  async openAssignTaskModal(x, y, callback: Function): Promise<void> {
    const assignTaskModal = this._dialogModal.open(AssignTaskComponent, {
      width: "55%",
      disableClose: false,
      autoFocus: false,
      data: {
        title: "Assign Worklist Task",
        sub_title: "Select a user to assign the worklist task.",
        record: x,
        assginData: y,
        workListID: this.worklistDetail.worklistId,
        canAssignWorklistTask: this.worklistDetail.canAssignWorklistTask,
      },
    });
    assignTaskModal.afterClosed().subscribe(({ AssignedToUser, res }) => {
      if (res && res.httpStatusCode === 200) {
        this.worklistEvents.emit(Events.REFRESH_WORKLIST_COUNT);
        this._alert.success(
          "success",
          `Worklist task assigned to ${AssignedToUser} successfully`
        );
        this.autoGenerateNotes(
          x,
          callback,
          `Task assigned to ${AssignedToUser}.`
        );
        if (callback) {
          callback();
        }
      }
    });
  }

  async unassignTask(x, callback: Function): Promise<void> {
    let payload: UpdateTaskRequest;
    let newX;
    if (Array.isArray(x)) {
      newX = x.filter((obj) => obj.assignedToUser);
      if (newX.length == 0) {
        this._alert.info("info", "All tasks are already unassigned.");
        return;
      }
      payload = {
        WlTaskId: newX.map((obj) => obj.worklistTaskId).join(","),
        AssignedBy: this._userService.getUserID(),
        AssignedTo: 0,
        AssignedByUser: this._userService.getUserName(),
        AssignedToUser: null,
        UpdatedBy: this._userService.getUserID(),
        UpdatedByUser: this._userService.getUserName(),
      };
    }
    else {
      if (!x.assignedToUser) {
        this._alert.info("info", "Task is already unassigned.");
        return;
      }
      payload = {
        WlTaskId: x.worklistTaskId.toString(),
        AssignedBy: this._userService.getUserID(),
        AssignedTo: 0,
        AssignedByUser: this._userService.getUserName(),
        AssignedToUser: null,
        UpdatedBy: this._userService.getUserID(),
        UpdatedByUser: this._userService.getUserName(),
      };
    }
    this._common
      .updateTask(payload, "AssignedTo")
      .subscribe((res: assignTaskModel) => {
        if (res) {
          this._alert.success("success", "Task unassigned successfully.");
          if (Array.isArray(x)) {
            this.autoGenerateNotes(
              newX,
              callback,
              `Task is unassigned.`
            );
          }
          else {
            this.autoGenerateNotes(
              x,
              callback,
              `Task is unassigned.`
            );
          }
          if (callback) {
            callback();
          }
        }
      });
  }

  downloadFile(record) {
    let payload = {
      AppSecret: this.appConfig.appsecret,
      AppName: this.appConfig.appName,
      HHAWSURL: this.appConfig.hhawsenturl,
      FileGUID: "",
    };
    payload.FileGUID = record.lastNotes.fileGuid;
    this._fileService.downloadFile(payload).subscribe((res) => {
      if (res.ok) {
        const blob = new Blob([res.body], {
          type: res.headers.get("x-file-content-type"),
        });
        const nav = (window.navigator as any);
        if (nav.msSaveOrOpenBlob) {
          // IE 11
          nav.msSaveOrOpenBlob(blob, record.lastNotes.fileName);
        } else {
          // Google chome, Firefox, ....
          FileSaver.saveAs(blob, record.lastNotes.fileName);
        }
        this._alert.success("success", "File downloaded successfully");
      }
    });
  }

  async onMouseEnter(row, menuTrigger) {
    this._notesService
      .GetAllNotesByTaskID(row.worklistTaskId, this._userService.getUserPrimaryOfficeID(), this._config.appConfiguration.entapiurl + "api/")
      .subscribe((res: IGetAllNotesByTaskID) => {
        if (res) {
          let resp: IGetAllNotesByTaskIDResult[] = res["result"];
          this.lastTaskDateTime = resp[0].createdDate;
          this.lastNoteEntered = resp[0].note;
          this.taskNotesCount = resp.length;
        }
      });
    menuTrigger.openMenu();
  }

  printScreen() {
    window.print();
  }

  onFocusIn() {
    this.ref.nativeElement.click();
  }

  formatSrTime(scheduleTime: string, scheduleType: string): string {
    if (!scheduleTime) {
      return "";
    }

    if (scheduleType === VisitScheduleType.DAILY_FIXED) {
      return this._common.getSrTime(scheduleTime, (this.isUserInNewSkin && this.vendor12HoursFlag));
    }

    return this._common.getFormattedSrTime(scheduleTime);
  }

  restoreFocus(eleID) {
    document.getElementById(eleID).focus();
  }

  formatScheduledTime(scheduledTime: string): string {
    const hoursMinutesFormat = /^(\d{1,2})H \d{2}M$/;

    if (!scheduledTime) {
      return "";
    }

    if (hoursMinutesFormat.test(scheduledTime)) {
      return scheduledTime;
    }

    if (this.isUserInNewSkin && this.vendor12HoursFlag) {
      return this._common.getFormattedTime(scheduledTime);
    }

    return scheduledTime;
  }


  formatMasterWeekSchedule(masterWeekSchedule): string {
    if (this.isUserInNewSkin && this.vendor12HoursFlag) {
      const converetedMasterWeekSchedule = masterWeekSchedule.replace(/(\d{2})(\d{2}) - (\d{2})(\d{2})/g, (match, fromHours, fromMinutes, toHours, toMinutes) => {
        const fromTime = this.convertToAMPM(`${fromHours}:${fromMinutes}`);
        const toTime = this.convertToAMPM(`${toHours}:${toMinutes}`);
        return `${fromTime} - ${toTime}`;
      });

      return converetedMasterWeekSchedule;
    } else {
      return masterWeekSchedule;
    }
  }

  convertToAMPM(inputTime: string): string {
    const [hours, minutes] = inputTime.split(':');
    const parsedHours = parseInt(hours, 10);

    if (parsedHours >= 12) {
      return `${parsedHours === 12 ? parsedHours : (parsedHours - 12).toString().padStart(2, '0')}:${minutes} PM`;
    } else {
      return `${parsedHours === 0 ? 12 : parsedHours.toString().padStart(2, '0')}:${minutes} AM`;
    }
  }

  exportToCsvFile() {
    this.getExportParams = {};
    this.getExportParams = this.getParams;
    this._worklist.getAllSearchDataForExport(this.getUrl, this._generateExportRequestParams()).subscribe(
      (result: any) => {
        if (!result.data || !result.data.length) {
          this._alert.error("error", "No records found for export.");
        }
        else {
          this.mapExportColumn(result);
          this._alert.success("success", "File exported successfully.");
        }

      },
      (error) => { this._alert.error("error", "There was error while fetching export data(s)."); }
    );
  }

  private _generateExportRequestParams(): GetRequest {
    return {
      page: { pageNumber: 1, pageSize: -1, },
      sort: { direction: SortDirection.Ascending, item: "CreatedDate" },
      ...this.getExportParams,
    } as GetRequest;
  }

  private mapExportColumn(result: any): void {
    this.exportColumnNames = [];
    this.exportFileName = this.worklistDetail.worklistPath;

    switch (this.worklistDetail.worklistPath) {
      case Worklist.MEDICAL_COMPLIANCE:
        result.data = result.data.map(({ expirationItem, dueDate, createdDate, careGiverFullName, careGiverCode, lastNotes, assignedToUser, status }) => ({ expirationItem, dueDate, createdDate, careGiverFullName, careGiverCode, lastNotes, assignedToUser, status }));
        this.exportColumnNames = ['expirationItem', 'dueDate', 'createdDate', 'careGiverFullName', 'careGiverCode', 'lastNotes', 'assignedToUser', 'status'];
        this.exportFileName = 'ExpiringMedicalCompliance';
        break;
      case Worklist.EXPIRING_AUTHORIZATION:
        result.data = result.data.map(({ patientFullname, admissionId, authorizationNumber, dueDate, contractName, createdDate, lastNotes, assignedToUser, status }) => ({ patientFullname, admissionId, authorizationNumber, dueDate, contractName, createdDate, lastNotes, assignedToUser, status }));
        this.exportColumnNames = ['patientFullname', 'admissionId', 'authorizationNumber', 'dueDate', 'contractName', 'createdDate', 'lastNotes', 'assignedToUser', 'status'];
        break;
      case Worklist.UNSTAFFED_VISITS:
        result.data = result.data.map(({ patientFullname, admissionId, visitDate, scheduledTime, address1, city, state, zipCode, contractName, disciplineName, createdDate, lastNotes, assignedToUser, status }) => ({ patientFullname, admissionId, visitDate, scheduledTime: this.formatScheduledTime(scheduledTime), address1, city, state, zipCode, contractName, disciplineName, createdDate, lastNotes, assignedToUser, status }));
        this.exportColumnNames = ['patientFullname', 'admissionId', 'visitDate', 'scheduledTime', 'address1', 'city', 'state', 'zipCode', 'contractName', 'disciplineName', 'createdDate', 'lastNotes', 'assignedToUser', 'status'];
        break;
      case Worklist.MASTER_WEEK:
        result.data = result.data.map(({ patientFullname, admissionId, masterWeekSchedule, masterWeekEndDate, contractNames, caregiverNames, createdDate, lastNotes, assignedToUser, status }) => ({ patientFullname, admissionId, masterWeekSchedule: this.formatMasterWeekSchedule(masterWeekSchedule), masterWeekEndDate, contractNames, caregiverNames, createdDate, lastNotes, assignedToUser, status }));
        this.exportColumnNames = ['patientFullname', 'admissionId', 'masterWeekSchedule', 'masterWeekEndDate', 'contractNames', 'caregiverNames', 'createdDate', 'lastNotes', 'assignedToUser', 'status'];
        this.exportFileName = 'ExpiringMasterWeek';
        break;
      case Worklist.CERTIFICATION_PERIOD:
        result.data = result.data.map(({ patientFullname, admissionId, certificationPeriod, nurseName, physicianName, createdDate, lastNotes, assignedToUser, status }) => ({ patientFullname, admissionId, certificationPeriod, nurseName, physicianName, createdDate, lastNotes, assignedToUser, status }));
        this.exportColumnNames = ['patientFullname', 'admissionId', 'certificationPeriod', 'nurseName', 'physicianName', 'createdDate', 'lastNotes', 'assignedToUser', 'status'];
        break;
    }

    this.exportToCsv(result.data, this.exportFileName, this.exportColumnNames);
  }

  private exportToCsv(rows: object[], fileName: string, columns?: string[]): string {
    if (!rows || !rows.length) { return; }

    const keys = Object.keys(rows[0]).filter(k => {
      if (columns?.length) { return columns.includes(k); }
      else { return true; }
    });

    const csvContent =
      this.formatColumnName(keys.join(CSV_SEPARATOR)) +
      '\n' +
      rows.map(row => {
        return keys.map(k => {
          let cell = row[k] === null || row[k] === undefined ? '' : row[k];

          if ((k == 'createdDate' || k == 'dueDate' || k == 'visitDate' || k == 'masterWeekEndDate' || k == 'certificationPeriod') && cell !== '') {
            cell = this._datePipe.transform(row[k], 'MM/dd/yyyy');
          }

          if (k == 'lastNotes' && cell !== '') {
            let subject = '';
            if (![null, undefined, 0, '0', ''].includes(row[k].subject)) {
              subject = row[k].subject;
            }
            let notes = [subject, row[k].note];
            cell = notes.filter(Boolean).join(" ");
          }

          cell = cell instanceof Date ? cell.toLocaleString() : cell.toString().replace(/"/g, '""');
          cell = `"${cell}"`;
          return cell;
        }).join(CSV_SEPARATOR);
      }).join('\n');

    this.saveAsFile(csvContent, `${fileName}${CSV_EXTENSION}`, CSV_TYPE);
  }

  private saveAsFile(blobData: any, fileName: string, fileType: string): void {
    const data: Blob = new Blob([blobData], { type: fileType });
    const nav = (window.navigator as any);

    if (nav.msSaveOrOpenBlob) {
      nav.msSaveOrOpenBlob(data, fileName);
    } else {
      FileSaver.saveAs(data, fileName);
    }
  }

  private formatColumnName(columnName: string): string {
    columnName = columnName.replace('createdDate', '"Reported On"')
      .replace('lastNotes', '"Last Note Entered"')
      .replace('assignedToUser', '"Assignee"')
      .replace('status', '"Status"')
      .replace('patientFullname', '"Patient"')
      .replace('admissionId', '"Admission ID"');

    switch (this.worklistDetail.worklistPath) {
      case Worklist.MEDICAL_COMPLIANCE:
        columnName = columnName.replace('expirationItem', '"Expiring Medical"')
          .replace('dueDate', '"Expiration Date"')
          .replace('careGiverFullName', '"Caregiver"')
          .replace('careGiverCode', '"Caregiver Code"');
        break;
      case Worklist.EXPIRING_AUTHORIZATION:
        columnName = columnName.replace('authorizationNumber', '"Auth Number"')
          .replace('contractName', '"Contract"');
        break;
      case Worklist.UNSTAFFED_VISITS:
        columnName = columnName.replace('authorizationNumber', '"Auth Number"')
          .replace('visitDate', '"Visit Date"')
          .replace('scheduledTime', '"Schedule Time"')
          .replace('address1', '"Address 1"')
          .replace('city', '"City"')
          .replace('state', '"State"')
          .replace('zipCode', '"Zip Code"')
          .replace('contractName', '"Contract"')
          .replace('disciplineName', '"Discipline"');
        break;
      case Worklist.MASTER_WEEK:
        columnName = columnName.replace('masterWeekSchedule', '"Master Week"')
          .replace('masterWeekEndDate', '"End Date"')
          .replace('contractNames', '"Contract(s)"')
          .replace('caregiverNames', '"Caregiver(s)"');
        break;
      case Worklist.CERTIFICATION_PERIOD:
        columnName = columnName.replace('certificationPeriod', '"Certification Period"')
          .replace('nurseName', '"Nurse"')
          .replace('physicianName', '"Physician"');
        break;
    }
    return columnName;
  }

}

class Helper {
  static OfficeToTreeViewItem(
    officeList: Office[],
    isfromENTMLApplication: boolean,
    primaryOfficeID
  ): TreeviewItem[] {
    const newList = officeList;
    try {
      for (var i = 0; i < newList.length; i++) {
        const currOfc = newList[i];
        currOfc.children = [];
        currOfc.children = newList.filter(
          (ofc) => ofc.parentID === currOfc.officeID
        );
      }
      var sendThis = newList.filter((ofc) => ofc.parentID === -1)[0];
      return sendThis.children.map((ofc) =>
        this.convertOffice(ofc, isfromENTMLApplication, primaryOfficeID)
      );
    } catch (err) {
      return;
    }
  }

  private static convertOffice(
    office: Office,
    isfromENTMLApp: boolean,
    primaryOfficeID
  ): TreeviewItem {
    const treeItem =
      office.children !== null && office.children.length > 0
        ? new TreeviewItem({
          text: office.officeName,
          value: office.officeID,
          checked: primaryOfficeID.toString() === office.officeID.toString(),
          disabled: false,
          children:
            office.children !== null && office.children.length > 0
              ? office.children.map((ofc) =>
                this.convertOffice(ofc, isfromENTMLApp, primaryOfficeID)
              )
              : [],
        })
        : new TreeviewItem({
          text: office.officeName,
          value: office.officeID,
          checked: primaryOfficeID.toString() === office.officeID.toString(),
          disabled: false,
        });
    return treeItem;
  }

  static ComplianceExpItemToTreeViewItem(
    complianceExpItemList: ComplianceExpItem[]
  ): TreeviewItem[] {
    const newList = complianceExpItemList;
    try {
      for (var i = 0; i < newList.length; i++) {
        const currCmp = newList[i];
        currCmp.children = [];
        currCmp.children = newList.filter(
          (cmp) => cmp.parentID === currCmp.complianceExpItemID
        );
      }
      var sendThis = newList.filter((cmp) => cmp.parentID === -1)[0];
      return sendThis.children.map((cmp) =>
        this.convertComplianceItem(cmp)
      );
    } catch (err) {
      return;
    }
  }

  private static convertComplianceItem(
    complianceExpItem: ComplianceExpItem
  ): TreeviewItem {
    const treeItem =
      complianceExpItem.children !== null && complianceExpItem.children.length > 0
        ? new TreeviewItem({
          text: complianceExpItem.expirationItem,
          value: complianceExpItem.expirationItem,
          checked: true,
          disabled: false,
          children:
            complianceExpItem.children !== null && complianceExpItem.children.length > 0
              ? complianceExpItem.children.map((cmp) =>
                this.convertComplianceItem(cmp)
              )
              : [],
        })
        : new TreeviewItem({
          text: complianceExpItem.expirationItem,
          value: complianceExpItem.expirationItem,
          checked: true,
          disabled: false,
        });
    return treeItem;
  }

  static languagesToTreeViewItem(language: LanguageResponseBody[]): TreeviewItem[] {
    return language.map(obj => {
      return new TreeviewItem({
        text: obj.language,
        value: obj.languageID,
        checked: true,
        disabled: false
      });
    });
  }
}
