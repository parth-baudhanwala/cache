import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";

import {
  HhaxTablePagingDirective,
  HhaxTablePagingBaseDirective,
} from "./paging.directive";
import { HhaxTableTransportDirective } from "./transport.directive";
import { HhaxTablePaginationDirective } from "./inMemory.directive";
import { PaginationComponent } from "../pagination/pagination.component";
import { SpinnerModule } from "hhax-components";

import { BaseHttpService } from "../../../../services/base.http.service";

const MODULE_EXPORTS = [
  HhaxTableTransportDirective,
  HhaxTablePaginationDirective,
  HhaxTablePagingDirective,
];

@NgModule({
    declarations: [
        ...MODULE_EXPORTS,
        HhaxTablePagingBaseDirective,
        PaginationComponent,
    ],
    exports: MODULE_EXPORTS,
    imports: [CommonModule, HttpClientModule, SpinnerModule],
    providers: [BaseHttpService]
})
export class HhaxTableDataModule {}
