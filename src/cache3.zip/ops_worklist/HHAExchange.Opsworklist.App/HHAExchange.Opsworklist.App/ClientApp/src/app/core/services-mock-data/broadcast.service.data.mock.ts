export const sendBroadcastData = {
    "BroadCastModel": {
        aideID: 143172,
        aideCode: ['214516'],
        aideName: "string",
        notificationPreference: "string"
    },
    "responseBody": {
        "broadCastModel": [],
        "broadCastID": 143172
    },
    "httpStatusCode": 200,
    "httpStatusMessage": null,
    "authenticationToken": null
}

