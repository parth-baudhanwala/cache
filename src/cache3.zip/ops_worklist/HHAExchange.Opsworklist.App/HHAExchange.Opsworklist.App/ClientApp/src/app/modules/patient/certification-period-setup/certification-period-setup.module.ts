import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CertificationPeriodSetupComponent } from './certification-period-setup.component';
import { CoreModule } from '../../../core/core.module';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    CertificationPeriodSetupComponent
  ],
  imports: [
    CommonModule,
    CoreModule,
    AngularMultiSelectModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class CertificationPeriodSetupModule {
  static entry = CertificationPeriodSetupComponent;
}
