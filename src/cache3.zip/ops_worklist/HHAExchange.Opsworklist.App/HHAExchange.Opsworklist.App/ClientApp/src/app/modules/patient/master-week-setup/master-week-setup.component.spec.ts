import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterWeekSetupComponent } from './master-week-setup.component';

describe('MasterWeekSetupComponent', () => {
  let component: MasterWeekSetupComponent;
  let fixture: ComponentFixture<MasterWeekSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MasterWeekSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterWeekSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
