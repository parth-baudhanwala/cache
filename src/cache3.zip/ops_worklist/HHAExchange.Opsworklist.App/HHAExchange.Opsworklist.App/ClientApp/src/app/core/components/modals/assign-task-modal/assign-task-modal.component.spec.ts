import { HttpClientModule } from "@angular/common/http";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { FormBuilder } from "@angular/forms";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogModule,
  MatDialogRef,
} from "@angular/material/dialog";
import { HHAUserService } from "@app/core/authentication/user.service";
import {
  GetUsersByWorklistIDResponse,
  UpdateStatusResponse,
} from "@app/core/services-mock-data/common.service.mock";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { WorkslistService } from "@app/core/services/workslist.service";
import { of } from "rxjs";

import { AssignTaskComponent } from "./assign-task-modal.component";

let mockRecord = {
  worklistTaskId: 6,
  assignedBy: null,
  assignedTo: null,
  assignedByUser: null,
  assignedToUser: null,
  createdDate: "2021-02-22T22:29:16.558435",
  status: "Open",
  lastNotes: {
    note: "notes qa testing ow-21",
    createdBy: 622,
    createdByUser: "Srinivas Merugu",
    createdDate: "0001-01-01T00:00:00",
    createdDateUtc: "0001-01-01T00:00:00",
  },
  expirationItemType: "Test",
  expirationItem: "Test",
  dueDate: "2021-02-23T00:00:00",
  careGiverId: null,
  careGiverTeamId: null,
  careGiverFirstname: null,
  careGiverLastname: null,
  careGiverMiddlename: null,
  careGiverFullName: "",
};
describe("AssignTaskComponent", () => {
  const mockDialogRef = {
    close: jasmine.createSpy("close"),
  };
  let component: AssignTaskComponent;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AssignTaskComponent],
      imports: [MatDialogModule, HttpClientModule],
      providers: [
        {
          provide: CommonService,
          useValue: {
            GetUsersByWorklistID: () => of(GetUsersByWorklistIDResponse),
            updateTask: () => of(UpdateStatusResponse),
          },
        },
        {
          provide: MatDialogRef,
          useValue: mockDialogRef,
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserID: () => of(37485),
            getUserName: () => of("test"),
          },
        },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userOffices: [{ officeID: "123" }],
            },
          },
        },
        {
          provide: WorkslistService,
          useValue: {
            newsubject: () => of("test"),
          },
        },
        FormBuilder,
        { provide: "HOST", useValue: "test" },
        MatDialog,
        {
          provide: MAT_DIALOG_DATA,
          useValue: {
            data: {
              record: { worklistTaskId: "1234" },
              assignedTo: { userID: 123, name: "test" },
            },
          },
        },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    let fixture: ComponentFixture<AssignTaskComponent>;
    fixture = TestBed.createComponent(AssignTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeDefined();
  });
  it("should check assign list data", () => {
    expect(component.assigneeList).toEqual(GetUsersByWorklistIDResponse);
  });
  it("should call assignTask", async () => {
    component.data = {
      title: "Assign Worklist Task",
      sub_title: "Select a user to assign the worklist task.",
      record: mockRecord,
      assignedTo: { userID: 1, name: "John" },
      assginData: [],
    };
    await component.assignTask();
    component.data.record = [mockRecord, mockRecord];
    await component.assignTask();
    component.closeDialog("Closed");
    expect(component._commonService.updateTask).toBeDefined();
  });
});
