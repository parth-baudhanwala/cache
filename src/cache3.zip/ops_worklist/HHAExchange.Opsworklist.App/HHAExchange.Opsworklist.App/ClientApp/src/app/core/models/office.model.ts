import { ConfigurationService } from '@app/core/services/configuration.service';

import { Defaultparam } from './defaultparam.model';

export class Office {
  static generateHierarchy(officeList: Office[]) {
    try {
      const newList = officeList;
      for (var i = 0; i < newList.length; i++) {
        const currOfc = newList[i];
        currOfc.children = [];
        currOfc.children = newList.filter(
          (ofc) => ofc.parentID === currOfc.officeID
        );
      }
      return newList.filter((ofc) => ofc.parentID === -1)[0].children;
    } catch (err) {
      return [];
    }
  }
  selected: boolean;
  officeName: string;
  office: string;
  officeID: number;
  parentID: number;
  isLeaf: boolean;
  level: number;
  hirarchyLevel: number;
  type: string;
  parent: string;
  sortOrder: number;
  isEnable: boolean;
  children: Office[];
  patientOfficeChecked: boolean;
}
export class OfficeParams extends Defaultparam {
  SelectionType: string;
  PermissionName: string;
  constructor(config: ConfigurationService) {
    super(config);
    this.SelectionType = "filter";
    this.PermissionName = "Smart Map Beta";
  }
}
