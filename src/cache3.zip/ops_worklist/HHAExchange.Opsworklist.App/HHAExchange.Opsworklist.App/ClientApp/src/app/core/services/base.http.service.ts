import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { IHhaxHttpService } from "hhax-components";
import { Observable } from "rxjs/internal/Observable";
import { ConfigurationService } from "./configuration.service";

@Injectable({
  providedIn: "root",
})
export class BaseHttpService implements IHhaxHttpService {
  public apiUrl: string;
  public apiPrefix: string = "";
  constructor(
    private _httpClient: HttpClient,
    public _config: ConfigurationService
  ) {
    this.apiUrl = this._config.apiUrl;
  }

  get<T>(url: string, params?: any): Observable<T> {
    return this._httpClient.get<T>(`${this.apiUrl}${this.apiPrefix}${url}`, {
      params: this.serialise(params),
    });
  }

  getArrayBuffer(
    url: string,
    params?: any
  ): Observable<HttpResponse<ArrayBuffer>> {
    return this._httpClient.get(`${this.apiUrl}${this.apiPrefix}${url}`, {
      params: this.serialise(params),
      responseType: "arraybuffer",
      observe: "response",
    });
  }

  post<T>(url: string, params?: Object): Observable<T> {
    return this._httpClient.post<T>(
      `${this.apiUrl}${this.apiPrefix}${url}`,
      params
    );
  }

  postRequestWithUrl<T>(url: string, params?: Object): Observable<T> {
    return this._httpClient.post<T>(url, params);
  }

  put<T>(url: string, params?: Object): Observable<T> {
    const headers = new HttpHeaders().set(
      "Content-Type",
      "application/json; charset=utf-8"
    );
    return this._httpClient.put<T>(
      `${this.apiUrl}${this.apiPrefix}${url}`,
      params,
      { headers: headers }
    );
  }

  delete<T>(url: string, params?: Object): Observable<T> {
    return this._httpClient.delete<T>(`${this.apiUrl}${this.apiPrefix}${url}`, {
      params: this.serialise(params),
    });
  }

  private serialise(model: object): HttpParams {
    let params = new HttpParams();
    const serialise = (obj: object, prefix?: string) => {
      for (const propName in obj) {
        if (obj.hasOwnProperty(propName)) {
          const key = prefix ? `${prefix}.${propName}` : propName;
          const value = obj[propName];

          if (value !== null && typeof value === "object") {
            if (Array.isArray(value)) {
              params = params.set(key, value.join(","));
            } else {
              serialise(value, key);
            }
          } else {
            params = params.set(key, value);
          }
        }
      }
    };

    serialise(model);

    return params;
  }

  /**
   * Converts the properties and values of an object to HttpParams, removing null and undefined values in
   * the process
   * @param model The model whose properties will be converted to a HttpParam instance
   */
  protected GenerateHttpParamsFromModel(model: object): HttpParams {
    return Object.entries(model).reduce((queryParams, [key, value]) => {
      if (value) {
        return queryParams.set(key, value);
      }
      return queryParams;
    }, new HttpParams());
  }
}
