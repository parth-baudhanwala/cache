import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { HHAUserService } from "@app/core/authentication/user.service";
import { BaseComponent } from "@app/core/components/base-component/base.component";
import { closingConditionParams, patientAutocomplete, TypeAheadCriteria, Worklist, } from "@app/core/models/common.model";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { FileService } from "@app/core/services/file.service";
import { NotesService } from "@app/core/services/notes.service";
import { SearchFieldsService } from "@app/core/services/search-fields.service";
import { WorkslistService } from "@app/core/services/workslist.service";
import { isBlank } from "@app/lib/utils";
import { ToastrAlertService } from "hhax-components";
import { SessionStorageService } from "@app/core/services/session-storage.service";
import { configHelper } from "@app/core/config/static-options";
import { DatePipe } from '@angular/common';

@Component({
  selector: "app-expiring-authorizations",
  templateUrl: "./expiring-authorizations.component.html",
})
export class ExpiringAuthorizationsComponent
  extends BaseComponent
  implements OnInit {
  workListGroup: FormGroup;
  getAssignData: string;
  _gridPageSize: number = configHelper.pageSize10;
  isAuthenticationDone: boolean = false;
  actionButtons = [
    {
      label: "Refresh Status",
      handler: (x) =>
        this.refreshRecords(x, Worklist.EXPIRING_AUTHORIZATION, () =>
          this.searchWorkLists()
        ),
    },
    {
      label: "Update Status to Open",
      handler: (x) =>
        this.updateStatus(x, "Open", () => this.searchWorkLists()),
    },
    {
      label: "Update Status to In-Progress",
      handler: (x) =>
        this.updateStatus(x, "In-Progress", () => this.searchWorkLists()),
    },
    {
      label: "Update Status to Closed",
      handler: (x) => this.updateClosedStatus(x, () => this.searchWorkLists()),
    },
    {
      label: "View/Add Notes",
      handler: (x) => this.openAddNoteDialog(x, () => this.searchWorkLists()),
      isModal: true,
    },
    {
      label: "Assign Task",
      handler: (x) =>
        this.openAssignTaskModal(x, this.getAssignData, () =>
          this.searchWorkLists()
        ),
      isModal: true,
    },
    {
      label: "Unassign Task",
      handler: (x) => this.unassignTask(x, () => this.searchWorkLists()),
    },
  ];
  getAssigneeData: string;
  patientParams: patientAutocomplete;
  taskNotesCount: number;
  closingConditionParams: closingConditionParams;

  constructor(
    public _searchservice: SearchFieldsService,
    public _fb: FormBuilder,
    public _dialogModal: MatDialog,
    public _config: ConfigurationService,
    public _userService: HHAUserService,
    public _alert: ToastrAlertService,
    public _worklist: WorkslistService,
    public _common: CommonService,
    public _notesService: NotesService,
    public _fileService: FileService,
    public _storage: SessionStorageService,
    public _datePipe: DatePipe
  ) {
    super(
      _config,
      _searchservice,
      _alert,
      _common,
      _dialogModal,
      _worklist,
      _userService,
      _fileService,
      _notesService,
      _storage,
      _datePipe
    );
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.checkAuthentication(this.AuthParams).subscribe((isValidUser: boolean) => {
      if (isValidUser) {
        if (this.worklistDetail.canManuallyCloseWorklistTask === "No") {
          this.actionButtons.forEach((button, index) => {
            if (button.label === "Update Status to Closed") {
              this.actionButtons[index].handler = async () => { };
              this.actionButtons[index]["isDisable"] = "true";
            }
          });
        }
        this.fetchSearchOptionsData();
        this.searchWorkLists(true);
        (this.workListGroup.get("patient") as FormControl).valueChanges.subscribe(
          (value: string) => {
            this.patientParams = {
              worklistPath: this.worklistDetail.worklistPath,
              patient: value,
              providerId: this._userService.getVendorID(),
              officeId: this.workListGroup.get("officeID").value,
              criteria: TypeAheadCriteria.StartsWith,
              count: 10,
            };
          }
        );
        this.isAuthenticationDone = true;
      }
    }
    );
  }

  fetchSearchOptionsData() {
    this.assigneeOptions = [];
    this.workListGroup = new FormGroup({
      officeID: new FormControl([], Validators.required),
      disciplineID: new FormControl([-1]),
      coordinatorID: new FormControl([-1]),
      contractID: new FormControl([-1]),
      assignee: new FormControl([]),
      patientStatusID: new FormControl([3]),
      status: new FormControl(["Open"]),
      expirationDuration: new FormControl("30"),
      patient: new FormControl(""),
    });

    let payload = {
      WorklistID: this.worklistDetail.worklistId,
      OfficeIDs: this.appConfig.userOffices
        .map((obj) => obj.officeID)
        .join(","),
    };
    this.getAssignees(payload);
  }

  searchWorkLists(onInit = false) {
    this.getParams = this.getSearchParams(onInit);
    this.gridPageSize = this._gridPageSize;
  }

  getSearchParams(onInit = false) {
    const formSubmittedData = this.workListGroup.value;
    const appConfig = this._config.appConfiguration;
    const params: any = {};
    if (onInit) {
      let userOfficeId: number[] | number = [];
      if (appConfig && appConfig.userOffices) {
        userOfficeId =
          appConfig.userOffices.length > 1
            ? appConfig.userOffices
              .filter((obj) => obj.isPrimary)
              .map((obj) => obj.officeID)
            : appConfig.userOffices[0].officeID;
      }
      params.status = "Open";
      params.officeID = userOfficeId;
      params.assignee = appConfig.userId;
      params.expirationDuration = "30";
    } else {
      if (
        !isBlank(formSubmittedData.officeID) &&
        formSubmittedData.officeID[0] !== -1
      )
        params.officeID = formSubmittedData.officeID;
      if (
        !isBlank(formSubmittedData.coordinatorID) &&
        formSubmittedData.coordinatorID[0] !== -1
      )
        params.coordinatorID = formSubmittedData.coordinatorID;
      if (
        !isBlank(formSubmittedData.contractID) &&
        formSubmittedData.contractID[0] !== -1
      )
        params.contractID = formSubmittedData.contractID;
      if (
        !isBlank(formSubmittedData.assignee) &&
        formSubmittedData.assignee[0] !== -1
      )
        params.assignee = formSubmittedData.assignee;

      if (this.isUserInNewSkin) {
        params.disciplineID = this.setDisciplineIds(formSubmittedData.disciplineID);
      }
      else {
        if (!isBlank(formSubmittedData.disciplineID) && formSubmittedData.disciplineID[0] !== -1) {
          params.disciplineID = formSubmittedData.disciplineID;
        }
      }

      if (
        !isBlank(formSubmittedData.status) &&
        formSubmittedData.status[0] !== -1
      )
        params.status = formSubmittedData.status;

      if (!isBlank(formSubmittedData.patientStatusID) &&
        formSubmittedData.patientStatusID[0] !== -1
      )
        params.patientStatusID = formSubmittedData.patientStatusID;

      if (!isBlank(formSubmittedData.patient))
        params.patient = formSubmittedData.patient;

      if (!isBlank(formSubmittedData.expirationDuration))
        params.expirationDuration = formSubmittedData.expirationDuration;
    }
    params.userID = appConfig.userId;
    params.providerID = appConfig.agencyID;
    return params;
  }

  onSubmit() {
    this.searchWorkLists();
  }

  onReset(): void {
    this.getOffices(this.params);
    this.workListGroup.patchValue({
      coordinatorID: [-1, ...this.coordinatorOptions.map((obj) => obj.value)],
      contractID: [-1, ...this.contractOptions.map((obj) => obj.value)],
      assignee: [this.appConfig.userId],
      status: ["Open"],
      disciplineID: [-1, ...this.disciplineOptions.map((obj) => obj.value)],
      expirationDuration: "30",
      patient: "",
      patientStatusID: [3],
    });
    if (document.getElementsByClassName("mat-autocomplete-trigger")[0]) {
      const inputElement: HTMLInputElement = document.getElementsByClassName(
        "mat-autocomplete-trigger"
      )[0] as HTMLInputElement;
      inputElement.value = "";
    }
    this._gridPageSize = configHelper.pageSize10;
    this.searchWorkLists();
  }

  async openPopUp(x: any): Promise<void> {
    let entMailUrl = this._config.appConfiguration.entMainURL;
    entMailUrl += entMailUrl.endsWith("/") ? "" : "/";
    const url = `${entMailUrl}Patient/InternalPatientInfo.aspx?PatientId=${x.data.patientId}&FromSearch=1`;
    this.openWindowPopUp(url, x, Worklist.EXPIRING_AUTHORIZATION, () =>
      this.searchWorkLists()
    );
  }

  openNote(record) {
    this.openAddNoteDialog(record, () => this.searchWorkLists());
  }

  onAssigneeClick(record, assignee) {
    this.openAssignTaskModal(record, assignee, () => this.searchWorkLists());
  }

  pageSizeSelectedChange() {
    this.searchWorkLists();
  }
}
