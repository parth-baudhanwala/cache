import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { BaseHttpService } from "./base.http.service";
import { ConfigurationService } from "./configuration.service";
import { Worklist } from "../models/common.model";
import { Observable, Subject } from "rxjs";
import { IPutResponse, closingConditionParams } from "../models/common.model";

@Injectable({
  providedIn: "root",
})
export class WorkslistService extends BaseHttpService {
  public newsub = new Subject();

  constructor(httpClient: HttpClient, config: ConfigurationService) {
    super(httpClient, config);
  }

  closingCondition(worklist: Worklist, searchParams: closingConditionParams): Observable<IPutResponse> {
    return this.post<IPutResponse>(`ClosingRules/CloseTask/${worklist}`, searchParams);
  }

  getAllSearchDataForExport(worklistApiUrl: string, params: any): Observable<any> {
    return this.get<any>(worklistApiUrl, params);
  }
}
