import {
  Component,
  Input,
  forwardRef,
  ViewChild,
  AfterViewChecked,
  AfterViewInit,
  OnInit,
  Output,
  EventEmitter,
  ChangeDetectionStrategy,
} from "@angular/core";
import { NG_VALUE_ACCESSOR, FormGroupDirective } from "@angular/forms";

import { MatSelect } from "@angular/material/select";
import { MatOption } from "@angular/material/core";
import { HHAFormWithValidationComponent } from "hhax-components";

@Component({
  selector: "hha-multi-select",
  templateUrl: "./multi-select.component.html",
  styleUrls: ["./multi-select.component.scss"],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => MultiSelectComponent),
      multi: true,
    },
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultiSelectComponent
  extends HHAFormWithValidationComponent
  implements OnInit, AfterViewChecked, AfterViewInit
{
  @Input() label: string;
  @Input() options: MultiSelectOption[];
  @Input() showAllOption = false;
  @Input() allOptionValue = -1;
  @Input() selectAllOnLoad: boolean;
  @Input() placeholder: string = "";
  @Input() showLabel: boolean = true;
  @Output() optionSelect: EventEmitter<MatOption> =
    new EventEmitter<MatOption>();

  isAllSelected = false;

  @ViewChild("selectControl", { static: true }) selectControl: MatSelect;
  @ViewChild("allOption", { static: false }) allOption: MatOption;

  constructor(parentF: FormGroupDirective) {
    super(parentF);
  }

  ngOnInit(): void {
    super.ngOnInit();
    if (this.placeholder == "") {
      this.placeholder = "Select " + this.label;
    }
  }

  ngAfterViewInit(): void {
    this.selectControl.optionSelectionChanges.subscribe({
      next: (option) => {
        if (option.source.value === -1) {
          this.enableDisableAll(option);
        } else {
          this.enableDisableOption(option);
        }
      },
    });
  }

  ngAfterViewChecked(): void {
    if (this.selectAllOnLoad && this.options?.length > 0) {
      this.selectAllOnLoad = false;
      this.enableDisableAll();
    }
  }

  enableDisableOption(event?: any): boolean {
    if (!event || event?.isUserInput) {
      if (this.allOption.selected) {
        this.allOption.deselect();
        this.optionSelect.emit(event);
        return false;
      }
      if (
        !this.selectControl.options.some(
          (o) => o.value !== this.allOptionValue && !o.selected
        )
      ) {
        this.allOption.select();
      }
      this.optionSelect.emit(event);
    }
  }

  enableDisableAll(event?: any): void {
    if (!event || event?.isUserInput) {
      this.isAllSelected = !this.isAllSelected;
      if (this.isAllSelected) {
        this.selectControl.options.forEach((item: MatOption) => item.select());
      } else {
        this.selectControl.options.forEach((item: MatOption) =>
          item.deselect()
        );
      }
      this.optionSelect.emit(event);
    }
  }

  getFirstOptionValue(): string {
    const firstSelectedOption = this.selectControl.options?.find(
      (o: MatOption) => o.selected
    );
    return firstSelectedOption !== undefined
      ? firstSelectedOption.viewValue
      : "";
  }
}

export class MultiSelectOption {
  text: string;
  value: string | number;
}
