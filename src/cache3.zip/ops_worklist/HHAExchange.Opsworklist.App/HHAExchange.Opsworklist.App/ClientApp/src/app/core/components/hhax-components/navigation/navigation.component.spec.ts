import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { LinkIconRightComponent } from './link-icon-right/link-icon-right.component';
import { NavLeftContainerDirective, NavRightContainerDirective } from './navigation.directive';
import { LinkIconComponent } from './link-icon/link-icon.component';
import { Component, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HhaxHeaderModule } from './header.module';
import { AlignLinkRightDirective, HeaderNavLinkWrapperComponent, LinkComponent } from './link/link.component';
import { ActionLink } from './link/model';

import { NavigationComponent } from './navigation.component';
import { Key } from 'ts-key-enum';

@Component({
  template: `
    <hhax-navigation-header>
      <li role="none" hhax-header-link [title]="'Home'" link="home"></li>
      <li role="none" hhax-header-link [title]="'Member'" [childLinks]="commChildLinks"></li>
      <li role="none" hhax-header-link [title]="'Reporting'" link="reporting"></li>
      <li role="none" hhax-header-link [title]="'Communication'" [childLinks]="commChildLinks"></li>
    </hhax-navigation-header>
  `
})
class NavigationTestComponent {
  @ViewChild(NavigationComponent, { static: true }) navigation: NavigationComponent;

  commChildLinks: ActionLink[] = [
    {
      id: 1,
      route: './communication/messages',
      label: 'Messages'
    },
    {
      id: 2,
      route: './communication/messages',
      label: 'Messages'
    }
  ];

  readonly userLinks: ActionLink[] = [
    {
      id: 1,
      route: '',
      label: 'Settings'
    },
    {
      id: 2,
      handler: () => { },
      label: 'Logout'
    }
  ];

  public notifications: ActionLink[] = [
    {
      id: 1,
      route: '',
      label: 'Notification'
    },
    {
      id: 2,
      route: '',
      label: 'Notification'
    }
  ];
}

describe('NavigationComponent', () => {
  let component: NavigationComponent;
  let fixture: ComponentFixture<NavigationTestComponent>;
  let fixtureHtml: HTMLElement;

  const getTopLevelMenuLinks = () => {
    const allLinks = Array.from(fixtureHtml.querySelectorAll<HTMLAnchorElement>(`div.top-bar-left > ul > li > a`));
    const linksWithoutLogo = allLinks.filter(link => !link.querySelector('img'));
    return linksWithoutLogo;
  }

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        HhaxHeaderModule,
        FontAwesomeModule,
        RouterTestingModule.withRoutes([]),
      ],
      declarations: [
        AlignLinkRightDirective,
        HeaderNavLinkWrapperComponent,
        LinkComponent,
        LinkIconComponent,
        NavigationComponent,
        NavLeftContainerDirective,
        NavRightContainerDirective,
        LinkIconRightComponent,
        NavigationTestComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavigationTestComponent);
    fixtureHtml = fixture.nativeElement;
    component = fixture.componentInstance.navigation;
    fixture.detectChanges();
    const currentActiveItem = getTopLevelMenuLinks()[0];
    currentActiveItem.focus();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility', () => {

    const pressLeftArrowKey = () => {
      pressKey(Key.ArrowLeft);
    }

    const pressRightArrowKey = () => {
      pressKey(Key.ArrowRight);
    }

    const pressKey = (key: string) => {
      const keyEvent = new KeyboardEvent('keydown', { key, cancelable: true });
      window.dispatchEvent(keyEvent);
    }

    describe('Left Arrow Key', () => {
      it('should set focus to previous menu item', () => {
        // Arrange
        const currentActiveItem = getTopLevelMenuLinks()[2];
        currentActiveItem.focus();

        // Act
        pressLeftArrowKey();

        // Assert
        const expectedResult = getTopLevelMenuLinks()[1];
        const actualResult = document.activeElement;
        expect(actualResult).toEqual(expectedResult);
      });

      it('should set focus to last menu item when at start of list', () => {
        // Arrange
        const allMenuItems = getTopLevelMenuLinks();
        const lastItemIndex = allMenuItems.length - 1;

        // Act
        pressLeftArrowKey();

        // Assert
        const expectedResult = getTopLevelMenuLinks()[lastItemIndex];
        const actualResult = document.activeElement;
        expect(actualResult).toEqual(expectedResult);
      });

      it('should not select logo as part of menu', () => {
        // Arrange
        const allMenuItems = getTopLevelMenuLinks();
        let isLogo = false;

        // Act
        for (let i = 0; i < allMenuItems.length; i++) {
          pressLeftArrowKey();
          if (getTopLevelMenuLinks()[i].querySelector('img')) {
            isLogo = true;
          }
        }

        // Assert
        expect(isLogo).toEqual(false);
      });
    });

    describe('Right Arrow Key', () => {
      it('should set focus to the next menu', () => {
        // Arrange

        // Act
        pressRightArrowKey();

        // Assert
        const expectedResult = getTopLevelMenuLinks()[1];
        const actualResult = document.activeElement;
        expect(actualResult).toEqual(expectedResult);
      });

      it('should keep focus on last item when at end of list', () => {
        // Arrange
        const allMenuItems = getTopLevelMenuLinks();
        const lastItemIndex = allMenuItems.length - 1;
        const currentActiveItem = allMenuItems[lastItemIndex];
        currentActiveItem.focus();

        // Act
        pressRightArrowKey();

        // Assert
        const expectedResult = currentActiveItem;
        const actualResult = document.activeElement;
        expect(actualResult).toEqual(expectedResult);
      });
    });

    it('should only react to left / right arrow key inputs', () => {
      // Arrange
      const handleMenuNavSpy = spyOn(component, 'handleMenuNavigation');
      const keydownInputs = [
        // Acceptable
        Key.ArrowLeft,
        Key.ArrowRight,

        // Unacceptable
        Key.F1,
        Key.Help,
        Key.PageDown,
        'a',
        'b',
        'C',
      ];

      keydownInputs.forEach(key => {
        // Act
        pressKey(key);
      });

      // Assert
      expect(handleMenuNavSpy).toHaveBeenCalledTimes(2);
    });

    it('Should call prevent default', () => {
      const keyEvent = new KeyboardEvent('keydown', { key: Key.ArrowLeft });
      const spy = spyOn(keyEvent, 'preventDefault');
      component.handleMenuNavigation(keyEvent);
      fixture.detectChanges();
      expect(spy).toHaveBeenCalled()
    });

    it('Should not call prevent default', () => {
      const keyEvent = new KeyboardEvent('keydown', { key: 'A' });
      const spy = spyOn(keyEvent, 'preventDefault');
      component.handleMenuNavigation(keyEvent);
      fixture.detectChanges();
      expect(spy).toHaveBeenCalled()
    });
  });
});
