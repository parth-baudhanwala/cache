import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppConfiguration } from '@app/core/models/common.model';
import { Observable } from 'rxjs';

import { FileUploadValidate } from '../models/notes.model';
import { BaseHttpService } from './base.http.service';
import { ConfigurationService } from './configuration.service';
import { HHAUserService } from '../authentication/user.service';
@Injectable({
  providedIn: "root",
})
export class FileService extends BaseHttpService {
  appConfig: AppConfiguration;
  constructor(
    httpClient: HttpClient,
    config: ConfigurationService,
    public _userService: HHAUserService,
    ) {
    super(
      httpClient,
      config);
    this.apiPrefix = "File/";
  }

  isValidFile(eventTarget, fileSizeLimit : number): boolean {
    let fileName = eventTarget.files[0].name;
    const file: File = eventTarget.files[0];
    const sizeInMB = parseFloat((file.size / (1024 * 1024)).toFixed(2));
    if (fileName.length > 50 || sizeInMB > fileSizeLimit) {
      eventTarget.value = null;
      return false;
    } else {
      return true;
    }
  }

  isValidFileExtension(attachedFile): boolean {
    let attachedFileName = attachedFile.files[0].name;
    let attachedFileExtension = attachedFileName.split('.').pop().toLocaleLowerCase();
    const allowedFileTypes: string[] = this._userService.getAlloweFileTypes().split(',');

    if (allowedFileTypes.includes(attachedFileExtension)) {
      return true;
    } else {
      return false;
    }
  }

  FileUpload(fileUploadData: FormData): Observable<FileUploadValidate[]> {
    return this.post<FileUploadValidate[]>("UploadDocument", fileUploadData);
  }

  downloadFile(payload: any): Observable<HttpResponse<ArrayBuffer>> {
    return this.getArrayBuffer("Download", payload);
  }
}
