import {
  Component,
  Directive,
  ElementRef,
  HostBinding,
  HostListener,
  Input,
  OnChanges,
  ChangeDetectorRef,
  ViewChild,
  ViewChildren,
  QueryList,
} from '@angular/core';
import { faCaretDown } from '@fortawesome/pro-solid-svg-icons';

import { ActionLink } from './model';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { Key } from 'ts-key-enum';
import { Params } from '@angular/router';

@Component({
  selector: '[hhax-header-link]',
  templateUrl: './link.component.html',
  styleUrls: ['./link.component.scss']
})
export class LinkComponent implements OnChanges {

  @Input()
  public childLinks: ActionLink[];
  @Input()
  public link: string;
  @Input()
  public queryParams: Params;
  @Input()
  public title: string;
  @Input()
  public ariaLabel: string;
  @Input()
  public target: string = "_self";
  @Input()
  public href: string;
  @Input()
  public icon: string;
  @Input('alignRight')
  get alignRight() { return this._isAlignedRight; }
  set alignRight(value) { this._isAlignedRight = coerceBooleanProperty(value); }
  private _isAlignedRight: boolean;
  @Input()
  get counter(): number { return this._counter; }
  set counter(counter: number) {
    this._counter = counter;
  }

  private _counter: number;
  isSubListOpen: boolean;
  private _selectedChildLink: number;

  @ViewChildren('childLink', { read: ElementRef }) private _childrenLinks: QueryList<ElementRef>;
  @ViewChild('parentLink') private _parentLink: ElementRef;
  @ViewChild('menuLink', { read: ElementRef }) public menuLink: ElementRef;

  @HostBinding('class.active') isActive: boolean;
  @HostBinding('class.is-dropdown-submenu-parent') isSubmenuParent: boolean;
  @HostBinding('class.opens-left') opensLeft: boolean;
  @HostBinding('class.opens-right') opensRight: boolean;

  readonly faCaretDown = faCaretDown;

  // Keyboard navigation for accessibility.
  @HostListener('keydown', ['$event']) keydown(event: KeyboardEvent) {
    if (!this.childLinks) {
      return
    }
    if ((event.key === Key.Enter || event.key === Key.ArrowDown || event.key === ' ') && !this.isSubListOpen) {
      this.isSubListOpen = true
      this._selectedChildLink = 0
    } else if ((event.key === Key.Escape || event.key == Key.ArrowLeft || event.key == Key.ArrowRight) && this.isSubListOpen) {
      this.isSubListOpen = false
      this._parentLink.nativeElement.focus()
      event.stopPropagation();
    } else if (event.key === Key.Enter && this.isSubListOpen) {
      // To handle links that are handled by a handler and not a link
      if (this.childLinks[this._selectedChildLink].handler != undefined) {
        this.childLinks[this._selectedChildLink].handler(event);
      }
    }
    // Keyboard trap
    else if ((event.key === Key.Tab || event.key === Key.ArrowUp || event.key === Key.ArrowDown) && this.isSubListOpen) {
      if (event.shiftKey || event.key == Key.ArrowUp) { // Shift + Tab || Up arrow = Previouse tab
        if (this._selectedChildLink == 0) {
          this._selectedChildLink = this._childrenLinks.length - 1
        } else {
          this._selectedChildLink--
        }
      } else { // Tab || Down arrow = Next tab
        if (this._selectedChildLink == this._childrenLinks.length - 1) {
          this._selectedChildLink = 0
        } else {
          this._selectedChildLink++
        }
      }
      this._childrenLinks.toArray()[this._selectedChildLink].nativeElement.focus()
      event.preventDefault()
    }
  }

  @HostListener('keyup', ['$event']) keyup(event) {
    if (!this.childLinks) {
      return
    }
    // Element doesn't exist on keydown so focusing on keyup
    if ((event.key === Key.Enter || event.key === Key.ArrowDown || event.key === ' ') && this.isSubListOpen) {
      this._childrenLinks.toArray()[this._selectedChildLink].nativeElement.focus()
    }
  }

  @HostListener('click') click() {
    if (this.childLinks) {
      this.isSubListOpen = !this.isSubListOpen;
    }
  }

  @HostListener('document:click', ['$event.target'])
  public onClick(targetElement: HTMLElement): void {
    if (!targetElement || !this.isSubListOpen) {
      return;
    }

    const clickedInside = this.elementRef.nativeElement.contains(targetElement);
    if (!clickedInside) {
      this.isSubListOpen = false;
    }
  }

  set _childLinks(data: Array<ActionLink>) {
    this.childLinks = data;
  }

  constructor(public elementRef: ElementRef, public changeDetectorRef: ChangeDetectorRef) { }

  ngOnChanges(): void {
    this.isSubmenuParent = !!this.childLinks && !!this.childLinks.length;
  }
}

// This may not be necessary now
@Component({
  selector: 'hhax-nav-link-wrapper',
  template: `
    <li class="menu-item">
      <ng-content></ng-content>
    </li>
  `
})
export class HeaderNavLinkWrapperComponent { }

@Directive({ selector: '[hhaxAlignRight]' })
export class AlignLinkRightDirective {
  constructor(public linkComponentRef: LinkComponent) { }
}
