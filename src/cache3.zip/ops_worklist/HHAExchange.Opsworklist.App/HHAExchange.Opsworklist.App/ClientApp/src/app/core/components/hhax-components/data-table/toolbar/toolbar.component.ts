import { Component, TemplateRef, ViewChild } from "@angular/core";

@Component({
  selector: "hhax-table-toolbar",
  templateUrl: "./toolbar.component.html",
})
export class ToolbarComponent {
  @ViewChild(TemplateRef, { static: true }) _templateRef: TemplateRef<any>;
}
