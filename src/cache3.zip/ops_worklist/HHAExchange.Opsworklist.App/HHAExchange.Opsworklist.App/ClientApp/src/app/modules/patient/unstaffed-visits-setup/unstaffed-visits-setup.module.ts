import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UnstaffedVisitsSetupComponent } from './unstaffed-visits-setup.component';
import { CoreModule } from '../../../core/core.module';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    UnstaffedVisitsSetupComponent
  ],
  imports: [
    CommonModule,
    CoreModule,
    AngularMultiSelectModule,
    ReactiveFormsModule,
    FormsModule,
  ]
})

export class UnstaffedVisitsSetupModule {
  static entry = UnstaffedVisitsSetupComponent;
}
