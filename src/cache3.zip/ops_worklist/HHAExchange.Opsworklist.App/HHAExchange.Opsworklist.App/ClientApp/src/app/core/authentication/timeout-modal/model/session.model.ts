export interface SessionConfig {
    /**
     * The number of seconds before the service will attempt a silent token refresh.
     */
    tokenRefreshInterval?: number;

    /**
     * The number of seconds the service will wait without input before the user is considered 'idle'.
     */
    idleDuration?: number;

    /**
     * The number of seconds the service will wait before automatically logging the user out.
     */
    sessionTimeout?: number;

    /**
     * The number of seconds the timeout modal will start counting down from when first displayed.
     */
    timeoutModalDuration?: number;

  }