import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { getTestBed, TestBed } from "@angular/core/testing";

import { ExternalService } from "./external.service";
import { ConfigurationService } from "../configuration.service";

describe("ExternalService", () => {
  let service: ExternalService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userId: 27398,
              hhawsenturl: "https://uat.hhaexchange.com/HHAWSENT2105010000/",
            },
          },
        },
      ],
    });
    injector = getTestBed();
    service = injector.inject(ExternalService);
    httpMock = injector.inject(HttpTestingController);
  });
  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });
  it("ExternalService should be created", () => {
    expect(service).toBeTruthy();
  });
  it("should call saveQuickBroadcastInfo", () => {
    let params = {
      broadcastID: 1,
      broadcastNote: "string",
      broadcastNoteText: "string",
      visitID: 1,
      OfficeID: 1,
      BroadcastStatus: "string",
      PatientID: 1,
      ProcessStatus: "string",
      VisitDate: "string",
      AdmissionID: "string",
      AppName: "string",
      AppSecret: "string",
      CallerInfo: "string",
    };
    let quickBroadcastResponse = { d: 1 };
    service.saveQuickBroadcastInfo(params).subscribe((res) => {
      expect(res).toEqual(quickBroadcastResponse);
    });
    const request = httpMock.expectOne(
      "https://uat.hhaexchange.com/HHAWSENT2105010000/BroadcastInfo.svc/SaveQuickBroadcastInfo"
    );
    expect(request.request.method).toBe("POST");
    request.flush(quickBroadcastResponse);
  });
});
