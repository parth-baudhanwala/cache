import { HttpClient } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthorizationSetup, MedicalComplianceSetupModel, UnscheduledVisitsSetupModel, MasterweekSetup, CertificationSetup } from "../models/worklist-setup.model";
import { BaseHttpService } from './base.http.service';
import { ConfigurationService } from "./configuration.service";

@Injectable({
  providedIn: 'root'
})
export class OpsWorklistSetupService extends BaseHttpService {

  constructor(httpClient: HttpClient, config: ConfigurationService) {
    super(httpClient, config);
    this.apiPrefix = "WorklistSetup/";
  }
    
  saveAuthorizationSetup(authorizationSetup: AuthorizationSetup): Observable<void> {
    return this.put("SaveAuthorizationSetup", authorizationSetup);
  }

  getAuthorizationSetup(providerId: number): Observable<AuthorizationSetup> {
    return this.get<AuthorizationSetup>("GetAuthorizationSetup", {
      ProviderId: providerId
    });
  }

  getMedicalComplianceSetup(providerId: number): Observable<MedicalComplianceSetupModel> {
    return this.get<MedicalComplianceSetupModel>("GetMedicalComplianceSetup", { providerId: providerId });
  }

  saveMedicalComplianceSetup(medicalComplianceSetupModel: MedicalComplianceSetupModel): Observable<void> {
    return this.put("SaveMedicalComplianceSetup", medicalComplianceSetupModel);
  }

  getMasterWeekSetup(providerId: number): Observable<MasterweekSetup> {
    return this.get<MasterweekSetup>("GetMasterWeekSetup", { providerId: providerId });
  }

  saveMasterWeekSetup(masterWeekSetupModel: MasterweekSetup): Observable<void> {
    return this.put("SaveMasterWeekSetup", masterWeekSetupModel);
  }

  getUnscheduledVisitsSetup(providerId: number): Observable<UnscheduledVisitsSetupModel> {
    return this.get<UnscheduledVisitsSetupModel>("GetUnscheduledVisitsSetup", { providerId: providerId });
  }

  saveUnscheduledVisitsSetup(unscheduledVisitsSetupModel: UnscheduledVisitsSetupModel): Observable<void> {
    return this.put("SaveUnscheduledVisitsSetup", unscheduledVisitsSetupModel);
  }

  getCertificationSetup(providerId: number): Observable<CertificationSetup> {
    return this.get<CertificationSetup>("GetCertificationSetup", { providerId: providerId });
  }

  saveCertificationSetup(certificationSetupModel: CertificationSetup): Observable<void> {
    return this.put("SaveCertificationSetup", certificationSetupModel);
  }
}
