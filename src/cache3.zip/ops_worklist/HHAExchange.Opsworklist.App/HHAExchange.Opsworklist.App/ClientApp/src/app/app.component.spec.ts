import { TestBed, waitForAsync } from "@angular/core/testing";
import { WindowRefService } from "hhax-components";
import { AppComponent } from "./app.component";
import { SessionManagerService } from "./core/authentication/session-manager.service";
import { ConfigurationService } from "./core/services/configuration.service";
import { HhaxMasterLayoutModule } from "./modules/hhax-master-layout/hhax-master-layout.module";

describe("AppComponent", () => {
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [],
      declarations: [AppComponent, HhaxMasterLayoutModule],
      providers: [
        { provide: ConfigurationService, useValue: "" },
        {
          provide: SessionManagerService,
          useValue: {
            keepAliveInit: () => {},
          },
        },
        {
          provide: WindowRefService,
          useValue: {
            nativeWindow: {
              location: {
                href: "http://localhost:4200/",
              },
            },
          },
        },
      ],
    }).compileComponents();
  }));

  it("should create the app", () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'HHAx-WorkList'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual("HHAx-WorkList");
    app.showApp();
  });
});
