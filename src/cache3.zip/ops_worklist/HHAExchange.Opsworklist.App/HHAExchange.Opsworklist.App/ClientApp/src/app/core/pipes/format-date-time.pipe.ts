import { Pipe, PipeTransform } from '@angular/core';
import moment from 'moment';

@Pipe({
  name: 'formatDateTime'
})
export class FormatDateTime implements PipeTransform {
  transform(value: Date, defaultStr: string = ""): string {
    return value != null ? moment(value).format('MM/DD/YYYY LT') : defaultStr
  }
}
