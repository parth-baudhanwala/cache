import { Defaultparam } from "@app/core/models/defaultparam.model";

export enum PriorityType {
  LOW = "1",
  MEDIUM = "2",
  HIGH = "3",
}

export enum ScheduleType {
  NOW = "1",
  SCHEDULE = "2",
}

export enum DeliveryMethodType {
  TEXT = "5",
  EMAIL = "3",
  MOBILEMESSAGING = "4",
  MOBILEANDTEXT = "2"
}

export class TemplateParams extends Defaultparam {
  TemplateId: number;
  AgencyId: number;
}

export class BroadcastParams {
  AideID: number[];
  AttachmentFileName?: string;
  BCC?: string;
  DeliveryOption: number;
  IsScheduled: number;
  Message: string;
  MessageTypeID: string;
  PriorityType: number;
  ProviderID: number;
  ScheduleDate?: string;
  ScheduledFromTime?: string;
  Subject: string;
  TemplateID: number;
  UserID: number;
  voiceFilePath?: string;
}
