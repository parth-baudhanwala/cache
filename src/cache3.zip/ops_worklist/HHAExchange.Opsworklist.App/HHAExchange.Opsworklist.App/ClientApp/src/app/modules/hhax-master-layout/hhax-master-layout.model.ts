export interface MenuModel {
  id: number;
  name: string;
  parentId: number;
  url: string;
  isPopup: boolean;
  windowFeatures: string;
}

export interface MachineModel {
  machineDateTime: string;
  machineName: string;
}

export interface NotificationModel {
  userNotifMsgCnt: number;
  userMessagesCnt: number;
  userToDosMsgCnt: number;
  openCaseMsgCnt: number;
  openCaseURL: string;
}
