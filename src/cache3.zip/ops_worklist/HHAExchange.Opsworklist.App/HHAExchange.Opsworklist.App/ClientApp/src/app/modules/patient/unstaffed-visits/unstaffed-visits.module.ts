import { NgModule } from "@angular/core";
import { CommonModule, DatePipe } from "@angular/common";
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { TreeviewModule } from "@app/core/components/ngx-treeview-dropdown/treeview.module";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown";
import { HhaxTableModule } from "@app/core/components/hhax-components/data-table/data-table.module";
import { ShowHideModule } from "hhax-components";
import { AutocompleteModule } from "@app/core/components/hhax-components/autocomplete/autocomplete.module";
import { HhaxTableDataModule } from "@app/core/components/hhax-components/data-table/datasource/datasource.module";
import { CoreModule } from "@app/core/core.module";
import { AuthInterceptor } from "@app/core/authentication/auth.interceptor";
import { HttpErrorInterceptor } from "@app/core/authentication/http-error.interceptor";
import { UnstaffedVisitsComponent } from "./unstaffed-visits.component";

@NgModule({
    imports: [
        AutocompleteModule,
        AngularMultiSelectModule,
        CommonModule,
        CoreModule,
        ReactiveFormsModule,
        FormsModule,
        HhaxTableModule,
        HhaxTableDataModule,
        ShowHideModule,
        TreeviewModule.forRoot(),
    ],
    declarations: [UnstaffedVisitsComponent],
    providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthInterceptor,
            multi: true,
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: HttpErrorInterceptor,
            multi: true,
        },
        DatePipe
    ]
})
export class UnstaffedVisitsModule {
  static entry = UnstaffedVisitsComponent;
}
