import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { fakeAsync, getTestBed, TestBed } from "@angular/core/testing";
import { ConfigurationService } from "./configuration.service";
import { SessionStorageService } from "./session-storage.service";

describe("ConfigurationService", () => {
  let service: ConfigurationService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: SessionStorageService,
          useValue: {
            getItem: () => null,
            setItem: () => null,
            removeItem: () => null,
          },
        },
      ],
    });
    injector = getTestBed();
    service = injector.inject(ConfigurationService);
  });

  it("SessionStorageService should be created", () => {
    expect(service).toBeDefined();
  });

  it("should call resetAppConfiguration", () => {
    service.resetAppConfiguration();
  });

  it("should call geAppConfiguration", () => {
    var UserID = 542875;
    service.appConfiguration == null;
    service.geAppConfiguration(UserID);
  });

  it("should call  getIdentityURL", () => {
    expect(service.basePath.includes("localhost")).toEqual(true);
    service.getIdentityURL();
  });
  it("should call  getIdentityURL false", () => {
    service.basePath.includes("localhost").valueOf();
    const location = `${window.location.protocol}//${window.location.host}/Identity`;
    expect(location).toEqual("http://localhost:9876/Identity");
    service.getIdentityURL();
  });

  it("should call  appConfiguration", () => {
    service.basePath.includes("localhost").valueOf();
  });

  it("should call appConfiguration", fakeAsync(() => {
    const store = {};
    spyOn(sessionStorage, "getItem").and.callFake((key) => {
      return store[key];
    });
    service.appConfiguration;
  }));

  it("should call geAppConfiguration", () => {
    const store = {};
    const UserID = 21451;
    spyOn(sessionStorage, "getItem").and.callFake((key) => {
      return store[key];
    }).and.returnValue;
    service.appConfiguration === null;
    service.geAppConfiguration(UserID);
  });
});
