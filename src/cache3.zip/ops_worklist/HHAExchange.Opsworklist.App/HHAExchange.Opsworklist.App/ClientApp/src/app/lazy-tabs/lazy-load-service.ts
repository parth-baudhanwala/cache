import { Compiler, Inject, Injectable, Injector, NgModuleFactory, ViewContainerRef } from "@angular/core";
import { WorklistDetail } from "@app/core/models/common.model";
import { LAZY_TABS } from "./lazy-tabs";

@Injectable()
export class LazyLoadService {
  constructor(
    private _injector: Injector,
    private _compiler: Compiler,
    @Inject(LAZY_TABS)
    private _lazyTabs: { [key: string]: () => Promise<NgModuleFactory<any>> }
  ) { }

  async load(worklistDetail: WorklistDetail, container: ViewContainerRef, eventsCallBack?: Function) {
    const modulePromise = this._lazyTabs[worklistDetail.worklistPath];

    if (modulePromise !== undefined) {
      const ngModuleOrNgModuleFactory: NgModuleFactory<any> = await modulePromise();
      let moduleFactory: any;

      if (ngModuleOrNgModuleFactory instanceof NgModuleFactory) {
        moduleFactory = ngModuleOrNgModuleFactory;
      }
      else {
        moduleFactory = await this._compiler.compileModuleAsync(ngModuleOrNgModuleFactory);
      }

      const entryComponent = moduleFactory.moduleType.entry;
      const moduleRef = moduleFactory.create(this._injector);

      const compFactory = moduleRef.componentFactoryResolver.resolveComponentFactory(entryComponent);

      const tab = container.createComponent(compFactory);

      tab.instance["worklistDetail"] = worklistDetail;

      if (eventsCallBack) {
        tab.instance["worklistEvents"].subscribe((v: string) => eventsCallBack(v));
      }
    }
  }
}
