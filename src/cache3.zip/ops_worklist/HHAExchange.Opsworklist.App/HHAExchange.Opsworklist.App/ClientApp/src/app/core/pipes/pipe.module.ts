import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { DateToTime24hrPipe } from './date-to-time-24hr';
import { DateToTimePipe } from './date-to-time.pipe';
import { EncodeUriPipe } from './encode-uri.pipe';
import { FormatDateTime24hr } from './format-date-time-24hr.pipe';
import { FormatDateTime } from './format-date-time.pipe';
import { MonthNamePipe } from './month-name.pipe';
import { ReplaceKeywordPipe } from './replace-keyword.pipe';

const declarations = [
    FormatDateTime,
    DateToTimePipe,
    MonthNamePipe,
    DateToTime24hrPipe,
    FormatDateTime24hr,
    EncodeUriPipe,
    ReplaceKeywordPipe
]
@NgModule({
    declarations: [
        declarations,
    ],
    imports: [CommonModule],
    providers: [
        declarations,
    ],
    exports: [
        declarations,
    ]
  })
export class PipeModule { }