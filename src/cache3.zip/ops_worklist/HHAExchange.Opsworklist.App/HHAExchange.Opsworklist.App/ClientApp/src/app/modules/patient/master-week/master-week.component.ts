import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { HHAUserService } from "@app/core/authentication/user.service";
import { BaseComponent } from "@app/core/components/base-component/base.component";
import {
  closingConditionParams,
  patientAutocomplete,
  TypeAheadCriteria,
  Worklist,
} from "@app/core/models/common.model";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { FileService } from "@app/core/services/file.service";
import { NotesService } from "@app/core/services/notes.service";
import { SearchFieldsService } from "@app/core/services/search-fields.service";
import { WorkslistService } from "@app/core/services/workslist.service";
import { isBlank } from "@app/lib/utils";
import moment from "moment";
import { ToastrAlertService } from "hhax-components";
import { SessionStorageService } from "@app/core/services/session-storage.service";
import { configHelper } from "@app/core/config/static-options";
import { DatePipe } from '@angular/common';

@Component({
  selector: "app-master-week",
  templateUrl: "./master-week.component.html",
})
export class MasterWeekComponent extends BaseComponent implements OnInit {
  workListGroup: FormGroup;
  getAssignData: string;
  isAuthenticationDone: boolean = false;
  _gridPageSize: number = configHelper.pageSize10;
  actionButtons = [
    {
      label: "Refresh Status",
      handler: (x) =>
        this.refreshRecords(x, Worklist.MASTER_WEEK, () =>
          this.searchWorkLists()
        ),
    },
    {
      label: "Update Status to Open",
      handler: (x) =>
        this.updateStatus(x, "Open", () => this.searchWorkLists()),
    },
    {
      label: "Update Status to In-Progress",
      handler: (x) =>
        this.updateStatus(x, "In-Progress", () => this.searchWorkLists()),
    },
    {
      label: "Update Status to Closed",
      handler: (x) => this.updateClosedStatus(x, () => this.searchWorkLists()),
    },
    {
      label: "View/Add Notes",
      handler: (x) => this.openAddNoteDialog(x, () => this.searchWorkLists()),
    },
    {
      label: "Assign Task",
      handler: (x) =>
        this.openAssignTaskModal(x, this.getAssignData, () =>
          this.searchWorkLists()
        ),
    },
    {
      label: "Unassign Task",
      handler: (x) => this.unassignTask(x, () => this.searchWorkLists()),
    },
  ];
  getAssigneeData: string;
  patientParams: patientAutocomplete;
  taskNotesCount: number;
  closingConditionParams: closingConditionParams;
  formattedScheduleWeek = "";
  scheduleTime = [];
  isUserInNewSkin: boolean;
  vendor12HoursFlag: boolean;
  constructor(
    public _searchservice: SearchFieldsService,
    public fb: FormBuilder,
    public _dialogModal: MatDialog,
    public _config: ConfigurationService,
    public _userService: HHAUserService,
    public _alert: ToastrAlertService,
    public _worklist: WorkslistService,
    public _common: CommonService,
    public _notesService: NotesService,
    public _fileService: FileService,
    public _storage: SessionStorageService,
    public _datePipe: DatePipe
  ) {
    super(
      _config,
      _searchservice,
      _alert,
      _common,
      _dialogModal,
      _worklist,
      _userService,
      _fileService,
      _notesService,
      _storage,
      _datePipe
    );
  }

  ngOnInit(): void {

    super.ngOnInit();

    this.isUserInNewSkin = this._userService.getIsUserNewskin();
    this.vendor12HoursFlag = this._userService.getVendor12HoursFlag();

    this.checkAuthentication(this.AuthParams).subscribe((isValidUser: boolean) => {
      if (isValidUser) {
        if (this.worklistDetail.canManuallyCloseWorklistTask === "No") {
          this.actionButtons.forEach((button, index) => {
            if (button.label === "Update Status to Closed") {
              this.actionButtons[index].handler = async () => { };
              this.actionButtons[index]["isDisable"] = "true";
            }
          });
        }

        this.fetchSearchOptionsData();
        this.searchWorkLists(true);
        (this.workListGroup.get("patient") as FormControl).valueChanges.subscribe(
          (value: string) => {
            this.patientParams = {
              worklistPath: this.worklistDetail.worklistPath,
              patient: value,
              providerId: this._userService.getVendorID(),
              officeId: this.workListGroup.get("officeID").value,
              criteria: TypeAheadCriteria.StartsWith,
              count: 10
            };
          }
        );
        this.isAuthenticationDone = true;
      }
    });
  }

  fetchSearchOptionsData() {
    this.assigneeOptions = [];
    this.contractOptions = [];
    this.coordinatorOptions = [];
    this.workListGroup = new FormGroup({
      officeID: new FormControl([], Validators.required),
      coordinatorID: new FormControl([-1]),
      contractID: new FormControl([-1]),
      assignee: new FormControl([]),
      status: new FormControl(["Open"]),
      endDateFrom: new FormControl(
        moment().format().substring(0, 10),
        Validators.required
      ),
      endDateTo: new FormControl(
        moment().add(4, "d").format().substring(0, 10),
        Validators.required
      ),
      disciplineID: new FormControl([-1]),
      patient: new FormControl(""),
      patientStatusID: new FormControl([3]),
    });

    let payload = {
      WorklistID: this.worklistDetail.worklistId,
      OfficeIDs: this.appConfig.userOffices
        .map((obj) => obj.officeID)
        .join(","),
    };
    this.getAssignees(payload);
  }

  searchWorkLists(onInit = false) {
    this.getParams = this.getSearchParams(onInit);
    this.gridPageSize = this._gridPageSize;
  }

  getSearchParams(onInit = false) {
    const formSubmittedData = this.workListGroup.value;
    const appConfig = this._config.appConfiguration;
    const params: any = {};
    if (onInit) {
      let userOfficeId: number[] | number = [];
      if (appConfig && appConfig.userOffices) {
        userOfficeId =
          appConfig.userOffices.length > 1
            ? appConfig.userOffices
              .filter((obj) => obj.isPrimary)
              .map((obj) => obj.officeID)
            : appConfig.userOffices[0].officeID;
      }
      let startDate = moment(this.workListGroup.value.endDateFrom).format(
        "MM/DD/YYYY"
      );

      let endDate = moment(this.workListGroup.value.endDateTo).format(
        "MM/DD/YYYY"
      );
      params.MasterWeekDate = `${startDate}-${endDate}`;
      params.status = "Open";
      params.officeID = userOfficeId;
      params.assignee = appConfig.userId;
      params.expirationDuration = "14";
    } else {
      if (
        !isBlank(formSubmittedData.officeID) &&
        formSubmittedData.officeID[0] !== -1
      )
        params.officeID = formSubmittedData.officeID;

      if (
        !isBlank(formSubmittedData.coordinatorID) &&
        formSubmittedData.coordinatorID[0] !== -1
      )
        params.coordinatorID = formSubmittedData.coordinatorID;

      if (
        !isBlank(formSubmittedData.contractID) &&
        formSubmittedData.contractID[0] !== -1
      )
        params.contractID = formSubmittedData.contractID;

      if (
        !isBlank(formSubmittedData.assignee) &&
        formSubmittedData.assignee[0] !== -1
      )
        params.assignee = formSubmittedData.assignee;

      if (this.isUserInNewSkin) {
        params.disciplineID = this.setDisciplineIds(formSubmittedData.disciplineID);
      }
      else {
        if (!isBlank(formSubmittedData.disciplineID) && formSubmittedData.disciplineID[0] !== -1) {
          params.disciplineID = formSubmittedData.disciplineID;
        }
      }

      if (!isBlank(formSubmittedData.patientStatusID) &&
        formSubmittedData.patientStatusID[0] !== -1
      )
        params.patientStatusID = formSubmittedData.patientStatusID;

      if (
        !isBlank(formSubmittedData.status) &&
        formSubmittedData.status[0] !== -1
      )
        params.status = formSubmittedData.status;

      if (!isBlank(formSubmittedData.patient))
        params.patient = formSubmittedData.patient;

      if (
        ["", null, undefined].includes(formSubmittedData.endDateFrom) ||
        ["", null, undefined].includes(formSubmittedData.endDateTo)
      ) {
        this._alert.error("error", "Invalid Master Week Date Range.");
        this.workListGroup.patchValue({
          endDateFrom: moment().toDate(),

          endDateTo: moment(this.workListGroup.value.endDateFrom)
            .clone()
            .add(5, "days"),
        });
      } else {
        params.MasterWeekDate =
          moment(formSubmittedData.endDateFrom).format("MM/DD/YYYY") +
          "-" +
          moment(formSubmittedData.endDateTo).format("MM/DD/YYYY");
      }
    }
    params.userID = appConfig.userId;
    params.providerID = appConfig.agencyID;
    return params;
  }

  onSubmit() {
    this.searchWorkLists();
  }

  onReset(): void {
    this.getOffices(this.params);
    this.workListGroup.patchValue({
      coordinatorID: [-1, ...this.coordinatorOptions.map((obj) => obj.value)],
      contractID: [-1, ...this.contractOptions.map((obj) => obj.value)],
      assignee: [this.appConfig.userId],
      endDateFrom: moment().format().substring(0, 10),
      endDateTo: moment().add(4, "d").format().substring(0, 10),
      status: ["Open"],
      disciplineID: [-1, ...this.disciplineOptions.map((obj) => obj.value)],
      patient: "",
      patientStatusID: [3],
    });
    if (document.getElementsByClassName("mat-autocomplete-trigger")[0]) {
      const inputElement: HTMLInputElement = document.getElementsByClassName(
        "mat-autocomplete-trigger"
      )[0] as HTMLInputElement;
      inputElement.value = "";
    }
    this._gridPageSize = configHelper.pageSize10;
    this.searchWorkLists();
  }

  async openPopUp(x: any): Promise<void> {
    let entMailUrl = this._config.appConfiguration.entMainURL;
    entMailUrl += entMailUrl.endsWith("/") ? "" : "/";
    const url = `${entMailUrl}Patient/InternalPatientInfo.aspx?PatientId=${x.data.patientId}&FromSearch=1`;
    this.openWindowPopUp(url, x, Worklist.MASTER_WEEK, () =>
      this.searchWorkLists()
    );
  }

  openNote(record) {
    this.openAddNoteDialog(record, () => this.searchWorkLists());
  }
  openMasterWeekSchedule(record) {
    this.openWeekScheduleModal(record, () => this.searchWorkLists());
  }
  onAssigneeClick(record, assignee) {
    this.openAssignTaskModal(record, assignee, () => this.searchWorkLists());
  }

  getSRMasterWeekDescription(scheduleWeek: string): string {
    const days = {
      M: "Monday",
      Tu: "Tuesday",
      W: "Wednesday",
      Th: "Thursday",
      F: "Friday",
      Sa: "Saturday",
      Su: "Sunday",
    };

    const scheduleDayTime = scheduleWeek.split(", ");

    const formattedDescriptions = scheduleDayTime.map((part) => {
      const [day, scheduleTime] = part.split(":");
      const weekDay = days[day];

      if (scheduleTime.includes("-")) {
        const [fromTime, toTime] = scheduleTime.split(" - ");
        return `${weekDay} ${this.getFormattedTime(fromTime)} to ${this.getFormattedTime(toTime)}`;
      } else {
        return `${weekDay} ${this.getFormattedTime(scheduleTime)}`;
      }
    });

    return formattedDescriptions.join(" ");
  }

  getFormattedTime(time: string): string {
    if (time.includes("H")) {
      const [hours, minutes] = time.split("H");

      const hoursText = hours === '1' ? 'Hour' : 'Hours';
      const minutesText = minutes === '1' ? 'Minute' : 'Minutes';

      return `${Number(hours)} ${hoursText} and ${Number(minutes.replace("M",""))} ${minutesText}`;
    } 

    if (this.isUserInNewSkin && this.vendor12HoursFlag) {
      const hours = time.substring(0, 2)
      const minutes = time.substring(2);

      const parsedHours = parseInt(hours, 10);

      if (parsedHours >= 12) {
        return `${parsedHours === 12 ? parsedHours : (parsedHours - 12).toString().padStart(2, '0')}:${minutes} PM`;
      } else {
        return `${parsedHours === 0 ? 12 : parsedHours.toString().padStart(2, '0')}:${minutes} AM`;
      }
    } else {
      const [hours, minutes] = time.match(/.{1,2}/g);
      return `${hours.padStart(2, '0')} Hours ${minutes.padStart(2, '0')} Minutes`;
    }
  }

  pageSizeSelectedChange() {
    this.searchWorkLists();
  }
}
