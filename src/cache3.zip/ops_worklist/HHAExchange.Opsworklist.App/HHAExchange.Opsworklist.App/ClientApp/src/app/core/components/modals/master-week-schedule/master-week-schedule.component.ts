import {
  Component,
  ElementRef,
  Inject,
  Input,
  OnInit,
  ViewChild,
} from "@angular/core";
import { HHAUserService } from "@app/core/authentication/user.service";
import {
  AppConfiguration,
  MasterWeekInfoParams,
  MasterWeekInfoResponse,
} from "@app/core/models/common.model";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { CommonService } from "@app/core/services/common.service";
import { faMinus, faPlus } from "@fortawesome/free-solid-svg-icons";
import { ToastrAlertService } from "hhax-components";
import isEqual from "lodash/fp/isEqual";
import { VisitScheduleType } from "../../../models/schedule-type.enum";

@Component({
  selector: "master-week-schedule",
  templateUrl: "./master-week-schedule.component.html",
})
export class MasterWeekModal implements OnInit {
  @Input() titleText: string;
  @Input() id: string;
  @ViewChild("scheduleModalRef", { read: ElementRef })
  private scheduleModalRef: ElementRef;
  appConfig: AppConfiguration;
  show: boolean;
  isHidden: boolean;
  plus = faPlus;
  minus = faMinus;
  alertMsg: string;
  alertModalMsg: string;
  scheduleType = VisitScheduleType;
  isInternalPatient: boolean;
  isUserInNewSkin: boolean;
  vendor12HoursFlag: boolean;
  masterWeekInfoData: MasterWeekInfoResponse = {
    sunday: {},
    monday: {},
    tuesday: {},
    wednesday: {},
    thursday: {},
    friday: {},
    saturday: {},
  };
  noDataObj = {
    hours: "-",
    caregiver: ", ",
    assignmentID: null,
    payCode: null,
    poc: null,
    primaryBillTo: null,
    duration: "00-00",
    serviceCode: null,
    rateType: null,
    includeinMileage: "False",
  };

  constructor(
    public masterWeekSchedule: MatDialog,
    public dialogRef: MatDialogRef<MasterWeekModal>,
    public _config: ConfigurationService,
    public _userService: HHAUserService,
    public _alert: ToastrAlertService,
    public _common: CommonService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.alertModalMsg = "Opened Master Week Schedule Popup";
    this.appConfig = this._config.appConfiguration;
    this.isHidden = false;
    const record = this.data.record;
    const params: MasterWeekInfoParams = new MasterWeekInfoParams(this._config);
    this.isInternalPatient = record.isInternalPatient;
    this.isUserInNewSkin = this._userService.getIsUserNewskin();
    this.vendor12HoursFlag = this._userService.getVendor12HoursFlag();

    params.masterWeekHeaderID = record.worklistEntKey;
    params.PatientID = record.patientId;
    if (this.isInternalPatient) {
      this._common
        .GetPatientMasterWeekInfo(params)
        .subscribe((obj: MasterWeekInfoResponse) => {
          Object.keys(obj).forEach((key) => {
            if (obj[key] && obj[key].scheduledTime === "-") obj[key] = {};
          });
          this.masterWeekInfoData = obj;
        });
    } else {
      this._common
        .GetUPRPatientMasterWeekInfo(params)
        .subscribe((obj: MasterWeekInfoResponse) => {
          Object.keys(obj).forEach((key) => {
            if (obj[key] && obj[key].scheduledTime === "-") obj[key] = {};
          });
          this.masterWeekInfoData = obj;
        });
    }
  }

  ngAfterViewInit(): void {
    if (this.scheduleModalRef) this.scheduleModalRef.nativeElement.click();
  }

  public toggle() {
    this.isHidden = !this.isHidden;
  }
  closeDialog(action: any): void {
    this.dialogRef.close(action);
  }

  formatMasterWeekSrTime(masterWeekDay): string {
    if (Object.keys(masterWeekDay).length === 0) {
      return "";
    }

    if (!this.isInternalPatient) {
      return this._common.getSrTime(masterWeekDay.scheduledTime, (this.isUserInNewSkin && this.vendor12HoursFlag));
    }

    if (!masterWeekDay.scheduleType || masterWeekDay.scheduleType === this.scheduleType.DAILY_FIXED) {
      return this._common.getSrTime(masterWeekDay.scheduledTime, (this.isUserInNewSkin && this.vendor12HoursFlag));
    } else {
      return this._common.getFormattedSrTime(masterWeekDay.scheduledHours);
    }
  }

  displayMasterWeekScheduledTime(masterWeekDay): string {
    if (Object.keys(masterWeekDay).length === 0) {
      return "";
    }

    if (!this.isInternalPatient) {
      if (this.isUserInNewSkin && this.vendor12HoursFlag) {
        return this._common.getFormattedTime(masterWeekDay.scheduledTime);
      } else {
        return masterWeekDay.scheduledTime;
      }
    }

    if (!masterWeekDay.scheduleType || masterWeekDay.scheduleType === this.scheduleType.DAILY_FIXED) {
      if (this.isUserInNewSkin && this.vendor12HoursFlag) {
        return this._common.getFormattedTime(masterWeekDay.scheduledTime);
      } else {
        return masterWeekDay.scheduledTime
      }
    } else {
      return masterWeekDay.scheduledHours;
    }
  }

  getColInfo(scheduleWeekday) {
    let noDataText = "No data available";
    if (isEqual(scheduleWeekday, {})) {
      return noDataText;
    } else {
      let assignmentIDText = scheduleWeekday.assignmentID || noDataText;
      let payCodeText = scheduleWeekday.payCode || noDataText;
      let pocText =
        scheduleWeekday.poc === "-1"
          ? noDataText
          : scheduleWeekday.poc || noDataText;
      let primaryBillToText = scheduleWeekday.primaryBillTo || noDataText;
      let durationText = scheduleWeekday.scheduledHours || noDataText;
      let serviceCodeText = scheduleWeekday.serviceCode || noDataText;
      let rateTypeText = scheduleWeekday.rateType || noDataText;
      let includeinMileageText = scheduleWeekday.includeinMileage || noDataText;
      return `Assignment ID ${assignmentIDText} Pay Code ${payCodeText}
              POC ${pocText} Primary Bill To ${primaryBillToText}
              Duration ${durationText} Service Code ${serviceCodeText}
              Rate Type ${rateTypeText} Include in Mileage ${includeinMileageText}`;
    }
  }
}
