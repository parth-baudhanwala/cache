import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { getTestBed, TestBed } from '@angular/core/testing';

import {
  GetAllNotesByTaskIDResponseData,
  getItemsdataResponse,
  saveNotesResponse,
} from '../services-mock-data/notes.service.mock';
import { BaseHttpService } from './base.http.service';
import { NotesService } from './notes.service';
import { SessionStorageService } from './session-storage.service';

describe("BroadCastService", () => {
  let baseService: BaseHttpService
  let WorklistTaskId: 16597
  let saveNotesParams = {
    UserID: 27398,
    AppVersion: "ENT",
    Version: 21.02,
    MinorVersion: 1,
    ProviderID: 691,
    CreatedBy: "27398",
    CreatedByUser: "27398",
    Subject: "116478",
    SubjectText: "Test Special Char &",
    Note: "test special",
    WorklistTaskIds: "16603",
    OfficeID: 851,
    CopyNotesTo: "caregiver",
    AideIDs: "977742",
    FileAttachmentGUID: "abc.png",
    AttachmentName: "bc.png",
    Result: 691,
    PatientIDs: "3199154",
  }

  let getItemsDataParams = {
    reasonType: 105,
    UserID: 27398,
    IsActive: 1,
    AppVersion: "ENT",
    Version: 21.02,
    MinorVersion: 1
  }
  let service: NotesService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        SessionStorageService,
        { provide: "HOST", useValue: "test" },

      ],
    });
    injector = getTestBed();
    service = injector.inject(NotesService);
    httpMock = injector.inject(HttpTestingController);
  });
  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });
  it("BroadCastService should be created", () => {
    expect(service).toBeTruthy();
  });
  it("BroadCastService getSubjectItems", () => {
    service.getSubjectItems(getItemsDataParams).subscribe((res) => {
      expect(res).toEqual(getItemsdataResponse);
    });
    const request = httpMock.expectOne('Notes/GetSubjectItems?reasonType=105&UserID=27398&IsActive=1&AppVersion=ENT&Version=21.02&MinorVersion=1');
    expect(request.request.method).toBe('GET');
    request.flush(getItemsdataResponse);
  });
  it("BroadCastService GetAllNotesByTaskID", () => {
    service.GetAllNotesByTaskID(15, 0, "").subscribe((res) => {
      expect(res).toEqual(GetAllNotesByTaskIDResponseData);
    });
    const request = httpMock.expectOne('Notes/GetAllNotesByTaskID?WorklistTaskId=' + 15);
    expect(request.request.method).toBe('GET');
    request.flush(GetAllNotesByTaskIDResponseData);
  });
  it("BroadCastService SaveNotes", () => {
    service.SaveNotes(saveNotesParams).subscribe((res) => {
      expect(res).toEqual(saveNotesResponse);
    });
    const request = httpMock.expectOne('Notes/');
    expect(request.request.method).toBe('POST');
    request.flush(saveNotesResponse);
  });
});
