import { lazyArrayToObj, lazyTabs } from "./lazy-tabs";
describe("lazy tabs", () => {
  it("should call lazyArrayToObj", () => {
    lazyArrayToObj();
    lazyTabs.forEach((tab) => {
      tab.loadChildren();
      expect(tab.loadChildren).toBeDefined();
    });
  });
});
