import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ModalModule } from 'hhax-components';
import { AuthCallbackComponent } from './core/authentication/auth-callback.component';
import { SilentRefreshCallBackComponent } from './core/authentication/silent-refresh-callback.component';
import { CoreModule } from './core/core.module';
import { ForbiddenComponent } from './modules/hhax-master-layout/forbidden/forbidden.component';

const routes: Routes = [
  {
    path: "auth-complete",
    component: AuthCallbackComponent
  },
  {
    path: "ops-worklist",
    loadChildren: () => import("./ops-worklist-dashboard/ops-worklist-dashboard.module").then((x) => x.OpsWorklistDashboardModule)
  },
  {
    path: "silent-refresh",
    component: SilentRefreshCallBackComponent
  },
  {
    path: "forbidden",
    component: ForbiddenComponent
  },
  {
    path: "ops-worklist-setup",
    loadChildren: () => import("./ops-worklist-setup/ops-worklist-setup.module").then((x) => x.OpsWorklistSetupModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes,
      {
        initialNavigation: 'disabled',
        paramsInheritanceStrategy: 'always',
        scrollPositionRestoration: 'top',
        relativeLinkResolution: 'legacy'
      }),
    ModalModule,
    CoreModule,
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
