import {
    AfterViewInit,
    ComponentFactory,
    ComponentFactoryResolver,
    ComponentRef,
    Directive,
    Input,
    OnChanges,
    OnDestroy,
    SimpleChanges,
} from '@angular/core';
import { PaginationComponent } from '../pagination/pagination.component';
import { HhaxTableComponent } from '../data-table.component';
import { SpinnerComponent } from 'hhax-components';
import { HhaxTablePagingBaseDirective } from './paging.directive';
import { PageChangeEvent } from '../pagination/model';
  
  @Directive({
    selector: '[hhaxInMemoryTransport]'
  })
  export class HhaxTablePaginationDirective<T> extends HhaxTablePagingBaseDirective implements OnChanges, AfterViewInit, OnDestroy {
  
    @Input() getUrl: string;
    @Input() getParams: object;
    @Input() gridPageSize: number;
    @Input() isTableEmptyByDefault: boolean;
    @Input() data: T[];
    @Input() shouldDisplaySpinner: boolean;
    totalRecordCount: number;
    shouldSave = true;
  
    private readonly _spinnerFactory: ComponentFactory<SpinnerComponent>;
    private readonly _paginationFactory: ComponentFactory<PaginationComponent>;
    private _spinnerRefs: ComponentRef<SpinnerComponent>[];
    private _paginationRef: ComponentRef<PaginationComponent>;

  
    constructor(
      private _table: HhaxTableComponent,
      private _componentFactory: ComponentFactoryResolver) {
      super();
        this._paginationFactory = this._componentFactory.resolveComponentFactory(PaginationComponent);
        this._spinnerFactory = this._componentFactory.resolveComponentFactory(SpinnerComponent);
        this._spinnerRefs = [];
  
        // TODO replace this with a sort directive. The current request object uses the
        // table's sort variable, which is updated automatically. This isn't ideal and the
        // two should be separated down the line.
        this._table.sortChange.subscribe(() => { this._requestGet(); });
    }
  
    ngAfterViewInit(): void {
      this._refreshPagination();
    }
  
    ngOnChanges(changes: SimpleChanges): void {
      if (changes.getParams) {
        this.resetPagination();
      }
      if (!this.isTableEmptyByDefault) {
        this.refresh();
      }
      this.isTableEmptyByDefault = false;

      (changes.shouldDisplaySpinner.currentValue) ? this._createSpinner() : this._destroySpinner();
    }
  
    ngOnDestroy(): void {
      this._destroyPagination();
      this._destroySpinner();
    }
  
    updateParameters(params: object): void {
      this.getParams = params;
      this._requestGet();
    }
  
    refresh(): void {
      if ((this.getParams && this.getUrl) || this.data) {
        this._requestGet();
      }
    }
  
    resetPagination(): void {
      if (this._paginationRef) {
        this._paginationRef.instance.currentPage = this.pageNumber = 1;
      }
    }
  
    private _requestGet(): void {
      this._createSpinner();
      if (this.data) {
      this._table.data = this._paginateData();
      this._table.totalRecordCount = this.totalRecordCount;
      this._table.setTableRowData();
      this._destroySpinner();
      this._table.renderRows();
      } else {
      this._table.rows.length = 0;
      this._table.clearRows();
      }
      this._refreshPagination();
    }
  
    private _createSpinner(): void {
      const spinnerComponentRef = this._table.spinnerOutlet.createComponent(this._spinnerFactory);
      spinnerComponentRef.instance.fillContainer = true;
      spinnerComponentRef.instance.show = true;
  
      this._spinnerRefs.push(spinnerComponentRef);
    }
  
    private _destroySpinner(): void {
      if (this._spinnerRefs.length) {
        this._spinnerRefs.pop().destroy();
      }
    }
  
    private _refreshPagination(): void {
      if (this._table._containerRef && this._table.rows.length) {
        this._createPagination();
      } else if (!this._table.rows.length) {
        this._destroyPagination();
      }
    }
  
    private _createPagination(): void {
      if (!this._paginationRef) {
        this._paginationRef = this._table._containerRef.createComponent(this._paginationFactory);
        this._paginationRef.instance.pageSize = this.pageSize;
        this._paginationRef.instance.totalRecords = this._table.totalRecordCount;
        this._paginationRef.instance.pageChange.subscribe((pageDetails: PageChangeEvent) => {
          this.pageNumber = pageDetails.pageNumber;
          this.refresh();
        });
      } else {
        this._paginationRef.instance.totalRecords = this._table.totalRecordCount;
        this._paginationRef.instance.refresh();
      }
    }
  
    private _destroyPagination(): void {
      if (this._paginationRef) {
        this._paginationRef.destroy();
        this._paginationRef = null;
      }
    }

    private _paginateData(): T[] {
      this.totalRecordCount = this.data.length;
      return this.data.slice((this.pageNumber - 1) * this.pageSize, this.pageNumber * this.pageSize);
    }
  }
