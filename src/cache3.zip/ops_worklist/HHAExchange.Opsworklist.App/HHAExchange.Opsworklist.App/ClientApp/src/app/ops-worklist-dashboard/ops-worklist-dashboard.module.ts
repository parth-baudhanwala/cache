import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatDialogConfig, MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material/dialog';
import { provideRoutes, RouterModule, Routes } from '@angular/router';
import { CardModule, TabsModule } from 'hhax-components';
import { LazyLoadService } from '../lazy-tabs/lazy-load-service';
import { lazyArrayToObj, lazyTabs, LAZY_TABS } from '../lazy-tabs/lazy-tabs';
import { OpsWorklistDashboardComponent } from './ops-worklist-dashboard.component';
import { PipeModule } from '@app/core/pipes/pipe.module';

const routes: Routes = [
  { path: '', component: OpsWorklistDashboardComponent }
]

@NgModule({
  declarations: [
    OpsWorklistDashboardComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    TabsModule,
    CardModule,
    PipeModule
  ],
  providers: [
    { provide: LAZY_TABS, useFactory: lazyArrayToObj },
    {
      provide: MAT_DIALOG_DEFAULT_OPTIONS,
      useValue: {
        disableClose: true,
        hasBackdrop: true,
        restoreFocus: true,
        role: 'dialog',
      } as MatDialogConfig<any>
    },
    LazyLoadService,
    provideRoutes(lazyTabs),
  ]
})
export class OpsWorklistDashboardModule { }
