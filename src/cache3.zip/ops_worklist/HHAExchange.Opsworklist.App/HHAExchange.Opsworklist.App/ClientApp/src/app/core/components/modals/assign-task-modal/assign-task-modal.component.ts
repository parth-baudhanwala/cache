import { Component, Inject, OnInit } from "@angular/core";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from "@angular/material/dialog";
import { HHAUserService } from "@app/core/authentication/user.service";
import { UpdateTaskRequest } from "@app/core/models/common.model";
import {
  assignTaskModel,
  getUsersByWorklistIDData,
} from "@app/core/models/notes.model";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";

@Component({
  selector: "assign-task",
  templateUrl: "./assign-task-modal.component.html",
  styleUrls: ["./assign-task-modal.component.scss"],
})
export class AssignTaskComponent implements OnInit {
  columns = [
    { label: "Name", key: "name" },
    { label: "User Name", key: "userName" },
  ];
  assigneeList: getUsersByWorklistIDData[];
  alertModalMsg: string;
  constructor(
    public _assignTaskModal: MatDialog,
    public _dialogRef: MatDialogRef<AssignTaskComponent>,
    public _commonService: CommonService,
    public _userService: HHAUserService,
    private _config: ConfigurationService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    if (this.data.canAssignWorklistTask === "No") {
      this.assigneeList = [
        {
          userID: this._userService.getUserID(),
          userName: this._userService.getUserName(),
          firstName: this._userService.getUserFullName().split(" ")[0],
          lastName: this._userService.getUserFullName().split(" ")[1],
        },
      ];
    } else {
      let payload = {
        WorklistID: this.data.workListID,
        OfficeIDs: this._config.appConfiguration.userOffices
          .map((obj) => obj.officeID)
          .join(","),
      };
      this.alertModalMsg = "Opened Assign Task Popup";
      this._commonService
        .GetUsersByWorklistID(payload)
        .subscribe((res: getUsersByWorklistIDData[]) => {
          if (res) {
            this.assigneeList = res;
          }
        });
    }
  }

  closeDialog(action: any): void {
    this._dialogRef.close(action);
  }

  async assignTask() {
    let payload: UpdateTaskRequest = {
      WlTaskId: Array.isArray(this.data.record)
        ? this.data.record.map((obj) => obj.worklistTaskId).join(",")
        : this.data.record.worklistTaskId.toString(),
      AssignedBy: this._userService.getUserID(),
      AssignedTo: this.data.assignedTo.userID,
      AssignedByUser: this._userService.getUserName(),
      AssignedToUser: `${this.data.assignedTo.firstName} ${this.data.assignedTo.lastName} `,
      UpdatedBy: this._userService.getUserID(),
      UpdatedByUser: this._userService.getUserName(),
    };

    this._commonService
      .updateTask(payload, "AssignedTo")
      .subscribe((res: assignTaskModel) => {
        if (res) {
          this.closeDialog({
            AssignedToUser: payload.AssignedToUser,
            res,
          });
        }
      });
  }
}
