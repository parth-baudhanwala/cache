export interface ScriptMessages {
  templateId: number;
  description: string;
}

export interface ISendMessage {
  responseBody: ScriptMessages[];
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface ResponseBody {
  templateID: number;
  templateTypeId: number;
  description: string;
  message: string;
  subject: string;
  bcc: string;
  format: number;
  attachment: string;
  priority: number;
  language: number;
  type: number;
  isIVRVoiceFile: boolean;
  voiceFilePath: string;
  emailAttachmentGUID: string;
}

export interface IScriptData {
  responseBody: ResponseBody[];
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface LastNotes {
  note: string;
  createdBy: number;
  createdByUser: string;
  createdDate: Date;
  createdDateUtc: Date;
}

export interface Record {
  worklistTaskId: number;
  assignedBy: number;
  assignedTo: number;
  assignedByUser: string;
  assignedToUser: string;
  createdDate: Date;
  status: string;
  lastNotes: LastNotes;
  expirationItemType: string;
  expirationItem: string;
  dueDate: Date;
  careGiverId: number;
  careGiverTeamId: number;
  careGiverFirstname: string;
  careGiverLastname: string;
  careGiverMiddlename: string;
  careGiverFullName: string;
}

export interface IRecordData {
  attachment?: string | ArrayBuffer;
  file?: File;
  title: string;
  record: Record;
}
export interface BroadCastModel {
  aideID: number;
  aideCode: string;
  aideName: string;
  notificationPreference: string;
}

export interface BroadCastResponseBody {
  broadCastModel: BroadCastModel[];
  broadCastID: number;
}

export interface IBroadCastModelResponse {
  responseBody: BroadCastResponseBody;
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}
