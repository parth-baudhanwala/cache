import { Guid } from "guid-typescript";

export interface TableColumn<T> {
  label: string;
  key: keyof T;
  sortable?: boolean;
  width?: string;
  toolTip?: string;
}

export interface DataRow<T> {
  selected?: boolean;
  data: T;
  guid?: Guid;
}

export interface ActionButton<T> {
  label: string;
  handler?: (record: T) => void;
  route?: any;
  isDisable?: string;
  isModal: boolean;
}
