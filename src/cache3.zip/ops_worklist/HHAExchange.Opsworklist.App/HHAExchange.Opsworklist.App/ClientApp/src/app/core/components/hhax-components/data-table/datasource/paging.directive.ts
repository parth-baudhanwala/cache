import {
  AfterViewInit,
  ComponentFactory,
  ComponentFactoryResolver,
  ComponentRef,
  Directive,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
} from '@angular/core';

import { HhaxTableComponent } from '../data-table.component';
import { PaginationComponent } from '../pagination/pagination.component';

import { PageChangeEvent } from '../pagination/model';

@Directive({ selector: '[hhaxPagingBase]' })
export class HhaxTablePagingBaseDirective {
  @Input() pageSize = 10;
  @Input() pageNumber = 1;
}

@Directive({
  selector: '[hhaxPaging]',
})
export class HhaxTablePagingDirective implements OnDestroy, AfterViewInit, OnChanges {

  @Input() pageSize = 10;
  @Input() totalRecords: number;

  @Output() pageChange: EventEmitter<PageChangeEvent> = new EventEmitter();

  private _paginationRef: ComponentRef<PaginationComponent>;
  private readonly _paginationFactory: ComponentFactory<PaginationComponent>;

  constructor(
    private _table: HhaxTableComponent,
    private _componentFactory: ComponentFactoryResolver) {
    this._paginationFactory = this._componentFactory.resolveComponentFactory(PaginationComponent);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.totalRecords?.currentValue <= 0) {
      this._destroyPaginationComponent();
    } else if (changes.totalRecords?.currentValue > 0 && !this._paginationRef) {
      this._createPaginationComponent();
    } else {
      this._refreshPaginationComponent();
    }
  }

  ngAfterViewInit(): void {
    if (this.totalRecords > 0) {
      this._createPaginationComponent();
    }
  }

  ngOnDestroy(): void {
    if (this._paginationRef && (this._paginationRef != undefined || this._paginationRef != null)) {
      this._paginationRef.destroy();
    }
  }

  private _createPaginationComponent(): void {
    if (!this._paginationRef) {
      this._paginationRef = this._table._containerRef.createComponent(this._paginationFactory);
      this._setComponentInputValues();
      this._paginationRef.instance.pageChange.subscribe((pageDetails: PageChangeEvent) => {
        this.pageChange.emit(pageDetails);
      });
    }
  }

  private _setComponentInputValues(): void {
    this._paginationRef.instance.pageSize = this.pageSize;
    this._paginationRef.instance.totalRecords = this.totalRecords;
  }

  private _refreshPaginationComponent(): void {
    this._setComponentInputValues();
    this._paginationRef.instance.refresh();
  }

  private _destroyPaginationComponent(): void {
    if (this._paginationRef) {
      this._paginationRef.destroy();
      this._paginationRef = null;
    }
  }
}
