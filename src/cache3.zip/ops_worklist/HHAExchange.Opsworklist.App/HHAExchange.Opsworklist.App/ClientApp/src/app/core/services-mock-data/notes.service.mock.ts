import { IGetAllNotesByTaskID } from "../models/notes.model";

export const GetAllNotesByTaskIDResponse = [
  {
    worklistTaskNoteId: 1138,
    worklistTaskId: 685,
    subject: 91430,
    note: "test data",
    attachment: null,
    attachmentName: null,
    createdBy: 34855,
    createdByUser: "Dhaval Bhatt",
    createdDate: "2021-03-30T04:20:11.898291",
    createdDateUtc: "2021-03-30T08:20:11.898294",
    worklistTask: null,
  },
  {
    worklistTaskNoteId: 1138,
    worklistTaskId: 685,
    subject: 91430,
    note: "test data",
    attachment: null,
    attachmentName: null,
    createdBy: 34855,
    createdByUser: "Dhaval Bhatt",
    createdDate: "2021-03-30T04:20:11.898291",
    createdDateUtc: "2021-03-30T08:20:11.898294",
    worklistTask: null,
  },
];

export const FileUploadResponseData = [
  {
    uploadMessage: "",
    fileGUID: "testGUID",
    isfileUploadedSucessfully: true,
  },
];

export const fileUplaodResponse = [
  {
    uploadMessage: "",
    fileGUID: null,
    isfileUploadedSucessfully: true,
  },
];

export const saveNotesResponse = {
  responseBody: 2,
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const fileUploadResponse = {
  uploadMessage: "succuss fully uploaded",
  fileGUID: "any",
  isfileUploadedSucessfully: true,
};

export const getItemsdataResponse = {
  responseBody: [
    {
      reasonID: 54209,
      reason: "Mobile data",
      reasonDescription: null,
      reasonType: 105,
      reasonLocation: "Caregiver Notes",
      active: 1,
      nonCompliant: 0,
      status: "Active",
      omigEnabled: 0,
      sortOrder: 0,
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};
export const GetAllNotesByTaskIDResponseData: IGetAllNotesByTaskID = {
  result: [
    {
      worklistTaskNoteId: 473,
      worklistTaskId: 13044,
      subject: "Test Special Char &",
      note: "qa attach ",
      fileGuid: "C6F1C5BA-A135-460F-B4CB-504AC58B8CFD",
      attachmentName: "MicrosoftTeams-image (6) (1) (2) (1).png",
      createdBy: 27398,
      createdByUser: "Shekhar Pandey (shekhussp)",
      createdDate: new Date(),
      createdDateUtc: new Date(),
    },
    {
      worklistTaskNoteId: 516,
      worklistTaskId: 13044,
      subject: "NONCLINI MKJP 14",
      note: "gif",
      fileGuid: "BA846639-2393-40DD-BF44-7625F72F45B1",
      attachmentName: "_img4_449023_1_En_7_Fig2_HTML (1).gif",
      createdBy: 27398,
      createdByUser: "Shekhar Pandey (shekhussp)",
      createdDate: new Date(),
      createdDateUtc: new Date(),
    },
  ],
  id: 102880,
  exception: null,
  status: 5,
  isCanceled: false,
  isCompleted: true,
  isCompletedSuccessfully: true,
  creationOptions: 0,
  asyncState: null,
  isFaulted: false,
};
