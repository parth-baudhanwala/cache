import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { faBell } from '@fortawesome/pro-solid-svg-icons';

@Component({
  selector: '[hhax-link-icon-right]',
  templateUrl: './link-icon-right.component.html',
  styleUrls: ['./link-icon-right.component.scss']
})
export class LinkIconRightComponent {

  @Input()
  public counter: number;

  @ViewChild('wrapper', {static: true, read: ElementRef})
    public wrapperElement: ElementRef;

  readonly icon = faBell;
  constructor() {}
}
