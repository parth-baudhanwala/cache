import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: 'hhax-link-icon',
  templateUrl: './link-icon.component.html'
})
export class LinkIconComponent implements OnInit {

  @Input() icon: IconDefinition;
  @Input() counter: number;

  @ViewChild('wrapper', {static: true, read: ElementRef})
    public wrapperElement: ElementRef;

  constructor() { }

  ngOnInit(): void {
  }

}
