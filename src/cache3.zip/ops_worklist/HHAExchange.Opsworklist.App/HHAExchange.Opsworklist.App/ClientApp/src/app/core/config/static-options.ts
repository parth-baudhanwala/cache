import { MultiSelectOption,DropdownListOption } from "hhax-components";

export const statusOptions: MultiSelectOption[] = [
  { text: "Open", value: "Open" },
  { text: "In-Progress", value: "In-Progress" },
  { text: "Closed", value: "Closed" },
  { text: "Completed", value: "Completed" },
];

export const caregiverStatusOptions: MultiSelectOption[] = [
  { text: "Active", value: 1 },
  { text: "InActive", value: 0 },
  { text: "Hold", value: 2 },
  { text: "On Leave", value: 3 },
  { text: "Terminated", value: 4 }
];

export const medicalColumns = [
  {
    label: "Expiring Medical",
    key: "expirationItem",
    sortable: true,
    width: "12%",
  },
  {
    label: "Expiration Date",
    key: "dueDate",
    sortable: true,
  },
  {
    label: "Reported On",
    key: "createdDate",
    sortable: true,
  },
  {
    label: "Caregiver",
    key: "careGiverFullName",
    sortable: true,
    width: "17%",
  },
  {
    label: "Last Note Entered",
    key: "lastNotes",
    sortable: false,
    width: "20%",
  },
  {
    label: "Assignee",
    key: "assignedToUser",
    sortable: true,
  },
  {
    label: "Status",
    key: "status",
    sortable: true,
  },
];

export const expiringAuthColumns = [
  {
    label: "Patient",
    key: "patientFullname",
    sortable: true,
    width: "13%",
  },
  {
    label: "Auth Number",
    key: "authorizationNumber",
    sortable: true,
    width: "12%",
  },
  {
    label: "Expiration Date",
    key: "dueDate",
    sortable: true,
    width: "8%",
  },
  {
    label: "Contract",
    key: "contractName",
    sortable: true,
    width: "12%",
  },
  {
    label: "Reported On",
    key: "createdDate",
    sortable: true,
  },
  {
    label: "Last Note Entered",
    key: "lastNotes",
    sortable: false,
    width: "15%",
  },
  {
    label: "Assignee",
    key: "assignedToUser",
    sortable: true,
  },
  {
    label: "Status",
    key: "status",
    sortable: true,
  },
];

export const unstaffedVisitsColumns = [
  {
    label: "Patient",
    key: "patientFullname",
    sortable: true,
    width: "8%",
  },
  {
    label: "Visit Date",
    key: "visitDate",
    sortable: true,
    width: "9%",
  },
  {
    label: "Schedule Time",
    key: "scheduledTime",
    sortable: true,
  },
  {
    label: "Address",
    key: "address",
    sortable: true,
  },
  {
    label: "Contract",
    key: "contractName",
    sortable: true,
  },
  {
    label: "Discipline",
    key: "disciplineName",
    sortable: true,
    width: "9%",
  },
  {
    label: "Reported On",
    key: "createdDate",
    sortable: true,
  },
  {
    label: "Last Note Entered",
    key: "lastNotes",
    sortable: false,
    width: "14%",
  },
  {
    label: "Assignee",
    key: "assignedToUser",
    sortable: true,
    width: "8%",
  },
  {
    label: "Status",
    key: "status",
    sortable: true,
  },
];

export const masterWeekColumns = [
  {
    label: "Patient",
    key: "patientFullname",
    sortable: true,
    width: "126px",
  },

  {
    label: "Master Week",
    key: "masterWeekSchedule",
    sortable: true,
    width: "12%",
  },
  {
    label: "End Date",
    key: "masterWeekEndDate",
    sortable: true,
    width: "9%",
  },
  {
    label: "Contract(s)",
    key: "contractNames",
    sortable: true,
    width: "11%",
  },
  {
    label: "Caregiver(s)",
    key: "caregiverNames",
    sortable: true,
    width: "11%",

  },
  {
    label: "Reported On",
    key: "createdDate",
    sortable: true,
    width: "7%"
  },
  {
    label: "Last Note Entered",
    key: "lastNotes",
    sortable: false,
    width: "17%",
  },
  {
    label: "Assignee",
    key: "assignedToUser",
    sortable: true,
    width: "9%",
  },
  {
    label: "Status",
    key: "status",
    sortable: true,
    width: "8%",
  },
];

export const certificationPeriodColumns = [
  {
    label: "Patient",
    key: "patientFullname",
    sortable: true,
    width: "12%"
  },
  {
    label: "Certification Period",
    key: "certificationPeriod",
    sortable: true,
    width: "10%",
  },
  {
    label: "Nurse",
    key: "nurseName",
    sortable: true,
    width: "12%",
  },
  {
    label: "Physician",
    key: "physicianName",
    sortable: true,
    width: "12%",
  },
  {
    label: "Reported On",
    key: "createdDate",
    sortable: true,
    width: "10%",
  },
  {
    label: "Last Note Entered",
    key: "lastNotes",
    sortable: false,
    width: "18%",
  },
  {
    label: "Assignee",
    key: "assignedToUser",
    sortable: true,
    width: "10%",
  },
  {
    label: "Status",
    key: "status",
    sortable: true,
    width: "7%",
  },
];

export const configHelper =
{
  defaultSessionTimeoutMinute: '15',
  defaultSessionTimeoutWarningMinute: '14',
  domainName: 'hhaexchange.com',
  hhaSessionKey: 'hhaSessionTime',
  pageSize10: 10
}

export const patienStatusOptions: MultiSelectOption[] = [
  { text: "Waiting", value: 1 },
  { text: "Active", value: 3 },
  { text: "Hospitalized", value: 4 },
  { text: "Discharged", value: 5 },
  { text: "Hold", value: 8 }
];

export const employeeTypeOptions: DropdownListOption[] = [
  { text: "All", value: -1 },
  { text: "Applicant", value: 1 },
  { text: "Employee", value: 2 },
];
