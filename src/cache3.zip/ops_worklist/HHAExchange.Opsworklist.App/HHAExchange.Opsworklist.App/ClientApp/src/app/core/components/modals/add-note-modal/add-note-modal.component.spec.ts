import { HttpClientModule } from "@angular/common/http";
import { ComponentFixture, fakeAsync, TestBed, tick, waitForAsync } from "@angular/core/testing";
import { FormBuilder, FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogModule,
  MatDialogRef,
} from "@angular/material/dialog";
import { HHAUserService } from "@app/core/authentication/user.service";
import {
  FileUploadResponseData,
  GetAllNotesByTaskIDResponseData,
  getItemsdataResponse,
  saveNotesResponse,
} from "@app/core/services-mock-data/notes.service.mock";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { FileService } from "@app/core/services/file.service";
import { NotesService } from "@app/core/services/notes.service";
import { DropdownListModule, ToastrAlertService } from "hhax-components";
import { of } from "rxjs";

import { AddNoteComponent } from "./add-note-modal.component";

let mockRecord = {
  record: {
    expirationItemType: "Other Compliance",
    expirationItem: "Annual Evauation",
    dueDate: "2021-04-30T00:00:00",
    careGiverCode: "EXQ-2096",
    careGiverId: 977506,
    careGiverTeamId: 0,
    careGiverFirstname: "Ida",
    careGiverLastname: "Aaron",
    careGiverMiddlename: "",
    careGiverFullName: "Ida Aaron",
    worklistTaskId: 42367,
    officeId: 851,
    assignedBy: 27398,
    assignedTo: 27398,
    assignedByUser: "shekhussp",
    assignedToUser: "Shekhar Pandey",
    createdDate: "2021-04-09T07:04:46.259777",
    status: "Open",
    lastNotes: {
      note: "test qa bd sent message",
      subject: "[Push Notification]",
      fileGuid: "53570B89-F174-4890-9119-B5935EEC0CD4",
      fileName: "PP_Rules_Redesign_naren.xls",
      createdBy: 27398,
      createdByUser: "Shekhar Pandey (shekhussp)",
      createdDate: "2021-04-10T13:19:53.2958472+05:30",
      createdDateUtc: "2021-04-10T07:49:53.2958481Z",
    },
    worklistEntKey: "6632-||-691-||-977506",
  },
  title: "View/Add Notes",
  subject: "",
  notes: "",
  attachment: "",
  showViewAllNotes: true,
  worklistPath: "MedicalCompliance",
  taskName: "Annual Evauation",
};

let viewAllDataResponse = [
  {
    reverse: "test",
    worklistTaskNoteId: 1,
    worklistTaskId: 2,
    subject: "test",
    note: "notes test",
    attachment: "1.png",
    attachmentName: "2.png",
    createdBy: 1245,
    createdByUser: "srinivas",
    createdDate: new Date(),
    createdDateUtc: new Date(),
    worklistTask: "test tas;",
    fileGuid: "10:401:0000",
    fileName: "1.jpg",
  },
];

let getDataResponse = {
  result: [
    {
      worklistTaskNoteId: 119,
      worklistTaskId: 38697,
      subject: "Calendar Note",
      note: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempSed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi temp",
      fileGuid: null,
      attachmentName: null,
      createdBy: 27398,
      createdByUser: "Shekhar Pandey (shekhussp)",
      createdDate: "2021-04-09T23:57:59.849999",
      createdDateUtc: "2021-04-09T18:27:59.85",
    },
  ],
  id: 36100,
  exception: null,
  status: 5,
  isCanceled: false,
  isCompleted: true,
  isCompletedSuccessfully: true,
  creationOptions: 0,
  asyncState: null,
  isFaulted: false,
};

let testData = {
  responseBody: [
    {
      reasonID: 45440,
      reason: "Calendar Note",
      reasonDescription: "Calendar Note",
      reasonType: 101,
      reasonLocation: "Patient General Notes",
      active: 1,
      nonCompliant: 0,
      status: "Active",
      omigEnabled: 0,
      sortOrder: 0,
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};
describe("AddNoteComponent", () => {
  const mockDialogRef = {
    close: jasmine.createSpy("close"),
  };
  let component: AddNoteComponent;
  let fixture: ComponentFixture<AddNoteComponent>;
  let servicsData: NotesService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [AddNoteComponent],
      providers: [
        {
          provide: NotesService,
          useValue: {
            GetAllNotesByTaskID: () => of(GetAllNotesByTaskIDResponseData),
            getSubjectItems: () => of(getItemsdataResponse),
            SaveNotes: () => of(saveNotesResponse),
          },
        },
        {
          provide: MatDialogRef,
          useValue: mockDialogRef,
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserID: () => of(37485),
            getUserName: () => of("test"),
          },
        },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userId: 27398,
              minorVersion: 1,
              appName: "ENT",
              version: 21.02,
              agencyID: 691,
            },
          },
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserFullName: () => of("test test"),
            getUserName: () => of("test"),
          },
        },
        FormBuilder,
        { provide: "HOST", useValue: "test" },
        MatDialog,
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockRecord,
        },
        {
          provide: ToastrAlertService,
          useValue: {
            error: () => of("error", "Incorrect File size or File type"),
          },
        },
        {
          provide: FileService,
          useValue: {
            isValidFile: () => true,
            FileUpload: () => of(FileUploadResponseData),
            downloadFile: () => of({}),
          },
        },
      ],
      imports: [
        MatDialogModule,
        HttpClientModule,
        FormsModule,
        DropdownListModule,
        ReactiveFormsModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddNoteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeDefined();
  });

  it("should call saveBulkNotes", async () => {
    await component.saveBulkNotes(
      {
        "691": {
          AideIDs: ["test"],
          taskIds: ["test"],
        },
      },
      {}
    );
    expect(component.show).toEqual(false);
    component.closeDialog("Closed");
  });
  it("should call changeListener Functions", () => {
    const blob = new Blob(["test text"], { type: "text/plain" });
    blob["name"] = "foo";
    var files = [blob];
    component.changeListener({ target: { files } });
    component.displayFileName = "npm.png";
    expect(component.fileUploadedValidate).toEqual(true);
  });

  it("tests the exit button click", fakeAsync(() => {
    component.srUploadAlert();
    tick(700);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.alertMsg = "";
      expect(component.alertMsg).toBe("");
    });
  }));
  it("it's should call saveNote", () => {
    component.show = true;
    component.fileUpload = true;
    component.saveNote();
    component.fileData = "image/jpeg";
    component.fileUploadData.append("i1.jpg", component.fileData);
    component.fileUploadData.append("MethodType", "save");
    component.fileUploadData.append("UserID", "88");
    component.fileUploadData.append(
      "Module",
      component.data.workListID === 1 ? "Aide" : "Patient"
    );
    component.fileUploadData.append("FileGUID", "");
    component.data.record = [mockRecord, mockRecord];
    expect(component.fileGUID).toEqual("testGUID");
    component.saveNotes();
  });
  it("it's shuld call toggle", () => {
    component.toggle();
    expect(component.isHidden).toEqual(true);
  });
  it("it's shuld call downloadFile", () => {
    let record = {
      fileGuid: "1234",
      attachmentName: "1.jpg",
    };
    component.downloadFile(record);
    expect(component._fileService.downloadFile).toBeDefined();
  });
  it("it's shuld call srUploadAlert", () => {
    component.srUploadAlert();
    expect(component.alertMsg).toEqual("Opening Attachment Window");
  });
});
