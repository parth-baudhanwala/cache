import { TestBed, getTestBed } from "@angular/core/testing";
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FileService } from "./file.service";
import { SessionStorageService } from "./session-storage.service";
import { FileUploadResponseData } from "../services-mock-data/notes.service.mock";

describe("FileService", () => {

  let service: FileService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        SessionStorageService,
        { provide: "HOST", useValue: "test" },

      ],
    });
    injector = getTestBed();
    service = injector.inject(FileService);
    httpMock = injector.inject(HttpTestingController);
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });


  it("FileService should be created", () => {
    expect(service).toBeDefined();
  });
  it("BroadCastService FileUpload", () => {
    var formData = new FormData();
    service.FileUpload(formData).subscribe((res) => {
      expect(res).toEqual(FileUploadResponseData);
    });
    const request = httpMock.expectOne( 'File/UploadDocument');
    expect(request.request.method).toBe('POST');
    request.flush(FileUploadResponseData);
  });

  it("BroadCastService isValidFile", () => {
    let $event = {target: {files: [{name: 'fileName.png', size: 3213}]}}    
    expect(service.isValidFile($event.target)).toBe(true)
    $event = {target: {files: [{name: 'fileName.png', size: 322222213}]}}
    expect(service.isValidFile($event.target)).toBe(false)
  });

});
