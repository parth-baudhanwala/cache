export default (url: string, w: number, h: number, callback: Function) => {
  // Fixes dual-screen position   Most browsers || Firefox
  const dualScreenLeft = window.screenX || window.screenLeft || 0;
  const dualScreenTop = window.screenY || window.screenTop || 0;

  const width =
    window.innerWidth || document.documentElement.clientWidth || screen.width;
  const height =
    window.innerHeight ||
    document.documentElement.clientHeight ||
    screen.height;

  const left = width / 2 - w / 2 + dualScreenLeft;
  const top = height / 2 - h / 2 + dualScreenTop;
  const newWindow = window.open(
    url,
    "_blank",
    `toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no,
     width=${w}, height=${h}, top=${top}, left=${left}`
  );

  // Puts focus on the newWindow
  if (window.focus) {
    newWindow.focus();
  }

  var popupTick = setInterval(function () {
    if (newWindow.closed) {
      clearInterval(popupTick);
      if (callback) newWindow.onbeforeunload = callback();
    }
  }, 500);
};
