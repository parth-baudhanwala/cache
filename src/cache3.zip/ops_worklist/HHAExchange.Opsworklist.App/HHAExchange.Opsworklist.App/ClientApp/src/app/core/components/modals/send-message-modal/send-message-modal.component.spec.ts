import { HttpClientModule } from "@angular/common/http";
import { ComponentFixture, fakeAsync, TestBed, tick, waitForAsync } from "@angular/core/testing";
import { FormBuilder, FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from "@angular/material/dialog";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { DeliveryMethodType } from "@app/core/models/send-message-modal.model";
import {
  GetCommunicationScript,
  getMessageByScriptIdResponse,
} from "@app/core/services-mock-data/common.service.mock";
import { FileUploadResponseData } from "@app/core/services-mock-data/notes.service.mock";
import { sendBroadCastSendMessageDataResponse } from "@app/core/services-mock-data/search-field.service.mock";
import { BroadCastService } from "@app/core/services/broadcast.service";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { FileService } from "@app/core/services/file.service";
import {
  DatepickerModule,
  DropdownListModule,
  FormLabelModule,
  InputModule,
  TextareaModule,
  ToastrAlertService,
} from "hhax-components";
import { RadioButtonModule } from "@app/core/components/hhax-components/radio-button/radio-button.module";
import { of } from "rxjs";
import { NotesService } from "@app/core/services/notes.service";
import { HHAUserService } from "@app/core/authentication/user.service";
import { SendMessageModalComponent } from "./send-message-modal.component";

let mockRecord = {
  title: "Send Message",
  record: {
    expirationItemType: "Medical",
    expirationItem: "01 Aesha",
    dueDate: "2021-05-30T00:00:00",
    careGiverCode: "HHA-3329",
    careGiverId: "979013",
    careGiverTeamId: 0,
    careGiverFirstname: "Yumery123",
    careGiverLastname: "Fabian",
    careGiverMiddlename: "",
    careGiverFullName: "Yumery123 Fabian",
    worklistTaskId: 57660,
    worklistId: 1,
    officeId: 852,
    assignedBy: null,
    assignedTo: null,
    assignedByUser: null,
    assignedToUser: null,
    createdDate: "2021-04-30T02:11:17.860802",
    status: "Open",
    lastNotes: null,
    worklistEntKey: "6664",
  },
};
describe("SendMessageModalComponent", () => {
  const mockDialogRef = {
    close: jasmine.createSpy("close"),
  };
  let component: SendMessageModalComponent;
  let fixture: ComponentFixture<SendMessageModalComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [SendMessageModalComponent],
      providers: [
        {
          provide: MatDialogRef,
          useValue: mockDialogRef,
        },
        FormBuilder,
        {
          provide: BroadCastService,
          useValue: {
            sendBroadCastDetails: () =>
              of(sendBroadCastSendMessageDataResponse),
          },
        },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              agencyID: 691,
              userId: 27398,
              AppVersion: "ENT",
              Version: 21.02,
              MinorVersion: 1,
              ProviderID: 691,
              userOffices: [{ officeID: "123" }],
            },
          },
        },
        {
          provide: ToastrAlertService,
          useValue: {
            error: () => of("error", "Incorrect File size or File type"),
            success: () => of("success", "Send Message Sent successfully."),
          },
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockRecord,
        },
        {
          provide: CommonService,
          useValue: {
            getScriptData: () => of(GetCommunicationScript),
            getMessageByScriptId: () => of(getMessageByScriptIdResponse),
          },
        },
        {
          provide: FileService,
          useValue: {
            isValidFile: () => true,
            FileUpload: () => of(FileUploadResponseData),
          },
        },
        {
          provide: "HOST",
          useValue: "test",
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserID: () => of(37485),
            getUserName: () => of("test"),
            getUserFullName: () => of("Test Test"),
          },
        },
        {
          provide: NotesService,
          useValue: {
            SaveNotes: () => of("saved"),
          },
        },
      ],
      imports: [
        MatDialogModule,
        HttpClientModule,
        ReactiveFormsModule,
        FormsModule,
        BrowserAnimationsModule,
        DropdownListModule,
        InputModule,
        TextareaModule,
        RadioButtonModule,
        DatepickerModule,
        FormLabelModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendMessageModalComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeDefined();
    component.closeDialog("Closed");
  });
  it("form invalid when empty", () => {
    expect(component.sendMessageForm.valid).toBeFalsy();
  });
  it("should call onDeliveryMethodChange", () => {
    var value = "2";
    component.onDeliveryMethodChange({ target: { value } });
    expect(component.emailDeliveryMethod).toBe(value);
  });

  it("should call showSchedule Method", () => {
    component.showSchedule();
    expect(component.deliveryTime).toBe(true);
  });

  it("should call hideSchedule Method", () => {
    component.hideSchedule();
    expect(component.deliveryTime).toBe(false);
  });

  it("should call sendMessage Method", async () => {
    await component.sendMessage();
    expect(component.getMessageBroadcastParams).toBeDefined();
  });
  it("should call getMessageBroadcastParams Method", () => {
    let form = component.sendMessageForm.value;
    form.deliveryMethod = "";
    form.subject = "message";
    form.email = "test@gmail.com";
    form.scheduleDate = "05/05/2021";
    form.ScheduledFromTime = "test message";
    form.scheduleType = null;
    component.getMessageBroadcastParams();
    expect(component.payloadData["Subject"]).toEqual("message");
    form.subject = "";
    component.getMessageBroadcastParams();
    expect(component.payloadData["Subject"]).toEqual(null);
  });

  it("should call onFileUpload Method", () => {
    const blob = new Blob(["test text"], { type: "text/plain" });
    blob["name"] = "foo";
    var files = [blob];
    component.onFileUpload({ target: { files } });
    expect(component._fileService.isValidFile).toBeDefined();
  });

  it("should call onScriptChange Method", () => {
    const value = 1;
    component.onScriptChange({ target: { value } });
    expect(component._commonService.getMessageByScriptId).toBeDefined();
  });

  it("should call fetchRecipents", () => {
    component.data.record = [
      { careGiverFullName: "Jane" },
      { careGiverFullName: "Joe" },
    ];
    component.fetchRecipents();
    expect(component.recipients).toEqual(["Jane", "Joe"]);
  });

  it("should call resetForm", () => {
    const value = "3";
    component.resetForm(value);
    expect(value).toEqual(DeliveryMethodType.EMAIL);
  });
  it("should call autoGenerateNote", () => {
    component.autoGenerateNote({ worklistTaskId: 1 }, () => {});
    component.autoGenerateNote(
      [{ worklistTaskId: 1 }, { worklistTaskId: 1 }],
      () => {}
    );
    expect(component._notesService.SaveNotes).toBeDefined();
  });
  it("should call srUploadAlert Method", fakeAsync(() => {
    component.srUploadAlert();
    tick(700);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.alertMsg = "";
      expect(component.alertMsg).toBe("");
    });
  }));
  it("should call getFileGUID", () => {
    component.sendMessageResult = {
      responseBody: { broadCastModel: [], broadCastID: 1 },
      httpStatusCode: 200,
      httpStatusMessage: "any",
      authenticationToken: "any",
    };
    component.getFileGUID({});
    expect(component._fileService.FileUpload).toBeDefined();
  });
});
