import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanLoad, Route, Router, RouterStateSnapshot } from '@angular/router';
import { LocalStorageKeyNames, LocalStorageService } from '@app/core/services/local-storage.service';
import { Observable } from 'rxjs';
import { HHAUserService } from './user.service';


@Injectable()
export class HHAAuthGuard implements CanActivate, CanLoad {
  constructor(private router: Router, private userService: HHAUserService, private _localStorageService: LocalStorageService) {    
    }

  canActivate(route: ActivatedRouteSnapshot, _state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const canActivate = this.userService.isLoggedIn() && this.checkUserAccess();
    
    if (!canActivate) {
      this.router.navigate(['/forbidden']);
      return false;
    }
    return true; 
  }

  canLoad(state: Route): boolean {

    if (this.userService.isLoggedIn()) {
      return true;
    }
    return false;
  }

  private checkUserAccess(): boolean {
    let isAllowURL = false;
    var hasMenuAccess = this._localStorageService.getItem(LocalStorageKeyNames.hasAccess);
    if (hasMenuAccess) {
      isAllowURL = true;
    } else {
      isAllowURL = false;
    }
    return isAllowURL;
  }
}


