import {
  HttpErrorResponse, HttpEvent,

  HttpHandler, HttpInterceptor,

  HttpRequest
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { HHAUserService } from './user.service';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class HttpErrorInterceptor implements HttpInterceptor {
  constructor(private router: Router,private _userService: HHAUserService) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request)
      .pipe(
        retry(1),
        catchError((error: HttpErrorResponse) => {
          if (error.status === 401) {
            this._userService.logoutUser();
          }
          if ((error.status === 0 && error.statusText == 'Unknown Error') || (error.status === 403)) {            
            this.router.navigate(['/forbidden']);            
          }
            return throwError(error);
        })
      );
  }
}
