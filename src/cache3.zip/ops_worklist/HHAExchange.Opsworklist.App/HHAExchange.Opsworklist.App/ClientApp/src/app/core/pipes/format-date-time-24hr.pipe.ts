import { Pipe, PipeTransform } from '@angular/core';
import moment from 'moment';

@Pipe({
  name: 'formatDateTime24hr'
})
export class FormatDateTime24hr implements PipeTransform {
  transform(value: Date, defaultStr: string = ""): string {
    return value != null ? moment(value).format('MM/DD/YYYY HH:mm') : defaultStr
  }
}
