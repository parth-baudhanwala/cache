import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { LinkComponent } from './link.component';
import { LinkIconComponent } from '../link-icon/link-icon.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

describe('LinkComponent', () => {
  let component: LinkComponent;
  let fixture: ComponentFixture<LinkComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        LinkComponent,
        LinkIconComponent
      ],
      imports: [
        FontAwesomeModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
