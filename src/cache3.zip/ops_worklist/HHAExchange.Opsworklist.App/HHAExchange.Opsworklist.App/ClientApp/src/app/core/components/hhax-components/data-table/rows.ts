import { Directive, TemplateRef, ViewContainerRef, Component } from '@angular/core';

@Directive({selector: '[hhaxRowDef]'})
export class DataTableRowDefinition {
  constructor(
    public _viewContainer: ViewContainerRef,
    public _templateRef: TemplateRef<any>) {}
}

@Component({
  selector: 'tr[hhax-row]',
  template: '<ng-container hhaxCellOutlet></ng-container>'
})
export class DataTableRowComponent { }

@Directive({selector: '[hhaxRowOutlet]'})
export class DataTableRowOutlet {

  static currentRowOutletInstance: DataTableRowOutlet = null;

  constructor(public _viewContainer: ViewContainerRef) {
    DataTableRowOutlet.currentRowOutletInstance = this;
  }
}
