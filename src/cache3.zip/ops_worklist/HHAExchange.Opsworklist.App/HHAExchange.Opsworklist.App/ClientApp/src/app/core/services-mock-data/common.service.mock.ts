import { IScriptData } from "../models/scripts.model";

export const GetWlTaskStatusCount = [
  {
    worklistID: 1,
    taskCount: 2,
  },
  {
    worklistID: 2,
    taskCount: 3,
  },
];

export const GetCommunicationScript = {
  responseBody: [
    {
      templateId: 3823,
      description: "AN Test Voice Script",
    },
    {
      templateId: 3765,
      description: "Ashish Voice Test",
    },
    {
      templateId: 3762,
      description: "sss",
    },
    {
      templateId: 3514,
      description: "test",
    },
    {
      templateId: 3764,
      description: "testing",
    },
    {
      templateId: 3847,
      description: "Testing_100",
    },
    {
      templateId: 3837,
      description: "testing_200",
    },
    {
      templateId: 3783,
      description: "TESTING_VOICE",
    },
    {
      templateId: 3784,
      description: "Voice OpsWorklist",
    },
    {
      templateId: 3828,
      description: "Voice Test HHH",
    },
    {
      templateId: 3771,
      description: "VOICE_1OCT_2020",
    },
    {
      templateId: 3406,
      description: "voice_broadcast_4227_voice_testing",
    },
    {
      templateId: 3786,
      description: "VOICE_SHRI_DESC",
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const GetUsersByWorklistIDResponse = [
  {
    userID: 27398,
    userName: "shekhussp",
    firstName: "Shekhar",
    lastName: "Pandey",
    name: "Shekhar Pandey",
  },
];

export const getMessageByScriptIdResponse: IScriptData = {
  responseBody: [
    {
      templateID: 3784,
      templateTypeId: 1,
      description: "Voice OpsWorklist",
      message: "",
      subject: "",
      bcc: "",
      format: 0,
      attachment: "",
      priority: 0,
      language: 0,
      type: 0,
      isIVRVoiceFile: false,
      voiceFilePath: "",
      emailAttachmentGUID: "00000000-0000-0000-0000-000000000000",
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const UpdateStatusResponse = {
  responseBody: "Number of records updated 1",
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const closingConditionResponse = {
  responseBody: "Closing condition performed.",
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};
