export enum OpsWorklistData {
  Module = "Caregiver",
  DeliveryOption = "1",
  ModuleID = "0",
  FeatureID = "0",
  Agency = "VENDOR",
  Feature = "ConexusEmail",
  FeatureNotes = "Notes",
  MethodTypeSave = "save",
  PatientModule = "Patient",
  AideModule = "AIDE",
  MethodTypeValidate = "validate"
}

export enum Events {
  REFRESH_WORKLIST_COUNT = "REFRESH_WORKLIST_COUNT"
}