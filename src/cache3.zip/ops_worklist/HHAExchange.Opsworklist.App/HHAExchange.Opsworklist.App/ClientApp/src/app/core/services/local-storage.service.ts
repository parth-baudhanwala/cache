import { Injectable } from '@angular/core';
import { LoggerService } from 'hhax-components';

@Injectable({
  providedIn: "root",
})
export class LocalStorageService {
  constructor(private _loggerService: LoggerService) { }

  public getItem<T>(key: LocalStorageKeyNames): T {
    const value = localStorage.getItem(key.toString());

    if (!value) {
      return null;
    }

    return JSON.parse(value) as T;
  }

  public setItem(key: LocalStorageKeyNames, value: any): void {
    if (!value) {
      this._loggerService.logError(
        `Local Storage value for: ${key.toString()}, could not be set to null or undefined`
      );
      return;
    }

    localStorage.setItem(key.toString(), JSON.stringify(value));
  }

  public removeItem(key: LocalStorageKeyNames): void {
    localStorage.removeItem(key.toString());
  }

  public destroyLocalStorage(): void {
    Object.keys(LocalStorageKeyNames).forEach((k) => {
      localStorage.removeItem(k);
    });
  }
}

export enum LocalStorageKeyNames {
  routePathName = "RoutePath",
  hasAccess = "Check",
  sessionID = "sessionID",
  userPrimaryOfficeID = "userPrimaryOfficeID",
  hhaKeyWordConfigurationSortedData = "hhaKeyWordConfigurationSortedData",
  mobileChatUrl = "mobileChatUrl",
  changePassword = "changePassword",
  contactSupportRedirectUrl = "ContactSupportRedirectUrl",
  liveChat = "LiveChat",
  mfaCookieName = "MFACookieName",
  mfaSettings = "MFASettings",
  remoteSupport = "RemoteSupport",
  supportCenterRedirectUrl = "SupportCenterRedirectUrl",
  tXSupportCenterRedirectUrl = "TXSupportCenterRedirectUrl",
  isTexasRedirection = "IsTexasRedirection",
  fileSizeLimit = "FileSizeLimit",
  emailFileSizeLimit = "EmailFileSizeLimit",
  allowedFileTypes = "AllowedFileTypes",
  isReskinFeatureEnable = "ToggleValue",
  reskinSupportCenterRedirectUrl = "ReskinSupportCenterRedirectUrl",
  txPaidSupportCenterRedirectUrl = "TXPaidSupportCenterRedirectUrl",
  environmentDescription = "EnvironmentDescription",
  isVendorIn12HourFormat = "Vendor12HourFormat",
  providerAdminAPIUrl = "ProviderAdminAPIUrl",
  maxProviderDisciplinesOfficeResponseCount = "MaxProviderDisciplinesOfficeResponseCount",
  caregiverMessageLimit = "CaregiverMessageLimit",
  userInfo = "UserInfo",
  salesforceCustomerID = "SalesforceCustomerID"
}
