import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrAlertService } from "hhax-components";
import { OpsWorklistSetupBaseComponent } from '../../../core/components/base-component/ops-worklist-setup-base.component';
import { caregiverStatusOptions, employeeTypeOptions } from '../../../core/config/static-options';
import { WorklistName } from '../../../core/models/common.model';
import { MedicalComplianceSetupModel } from '../../../core/models/worklist-setup.model';
import { ConfigurationService } from '../../../core/services/configuration.service';
import { OpsWorklistSetupService } from '../../../core/services/ops-worklist-setup.service';

@Component({
  selector: 'app-medical-compliance-setup',
  templateUrl: './medical-compliance-setup.component.html'
})
export class MedicalComplianceSetupComponent extends OpsWorklistSetupBaseComponent implements OnInit {

  worklistSetupTabName = WorklistName.MEDICAL_COMPLIANCE;
  employeeTypeOptions = employeeTypeOptions;
  caregiverTaskCreationStatusOptions = caregiverStatusOptions;
  medicalComplianceSetupGroup: FormGroup;

  constructor(
    private _alert: ToastrAlertService,
    private _config: ConfigurationService,
    private _opsWorklistSetupService: OpsWorklistSetupService) {
    super();
  }

  ngOnInit(): void {
    super.ngOnInit();

    this.medicalComplianceSetupGroup = new FormGroup(
      {
        employeeType: new FormControl(-1),
        taskCreation: new FormControl(30),
        taskCreationByStatus: new FormControl([1])
      }
    );

    this.getSetup();
  }

  getSetup(): void {
    this._opsWorklistSetupService.getMedicalComplianceSetup(this._config.appConfiguration.agencyID).subscribe({
      next: (medicalComplianceSetupModel) => {
        if (medicalComplianceSetupModel) {
          this.medicalComplianceSetupGroup.controls.employeeType.setValue(medicalComplianceSetupModel.employeeTypeId);
          this.medicalComplianceSetupGroup.controls.taskCreation.setValue(medicalComplianceSetupModel.taskCreationDays);

          const taskCreationByStatusArray = medicalComplianceSetupModel.caregiverStatusIds.split(",").map(x => Number(x));

          if (taskCreationByStatusArray.length == caregiverStatusOptions.length) {
            taskCreationByStatusArray.push(-1);
          }

          this.medicalComplianceSetupGroup.controls.taskCreationByStatus.setValue(taskCreationByStatusArray);
        }
      },
      error: () => this._alert.error("Error", "There was an error while getting information.")
    });
  }

  onSubmit(): void {
    const taskStatusIndex = this.medicalComplianceSetupGroup.get("taskCreationByStatus").value.findIndex(el => el == -1);

    if (taskStatusIndex != -1) {
      this.medicalComplianceSetupGroup.get("taskCreationByStatus").value.splice(taskStatusIndex, 1)
    }

    if (this.formValidation()) {
      const employeeTypeId: number = this.medicalComplianceSetupGroup.get("employeeType").value;
      const employeeType: string = employeeTypeOptions.find(x => x.value == employeeTypeId).text;
      const caregiverStatusIds: string = this.medicalComplianceSetupGroup.get("taskCreationByStatus").value;

      let caregiverStatusArray: string[] = [];

      for (let index = 0; index < caregiverStatusIds.length; index++) {
        let caregiverStatusText = caregiverStatusOptions.find(x => x.value == caregiverStatusIds[index]).text;
        caregiverStatusArray.push(caregiverStatusText);
      }

      const caregiverStatus = caregiverStatusArray.join(",");

      const medicalComplianceSetupModel: MedicalComplianceSetupModel = {
        providerId: this._config.appConfiguration.agencyID,
        employeeTypeId: employeeTypeId,
        employeeType: employeeType,
        taskCreationDays: this.medicalComplianceSetupGroup.get("taskCreation").value,
        caregiverStatusIds: caregiverStatusIds.toString(),
        caregiverStatus: caregiverStatus,
        userId: this._config.appConfiguration.userId,
        userName: this._config.appConfiguration.userName
      }

      this._opsWorklistSetupService.saveMedicalComplianceSetup(medicalComplianceSetupModel).subscribe(
        {
          complete: () => this._alert.success("Success", "Information has been saved successfully."),
          error: () => this._alert.error("Error", "There was an error while saving information.")
        }
      );
    }
  }

  formValidation(): boolean {
    let isFormValid = true;
    let messageError;
    const taskCreationValue = this.medicalComplianceSetupGroup.get("taskCreation").value;
    const taskCreationByStatusValue = this.medicalComplianceSetupGroup.get("taskCreationByStatus").value;

    if (!taskCreationValue && !taskCreationByStatusValue.length) {
      messageError = "Value required for Task Creation and Task Creation by Status.";
      isFormValid = false;
    }
    else if (taskCreationValue <= 0 && !taskCreationByStatusValue.length) {
      messageError = "Task Creation value should not be 0 and Value required for Task Creation by Status.";
      isFormValid = false;
    }
    else if (!taskCreationValue) {
      messageError = "Value required for Task Creation.";
      isFormValid = false;
    }
    else if (!taskCreationByStatusValue.length) {
      messageError = "Value required for Task Creation by Status.";
      isFormValid = false;
    }
    else if (taskCreationValue <= 0) {
      messageError = "Task Creation value should not be 0.";
      isFormValid = false;
    }

    if (!isFormValid) {
      this._alert.error("Error", messageError);
    }

    return isFormValid;
  }
}
