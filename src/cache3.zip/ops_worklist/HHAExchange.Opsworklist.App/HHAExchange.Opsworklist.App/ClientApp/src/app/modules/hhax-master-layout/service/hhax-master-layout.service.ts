import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { BaseHttpService } from '../../../core/services/base.http.service';
import { ConfigurationService } from '../../../core/services/configuration.service';
import { MachineModel, MenuModel, NotificationModel } from '../hhax-master-layout.model';

@Injectable({
  providedIn: 'root'
})
export class HhaxMasterLayoutService extends BaseHttpService {

  constructor(public httpClient: HttpClient, config: ConfigurationService) {
    super(httpClient, config);
  }

  getMenuList(payload): Observable<MenuModel[]> {
    return this.get<MenuModel[]>("MasterLayout/GetMenuList", payload);
  }

  getMachineDetails(): Observable<MachineModel> {
    return this.get<MachineModel>("MasterLayout/GetMachineInfo");
  }

  getTokenForMobileChatApi(): Observable<string> {
    return this.httpClient.get(`${this.apiUrl}OAuth/GetTokenForMobileChatApi`, { responseType: "text" });
  }

  getNotificationDetail(payload): Observable<NotificationModel> {
    return this.get<NotificationModel>("MasterLayout/GetNotifications", payload);
  }
}
