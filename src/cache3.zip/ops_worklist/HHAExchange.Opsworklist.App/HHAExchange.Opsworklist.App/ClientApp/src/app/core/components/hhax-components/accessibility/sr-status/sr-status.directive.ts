import { Directive, HostBinding } from '@angular/core';

/**
 * Turns the host into a status element for screen readers that
 * reads out status changes politely.
 */
@Directive({
  selector: '[srPoliteStatus]'
})

export class SrPoliteStatusDirective {

  /**
   * Sets the role to 'status'.
   */
  @HostBinding('attr.role') role = 'status';

  /**
   * Sets the aria-live type to 'polite'.
   */
  @HostBinding('attr.aria-live') ariaLive = 'polite';

}