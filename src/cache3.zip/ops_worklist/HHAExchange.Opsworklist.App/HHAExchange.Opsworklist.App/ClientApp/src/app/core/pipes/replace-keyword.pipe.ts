import type { PipeTransform } from "@angular/core";
import { Pipe } from "@angular/core";

@Pipe({
  name: "replaceKeyword",
})
export class ReplaceKeywordPipe implements PipeTransform {
  public transform(value: string): string {
    try {
      const jsonString = localStorage.getItem(
        "hhaKeyWordConfigurationSortedData"
      );

      if (jsonString !== null) {
        const data = JSON.parse(jsonString);

        /* allocate separate variables for each item inside data[key] list for more readability that's why disabled guard-for-in eslint rule*/
        // eslint-disable-next-line guard-for-in
        for (const key in data) {
          const currentKeyword = data[key][0];
          const expectedKeyword = data[key][1];

          if (value.includes(currentKeyword)) {
            value = value.replaceAll(currentKeyword, expectedKeyword);
          } else if (value.includes(currentKeyword.toLowerCase())) {
            value = value.replaceAll(
              currentKeyword.toLowerCase(),
              expectedKeyword.toLowerCase()
            );
          }
        }
      }
    } catch {
      return value;
    }

    return value;
  }
}
