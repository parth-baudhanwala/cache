// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { BaseHttpService } from '@app/core/services/base.http.service';
// import { AutocompleteComponent } from './autocomplete.component';
// import { of } from 'rxjs';
// import { autocompleteOptions } from '@app/core/services-mock-data/auto-complete.service.mock';
// import { LoggerService } from 'hhax-components';
// import { HttpClientModule } from '@angular/common/http';
// import { MatAutocompleteModule } from '@angular/material/autocomplete';
// import { NG_VALUE_ACCESSOR } from '@angular/forms';
// import { forwardRef, SimpleChange } from '@angular/core';


// // const placeholder: string = "";
// // const id = "12";
// // const label = "autocomplete";
// // const getUrl = "http://localhost:5000/SearchTask/GetCaregiver";
// // const getParams = {
// //   caregiver: "a",
// //   criteria: 1,
// //   count: 10
// // };

// describe('AutocompleteComponent', () => {
//   let component: AutocompleteComponent;
//   let fixture: ComponentFixture<AutocompleteComponent>;

//   let service: BaseHttpService


//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [AutocompleteComponent],
//       providers: [
//         {
//           provide: BaseHttpService, useValue: {
//             get: () => of(autocompleteOptions)
//           }
//         },
//         {
//           provide: NG_VALUE_ACCESSOR,
//           multi: true,
//           useExisting: forwardRef(() => AutocompleteComponent),
//         },
//         {
//           provide: LoggerService, useValue: {
//             logError: "Form control expected value of type 'string' or 'number', but instead received value of type"
//           }
//         }
//       ],
//       imports: [
//         HttpClientModule,
//         MatAutocompleteModule
//       ]
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AutocompleteComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });
//   it("should create", () => {
//     expect(component).toBeDefined();
//   });
//   it("should auto complete length", () => {
//     component.ngOnInit();
//     component.isLoading = false;
//     expect(component.autocompleteOptions).toEqual(autocompleteOptions);
//   });
//   it("should auto complete length", () => {
//     expect(component.autocompleteOptions.length).toBeGreaterThan(0);
//   });
//   it("should auto registerOnChange", () => {
//     const value = "string";
//     component.registerOnChange(value);
//     component.value = value;
//     component.control.setValue(component.value);
//   });
//   it("should auto displayFn", () => {
//     component.displayFn(1);
//     spyOn(service,'get').and.returnValue(of([{id: 1,name: "test"}]))
//   });
//   it("should auto sendOption", () => {
//     const option: any = "string";
//     const event = {
//       isUserInput: true
//     }
//     component.sendOption(event, option);
//     event.isUserInput = true
//     component.selectedOption.emit(option);
//   });

//   it("should auto registerOnTouched", () => {
//     const fn: any = {}
//     component.registerOnTouched(fn);
//     expect(component.onBlur).toEqual(fn);
//   });

//   it("should auto writeValue", () => {
//     const value: string = "string";
//     component.writeValue(value);
//     typeof value === "string" || typeof value === "number" || value === null;
//     component.value = value;
//   });

//   it("should auto writeValue", () => {
//     const value: string = "string";
//     component.writeValue(value);
//     typeof value === "string" || typeof value === "number" || value === null;
//     component.value = value;
//   });

//   it("should call  ngOnchanges", () => {
//     let prev_value = {patient: "", criteria: 1, count: 10}
//     let new_value = {patient: "a", criteria: 1, count: 10}
//     let is_first_change: boolean = false;
    
//     // component.ngOnChanges({
//     //   prop1: new SimpleChange(prev_value, new_value, is_first_change),
//     // });
//     expect(component.ngOnChanges).toEqual({
//         prop1: new SimpleChange(prev_value, new_value, is_first_change),
//       })
//   });
// });

