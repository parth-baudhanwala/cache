import { Component } from '@angular/core';

@Component({
  template: '<td>{{value}}</td>'
})
export class DataTableCellComponent {
  value: string | number;
}
