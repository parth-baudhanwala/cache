import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SilentRefreshRoutingModule } from './silent-refresh-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SilentRefreshRoutingModule
  ]
})
export class SilentRefreshModule { }
