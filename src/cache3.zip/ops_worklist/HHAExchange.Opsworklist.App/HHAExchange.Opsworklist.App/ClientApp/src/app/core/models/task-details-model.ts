export class TaskDetailsModel {
  aideID: number;
  taskDetail: string;
  officeID: number;
  worklistTaskIds: string;
}
