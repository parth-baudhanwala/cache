import { Defaultparam } from "./defaultparam.model";

export class TaskNotes extends Defaultparam {
  WorklistTaskIds: string;
  Subject?: string;
  SubjectText: string;
  Note: string;
  FileAttachmentGUID?: string;
  AttachmentName?: string;
  CreatedBy: string;
  CreatedByUser: string;
  Result?: number;
  PatientIDs?: string;
  AideIDs?: string;
  CopyNotesTo?: string;
  OfficeID: number;
  CopyNoteToProfile?: boolean;
  IsInternalNote?: boolean;
}
export interface IGetAllNotesByTaskIDResult {
  worklistTaskNoteId: number;
  worklistTaskId: number;
  subject: string;
  note: string;
  fileGuid: string;
  attachmentName: string;
  createdBy: number;
  createdByUser: string;
  createdDate: Date;
  createdDateUtc: Date;
}

export interface IGetAllNotesByTaskID {
  result: IGetAllNotesByTaskIDResult[];
  id: number;
  exception?: any;
  status: number;
  isCanceled: boolean;
  isCompleted: boolean;
  isCompletedSuccessfully: boolean;
  creationOptions: number;
  asyncState?: any;
  isFaulted: boolean;
}

export interface saveAddNote {
  responseBody: number;
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface getUsersByWorklistIDData {
  userID: number;
  userName: string;
  firstName: string;
  lastName: string;
  name?: string;
}

export interface assignTaskModel {
  responseBody: string;
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface scriptDataModel {
  UserID: number;
  ProviderID: number;
  TemplateType: number;
  OfficeIDs: string;
}

export interface FileUploadValidate {
  uploadMessage: string;
  fileGUID?: any;
  isfileUploadedSucessfully: boolean;
}
