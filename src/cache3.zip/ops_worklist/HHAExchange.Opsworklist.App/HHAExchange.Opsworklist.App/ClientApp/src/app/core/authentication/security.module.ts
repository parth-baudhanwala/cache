import { NgModule } from '@angular/core';
import { AuthCallbackComponent } from './auth-callback.component';
import { SessionManagerService } from './session-manager.service';
import { SilentRefreshCallBackComponent } from './silent-refresh-callback.component';
import { TimeoutModalModule } from './timeout-modal/timeout-modal.module';
import { HHAUserService } from './user.service';



@NgModule({
    declarations: [
        AuthCallbackComponent,
        SilentRefreshCallBackComponent,
    ],
    imports: [
        TimeoutModalModule
    ],
    exports: [
        AuthCallbackComponent,
        SilentRefreshCallBackComponent,
    ],
    providers: [
        SessionManagerService,
        HHAUserService,
    ],
  })
  export class SecurityModule { }
