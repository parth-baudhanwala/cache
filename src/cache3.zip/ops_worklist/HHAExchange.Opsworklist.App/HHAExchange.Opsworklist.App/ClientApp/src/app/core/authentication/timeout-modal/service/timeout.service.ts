import { Inject, Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { configHelper } from '../../../config/static-options';
import { HHAUserService } from '../../user.service';
import { SessionConfig } from '../model/session.model';
import { TimeoutModalComponent } from '../timeout-modal.component';
import { DEFAULT_TIMEOUT_CONFIG } from '../token/default-token';

@Injectable({
  providedIn: 'root'
})
export class TimeoutService {
  sessionTimes: any

  constructor(  private _matDialog: MatDialog,
    public _idle: Idle,
    public _keepAlive: Keepalive,
    private _userService: HHAUserService,
    @Inject(DEFAULT_TIMEOUT_CONFIG) public timeoutConfig: SessionConfig) { }

  openTimeoutModal(): void {
    this._matDialog
      .open(TimeoutModalComponent, {
        width: '25%',
        ariaLabel: 'Session Timeout',
      })
      .afterClosed()
      .subscribe({
        next: () => {
          this._userService.startSilentRefresh();
          // The timeout that triggers this also stops both watchers
          this.startWatchers();
        },
      });
  }

  initalizeIdleWatcher(): void {
    this.sessionTimes = new Date();
    const sessionTimeoutMinute = localStorage.getItem("SessionTimeoutMinutes");
    const latestSessionTimeoutMinute = sessionTimeoutMinute ? sessionTimeoutMinute : configHelper.defaultSessionTimeoutMinute;
    const resetSessionCount = parseInt(latestSessionTimeoutMinute) * 60;
    this._idle.setIdle(this.timeoutConfig.idleDuration);
    this._idle.setTimeout(this._calculateTimeoutOffset());
    this._idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    this._idle.onTimeout.subscribe(() => {
      var endDate = new Date();
      var seconds = (endDate.getTime() - this.sessionTimes.getTime()) / 1000;
      this.openTimeoutModal();
      const obj = this;
      setTimeout(function () {
        if (!document.hasFocus()) {
          obj._userService.logoutUser();
        }
      }, resetSessionCount - seconds);
    });
    this._idle.watch();
  }

  initializeKeepAliveWatcher(): void {
    this._keepAlive.interval(this.timeoutConfig.tokenRefreshInterval);
    this._keepAlive.onPing.subscribe(() => {
      if (!this._idle.isIdling()) {
        this._userService.startSilentRefresh();
      }
    });
  }

  setSessionTime() {
    return this.sessionTimes;
  }
  updateSessionTime(time: any) {
    this.sessionTimes = time;
  }

  startWatchers(): void {
    this._idle.watch();
    this._keepAlive.start();
  }

  private _calculateTimeoutOffset(): number {
    const {
      idleDuration,
      sessionTimeout,
      timeoutModalDuration,
    } = this.timeoutConfig;

    return sessionTimeout - idleDuration - timeoutModalDuration;
  }
}
