export const autocompleteOptions = [
  {
    id: "Alan20161212175312|Bixby|EXQ-1495",
    name: "Alan20161212175312 Bixby (EXQ-1495)"
  },
  {
    id: "Asha|Kulkarni|HHA-16",
    name: "Asha Kulkarni (HHA-16)"
  },
  {
    id: "Ida|Aaron|500-83",
    name: "Ida Aaron (500-83)"
  },
  {
    id: "Abc|xyz|HHA-69",
    name: "Abc xyz (HHA-69)"
  },
  {
    id: "Nancy|Abbot|500-80",
    name: "Nancy Abbot (500-80)"
  },
  {
    id: "Ida|Aaron|EXQ-2096",
    name: "Ida Aaron (EXQ-2096)"
  },
  {
    id: "ah1|ah2|HHA-122",
    name: "ah1 ah2 (HHA-122)"
  }
]
