import { Injectable } from "@angular/core";
import { LocalStorageKeyNames } from '../services/local-storage.service';
import { Profile, User, UserManager } from "oidc-client";
import { isNullOrUndefined } from "util";
import { ConfigurationService } from "../services/configuration.service";
import { identityConfiguration } from "./identity-configuration";
import { configHelper } from "../config/static-options";
import { CommonService } from "@app/core/services/common.service";

@Injectable({
  providedIn: "root",
})
export class HHAUserService {
  private _manager: UserManager = null;
  private _user: User = null;

  constructor(
    private _configurationService: ConfigurationService,
    private _common: CommonService
  ) {
    const basePath = _configurationService.basePath;
    identityConfiguration.authority = _configurationService.getIdentityURL();
    identityConfiguration.redirect_uri = basePath + "auth-complete";
    identityConfiguration.post_logout_redirect_uri = basePath + "";
    identityConfiguration.silent_redirect_uri = basePath + "silent-refresh";
    this.setUserManager();
  }

  async setUserManager(): Promise<void> {
    this._manager = new UserManager(identityConfiguration);
    this._manager.events.addSilentRenewError(this._handleSilentRenewError);
    this._manager.events.addAccessTokenExpiring(() =>
      console.log("Access Expiring")
    );
    this._manager.events.addAccessTokenExpired(() => this.timeOutUser());

    return this._manager.getUser().then((user) => {
      this._user = user;
    });
  }

  isLoggedIn(): boolean {
    this.checkUser();
    return this._user != null && !this._user.expired;
  }

  getClaims(): Profile {
    return this.isLoggedIn() ? this._user.profile : null;
  }

  getUserName(): string {
    return this.isLoggedIn()
      ? this._user.profile[
      "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"
      ]
      : null;
  }

  getUserID(): number {
    return this.isLoggedIn()
      ? Number(
        this._user.profile[
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"
        ]
      )
      : null;
  }

  getVendorID(): number {
    return this.isLoggedIn() ? Number(this._user.profile["vendorid"]) : null;
  }

  getUserFullName(): string {
    return this.isLoggedIn()
      ? `${this._user.profile["firstname"]} ${this._user.profile["lastname"]}`
      : null;
  }

  getUser(): User {
    this.checkUser();
    return this._user;
  }

  getAuthorizationHeaderValue(): string {
    return this.isLoggedIn()
      ? `${this._user.token_type} ${this._user.access_token}`
      : null;
  }

  getAccessToken(): string {
    return this.isLoggedIn() ? `${this._user.access_token}` : null;
  }

  startAuthentication(): Promise<void> {
    if (this.isLoggedIn()) {
      throw new Error("User already logged in");
    }
    return this._manager.signinRedirect();
  }

  completeAuthentication(): Promise<void> {
    return this._manager.signinRedirectCallback().then((user) => {
      this._user = user;
    });
  }

  completeSilentRefresh(): Promise<void> {
    return this._manager.signinSilentCallback().then(() => {
      this._manager.stopSilentRenew();
      this._manager.getUser().then((u) => (this._user = u));
    });
  }

  logoutUser(): void {
    const userId = this.getUserID();
    if (userId != null) {
      this._common.deleteUserAuthenticationFromCache(userId).subscribe();
    }
    this.setHhaSessionTime();
    this._manager.createSignoutRequest().then((usr) => {
      const redirectURL = usr.url.split("?");
      const logoutURL = redirectURL[0] + "?id_token_hint=" + this._user.id_token + "&" + redirectURL[1];
      localStorage.clear();
      sessionStorage.clear();
      location.href = logoutURL;
    });
  }

  setHhaSessionTime(): void {
    const sessionTimeoutMinute = localStorage.getItem("SessionTimeoutMinutes");
    const latestSessionTimeoutMinute = sessionTimeoutMinute ? sessionTimeoutMinute : configHelper.defaultSessionTimeoutMinute;
    const currentTime = new Date().getTime();
    const resetSessionCount = currentTime - parseInt(latestSessionTimeoutMinute + latestSessionTimeoutMinute);
    if (location.host.includes(configHelper.domainName)) {
      document.cookie = configHelper.hhaSessionKey + "=" + resetSessionCount.toString() + ";secure;path=/;domain=" + configHelper.domainName;
    }
    else {
      document.cookie = configHelper.hhaSessionKey + "=" + resetSessionCount.toString() + ";secure;path=/;";
    }
  }

  startSilentRefresh(): Promise<void> {
    this._manager.startSilentRenew();
    return this._manager
      .signinSilent()
      .then((user) => {
        this._user = user;
      })
      .catch((error) => console.log(error));
  }
  private checkUser() {
    if (this._user === null || this._user === undefined) {
      const keyName =
        "oidc._user:" +
        identityConfiguration.authority +
        "/:HHAExchange.Opsworklist.Api";

      this._user = JSON.parse(sessionStorage.getItem(keyName));
    }
  }

  getDefaultRoute(): string {
    return "ops-worklist";
  }

  revokeAccessToken(): Promise<void> {
    return this._manager.revokeAccessToken();
  }

  timeOutUser(isForced: boolean = false): void {
    this._manager.getUser().then((user) => {
      this._user = user;
      if (isForced || this._user.expired) {
        this.revokeAccessToken().then(() => {
          this.logoutUser();
        });
      }
    });
  }

  private _handleSilentRenewError(error): void {
    console.error("Silent renew error:" + error);
  }

  getUserPrimaryOfficeID(): number {
    if (!isNullOrUndefined(localStorage.getItem(LocalStorageKeyNames.userPrimaryOfficeID))) {
      return Number(localStorage.getItem(LocalStorageKeyNames.userPrimaryOfficeID));
    }
    return 0;
  }

  getLSupportCenterRedirectUrl(): string {
    if (localStorage.getItem(LocalStorageKeyNames.isReskinFeatureEnable) && localStorage.getItem(LocalStorageKeyNames.reskinSupportCenterRedirectUrl) && localStorage.getItem(LocalStorageKeyNames.isReskinFeatureEnable).toUpperCase() == "YES") {
      if (localStorage.getItem(LocalStorageKeyNames.isTexasRedirection) && localStorage.getItem(LocalStorageKeyNames.isTexasRedirection) == '1') {
        var entFreeOrPaid: string = JSON.parse(localStorage.getItem(LocalStorageKeyNames.userInfo))?.agency_subscription_level;
        if (localStorage.getItem(LocalStorageKeyNames.txPaidSupportCenterRedirectUrl) && entFreeOrPaid && entFreeOrPaid.toUpperCase() == 'ENTERPRISE-PAID') {
          return JSON.parse(localStorage.getItem(LocalStorageKeyNames.txPaidSupportCenterRedirectUrl))
        }
        else if (localStorage.getItem(LocalStorageKeyNames.tXSupportCenterRedirectUrl)) {
          return JSON.parse(localStorage.getItem(LocalStorageKeyNames.tXSupportCenterRedirectUrl))
        }
      }
      return JSON.parse(localStorage.getItem(LocalStorageKeyNames.reskinSupportCenterRedirectUrl))
    } else if (localStorage.getItem(LocalStorageKeyNames.supportCenterRedirectUrl)) {
      return JSON.parse(localStorage.getItem(LocalStorageKeyNames.supportCenterRedirectUrl))
    }
    return '';
  }

  getFileSizeLimit(): number {
    if (localStorage.getItem(LocalStorageKeyNames.fileSizeLimit)) {
      return Number(JSON.parse(localStorage.getItem(LocalStorageKeyNames.fileSizeLimit)))
    }
    return 0;
  }

  getEmailFileSizeLimit(): number {
    if (localStorage.getItem(LocalStorageKeyNames.emailFileSizeLimit)) {
      return Number(JSON.parse(localStorage.getItem(LocalStorageKeyNames.emailFileSizeLimit)))
    }
    return 0;
  }

  getAlloweFileTypes(): string {
    if (localStorage.getItem(LocalStorageKeyNames.allowedFileTypes)) {
      return JSON.parse(localStorage.getItem(LocalStorageKeyNames.allowedFileTypes));
    }
    return "";
  }

  getIsUserNewskin(): boolean {
    const isNewskin = localStorage.getItem(LocalStorageKeyNames.isReskinFeatureEnable);
    if (isNewskin && isNewskin.toUpperCase() === "YES") {
      return true;
    } else {
      return false
    }
  }

  getVendor12HoursFlag(): boolean {
    const isVendorIn12Hours = localStorage.getItem(LocalStorageKeyNames.isVendorIn12HourFormat);
    if (isVendorIn12Hours && isVendorIn12Hours === "1") {
      return true;
    } else {
      return false;
    }
  }

  getCaregiverMessageLengthLimit(): number {
    if (localStorage.getItem(LocalStorageKeyNames.caregiverMessageLimit)) {
      return Number(JSON.parse(localStorage.getItem(LocalStorageKeyNames.caregiverMessageLimit)))
    }
  }
}


