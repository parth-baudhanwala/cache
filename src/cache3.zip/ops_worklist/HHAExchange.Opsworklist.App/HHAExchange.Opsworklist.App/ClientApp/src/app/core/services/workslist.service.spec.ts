import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { getTestBed, TestBed } from "@angular/core/testing";

import { Worklist } from "../models/common.model";
import { closingConditionResponse } from "../services-mock-data/common.service.mock";
import { SessionStorageService } from "./session-storage.service";
import { WorkslistService } from "./workslist.service";

describe("WorkslistService", () => {
  let service: WorkslistService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let closingConditionRequestData = {
    UserID: 27398,
    AppVersion: "ENT",
    Version: 21.02,
    MinorVersion: 1,
    ProviderID: 691,
    worklistId: 1,
    entKeys: ["6708-||-691-||-"],
    UpdatedByUser: "123",
    isFromOpsWorklist: true
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SessionStorageService, { provide: "HOST", useValue: "test" }],
    });
    injector = getTestBed();
    service = injector.inject(WorkslistService);
    httpMock = injector.inject(HttpTestingController);
  });
  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });

  it("WorkslistService should be created", () => {
    expect(service).toBeTruthy();
  });
  it("SearchFieldsService should call closingCondition", () => {
    service
      .closingCondition(
        Worklist.EXPIRING_AUTHORIZATION,
        closingConditionRequestData
      )
      .subscribe((res) => {
        expect(res).toBe(closingConditionResponse);
      });
    const request = httpMock.expectOne(
      "ClosingRules/CloseTask/ExpiringAuthorization"
    );
    expect(request.request.method).toBe("POST");
    request.flush(closingConditionResponse);
  });
});
