import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SrPoliteStatusDirective } from './sr-status/sr-status.directive';



@NgModule({
  declarations: [SrPoliteStatusDirective],
  imports: [
    CommonModule
  ],
  exports: [SrPoliteStatusDirective],
})
export class HhaxAccessibilityModule { }
