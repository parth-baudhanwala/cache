import { Component, OnInit, ElementRef, ViewChild } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { CookieService } from "ngx-cookie";
import { HHAUserService } from "@app/core/authentication/user.service";
import { BaseComponent } from "@app/core/components/base-component/base.component";
import { caregiverAutocomplete, closingConditionParams, TypeAheadCriteria, Worklist, } from "@app/core/models/common.model";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { FileService } from "@app/core/services/file.service";
import { NotesService } from "@app/core/services/notes.service";
import { SearchFieldsService } from "@app/core/services/search-fields.service";
import { WorkslistService } from "@app/core/services/workslist.service";
import { isBlank } from "@app/lib/utils";
import { BaseService, ToastrAlertService } from "hhax-components";
import { SessionStorageService } from "@app/core/services/session-storage.service";
import { configHelper } from "@app/core/config/static-options";
import { DatePipe } from '@angular/common';
import { LocalStorageKeyNames } from "@app/core/services/local-storage.service";

@Component({
  selector: "app-medical-or-compliance",
  templateUrl: "./medical-or-compliance.component.html",
  styleUrls: ["./medical-or-compliance.component.scss"],
  providers: [BaseService],
})
export class MedicalOrComplianceComponent
  extends BaseComponent
  implements OnInit {
  @ViewChild("medical", { read: ElementRef }) medical;
  workListGroup: FormGroup;
  actionUpdates: string;
  getAssignData: string;
  _gridPageSize: number = configHelper.pageSize10;
  isAuthenticationDone: boolean = false;
  actionButtons = [
    {
      label: "Refresh Status",
      handler: (x) =>
        this.refreshRecords(x, Worklist.MEDICAL_COMPLIANCE, () =>
          this.searchWorkLists()
        ),
    },
    {
      label: "Update Status to Open",
      handler: (x) =>
        this.updateStatus(x, "Open", () => this.searchWorkLists()),
    },
    {
      label: "Update Status to In-Progress",
      handler: (x) =>
        this.updateStatus(x, "In-Progress", () => this.searchWorkLists()),
    },
    {
      label: "Update Status to Closed",
      handler: (x) => this.updateClosedStatus(x, () => this.searchWorkLists()),
    },
    {
      label: "View/Add Notes",
      handler: (x) => this.openAddNoteDialog(x, () => this.searchWorkLists()),
      isModal: true,
    },
    {
      label: "Assign Task",
      handler: (x) =>
        this.openAssignTaskModal(x, this.getAssignData, () =>
          this.searchWorkLists()
        ),
      isModal: true,
    },
    {
      label: "Unassign Task",
      handler: (x) => this.unassignTask(x, () => this.searchWorkLists()),
    },
    {
      label: "Send Message",
      handler: (x) => this.sendMessageModal(x, () => this.searchWorkLists()),
      isModal: true,
    },
  ];
  caregiverGetParams: caregiverAutocomplete;
  taskNotesCount: number;
  closingConditionParams: closingConditionParams;

  constructor(
    public _searchservice: SearchFieldsService,
    public _fb: FormBuilder,
    public _dialogModal: MatDialog,
    public _config: ConfigurationService,
    public _userService: HHAUserService,
    public _alert: ToastrAlertService,
    public _common: CommonService,
    public _worklist: WorkslistService,
    public _notesService: NotesService,
    public _fileService: FileService,
    public cookieService: CookieService,
    public _storage: SessionStorageService,
    public _datePipe: DatePipe,
  ) {
    super(
      _config,
      _searchservice,
      _alert,
      _common,
      _dialogModal,
      _worklist,
      _userService,
      _fileService,
      _notesService,
      _storage,
      _datePipe
    );
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.checkAuthentication(this.AuthParams).subscribe((isValidUser: boolean) => {
      if (isValidUser) {
        if (this.worklistDetail.canManuallyCloseWorklistTask === "No") {
          this.actionButtons.forEach((button, index) => {
            if (button.label === "Update Status to Closed") {
              this.actionButtons[index].handler = async () => { };
              this.actionButtons[index]["isDisable"] = "true";
            }
          });
        }
        this.fetchSearchOptionsData();
        this.searchWorkLists(true);
        (this.workListGroup.get("caregiver") as FormControl).valueChanges.subscribe(
          (value: string) => {
            this.caregiverGetParams = {
              caregiver: value,
              providerId: this._userService.getVendorID(),
              officeId: this.workListGroup.get("officeID").value,
              criteria: TypeAheadCriteria.StartsWith,
              count: 10,
            };
          }
        );
        this.isAuthenticationDone = true;
      }
    });
  }

  fetchSearchOptionsData(): void {
    this.workListGroup = new FormGroup({
      expirationDuration: new FormControl("30"),
      teamID: new FormControl([]),
      caregiver: new FormControl(""),
      branchID: new FormControl([]),
      locationID: new FormControl([]),
      disciplineID: new FormControl([-1]),
      caregiverStatusID: new FormControl([1]),
      officeID: new FormControl([], Validators.required),
      assignee: new FormControl([]),
      status: new FormControl(["Open"]),
      languageID: new FormControl([-2, ...this.languageOptions.map((obj) => obj.value)]),
      expirationItem: new FormControl([
        -1,
        ...this.complianceExpOptions.map((obj) => obj.value),
      ]),
    });
    this.disciplineOptions = [];
    this.locationOptions = [];
    this.teamOptions = [];
    this.branchOptions = [];
    this.assigneeOptions = [];
    this.languageOptions = [];

    this.getLanguages();
    this.getAssignees({
      WorklistID: this.worklistDetail.worklistId,
      OfficeIDs: this.appConfig.userOffices
        .map((obj) => obj.officeID)
        .join(","),
    });
    this.complianceExpOptions = [];
    this.officeDependentSearchFields(this.params);
  }

  searchWorkLists(onInit = false): void {
    this.getParams = this.getSearchParams(onInit);
    this.gridPageSize = this._gridPageSize;
  }

  getSearchParams(onInit = false) {
    const formSubmittedData = this.workListGroup.value;
    const appConfig = this._config.appConfiguration;
    const params: any = {};
    if (onInit) {
      let userOfficeId: number[] | number;
      if (appConfig && appConfig.userOffices) {
        userOfficeId =
          appConfig.userOffices.length > 1
            ? appConfig.userOffices
              .filter((obj) => obj.isPrimary)
              .map((obj) => obj.officeID)
            : appConfig.userOffices[0].officeID;
      }
      params.status = "Open";
      params.officeID = userOfficeId;
      params.assignee = appConfig.userId;
      params.expirationDuration = "30";
      params.caregiverStatusID = 1;
    } else {
      if (
        !isBlank(formSubmittedData.officeID) &&
        formSubmittedData.officeID[0] !== -1
      )
        params.officeID = formSubmittedData.officeID;

      if (!isBlank(formSubmittedData.expirationDuration))
        params.expirationDuration = formSubmittedData.expirationDuration;

      if (
        !isBlank(formSubmittedData.assignee) &&
        formSubmittedData.assignee[0] !== -1
      )
        params.assignee = formSubmittedData.assignee;

      if (
        !isBlank(formSubmittedData.status) &&
        formSubmittedData.status[0] !== -1
      )
        params.status = formSubmittedData.status;

      if (!isBlank(formSubmittedData.teamID))
        formSubmittedData.teamID[0] === -1
          ? (params.teamID = -1)
          : (params.teamID = formSubmittedData.teamID);

      if (!isBlank(formSubmittedData.branchID)) {
        formSubmittedData.branchID[0] === -1
          ? (params.branchID = -1)
          : (params.branchID = formSubmittedData.branchID);
      }
      if (!isBlank(formSubmittedData.locationID))
        formSubmittedData.locationID[0] === -1
          ? (params.locationID = -1)
          : (params.locationID = formSubmittedData.locationID);

      if (!isBlank(formSubmittedData.caregiver))
        params.caregiver = formSubmittedData.caregiver;

      if (this.isUserInNewSkin) {
        params.disciplineID = this.setDisciplineIds(formSubmittedData.disciplineID);
      }
      else {
        if (!isBlank(formSubmittedData.disciplineID) && formSubmittedData.disciplineID[0] !== -1) {
          params.disciplineID = formSubmittedData.disciplineID;
        }
      }

      if (!isBlank(formSubmittedData.caregiverStatusID) &&
        formSubmittedData.caregiverStatusID[0] !== -1
      )
        params.caregiverStatusID = formSubmittedData.caregiverStatusID;

      if (
        !isBlank(formSubmittedData.languageID) &&
        formSubmittedData.languageID[0] !== -2 &&
        !isBlank(this.languageList) &&
        (this.languageList.length !== formSubmittedData.languageID.length)
      )
        params.languageID = formSubmittedData.languageID;
    }

    params.providerID = appConfig.agencyID;

    if (
      !isBlank(formSubmittedData.expirationItem) &&
      formSubmittedData.expirationItem[0] !== -1 &&
      !isBlank(this.complianceExpItemList) &&
      ((this.complianceExpItemList.length - 3) !== formSubmittedData.expirationItem.length)
    ) {
      params.expirationItem = formSubmittedData.expirationItem;
    }

    return params;
  }

  onSubmit(): void {
    this.searchWorkLists();
  }

  onReset(): void {
    (this.workListGroup.get("caregiver") as FormControl).setValue("");
    this.getOffices(this.params);
    this.getLanguages();
    this.workListGroup.patchValue({
      disciplineID: [-1, ...this.disciplineOptions.map((obj) => obj.value)],
      caregiverStatusID: [1],
      expirationDuration: "30",
      teamID: [],
      caregiver: "",
      branchID: [],
      locationID: [],
      status: ["Open"],
      assignee: [this.appConfig.userId],
      languageID: [-2, ...this.languageOptions.map((obj) => obj.value)],
      expirationItem: [-1, ...this.complianceExpOptions.map((obj) => obj.value)],
    });
    if (document.getElementsByClassName("mat-autocomplete-trigger")[0]) {
      const inputElement: HTMLInputElement = document.getElementsByClassName(
        "mat-autocomplete-trigger"
      )[0] as HTMLInputElement;
      inputElement.value = "";
    }
    this._gridPageSize = configHelper.pageSize10;
    this.searchWorkLists();
  }

  openNote(record) {
    this.openAddNoteDialog(record, () => this.searchWorkLists());
  }

  openiframe(x) {
    const pageName = this.isNewskin && this.isNewskin.toUpperCase() == "YES" ? 'Requirement_ns' : 'Requirement';
    const url = `${this._config.appConfiguration.entpurl
      }General/${pageName}?s=${this.cookieService.get("HHAX_Session")}&AideID=${x.data.careGiverId
      }&SortField=SortOrder&SortDir=DESC&time=${new Date().getTime()}&ViewAllMedical=0&ViewAllEvaluation=0&officeID=${x.data.officeId
      }`;
    this.openIFrame(x, url, () => this.searchWorkLists());
  }

  openPopUp(row) {
    let entMailUrl = this._config.appConfiguration.entMainURL;
    entMailUrl += entMailUrl.endsWith("/") ? "" : "/";
    const pageName = this.isNewskin && this.isNewskin.toUpperCase() == "YES" ? 'Aide_ns' : 'Aide';
    const url = `${entMailUrl}Aide/${pageName}.aspx?AideId=${row.data.careGiverId}`;
    this.openWindowPopUp(url, row, Worklist.MEDICAL_COMPLIANCE, () =>
      this.searchWorkLists()
    );
  }

  public get isNewskin() {
    return localStorage.getItem(LocalStorageKeyNames.isReskinFeatureEnable);
  }

  onAssigneeClick(record, assignee) {
    this.openAssignTaskModal(record, assignee, () => this.searchWorkLists());
  }

  complianceItemSelectedChange($event): void {
    this.workListGroup.patchValue({
      expirationItem: [...$event],
    });
  }

  languageItemSelectedChange($event): void {
    this.workListGroup.patchValue({
      languageID: [...$event],
    });
  }

  pageSizeSelectedChange() {
    this.searchWorkLists();
  }
}
