import {
  AfterContentInit, ChangeDetectorRef, Component,
  ContentChildren,
  ElementRef, HostListener, Input, OnDestroy,
  QueryList,
  Renderer2,
  ViewChild
} from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Key } from 'ts-key-enum';
import {
  AlignLinkRightDirective,
  LinkComponent
} from './link/link.component';


let uniqueIdTracker = 0;
@Component({
  selector: 'hhax-navigation-header',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent implements OnDestroy, AfterContentInit {

  @Input() public logoRoute = '/home';
  @Input() public logoSrc = 'assets/logo_hhax-white.svg';
  @Input() logoAriaLabel: string;
  @Input() public projectTitle = '';

  @ViewChild('leftContainer', { read: ElementRef, static: true })
  private _leftContainer: ElementRef;
  @ViewChild('rightContainer', { read: ElementRef, static: true })
  private _rightContainer: ElementRef;

  @ContentChildren(LinkComponent)
  private _leftAlignedComponents: QueryList<LinkComponent>;
  @ContentChildren(AlignLinkRightDirective)
  private _rightAlignedItems: QueryList<AlignLinkRightDirective>;

  isNavBarDisplayed: boolean;
  id = `hhax-navigation-${uniqueIdTracker++}`;
  private _routeEventSubscription: Subscription;
  private _activeElement;


  // Keyboard navigation for accessibility.
  @HostListener('window:keydown', ['$event']) keyEvent(event: KeyboardEvent) {
    if (event.key === Key.ArrowLeft || event.key === Key.ArrowRight) {
      this.handleMenuNavigation(event);
    }
  }

  constructor(
    public changeDetectorRef: ChangeDetectorRef,
    private _router: Router,
    private _renderer: Renderer2) {
    this.isNavBarDisplayed = true;
  }

  ngAfterContentInit(): void {
    setTimeout(() => {
      this.appendLeftAlignedItems();
      this.appendRightAlignedItems();
      this.setActiveLinkWatcher();
    }, 500);
  }

  ngOnDestroy(): void {
    this._routeEventSubscription.unsubscribe();
  }

  public get showProjectTitle() {
    return this.projectTitle != '';
  }

  private appendLeftAlignedItems(): void {
    this._leftAlignedComponents.filter(
      component => !this._rightAlignedItems.some(rightAlignedComponent => rightAlignedComponent.linkComponentRef === component))
      .forEach(component => {
        component.opensRight = component.childLinks && !!component.childLinks.length;
        this._renderer.appendChild(this._leftContainer.nativeElement, component.elementRef.nativeElement);
      });
  }

  private appendRightAlignedItems(): void {
    this._rightAlignedItems.forEach(component => {
      component.linkComponentRef.opensLeft =
        component.linkComponentRef.childLinks && !!component.linkComponentRef.childLinks.length;
      this._renderer.appendChild(this._rightContainer.nativeElement, component.linkComponentRef.elementRef.nativeElement);
    });
  }

  private setActiveLinkWatcher(): void {
    this._routeEventSubscription = this._router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.setActiveLink(event.url);
      }
    }) as any;
    this.setActiveLink(this._router.url);
  }

  private setActiveLink(currentUrl: string): void {
    const isPartOfUrl = (snippet: string): boolean => {
      // TODO Replace this with 'snippet?.replace' when upgraded to v9
      return !!snippet && currentUrl.includes(snippet.replace(/^[.]/g, ''));
    };
    this._leftAlignedComponents.forEach(component => {
      if (component.childLinks) {
        component.isActive = component.childLinks.some(link => isPartOfUrl(link.route));
      } else {
        component.isActive = isPartOfUrl(component.link);
      }
    });
  }

  handleMenuNavigation(event: KeyboardEvent): void {
    const { key } = event;
    let topLevelLinks = Array.from(document.querySelectorAll(`div#${this.id} > div.top-bar-left > ul > li > a`));
    topLevelLinks = topLevelLinks.filter(link => !link.querySelector('img'));
    let activeLinkIndex = topLevelLinks.indexOf(document.activeElement);

    if (activeLinkIndex === -1) {
      return;
    }

    let indexAdjustment = 0;
    const listLengthAdjusted = topLevelLinks.length - 1;

    if (key === Key.ArrowLeft) {
      indexAdjustment = activeLinkIndex === 0 ? listLengthAdjusted : -1;
    } else if (key === Key.ArrowRight) {
      const isLastLinkInList = activeLinkIndex === listLengthAdjusted;
      if (!isLastLinkInList) {
        indexAdjustment = activeLinkIndex === listLengthAdjusted ? -listLengthAdjusted : 1;
      }
    }
    event.preventDefault();

    activeLinkIndex += indexAdjustment;
    this._activeElement = topLevelLinks[activeLinkIndex];
    this._activeElement.focus();
  }

}
