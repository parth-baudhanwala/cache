import { TemplateRef, Directive, Component } from '@angular/core';
import { DataRow } from './model';

@Directive({
  selector: '[hhaxCellCheckbox]'
})
export class CellCheckboxComponent {
  context: CellTemplateContext<DataRow<any>>;
  rowIndex: number;
  columnName: string;
  row: DataRow<any>;

  constructor(public _template: TemplateRef<any>) { }
}

@Component({
  selector: 'hhax-cell',
  template: `
    <td>
      <ng-content></ng-content>
    </td>
  `
})
export class TableCellComponent { }


@Directive({
  selector: '[hhaxActionCell]'
})
export class CellActionComponent {
  context: DataRow<any>;

  constructor(public _template: TemplateRef<any>) { }
}

export interface CellTemplateContext<T> {
  $implicit: T;

  columnName: string;

  row: DataRow<any>;
}
