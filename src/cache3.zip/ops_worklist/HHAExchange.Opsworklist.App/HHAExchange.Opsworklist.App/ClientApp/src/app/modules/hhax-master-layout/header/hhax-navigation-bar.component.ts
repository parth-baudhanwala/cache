import { Component, OnDestroy, OnInit } from '@angular/core';
import { faCog, faComment, faEnvelope, faUser } from '@fortawesome/pro-solid-svg-icons';
import { HttpTransportType, HubConnection, HubConnectionBuilder, HubConnectionState, LogLevel } from '@microsoft/signalr';
import { ToastrAlertService } from 'hhax-components';
import $ from "jquery";
import { Subscription, timer } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { HHAUserService } from '../../../core/authentication/user.service';
import { ActionLink } from '../../../core/components/hhax-components/navigation/link/model';
import { ConfigurationService } from '../../../core/services/configuration.service';
import { LocalStorageKeyNames, LocalStorageService } from '../../../core/services/local-storage.service';
import { MenuModel } from '../hhax-master-layout.model';
import { HhaxMasterLayoutService } from '../service/hhax-master-layout.service';


@Component({
  selector: 'hhax-navigation-bar',
  templateUrl: './hhax-navigation-bar.component.html'
})
export class HhaxNavigationBarComponent implements OnInit, OnDestroy {

  private _hubConnection: HubConnection;

  isLoaded = false;
  defaultRoute: string;
  hhaKeyWords = [];
  userId: number;
  providerId: number;
  userName: string;
  vendorName: string;
  appName: string;
  version: number;
  minorVersion: number;
  entMainUrl: string;
  mobileChatCounter: number;
  mobileChatLink: string;
  mobileChatIcon = faComment;
  userIcon = faUser;
  userFullName: string;
  vendorId: number;
  environmentDescription: string;
  isReskinEnable: boolean = false;
  salesforceCustomerID: string;

  readonly patientLinks: ActionLink[] = [];
  readonly caregiverLinks: ActionLink[] = [];
  readonly visitLinks: ActionLink[] = [];
  readonly actionLinks: ActionLink[] = [];
  readonly billingLinks: ActionLink[] = [];
  readonly reportLinks: ActionLink[] = [];
  readonly dashboardLinks: ActionLink[] = [];
  readonly adminLinks: ActionLink[] = [];
  userLinks: ActionLink[] = [];

  viewHomeMenu = false;
  viewPatientMenu = false;
  viewCaregiverMenu = false;
  viewVisitMenu = false;
  viewActionMenu = false;
  viewBillingMenu = false;
  viewReportMenu = false;
  viewDashboardMenu = false;
  viewAdminMenu = false;
  viewMobileChatIcon = false;

  notificationSubscription: Subscription;

  constructor(
    private _hhaxMasterLayoutService: HhaxMasterLayoutService,
    private _userService: HHAUserService,
    private _alert: ToastrAlertService,
    private _localStorageService: LocalStorageService,
    private _config: ConfigurationService
  ) { }

  ngOnInit(): void {
    this.hhaKeyWords = this._localStorageService.getItem(LocalStorageKeyNames.hhaKeyWordConfigurationSortedData);
    this.userId = this._config.appConfiguration.userId
    this.providerId = this._config.appConfiguration.agencyID;
    this.vendorName = this._config.appConfiguration.vendorName;
    this.appName = this._config.appConfiguration.appName;
    this.version = this._config.appConfiguration.version;
    this.minorVersion = this._config.appConfiguration.minorVersion;
    this.entMainUrl = this._config.appConfiguration.entMainURL;
    this.userFullName = this._userService.getUserFullName();
    this.vendorId = this._userService.getVendorID();
    this.salesforceCustomerID = this._localStorageService.getItem(LocalStorageKeyNames.salesforceCustomerID);
    this.environmentDescription = localStorage.getItem(LocalStorageKeyNames.environmentDescription);
    this.isReskinEnable = this._userService.getIsUserNewskin();
    this.userName = this.isReskinEnable ? this._userService.getUserName() : this._config.appConfiguration.userName;
    this.getMenuList();
    this.setUserProfileOptions();
    this.setNotificationDetails();
    this.setChatIconDetails();
    this.checkMfaSettingsCookie();
  }

  ngOnDestroy(): void {
    this.notificationSubscription.unsubscribe();
  }

  onMenuClick(event: any, id: number, isPopup: boolean, windowFeatures: string): void {
    if (isPopup && event.target.name) {
      if (!windowFeatures) {
        windowFeatures = "menubar=0,statusbar=1,resizable=1,width=1000,height=600,scrollbars=yes,left=05,top=20,menu=false";
      }

      if (windowFeatures.includes("screen.width")) {
        windowFeatures = windowFeatures.replace("screen.width", screen.width.toString());
      }

      if (windowFeatures.includes("screen.height")) {
        windowFeatures = windowFeatures.replace("screen.height", screen.height.toString());
      }

      window.open(event.target.name, event.target.innerText, windowFeatures);
    }
    else {
      let htmlElement = document.getElementById(id.toString());
      event.cancelBubble = true;
      event.stopPropagation();
      $(htmlElement).parent().parent().find('ul').css({ 'display': 'none', 'opacity': '0' });
      htmlElement.style.display = 'block';
      htmlElement.style.opacity = '1';
    }
  }

  getMenuList(): void {
    const payload = {
      userId: this.userId,
      appVersion: this.appName,
      version: this.version,
      minorVersion: this.minorVersion
    };

    this._hhaxMasterLayoutService.getMenuList(payload).subscribe((result) => {
      this.setMenuDetails(result);
    }, () => {
      this._alert.error("error", "There was an error while fetching menu details.");
    }, () => {
      this.isLoaded = true;
    });
  }

  async setMenuDetails(menuData: MenuModel[]): Promise<void> {
    let menuTitles = menuData.filter(x => x.parentId == 0);
    let menuTitlesDict = await Object.assign({}, ...menuTitles.map((x) => ({ [x.name]: { id: x.id, url: x.url } })));

    if (menuTitlesDict["Home"]) {
      this.defaultRoute = this.getUrl(menuTitlesDict["Home"].url);
      this.viewHomeMenu = true;
    }

    if (menuTitlesDict["Patient"]) {
      this.fillSubMenuDetails(menuData, menuTitlesDict["Patient"].id, this.patientLinks);
      this.viewPatientMenu = true;
    }

    if (menuTitlesDict["Caregiver"]) {
      this.fillSubMenuDetails(menuData, menuTitlesDict["Caregiver"].id, this.caregiverLinks);
      this.viewCaregiverMenu = true;
    }

    if (menuTitlesDict["Visit"]) {
      this.fillSubMenuDetails(menuData, menuTitlesDict["Visit"].id, this.visitLinks);
      this.viewVisitMenu = true;
    }

    if (menuTitlesDict["Action"]) {
      this.fillSubMenuDetails(menuData, menuTitlesDict["Action"].id, this.actionLinks);
      this.viewActionMenu = true;
    }

    if (menuTitlesDict["Billing"]) {
      this.fillSubMenuDetails(menuData, menuTitlesDict["Billing"].id, this.billingLinks);
      this.viewBillingMenu = true;
    }

    if (menuTitlesDict["Report"]) {
      this.fillSubMenuDetails(menuData, menuTitlesDict["Report"].id, this.reportLinks);
      this.viewReportMenu = true;
    }

    if (menuTitlesDict["Dashboard"]) {
      this.fillSubMenuDetails(menuData, menuTitlesDict["Dashboard"].id, this.dashboardLinks);
      this.viewDashboardMenu = true;
    }

    if (menuTitlesDict["Admin"]) {
      this.fillSubMenuDetails(menuData, menuTitlesDict["Admin"].id, this.adminLinks);
      this.viewAdminMenu = true;
    }
  }

  fillSubMenuDetails(menuData: MenuModel[], uniqueId: number, actionLink: ActionLink[]): void {
    for (const element of menuData) {
      if (element.parentId == uniqueId && element.parentId != 0) {
        actionLink.push({
          id: Number(element.id),
          label: this.replaceKeyWord(element.name),
          route: this.getUrl(element.url),
          handler: (event) => this.onMenuClick(event, element.id, element.isPopup, element.windowFeatures),
          children: [],
          isPopup: element.isPopup
        });
        let index = actionLink.length - 1;
        this.fillSubMenuDetails(menuData, element.id, actionLink[index].children);
        index = 0;
      }
    }
  }

  getUrl(url: string): string {
    if (url == null || url == "" || url.startsWith("#")) {
      return null;
    }

    if (url.includes("PatientSearch.aspx")) {
      url = "../Patient/PatientSearchXSLTIFrame.aspx";
    }
    else if (url.includes("SearchReferalManagement.aspx")) {
      url = "../Admin/SearchReferralManagementXSLT.aspx";
    }

    if (url.indexOf("#") == -1 && url.startsWith("/")) {
      return window.location.origin.concat(url);
    }

    return url.replace("../", this.entMainUrl);
  }

  replaceKeyWord(value: string): string {
    if (!this.hhaKeyWords) {
      return value;
    }

    for (let key in this.hhaKeyWords) {
      if (value.includes(this.hhaKeyWords[key][0])) {
        return value.replaceAll(this.hhaKeyWords[key][0], this.hhaKeyWords[key][1]);
      }
    }

    return value;
  }

  setChatIconDetails(): void {
    const hasChatAccess = this._config.appConfiguration.mobileChatAccess;
    const agent = window.navigator.userAgent.toLowerCase();

    if ((agent.indexOf('chrome') == -1 && agent.indexOf('edge') == -1) || !hasChatAccess) {
      this.viewMobileChatIcon = false;
      return;
    }

    let mobileChatUrl = this._config.appConfiguration.mobileChatUrl;

    if (!mobileChatUrl) {
      return;
    }

    this.viewMobileChatIcon = true;
    this.mobileChatLink = mobileChatUrl + "chat";

    this._hhaxMasterLayoutService.getTokenForMobileChatApi().subscribe((resultToken) => {
      const url = `${mobileChatUrl}api/notify?userid=${this.userId}`;

      this._hubConnection = new HubConnectionBuilder().withUrl(url, {
        accessTokenFactory: () => resultToken,
        skipNegotiation: true,
        transport: HttpTransportType.WebSockets
      }).configureLogging(LogLevel.Information).withAutomaticReconnect().build();

      this._hubConnection.on("TotalChatUnreadCount", (totalCount) => {
        this.mobileChatCounter = totalCount;
      });

      this._hubConnection.onreconnected(() => this.registerToNotifyUnreadChatCount());
      this.connectToSignalR();
    });
  }

  connectToSignalR(): void {
    this._hubConnection.start().then(() => {
      console.log("SignalR Connection Status : ", this._hubConnection.state);
      this.registerToNotifyUnreadChatCount();
    }).catch(err => {
      console.log(err.toString());
    });
  }

  registerToNotifyUnreadChatCount(): void {
    if (this._hubConnection.state === HubConnectionState.Connected) {
      this._hubConnection.invoke("RegisterToNotifyUnreadChatCountWithParameters",
        this.userId, this.providerId, this.userName).then(() => {
          console.log("Registered for SignalR notification successfully!");
        }).catch(err => {
          console.log(err.toString());
        });
    }
  }

  unregisterToNotifyUnreadChatCount(): void {
    if (this._hubConnection && this._hubConnection.state === HubConnectionState.Connected) {
      this._hubConnection.invoke("UnregisterToNotifyUnreadChatCountWithParameters", this.userId).then(() => {
        console.log("Unregistered for SignalR notification successfully!");
        this.disconnectToSignalR();
      }).catch(err => {
        console.log(err.toString());
      });
    }
  }

  disconnectToSignalR(): void {
    this._hubConnection.stop().then(() => {
      console.log("SignalR Connection Status : ", this._hubConnection.state);
    }).catch(err => {
      console.log(err.toString());
    });
  }

  setUserProfileOptions(): void {
    let oldSkinMenuItem: ActionLink[] = [{
      id: 1,
      label: "Other Alerts",
      handler: () => false,
      isLabelTitle: true
    },
    {
      id: 2,
      label: "Message Center",
      icon: faEnvelope,
      handler: () => false,
      counter: "0"
    },
    {
      id: 3,
      label: "System Notifications",
      icon: faCog,
      handler: () => false,
      counter: "0"
    },
    {
      id: 4,
      label: "Need Help?",
      handler: () => false,
      isLabelTitle: true
    },
    {
      id: 5,
      label: "Support Center",
      handler: () => this.openWindow("SupportCenter")
    },
    {
      id: 6,
      label: "Customer Support Portal",
      handler: () => this.openWindow("ContactSupport")
    },
    {
      id: 7,
      label: "Remote Support",
      handler: () => this.openWindow("RemoteSupport")
    },
    {
      id: 8,
      label: "Live Chat",
      handler: () => this.openWindow("LiveChat")
    },
    {
      id: 9,
      label: "MFA Settings",
      route: this.entMainUrl + this._localStorageService.getItem<string>(LocalStorageKeyNames.mfaSettings)
    },
    {
      id: 10,
      label: `Welcome - ${this.userName}`,
      handler: () => false,
      isLabelTitle: true
    },
    {
      id: 11,
      label: "Change Password",
      route: this.entMainUrl + this._localStorageService.getItem<string>(LocalStorageKeyNames.changePassword)
    },
    {
      id: 12,
      label: "Logout",
      handler: () => this.logoutUser()
    }
    ]

    let newSkinMenuItem: ActionLink[] = [{
      id: 1,
      label: "",
      handler: () => false,
      isLabelTitle: true,
      innerHtml: `<strong class="colour-gray"> ${this.userFullName} </strong>
      <br/>  <span class="colour-lightgray" >${this.userName}</span>
      <br/> <span class="colour-black">${this.vendorName}</span>
      <br/><span class="colour-black"> [ID# ${this.salesforceCustomerID}]</span>
       <br/><span class="colour-header-black" > ${this.environmentDescription ? this.environmentDescription : ""
        } </span>`
    },
    {
      id: 2,
      label: "Other Alerts",
      handler: () => false,
      isLabelTitle: true
    },
    {
      id: 3,
      label: "Message Center",
      icon: faEnvelope,
      handler: () => false,
      counter: "0"
    },
    {
      id: 4,
      label: "System Notifications",
      icon: faCog,
      handler: () => false,
      counter: "0"
    },
    {
      id: 5,
      label: "Need Help?",
      handler: () => false,
      isLabelTitle: true
    },
    {
      id: 6,
      label: "Support Center",
      handler: () => this.openWindow("SupportCenter")
    },
    {
      id: 7,
      label: "MFA Settings",
      route: this.entMainUrl + this._localStorageService.getItem<string>(LocalStorageKeyNames.mfaSettings)
    },
    {
      id: 8,
      label: "Change Password",
      route: this.entMainUrl + this._localStorageService.getItem<string>(LocalStorageKeyNames.changePassword)
    },
    {
      id: 9,
      label: "Logout",
      handler: () => this.logoutUser()
    }
    ]
    
    if(this.isReskinEnable) {
      this.userLinks = newSkinMenuItem;
    } else {
      this.userLinks = oldSkinMenuItem;
    }
  }

  openWindow(linkName: string): boolean {
    switch (linkName) {
      case "SupportCenter":
        window.open(this._userService.getLSupportCenterRedirectUrl());
        break;
      case "ContactSupport":
        const contactSupportRedirectUrl = this._localStorageService.getItem<string>(LocalStorageKeyNames.contactSupportRedirectUrl);
        window.open(contactSupportRedirectUrl);
        break;
      case "RemoteSupport":
        const remoteSupportUrl = this._localStorageService.getItem<string>(LocalStorageKeyNames.remoteSupport);
        window.open(this.entMainUrl + remoteSupportUrl, 'HHAXRS1', '');
        break;
      case "LiveChat":
        const liveChatUrl = this._localStorageService.getItem<string>(LocalStorageKeyNames.liveChat);
        window.open(this.entMainUrl + liveChatUrl, 'LiveChat', 'width=450,height=570');
        break;
      default:
        break;
    }

    return false;
  }

  setNotificationDetails(): void {
    const payload = {
      userId: this.userId,
      providerId: this.providerId,
      appVersion: this.appName,
      version: this.version,
      minorVersion: this.minorVersion
    };

    this.notificationSubscription = timer(0, 120000).pipe(switchMap(() => this._hhaxMasterLayoutService.getNotificationDetail(payload))).subscribe((result) => {
      if (result) {
        let messageCenterLink = this.userLinks.find(x => x.label == "Message Center");
        messageCenterLink.counter = String(result.userMessagesCnt);
        let systemNotificationsLink = this.userLinks.find(x => x.label == "System Notifications");
        systemNotificationsLink.counter = String(result.userNotifMsgCnt);
      }
    });
  }

  checkMfaSettingsCookie(): void {
    const cookiePrefix = this._localStorageService.getItem<string>(LocalStorageKeyNames.mfaCookieName);

    crypto.subtle.digest('SHA-1', new TextEncoder().encode(this.userId.toString())).then(x => {
      const hashArray = Array.from(new Uint8Array(x));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      const cookieName = cookiePrefix + hashHex;
      const isMfaCookieExist = document.cookie.split(';').some((item) => item.trim().startsWith(cookieName));

      if (!isMfaCookieExist) {
        this.userLinks = this.userLinks.filter(y => y.id != (this.isReskinEnable ? 7 : 9));
      }
    });
  }

  logoutUser(): void {
    try {
      this.unregisterToNotifyUnreadChatCount();
    }
    catch (ex) {
      console.error("Chat notification is not unregister successfully.", ex);
    }

    this._userService.logoutUser();
  }
}
