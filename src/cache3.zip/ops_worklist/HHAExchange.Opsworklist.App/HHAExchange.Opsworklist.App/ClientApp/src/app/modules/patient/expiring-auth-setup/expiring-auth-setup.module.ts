import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExpiringAuthSetupComponent } from './expiring-auth-setup.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { CoreModule } from '../../../core/core.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    ExpiringAuthSetupComponent
  ],
  imports: [
    CommonModule,
    CoreModule,
    AngularMultiSelectModule,
    ReactiveFormsModule,
    FormsModule,

  ]
})
export class ExpiringAuthSetupModule {
  static entry = ExpiringAuthSetupComponent;
}
