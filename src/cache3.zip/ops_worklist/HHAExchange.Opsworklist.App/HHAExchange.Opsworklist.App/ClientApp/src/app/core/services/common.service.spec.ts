import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { getTestBed, TestBed } from "@angular/core/testing";

import {
  GetCommunicationScript,
  getMessageByScriptIdResponse,
  GetUsersByWorklistIDResponse,
  GetWlTaskStatusCount,
  UpdateStatusResponse,
} from "../services-mock-data/common.service.mock";
import { CommonService } from "./common.service";
import { SessionStorageService } from "./session-storage.service";

describe("CommonService", () => {
  let getUsersByWorklistIDParams = {
    WorklistID: 1,
    OfficeIDs: "1366, 1731",
  };
  let updateStatusParams = {
    WlTaskId: "12952",
    Status: "In-Progress",
    UpdatedBy: 27398,
    UpdatedByUser: "shekhussp",
  };

  let scriptDataModelParams = {
    UserID: 27398,
    ProviderID: 691,
    TemplateType: 1,
    OfficeIDs:
      "1366,1849,1766,1338,852,851,1597,1428,1427,1113,853,1085,1778,1654,1592,1731",
  };

  let action = "Status";

  let GetTemplateDetailsByIDParams = {
    TemplateId: 3844,
    AgencyId: 691,
    UserID: 27398,
    AppVersion: "ENT",
    Version: 21.02,
    MinorVersion: 1,
    templateId: "3868",
  };
  let mwPatientParams = {
    AppVersion: "string",
    Version: 1,
    MinorVersion: 1,
    UserID: 1,
    ProviderID: 1,
    masterWeekHeaderID: 1,
    PatientID: 1,
  };
  let mwPatientResponse = {
    sunday: "any",
    monday: "any",
    tuesday: "any",
    wednesday: "any",
    thursday: "any",
    friday: "any",
    saturday: "any",
  };

  let service: CommonService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SessionStorageService, { provide: "HOST", useValue: "test" }],
    });
    injector = getTestBed();
    service = injector.inject(CommonService);
    httpMock = injector.inject(HttpTestingController);
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });

  it("CommonService should be created", () => {
    expect(service).toBeDefined();
  });

  it("CommonService GetPatientMasterWeekInfo", () => {
    service.GetPatientMasterWeekInfo(mwPatientParams).subscribe((res) => {
      expect(res).toEqual(mwPatientResponse);
    });
    const request = httpMock.expectOne(
      "Common/GetPatientMasterWeekInfo?AppVersion=string&Version=1&MinorVersion=1&UserID=1&ProviderID=1&masterWeekHeaderID=1&PatientID=1"
    );
    expect(request.request.method).toBe("GET");
    request.flush(mwPatientResponse);
  });

  it("CommonService GetUPRPatientMasterWeekInfo", () => {
    service.GetUPRPatientMasterWeekInfo(mwPatientParams).subscribe((res) => {
      expect(res).toEqual(mwPatientResponse);
    });
    const request = httpMock.expectOne(
      "Common/GetUPRPatientMasterWeekInfo?AppVersion=string&Version=1&MinorVersion=1&UserID=1&ProviderID=1&masterWeekHeaderID=1&PatientID=1"
    );
    expect(request.request.method).toBe("GET");
    request.flush(mwPatientResponse);
  });

  it("CommonService getWorkListsTaskCount", () => {
    service
      .getWorkListsTaskCount({ userID: 27398, providerID: 691 })
      .subscribe((res) => {
        expect(res).toEqual(GetWlTaskStatusCount);
      });
    const request = httpMock.expectOne(
      "Common/GetWlTaskStatusCount?userID=27398&providerID=691"
    );
    expect(request.request.method).toBe("GET");
    request.flush(GetWlTaskStatusCount);
  });
  it("CommonService GetUsersByWorklistID", () => {
    service
      .GetUsersByWorklistID(getUsersByWorklistIDParams)
      .subscribe((res) => {
        expect(res).toEqual(GetUsersByWorklistIDResponse);
      });
    const request = httpMock.expectOne(
      "Common/GetUsersByWorklistID?WorklistID=1&OfficeIDs=1366,%201731"
    );
    expect(request.request.method).toBe("GET");
    request.flush(GetUsersByWorklistIDResponse);
  });
  it("CommonService getScriptData", () => {
    service.getScriptData(scriptDataModelParams).subscribe((res) => {
      expect(res).toEqual(GetCommunicationScript);
    });
    const request = httpMock.expectOne("Common/GetCommunicationScript");
    expect(request.request.method).toBe("POST");
    request.flush(GetCommunicationScript);
  });
  it("CommonService updateTask", () => {
    service.updateTask(updateStatusParams, action).subscribe((res) => {
      expect(res).toEqual(UpdateStatusResponse);
    });
    const request = httpMock.expectOne("Common/UpdateTask?action=Status");
    expect(request.request.method).toBe("POST");
    request.flush(UpdateStatusResponse);
  });
  it("CommonService updateTask", () => {
    service
      .getMessageByScriptId(GetTemplateDetailsByIDParams)
      .subscribe((res) => {
        expect(res).toEqual(getMessageByScriptIdResponse);
      });
    const request = httpMock.expectOne("Common/GetTemplateDetailsByID");
    expect(request.request.method).toBe("POST");
    request.flush(getMessageByScriptIdResponse);
  });
});
