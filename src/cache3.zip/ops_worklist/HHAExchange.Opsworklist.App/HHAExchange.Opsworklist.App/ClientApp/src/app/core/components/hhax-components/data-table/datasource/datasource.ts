import { Observable } from 'rxjs/internal/Observable';
import { Subject } from 'rxjs';
import { Guid } from 'guid-typescript';

import { DataRow } from '../model';
import {
  DataTableRequest,
  DataTableResponse,
  PageRequest,
  Sort,
  TableDataSourceConfig,
} from './model';
import { IHhaxHttpService } from 'hhax-components';


export class TableDataSource<TResponse = any, TRequest = any> {

  data: Observable<DataRow<TResponse>[]>;
  totalRecordCount: number;
  currentPage: DataRow<TResponse>[] = [];
  pageSize: number;
  isFetchingData: boolean;

  private _config: TableDataSourceConfig;

  private readonly _dataSubscriber: Subject<DataRow<TResponse>[]>;
  private readonly _request: DataTableRequest<TRequest>;
  private readonly _httpService: IHhaxHttpService;

  constructor(config: TableDataSourceConfig, httpService: IHhaxHttpService) {
    this._httpService = httpService;
    this._config = config;
    this.pageSize = config.page.pageSize;
    this._request = {
      page: config.page,
      sort: config.sort,
      queryParams: config.get.queryParams
    };

    if (config.data) {
      this.totalRecordCount = config.data.length;
    }

    this._dataSubscriber = new Subject();
    this.data = this._dataSubscriber.asObservable();
  }

  setSort(sort: Sort): void {
    this._request.sort = sort;
    this._get();
  }

  getPage(request: PageRequest): void {
    this._request.page = request;
    this._get();
  }

  updateConfig(config: Partial<TableDataSourceConfig>): void {
    this._config = Object.assign(this._config, config);
  }

  updateQueryParams(params: any): void {
    this._request.queryParams = params;
    this._request.page.pageNumber = 1;
    this._get();
  }

  private _get(): void {
    if (this._config.data) {
      this._dataSubscriber.next(this._config.data);
    } else {
      this.isFetchingData = true;
      this._httpService.get<DataTableResponse<TResponse>>(this._config.get.url, this._generateRequestParams()).subscribe(response => {
        response = response ? response : {pageInfo: {totalRecordCount: 0}, data: []};
        const dataAsDataRows = response.data.map<DataRow<TResponse>>(row => ({
          data: row,
          guid: Guid.create()
        }));

        this.isFetchingData = false;
        this.totalRecordCount = response.pageInfo.totalRecordCount;
        this._dataSubscriber.next(dataAsDataRows);
      });
    }
  }

  private _generateRequestParams(): object {
    return {
      page: this._request.page,
      sort: this._request.sort,
      ...this._request.queryParams
    };
  }
}
