import { Component, OnInit } from '@angular/core';
import { ToastrAlertService } from 'hhax-components';
import { DeviceDetectorService } from 'ngx-device-detector';
import { ConfigurationService } from '../../../core/services/configuration.service';
import { LocalStorageKeyNames, LocalStorageService } from '../../../core/services/local-storage.service';
import { HhaxMasterLayoutService } from '../service/hhax-master-layout.service';
import { HHAUserService } from './../../../core/authentication/user.service';

@Component({
  selector: 'hhax-ent-footer',
  templateUrl: './footer.component.html'
})
export class HhaxFooterComponent implements OnInit {
  currentYear = new Date().getFullYear();
  applicationDetails: string;
  vendorId: number;
  environmentDescription: string;
  vendorName: string;
  isReskinEnable: boolean = false;
  salesforceCustomerID: string;

  constructor(
    private _hhaxMasterLayoutService: HhaxMasterLayoutService,
    private _deviceDetectorService: DeviceDetectorService,
    private _alert: ToastrAlertService,
    private _config: ConfigurationService,
    private _localStorageService: LocalStorageService,
    private _userService: HHAUserService
  ) { }

  ngOnInit(): void {
    const version = this._config.appConfiguration.version + ".0" + this._config.appConfiguration.minorVersion;
    const browser = this._deviceDetectorService.browser;
    const browserVersion = this._deviceDetectorService.browser_version.split(".");
    const browserDetails = browser.concat(" ", browserVersion[0]);
    this.vendorName = this._config.appConfiguration.vendorName;
    this.vendorId = this._userService.getVendorID();
    this.salesforceCustomerID = this._localStorageService.getItem(LocalStorageKeyNames.salesforceCustomerID);
    this.environmentDescription = localStorage.getItem(LocalStorageKeyNames.environmentDescription);
    this.isReskinEnable = this._userService.getIsUserNewskin();

    this._hhaxMasterLayoutService.getMachineDetails().subscribe((result) => {
      this.applicationDetails = `Enterprise ${version} ${result.machineName} ${browserDetails} (Doc ${browserDetails}) ${result.machineDateTime}`;
    }, () => {
      this._alert.error("error", "There was an error while fetching application details.");
    });
  }

  openWindow(linkName: string): boolean {
    const entMainUrl = this._config.appConfiguration.entMainURL;

    switch (linkName) {
      case "SupportCenter":
        window.open(this._userService.getLSupportCenterRedirectUrl());
        break;
      case "ContactSupport":
        const contactSupportRedirectUrl = this._localStorageService.getItem<string>(LocalStorageKeyNames.contactSupportRedirectUrl);
        window.open(contactSupportRedirectUrl);
        break;
      case "RemoteSupport":
        const remoteSupportUrl = this._localStorageService.getItem<string>(LocalStorageKeyNames.remoteSupport);
        window.open(entMainUrl + remoteSupportUrl, 'HHAXRS1', '');
        break;
      case "LiveChat":
        const liveChatUrl = this._localStorageService.getItem<string>(LocalStorageKeyNames.liveChat);
        window.open(entMainUrl + liveChatUrl, 'LiveChat', 'width=450,height=570');
        break;
      default:
        break;
    }

    return false;
  }
}
