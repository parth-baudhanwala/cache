import { DateToTime24hrPipe } from "./date-to-time-24hr";
import { DateToTimePipe } from "./date-to-time.pipe";
import { EncodeUriPipe } from "./encode-uri.pipe";
import { FormatDateTime24hr } from "./format-date-time-24hr.pipe";
import { FormatDateTime } from "./format-date-time.pipe";
import { MonthNamePipe } from "./month-name.pipe";

describe("month-name-pipe", () => {
  it("transforms date to time 24", () => {
    const pipe = new DateToTime24hrPipe();
    expect(pipe.transform(new Date(2021, 1, 1))).toBe("00:00");
  });

  it("transforms date to time DateToTimePipe", () => {
    const pipe = new DateToTimePipe();
    expect(pipe.transform(new Date(2021, 1, 1))).toBe("12:00 AM");
  });

  it("transforms EncodeUriPipe", () => {
    const pipe = new EncodeUriPipe();
    expect(pipe.transform("")).toBe("");
  });

  it("transforms date to time 24 FormatDateTime24hr", () => {
    const pipe = new FormatDateTime24hr();
    expect(pipe.transform(new Date(2021, 1, 1))).toBe("02/01/2021 00:00");
  });

  it("transforms date to datetime", () => {
    const datetimePipe = new FormatDateTime();
    let date = new Date(2021, 1, 1);
    expect(datetimePipe.transform(date)).toBe("02/01/2021 12:00 AM");
  });

  it("transforms number into month", () => {
    const pipe = new MonthNamePipe();
    expect(pipe.transform(1)).toBe("February");
  });
});
