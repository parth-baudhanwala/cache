export interface PageChangeEvent {
  pageNumber: number;
}
