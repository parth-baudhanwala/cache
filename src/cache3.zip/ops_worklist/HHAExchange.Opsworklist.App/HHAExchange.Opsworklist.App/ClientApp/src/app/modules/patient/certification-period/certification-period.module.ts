import { CommonModule, DatePipe } from "@angular/common";
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { AuthInterceptor } from "@app/core/authentication/auth.interceptor";
import { HttpErrorInterceptor } from "@app/core/authentication/http-error.interceptor";
import { AutocompleteModule } from "@app/core/components/hhax-components/autocomplete/autocomplete.module";
import { HhaxTableModule } from "@app/core/components/hhax-components/data-table/data-table.module";
import { HhaxTableDataModule } from "@app/core/components/hhax-components/data-table/datasource/datasource.module";
import { ShowHideModule } from "hhax-components";
import { CoreModule } from "@app/core/core.module";
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown";
import { TreeviewModule } from "@app/core/components/ngx-treeview-dropdown/treeview.module";

import { CertificationPeriodComponent } from "./certification-period.component";

@NgModule({
    imports: [
        AutocompleteModule,
        AngularMultiSelectModule,
        CommonModule,
        CoreModule,
        ReactiveFormsModule,
        FormsModule,
        HhaxTableModule,
        HhaxTableDataModule,
        ShowHideModule,
        TreeviewModule.forRoot(),
    ],
    declarations: [CertificationPeriodComponent],
    providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthInterceptor,
            multi: true,
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: HttpErrorInterceptor,
            multi: true,
        },
        DatePipe
    ]
})
export class CertificationPeriodModule {
  static entry = CertificationPeriodComponent;
}
