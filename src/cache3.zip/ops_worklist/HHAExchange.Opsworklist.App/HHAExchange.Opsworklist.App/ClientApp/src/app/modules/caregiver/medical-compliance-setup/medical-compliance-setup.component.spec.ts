import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalComplianceSetupComponent } from './medical-compliance-setup.component';

describe('MedicalComplianceSetupComponent', () => {
  let component: MedicalComplianceSetupComponent;
  let fixture: ComponentFixture<MedicalComplianceSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicalComplianceSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalComplianceSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
