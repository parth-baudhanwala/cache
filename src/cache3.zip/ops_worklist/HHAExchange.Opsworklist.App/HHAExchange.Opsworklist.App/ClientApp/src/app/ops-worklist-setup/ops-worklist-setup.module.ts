import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { provideRoutes, RouterModule, Routes } from '@angular/router';
import { TabsModule } from 'hhax-components';
import { LazyLoadService } from '../lazy-tabs/lazy-load-service';
import { lazyArrayToObj, lazyTabs, LAZY_TABS } from '../lazy-tabs/lazy-tabs';
import { OpsWorklistSetupComponent } from './ops-worklist-setup.component';
import { PipeModule } from '@app/core/pipes/pipe.module';

const routes: Routes = [
  { path: '', component: OpsWorklistSetupComponent }
]

@NgModule({
  declarations: [
    OpsWorklistSetupComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    TabsModule,
    PipeModule
  ],
  providers: [
    { provide: LAZY_TABS, useFactory: lazyArrayToObj },
    LazyLoadService,
    provideRoutes(lazyTabs),
  ]
})
export class OpsWorklistSetupModule { }
