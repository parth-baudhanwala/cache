import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

import {
  IAssignUser,
  IPutResponse,
  TaskCount,
  UpdateTaskRequest,
  workListCount,
  IAuthenticationParams,
  IUserDetailsModel,
  MasterWeekInfoParams,
  MasterWeekInfoResponse,
} from "../models/common.model";
import {
  getUsersByWorklistIDData,
  scriptDataModel,
} from "../models/notes.model";
import { IScriptData, ISendMessage } from "../models/scripts.model";
import { BaseHttpService } from "./base.http.service";
import { ConfigurationService } from "./configuration.service";
import {
  SessionStorageService
} from "./session-storage.service";

@Injectable({
  providedIn: "root",
})
export class CommonService extends BaseHttpService {
  private storage: SessionStorageService;

  constructor(
    httpClient: HttpClient,
    config: ConfigurationService,
    storage: SessionStorageService
  ) {
    super(httpClient, config);
    this.apiPrefix = "Common/";
    this.storage = storage;
  }

  GetPatientMasterWeekInfo(
    data: MasterWeekInfoParams
  ): Observable<MasterWeekInfoResponse> {
    return this.get<MasterWeekInfoResponse>("GetPatientMasterWeekInfo", data);
  }

  GetUPRPatientMasterWeekInfo(
    data: MasterWeekInfoParams
  ): Observable<MasterWeekInfoResponse> {
    return this.get<MasterWeekInfoResponse>(
      "GetUPRPatientMasterWeekInfo",
      data
    );
  }

  getWorkListsTaskCount(data: TaskCount): Observable<workListCount[]> {
    return this.get<workListCount[]>("GetWlTaskStatusCount", data);
  }

  getScriptData(scriptData: scriptDataModel): Observable<ISendMessage> {
    return this.post<ISendMessage>("GetCommunicationScript", scriptData);
  }

  getMessageByScriptId(data: any): Observable<IScriptData> {
    return this.post<IScriptData>("GetTemplateDetailsByID", data);
  }

  GetUsersByWorklistID(
    data: IAssignUser
  ): Observable<getUsersByWorklistIDData[]> {
    const result = this.get<getUsersByWorklistIDData[]>(
      "GetUsersByWorklistID",
      data
    );
    return result;
  }

  getUserAuthentication(params: IAuthenticationParams): Observable<IUserDetailsModel> {
    return this.get<IUserDetailsModel>("GetUserAuthenticationDetails", params);
  }

  deleteUserAuthenticationFromCache(userId: number): Observable<void> {
    return this.delete<void>("DeleteUserAuthenticationFromCache", { userId: userId }
    );
  }

  updateTask(
    statusData: UpdateTaskRequest,
    action: string
  ): Observable<IPutResponse> {
    return this.post<IPutResponse>(`UpdateTask?action=${action}`, statusData);
  }

  getSrTime(time: string, vendor12HoursConversionFlag: boolean): string {
    if (vendor12HoursConversionFlag) {
      let convertedAmPmTime = this.getFormattedTime(time);
      let splittedTime = convertedAmPmTime.split("-");

      let fromTime = splittedTime[0].split(" ");
      let toTime = splittedTime[1].split(" ");

      let fromTimeHours = (fromTime[0].split(":")[0]).padStart(2, '0');
      let fromTimeMinutes = (fromTime[0].split(":")[1]).padStart(2, '0');
      let fromTimePeriod = fromTime[1];

      let toTimeHours = (toTime[0].split(":")[0]).padStart(2, '0');
      let toTimeMinutes = (toTime[0].split(":")[1]).padStart(2, '0');
      let toTimePeriod = toTime[1];

      return `${fromTimeHours}:${fromTimeMinutes} ${fromTimePeriod} to ${toTimeHours}:${toTimeMinutes} ${toTimePeriod}`;
    } else {
      let splittedTime = time.split("-");

      let fromTime = splittedTime[0].match(/.{1,2}/g);
      let toTime = splittedTime[1].match(/.{1,2}/g);

      return `${(fromTime[0]).padStart(2, '0')} Hours ${(fromTime[1]).padStart(2, '0')} Minutes
        to ${(toTime[0]).padStart(2, '0')} Hours ${(toTime[1]).padStart(2, '0')} Minutes`;
    }
  }

  getFormattedSrTime(scheduleTime: string): string {
    const inputTime = scheduleTime.split(' ');

    const hours = parseInt(inputTime[0], 10);
    const minutes = parseInt(inputTime[1], 10);

    const hoursText = hours === 1 ? 'Hour' : 'Hours';
    const minutesText = minutes === 1 ? 'Minute' : 'Minutes';

    return `${hours.toString().padStart(2, '0')} ${hoursText} and ${minutes.toString().padStart(2, '0') } ${minutesText}`;
  }

  getFormattedTime(scheduledTime: string): string {
    const [startTime, endTime] = scheduledTime.split('-');

    const fromTime = `${startTime.slice(0, 2)}:${startTime.slice(2)}`;
    const toTime = `${endTime.slice(0, 2)}:${endTime.slice(2)}`;

    const convertedFromTime = this.convertToAMPM(fromTime);
    const convertedToTime = this.convertToAMPM(toTime);

    return `${convertedFromTime}-${convertedToTime}`;
  }

  convertToAMPM(inputTime: string): string {
    const [hours, minutes] = inputTime.split(':');
    const parsedHours = parseInt(hours, 10);

    if (parsedHours >= 12) {
      return `${parsedHours === 12 ? parsedHours : (parsedHours - 12).toString().padStart(2, '0')}:${minutes} PM`;
    } else {
      return `${parsedHours === 0 ? 12 : parsedHours.toString().padStart(2, '0')}:${minutes} AM`;
    }
  }
}
