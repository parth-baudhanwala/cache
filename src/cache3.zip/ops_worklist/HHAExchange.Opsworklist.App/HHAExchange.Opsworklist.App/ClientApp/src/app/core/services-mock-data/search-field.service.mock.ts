import { IBroadCastModelResponse } from "../models/scripts.model";

export const getCoordinatorsByIDResponse = {
  responseBody: [
    {
      coordinatorID: 12311,
      coordinatorName: "- Demo 123",
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const getContractOptionsResponse = {
  responseBody: [
    {
      sourceID: 17352,
      sourceName: " $@#$^^&&%%#@$#@()",
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const getLocationsData = {
  responseBody: [
    {
      locationID: 10013253,
      location: "Alabama (OX5)",
    },
    {
      locationID: 10013254,
      location: "Alaska (OX5)",
    },
    {
      locationID: 10013255,
      location: "Arizona (OX5)",
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const getBranchForOfficeResponse = {
  responseBody: [
    {
      branchID: 10076254,
      branchName: "abc (OX5)",
    },
    {
      branchID: 10080551,
      branchName: "AN Br RTM (OX5)",
    },
    {
      branchID: 10076638,
      branchName: "asf (OX5)",
    },
    {
      branchID: 10074155,
      branchName: "Brooklin (OX5)",
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const getDisciplineForOfficeResponse = {
  responseBody: [
    {
      disciplineID: 1,
      discipline: "PCA",
    },
    {
      disciplineID: 2,
      discipline: "HHA",
    },
    {
      disciplineID: 3,
      discipline: "RN",
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const getOfficeDataResponse = {
  responseBody: [
    {
      officeName: "ALL",
      office: 0,
      officeID: 0,
      parentID: -1,
      isLeaf: 0,
      level: 0,
      hirarchyLevel: 0,
      type: 0,
      parent: null,
      sortOrder: 0,
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const sendBroadCastSendMessageDataResponse: IBroadCastModelResponse = {
  responseBody: {
    broadCastModel: [
      {
        aideID: 977682,
        aideCode: "EXQ-2265",
        aideName: "6 Production",
        notificationPreference: "Voice Mail",
      },
    ],
    broadCastID: 0,
  },
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const getCaregiverTeamDataResponse: any = [
  {
    caregiverTeamID: 10343774,
    caregiverTeam: "Axle (OX5)",
  },
  {
    caregiverTeamID: 10332416,
    caregiverTeam: "Blue Team (OX5)",
  },
  {
    caregiverTeamID: 10343579,
    caregiverTeam: "ddddddddddddd (OX5)",
  },
  {
    caregiverTeamID: 10343812,
    caregiverTeam: "Deff (OX5)",
  },
];

export const getContractDetailResponse = {
  responseBody: [
    {
      sourceID: 17352,
      sourceName: "$@#$^^&&%%#@$#@()",
    },
    {
      sourceID: 16376,
      sourceName: "07272017_P (India Test Only)",
    },
    {
      sourceID: 16375,
      sourceName: "07272017_PRC (India Test Only)",
    },
    {
      sourceID: 17177,
      sourceName: "zumba21",
    },
    {
      sourceID: 11682,
      sourceName: "Zuno Contract",
    },
  ],
  httpStatusCode: 200,
  httpStatusMessage: null,
  authenticationToken: null,
};

export const getNurseOptionsResponse = [
  {
    nurseID: 12,
    nurseName: "Jane",
  },
];

export const getPhysicianOptionsResponse = [
  {
    physicianID: 1,
    physicianName: "John",
  },
];

export const getPatientTeamDataResponse = [
  { patientTeam: "patientTeam1", patientTeamID: 1 },
  { patientTeam: "patientTeam2", patientTeamID: 2 },
];
