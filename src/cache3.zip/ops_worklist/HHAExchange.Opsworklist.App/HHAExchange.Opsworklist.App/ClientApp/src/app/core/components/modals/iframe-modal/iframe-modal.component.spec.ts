import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MAT_DIALOG_DATA, MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { Worklist } from '@app/core/models/common.model';
import { saveNotesResponse } from '@app/core/services-mock-data/notes.service.mock';
import { ConfigurationService } from '@app/core/services/configuration.service';
import { NotesService } from '@app/core/services/notes.service';
import { WorkslistService } from '@app/core/services/workslist.service';
import { ToastrAlertService } from 'hhax-components';
import { of } from 'rxjs';

import { IframeModalComponent } from './iframe-modal.component';

describe("TaskNameComponent", () => {
  const mockDialogRef = {
    close: jasmine.createSpy("close"),
  };
  let component: IframeModalComponent;
  let fixture: ComponentFixture<IframeModalComponent>;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [IframeModalComponent],
      imports: [MatDialogModule, HttpClientModule],
      providers: [
        IframeModalComponent,
        {
          provide: MatDialogRef,
          useValue: mockDialogRef,
        },
        MatDialog,
        { provide: MAT_DIALOG_DATA, useValue: {} },
        {
          provide: WorkslistService,
          useValue: {
            closingCondition: () => of({}),
          },
        },
        {
          provide: ToastrAlertService, useValue: {
            error: () => of("error", "Incorrect File size or File type"),
            success: () => of("success", "Send Message Sent successfully.")
          }
        },
        {
          provide: NotesService, useValue: {
            SaveNotes: () => of(saveNotesResponse)
          }
        },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userId: 27398,
              userOffices: [{ officeID: "123" }],
              AppVersion: "ENT",
              Version: 21.02,
              MinorVersion: 1,
              VendorID: 691,
            },
          },
        }
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IframeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
    component.closeDialog("Closed");
  });
});
