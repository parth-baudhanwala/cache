export class OpsworklistDetailsParams {
  UserID: number;
  ENTMainAppversionID: number;
  ENTPAPIAppversionID: number;
  ProviderAPIAppversionID: number;
  HHAWSENTAppversionID: number;
}
export class OpsworklistDetailsResponce {
  public appName: string;
  public version: number;
  public minorVersion: number;
  public agencyID: number;
  public vendorName: string;
  public displayUserName: string;
}
