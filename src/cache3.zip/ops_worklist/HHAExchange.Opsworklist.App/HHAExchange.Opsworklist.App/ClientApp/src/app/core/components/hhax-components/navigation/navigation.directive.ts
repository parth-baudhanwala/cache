import { Directive } from '@angular/core';

@Directive({
  selector: '[hhaxNavLeftContainer]',
})
export class NavLeftContainerDirective { }

@Directive({
  selector: '[hhaxNavRightContainer]',
})
export class NavRightContainerDirective { }
