import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrAlertService } from 'hhax-components';
import { OpsWorklistSetupBaseComponent } from '../../../core/components/base-component/ops-worklist-setup-base.component';
import { patienStatusOptions } from '../../../core/config/static-options';
import { WorklistName } from '../../../core/models/common.model';
import { UnscheduledVisitsSetupModel } from '../../../core/models/worklist-setup.model';
import { ConfigurationService } from '../../../core/services/configuration.service';
import { OpsWorklistSetupService } from '../../../core/services/ops-worklist-setup.service';

@Component({
  selector: 'app-unstaffed-visits-setup',
  templateUrl: './unstaffed-visits-setup.component.html'
})
export class UnstaffedVisitsSetupComponent extends OpsWorklistSetupBaseComponent implements OnInit {

  unStaffedSetupGroup: FormGroup;
  worklistSetupTabName = WorklistName.UNSTAFFED_VISITS;
  constructor(
    private _alert: ToastrAlertService,
    private _config: ConfigurationService,
    private _opsWorklistSetupService: OpsWorklistSetupService
  ) {
    super();
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.fetchSaveData();
  }

  fetchSaveData(): void {
    this.unStaffedSetupGroup = new FormGroup({
      taskCreation: new FormControl(30),
      taskCreationbyStatus: new FormControl([3]),
      automaticallyAssignTasks: new FormControl(false)
    });
    this.getUnscheduledVisitsSetup();
  }

  getUnscheduledVisitsSetup(): void {
    this._opsWorklistSetupService.getUnscheduledVisitsSetup(this._config.appConfiguration.agencyID).subscribe({
      next: (response: UnscheduledVisitsSetupModel) => {
        if (response) {
          this.unStaffedSetupGroup.get("taskCreation").setValue(response.taskCreationDays);
          const patientStatusValues = response.patientStatusIds.split(',').map(element => {
            return Number(element);
          });

          if (patientStatusValues.length == patienStatusOptions.length) {
            patientStatusValues.push(-1);
          }

          this.unStaffedSetupGroup.get("taskCreationbyStatus").setValue(patientStatusValues);
          this.unStaffedSetupGroup.get("automaticallyAssignTasks").setValue(response.automaticallyAssignTasks);
        }
      },
      error: () => this._alert.error("Error", "There was an error while getting information.")
    });
  }

  onSubmit(): void {
    const taskStatusIndex = this.unStaffedSetupGroup.get("taskCreationbyStatus").value.findIndex(el => el == -1);
    if (taskStatusIndex != -1) {
      this.unStaffedSetupGroup.get("taskCreationbyStatus").value.splice(taskStatusIndex, 1);
    }
    if (this.formValidation()) {
      const patientStatusIds: string = this.unStaffedSetupGroup.get("taskCreationbyStatus").value;

      let patientStatusArray: string[] = [];

      for (let index = 0; index < patientStatusIds.length; index++) {
        let patientStatusText = patienStatusOptions.find(x => x.value == patientStatusIds[index]).text;
        patientStatusArray.push(patientStatusText);
      }

      const patientStatus = patientStatusArray.join(",");

      const unscheduledVisitsSetupModel: UnscheduledVisitsSetupModel = {
        providerId: this._config.appConfiguration.agencyID,
        taskCreationDays: this.unStaffedSetupGroup.get("taskCreation").value,
        patientStatusIds: patientStatusIds.toString(),
        patientStatus: patientStatus,
        automaticallyAssignTasks: this.unStaffedSetupGroup.get("automaticallyAssignTasks").value,
        userId: this._config.appConfiguration.userId,
        userName: this._config.appConfiguration.userName
      }

      this._opsWorklistSetupService.saveUnscheduledVisitsSetup(unscheduledVisitsSetupModel).subscribe({
        complete: () => this._alert.success("Success", "Information has been saved successfully."),
        error: () => this._alert.error("Error", "There was an error while getting information.")
      })
    }
  }

  formValidation(): boolean {
    let isFormValid = true;
    const taskCreationValue = this.unStaffedSetupGroup.get("taskCreation").value;
    const taskCreationByStatusValue = this.unStaffedSetupGroup.get("taskCreationbyStatus").value;
    let messageError;

    if (!taskCreationValue && !taskCreationByStatusValue.length) {
      messageError = "Value required for Task Creation and Task Creation by Status.";
      isFormValid = false;
    }
    else if (taskCreationValue == 0 && !taskCreationByStatusValue.length) {
      messageError = "Task Creation value should not be 0 and value required for Task Creation by Status.";
      isFormValid = false;
    }
    else if (!taskCreationValue) {
      messageError = "Value required for Task Creation.";
      isFormValid = false;
    }
    else if (!taskCreationByStatusValue.length) {
      messageError = "Value required for Task Creation by Status.";
      isFormValid = false;
    }
    else if (taskCreationValue == 0) {
      messageError = "Task Creation value should not be 0.";
      isFormValid = false;
    }
    if (!isFormValid) {
      this._alert.error("Error", messageError);
    }

    return isFormValid;
  }

}
