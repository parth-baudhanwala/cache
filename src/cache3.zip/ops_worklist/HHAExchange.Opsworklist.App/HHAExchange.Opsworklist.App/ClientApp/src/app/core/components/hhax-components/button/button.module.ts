import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {  HhaxAlertButtonDirective, HhaxButtonDirective, HhaxClearButtonDirective, HhaxPrimaryButtonDirective, HhaxSuccessButtonDirective, HxHollowButtonDirective } from './button.directive';

const directives = [
  HhaxButtonDirective,
  HhaxPrimaryButtonDirective,
  HhaxClearButtonDirective,
  HhaxAlertButtonDirective,
  HhaxSuccessButtonDirective,
  HxHollowButtonDirective,
];

@NgModule({
  declarations: [...directives],
  imports: [CommonModule],
  exports: [...directives],
})
export class HhaxButtonModule { }
