import { OverlayContainer } from "@angular/cdk/overlay";
import { Injectable } from "@angular/core";

@Injectable({ providedIn: 'root' })
export class HHAMaterialOverlayContainer extends OverlayContainer {

    protected _createContainer(): void {
        const containerClass = 'cdk-overlay-container';

        const container = this._document.createElement('div');
        container.id = 'material-overlay-container';
        const overlayContainer = this._document.createElement('div');
        overlayContainer.classList.add(containerClass);

        container.appendChild(overlayContainer);

        this._document.body.appendChild(container);
        this._containerElement = overlayContainer;
    }
}