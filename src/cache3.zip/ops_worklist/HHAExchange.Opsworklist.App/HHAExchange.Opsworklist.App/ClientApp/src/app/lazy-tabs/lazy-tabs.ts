import { InjectionToken } from "@angular/core";
import { NgModuleFactory, Type } from "@angular/core";
import { Worklist } from "@app/core/models/common.model";

export const lazyTabs: {
  path: string;
  loadChildren: () => Promise<NgModuleFactory<any> | Type<any>>;
}[] =
  [
    {
      path: Worklist.MEDICAL_COMPLIANCE,
      loadChildren: () => import("@app/modules/caregiver/medical-or-compliance/medical-or-compliance.module")
        .then((m) => m.MedicalOrComplianceModule),
    },
    {
      path: Worklist.EXPIRING_AUTHORIZATION,
      loadChildren: () => import("@app/modules/patient/expiring-authorizations/expiring-authorizations.module")
        .then((m) => m.ExpiringAuthorizationsModule),
    },
    {
      path: Worklist.UNSTAFFED_VISITS,
      loadChildren: () => import("@app/modules/patient/unstaffed-visits/unstaffed-visits.module")
        .then((m) => m.UnstaffedVisitsModule),
    },
    {
      path: Worklist.MASTER_WEEK,
      loadChildren: () => import("@app/modules/patient/master-week/master-week.module")
        .then((m) => m.MasterWeekModule)
    },
    {
      path: Worklist.CERTIFICATION_PERIOD,
      loadChildren: () => import("@app/modules/patient/certification-period/certification-period.module")
        .then((m) => m.CertificationPeriodModule)
    },
    {
      path: Worklist.MEDICAL_COMPLIANCE_SETUP,
      loadChildren: () => import("@app/modules/caregiver/medical-compliance-setup/medical-compliance-setup.module")
        .then((m) => m.MedicalComplianceSetupModule)
    },
    {
      path: Worklist.EXPIRING_AUTHORIZATION_SETUP,
      loadChildren: () => import("@app/modules/patient/expiring-auth-setup/expiring-auth-setup.module")
        .then((m) => m.ExpiringAuthSetupModule)
    },
    {
      path: Worklist.UNSTAFFED_VISITS_SETUP,
      loadChildren: () => import("@app/modules/patient/unstaffed-visits-setup/unstaffed-visits-setup.module")
        .then((m) => m.UnstaffedVisitsSetupModule)
    },
    {
      path: Worklist.MASTER_WEEK_SETUP,
      loadChildren: () => import("@app/modules/patient/master-week-setup/master-week-setup.module")
        .then((m) => m.MasterWeekSetupModule)
    },
    {
      path: Worklist.CERTIFICATION_PERIOD_SETUP,
      loadChildren: () => import("@app/modules/patient/certification-period-setup/certification-period-setup.module")
        .then((m) => m.CertificationPeriodSetupModule)
    }
  ];

export function lazyArrayToObj() {
  const result = {};
  for (const w of lazyTabs) {
    result[w.path] = w.loadChildren;
  }
  return result;
}

export const LAZY_TABS = new InjectionToken<{ [key: string]: any }>("LAZY_TABS");
