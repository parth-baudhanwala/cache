import { Component, Inject, OnInit } from "@angular/core";
import { FormBuilder, FormControl, FormGroup } from "@angular/forms";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from "@angular/material/dialog";
import { ToastrAlertService } from "hhax-components";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { ExternalService } from "@app/core/services/external-services/external.service";
import {
  QuickBroadcastParams,
  QuickBroadcastResponse,
} from "@app/core/models/unstaffed-visits.model";
import moment from "moment";
import { NotesService } from "@app/core/services/notes.service";
import { TaskNotes } from "@app/core/models/notes.model";
import { HHAUserService } from "@app/core/authentication/user.service";

@Component({
  selector: "app-quick-broadcast-modal",
  templateUrl: "./quick-broadcast-modal.component.html",
})
export class QuickBroadcastComponent implements OnInit {
  broadcastForm: FormGroup;
  show: boolean;
  quickBroadcastArray: any = [];
  messageText: string;
  messageLimit: number = 160;
  constructor(
    public _quickBroadcasttModal: MatDialog,
    public _dialogRef: MatDialogRef<QuickBroadcastComponent>,
    public _fb: FormBuilder,
    public _alert: ToastrAlertService,
    public _external: ExternalService,
    public _config: ConfigurationService,
    public _notesService: NotesService,
    public _userService: HHAUserService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    if (Array.isArray(this.data.record)) {
      this.quickBroadcastArray = this.data.record;
    } else {
      this.quickBroadcastArray.push(this.data.record);
    }
    this.broadcastForm = this._fb.group({
      mobileNote: new FormControl(""),
      textNote: new FormControl(""),
    });

    this.messageLimit = this._userService.getCaregiverMessageLengthLimit();
    this.messageText = "Limit to " + this.messageLimit + " characters"
  }

  closeDialog(action: any): void {
    this._dialogRef.close(action);
  }

  quickBroadcast() {
    this.show = true;
    let params = new QuickBroadcastParams(this._config);
    for (let record of this.quickBroadcastArray) {
      params.broadcastID = record.broadcastID;
      params.broadcastNote = this.broadcastForm.value.mobileNote;
      params.broadcastNoteText = this.broadcastForm.value.textNote;
      params.visitID = record.visitID;
      params.OfficeID = record.officeId;
      params.BroadcastStatus = record.broadcastStatus;
      params.PatientID = record.patientId;
      params.ProcessStatus = record.processStatus;
      params.VisitDate = moment(record.visitDate).format("MM/DD/YYYY");
      params.AdmissionID = record.admissionId;
      params.AppName = this._config.appConfiguration.appName;
      params.AppSecret = this._config.appConfiguration.appsecret;
      params.CallerInfo = "quickBroadcast";
      this._external
        .saveQuickBroadcastInfo(params)
        .subscribe((response: QuickBroadcastResponse) => {
          if (response.d > 0) {
            this.autoGenerateNote(record, this.data.refreshTable);
            this._alert.success("success", "Broadcast is successfull.");
          } else if (response.d === -2) {
            this._alert.error(
              "error",
              "Unable to broadcast. There is an existing broadcast initiated from another location. Please refresh and try again."
            );
          } else if (response.d === -3) {
            this._alert.error("error", "This action is no longer available.");
          } else {
            this._alert.error(
              "error",
              "Service is not available. Please try again."
            );
          }
          this.show = false;
          this.closeDialog("Closed");
        });
    }
  }

  autoGenerateNote(records, callback) {
    let taskNote = new TaskNotes(this._config);
    taskNote.CreatedBy = this._userService.getUserID().toString();
    taskNote.CreatedByUser = `${this._userService.getUserFullName()} (${this._userService.getUserName()})`;
    taskNote.SubjectText = null;
    taskNote.Note = "Quick Broadcast sent.";
    taskNote.WorklistTaskIds = "";
    taskNote.CopyNotesTo = "";
    taskNote.WorklistTaskIds = records.worklistTaskId.toString();
    taskNote.OfficeID = records.officeId;
    this._notesService.SaveNotes(taskNote).subscribe((res) => {
      if (res) {
        callback();
      }
    });
  }

  limitNotesCharactersWithHint(obj, messageTextId){
    const lengthOfCurrentText = obj.target.value.length;
    let messageTextHelpElement = document.getElementById(messageTextId);
    let broadcastButtonElement = document.getElementById("broadcastButton");
    if(lengthOfCurrentText > 0){
      let displayText = lengthOfCurrentText + '/' + this.messageLimit + ' characters'
      displayText = lengthOfCurrentText > this.messageLimit ? displayText + ' - Limit exceeded' : displayText;
      messageTextHelpElement.textContent = displayText;
      if (lengthOfCurrentText > this.messageLimit) {
        broadcastButtonElement.setAttribute("disabled", "true");
        messageTextHelpElement.classList.add("hhax-form-error-text");
      }
      else {
        broadcastButtonElement.removeAttribute("disabled");
        messageTextHelpElement.classList.remove("hhax-form-error-text");
      }
      obj.target.ariaLabel = obj.target.value;
      obj.target.ariaHidden = true;
    }
    else{
      obj.target.ariaLabel = null;
      obj.target.ariaHidden = false;
      messageTextHelpElement.classList.remove("hhax-form-error-text");
      messageTextHelpElement.textContent = "Limit to " + this.messageLimit + " characters";
    }
  }

  validateTextBox(){
    let broadcastButtonElement = document.getElementById("broadcastButton");
    if(this.broadcastForm.value.mobileNote.length > this.messageLimit
    || this.broadcastForm.value.textNote.length > this.messageLimit){
      broadcastButtonElement.setAttribute("disabled", "true");
    } 
  }
}
