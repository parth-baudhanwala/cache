import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MatTooltipModule } from '@angular/material/tooltip';

import { HhaxTableComponent, ColumnReference, CellDefinition, CellOutlet } from './data-table.component';
import { DataTableCellComponent } from './data-table-cell.component';
import { DataTableRowDefinition, DataTableRowOutlet, DataTableRowComponent } from './rows';
import { CellCheckboxComponent, CellActionComponent, TableCellComponent } from './cells';
import { BulkActionsComponent } from './bulk-actions/bulk-actions.component';
import { ToolbarComponent } from './toolbar/toolbar.component';
import { ColumnHeaderComponent } from './column/column-header/column-header.component';
import { HhaxCheckboxModule, SpinnerModule } from 'hhax-components';
import { ColumnActionComponent } from './column/column-action/column-action.component';
import { PipeModule } from '@app/core/pipes/pipe.module';

const dataTableComponents = [
  HhaxTableComponent,
  DataTableCellComponent,
  DataTableRowDefinition,
  DataTableRowOutlet,
  DataTableRowComponent,
  ColumnReference,
  CellCheckboxComponent,
  CellActionComponent,
  CellDefinition,
  CellOutlet,
];

@NgModule({
    declarations: [
        ...dataTableComponents,
        BulkActionsComponent,
        ToolbarComponent,
        TableCellComponent,
        ColumnHeaderComponent,
        ColumnActionComponent
    ],
    exports: [
        ...dataTableComponents,
        ToolbarComponent,
        BulkActionsComponent,
        TableCellComponent
    ],
    imports: [
        CommonModule,
        SpinnerModule,
        FontAwesomeModule,
        HhaxCheckboxModule,
        MatTooltipModule,
        PipeModule
    ]
})
export class HhaxTableModule { }
