import { ConfigurationService } from '@app/core/services/configuration.service';

export class Defaultparam {
  AppVersion: string;
  Version: number;
  MinorVersion: number;
  UserID: number;
  ProviderID: number;

  constructor(config: ConfigurationService) {
    this.UserID = config.appConfiguration.userId
    this.AppVersion = config.appConfiguration.appName
    this.Version = config.appConfiguration.version
    this.MinorVersion = config.appConfiguration.minorVersion
    this.ProviderID = config.appConfiguration.agencyID
  }
}

export class Headers {
  appSecret: string;
  appName: string;
  constructor() {
    this.appSecret = '';
    this.appName = 'ENT';
  }
}
