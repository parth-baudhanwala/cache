import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { IBroadCastModelResponse } from '../models/scripts.model';
import { BaseHttpService } from './base.http.service';
import { ConfigurationService } from './configuration.service';

@Injectable({
  providedIn: "root",
})
export class BroadCastService extends BaseHttpService {
  constructor(httpClient: HttpClient, config: ConfigurationService) {
    super(httpClient, config);
    this.apiPrefix = "BroadCast/";
  }

  sendBroadCastDetails(caregiverData: any): Observable<IBroadCastModelResponse> {
    return this.post<IBroadCastModelResponse>("SendBroadCastDetails", caregiverData);
  }
}
