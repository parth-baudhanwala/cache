import isEmpty from "lodash/fp/isEmpty";
import isNumber from "lodash/fp/isNumber";
import isNaN from "lodash/fp/isNaN";

export function isBlank(value: any): boolean {
  return (isEmpty(value) || isNaN(value)) && !isNumber(value);
}
