import {
  SessionStorageKeyNames,
  SessionStorageService,
} from "./session-storage.service";
import { getTestBed, TestBed } from "@angular/core/testing";
import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { LoggerService } from "hhax-components";

describe("SessionStorageService", () => {
  let service: SessionStorageService;
  let loggerService: LoggerService;
  let injector: TestBed;
  let httpMock: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: LoggerService,
          useValue: {
            logError: () =>
              "Session Storage value for: ${key.toString()}, could not be set to null or undefined",
          },
        },
      ],
    });

    injector = getTestBed();
    httpMock = injector.inject(HttpTestingController);
    service = injector.inject(SessionStorageService);
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });

  it("SessionManagerService should be created", () => {
    expect(service).toBeDefined();
  });

  it("getItem method value is empty", () => {
    const value = "appConfig";
    service.getItem(SessionStorageKeyNames.workListUsers);
    expect(value).toEqual("appConfig");
  });

  it("setItem method value empty", () => {
    const value = "";
    service.setItem(SessionStorageKeyNames.workListUsers, value);
    expect(value).toEqual("");
  });
  it("setItem method value not empty", () => {
    const value = "setItem";
    service.setItem(SessionStorageKeyNames.workListUsers, value);
    expect(value).toEqual("setItem");
  });

  it("removeItem method should call", () => {
    const value = "removeItem";
    service.removeItem(SessionStorageKeyNames.workListUsers);
    expect(value).toEqual("removeItem");
  });

  it("destroySessionStorage method should call", () => {
    service.destroySessionStorage();
    expect(
      service.getItem(SessionStorageKeyNames["workListUsers"])
    ).toBeFalsy();
  });
});
