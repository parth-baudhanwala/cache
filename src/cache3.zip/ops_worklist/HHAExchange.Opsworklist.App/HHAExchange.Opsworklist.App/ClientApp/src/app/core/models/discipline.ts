
export interface Discipline {
    disciplineID: string;
    discipline: string;
  }