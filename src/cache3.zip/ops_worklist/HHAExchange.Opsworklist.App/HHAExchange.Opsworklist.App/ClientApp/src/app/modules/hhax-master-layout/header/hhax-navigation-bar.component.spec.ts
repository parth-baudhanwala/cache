import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HhaxNavigationBarComponent } from './hhax-navigation-bar.component';

describe('HhaxNavigationBarComponent', () => {
  let component: HhaxNavigationBarComponent;
  let fixture: ComponentFixture<HhaxNavigationBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HhaxNavigationBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HhaxNavigationBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
