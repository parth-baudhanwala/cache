import { TestBed } from '@angular/core/testing';

import { HhaxMasterLayoutService } from './hhax-master-layout.service';

describe('HhaxMasterLayoutService', () => {
  let service: HhaxMasterLayoutService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HhaxMasterLayoutService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
