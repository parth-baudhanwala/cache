import { IconDefinition } from '@fortawesome/pro-solid-svg-icons';

export interface ActionLink {
  id: number;
  label: string;
  counter?: number | string;
  route?: string;
  icon?: IconDefinition;
  handler?: (event?: any) => void;
  children?: ActionLink[];
  isPopup?: boolean;
  isLabelTitle?: boolean;
  innerHtml?: string;
}
