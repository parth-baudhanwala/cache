import { Injectable } from '@angular/core';
import { LoggerService } from 'hhax-components';

@Injectable({
  providedIn: "root",
})
export class SessionStorageService {
  constructor(private _loggerService: LoggerService) {}

  public getItem<T>(key: SessionStorageKeyNames): T {
    const value = sessionStorage.getItem(key.toString());

    if (!value) {
      return null;
    }

    return JSON.parse(value) as T;
  }

  public setItem(key: SessionStorageKeyNames, value: any): void {
    if (!value) {
      this._loggerService.logError(
        `Session Storage value for: ${key.toString()}, could not be set to null or undefined`
      );
      return;
    }

    sessionStorage.setItem(key.toString(), JSON.stringify(value));
  }

  public removeItem(key: SessionStorageKeyNames): void {
    sessionStorage.removeItem(key);
  }

  public destroySessionStorage(): void {
    Object.keys(SessionStorageKeyNames).forEach((k) => {
      sessionStorage.removeItem(k);
    });
  }
}

export enum SessionStorageKeyNames {
  workListUsers = "workListUsers",
  appConfig = "appConfig",
  officeData = "GetAllOffices",
  cargeGiverDiscipline = "GetCaregiverDisciplinesForOffice",
  usersByWorklistID = "GetUsersByWorklistID",
  getContractDetail="getContractDetail",
  getCoordinatorsByID = "getCoordinatorsByID",
  language = "GetLanguage"
}
