export enum VisitScheduleType {
  DAILY_FIXED = "Daily Fixed",
  DAILY_VARIABLE = "Daily Variable",
  WEEKLY_VARIABLE = "Weekly Variable",
  NO_SCHEDULE = "No Schedule"
}
