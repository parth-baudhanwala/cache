import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { getTestBed, TestBed } from "@angular/core/testing";

import {
  getBranchForOfficeResponse,
  getCaregiverTeamDataResponse,
  getContractOptionsResponse,
  getCoordinatorsByIDResponse,
  getDisciplineForOfficeResponse,
  getLocationsData,
  getOfficeDataResponse,
  sendBroadCastSendMessageDataResponse,
  getNurseOptionsResponse
} from "../services-mock-data/search-field.service.mock";
import { ConfigurationService } from "./configuration.service";
import { SearchFieldsService } from "./search-fields.service";
import { SessionStorageService } from "./session-storage.service";

describe("SearchFieldsService", () => {
  let service: SearchFieldsService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let getLocationDataParams = {
    UserID: 27398,
    LocationID: -1,
    Active: -1,
    PatientID: -1,
    AideID: -1,
    OfficeXml: null,
    AppVersion: "ENT",
    Version: 21.02,
    MinorVersion: 1,
    VendorID: 691,
    OfficeId: "1366",
  };

  let sendBroadCastSendMessageData = {
    MessageTypeID: "1",
    TemplateID: 3823,
    Subject: "test data",
    Message: "AN Test Voice Script",
    IsScheduled: 1,
    UserID: 27398,
    PriorityType: 1,
    ProviderID: 691,
    AideID: [977682],
    DeliveryOption: 1,
  };
  let params = {
    UserID: 27398,
    VendorID: 691,
    OfficeId: 851,
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        SessionStorageService,
        { provide: "HOST", useValue: "test" },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userId: 27398,
            },
          },
        },
      ],
    });
    injector = getTestBed();
    service = injector.inject(SearchFieldsService);
    httpMock = injector.inject(HttpTestingController);
  });
  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });

  it("SearchFieldsService should be created", () => {
    expect(service).toBeTruthy();
  });
  it("SearchFieldsService should call getDiscipline", () => {
    service.getDiscipline(getLocationDataParams).subscribe((res) => {
      expect(res).toBe(getDisciplineForOfficeResponse);
    });
    const request = httpMock.expectOne(
      "SearchField/GetCaregiverDisciplinesForOffice?UserID=27398&LocationID=-1&Active=-1&PatientID=-1&AideID=-1&OfficeXml=null&AppVersion=ENT&Version=21.02&MinorVersion=1&VendorID=691&OfficeId=1366"
    );
    expect(request.request.method).toBe("GET");
    request.flush(getDisciplineForOfficeResponse);
  });
  it("SearchFieldsService should call getOfficeData", () => {
    service.getOfficeData(getLocationDataParams).subscribe((res) => {
      expect(res).toEqual(getOfficeDataResponse);
    });
    const request = httpMock.expectOne(
      "SearchField/GetAllOffices?UserID=27398&LocationID=-1&Active=-1&PatientID=-1&AideID=-1&OfficeXml=null&AppVersion=ENT&Version=21.02&MinorVersion=1&VendorID=691&OfficeId=1366"
    );
    expect(request.request.method).toBe("GET");
    request.flush(getOfficeDataResponse);
  });
  it("SearchFieldsService should call getLocationData", () => {
    service.getLocationData(getLocationDataParams).subscribe((res) => {
      expect(res).toEqual(getLocationsData);
    });
    const request = httpMock.expectOne(
      "SearchField/GetLocationForOffice?UserID=27398&LocationID=-1&Active=-1&PatientID=-1&AideID=-1&OfficeXml=null&AppVersion=ENT&Version=21.02&MinorVersion=1&VendorID=691&OfficeId=1366"
    );
    expect(request.request.method).toBe("GET");
    request.flush(getLocationsData);
  });
  it("SearchFieldsService should call getBranchData", () => {
    service.getBranchData(getLocationDataParams).subscribe((res) => {
      expect(res).toEqual(getBranchForOfficeResponse);
    });
    const request = httpMock.expectOne(
      "SearchField/GetBranchForOffice?UserID=27398&LocationID=-1&Active=-1&PatientID=-1&AideID=-1&OfficeXml=null&AppVersion=ENT&Version=21.02&MinorVersion=1&VendorID=691&OfficeId=1366"
    );
    expect(request.request.method).toBe("GET");
    request.flush(getBranchForOfficeResponse);
  });
  it("SearchFieldsService should call getTeamData", () => {
    service.getCaregiverTeamData(getLocationDataParams).subscribe((res) => {
      expect(res).toEqual(getCaregiverTeamDataResponse);
    });
    const request = httpMock.expectOne(
      "SearchField/GetCaregiverTeam?UserID=27398&LocationID=-1&Active=-1&PatientID=-1&AideID=-1&OfficeXml=null&AppVersion=ENT&Version=21.02&MinorVersion=1&VendorID=691&OfficeId=1366"
    );
    expect(request.request.method).toBe("GET");
    request.flush(getCaregiverTeamDataResponse);
  });
  it("SearchFieldsService should call sendMessagetoCaregiver", () => {
    service
      .sendMessagetoCaregiver(sendBroadCastSendMessageData)
      .subscribe((res) => {
        expect(res).toEqual(sendBroadCastSendMessageDataResponse);
      });
    const request = httpMock.expectOne("SearchField/sendBroadCastDetails");
    expect(request.request.method).toBe("POST");
    request.flush(sendBroadCastSendMessageDataResponse);
  });
  it("SearchFieldsService should call getContractOptions", () => {
    service.getContractOptions(getLocationDataParams).subscribe((res) => {
      expect(res).toEqual(getContractOptionsResponse);
    });
    const request = httpMock.expectOne(
      "SearchField/getContractDetail?UserID=27398&LocationID=-1&Active=-1&PatientID=-1&AideID=-1&OfficeXml=null&AppVersion=ENT&Version=21.02&MinorVersion=1&VendorID=691&OfficeId=1366"
    );
    expect(request.request.method).toBe("GET");
    request.flush(getContractOptionsResponse);
  });
  it("SearchFieldsService should call getCoordinatorOptions", () => {
    service.getCoordinatorOptions(getLocationDataParams).subscribe((res) => {
      expect(res).toEqual(getCoordinatorsByIDResponse);
    });
    const request = httpMock.expectOne(
      "SearchField/getCoordinatorsByID?UserID=27398&LocationID=-1&Active=-1&PatientID=-1&AideID=-1&OfficeXml=null&AppVersion=ENT&Version=21.02&MinorVersion=1&VendorID=691&OfficeId=1366"
    );
    expect(request.request.method).toBe("GET");
    request.flush(getCoordinatorsByIDResponse);
  });

  it("SearchFieldsService should call getNurseOptions", () => {
    service.getNurseOptions(params).subscribe((res) => {
      expect(res).toEqual(getNurseOptionsResponse);
    });
    const request = httpMock.expectOne(
      "SearchField/GetNurseDetails?UserID=27398&VendorID=691&OfficeId=851"
    );
    expect(request.request.method).toBe("GET");
    request.flush(getNurseOptionsResponse);
  });
  
});
