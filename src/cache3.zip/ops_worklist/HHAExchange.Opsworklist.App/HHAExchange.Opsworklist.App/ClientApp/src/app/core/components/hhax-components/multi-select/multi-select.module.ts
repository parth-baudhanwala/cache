import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { MultiSelectComponent } from "./multi-select.component";
import { FormLabelModule } from "hhax-components";
import { ReactiveFormsModule } from "@angular/forms";
import { MatSelectModule } from "@angular/material/select";
import { ScrollingModule } from "@angular/cdk/scrolling";

@NgModule({
  declarations: [MultiSelectComponent],
  exports: [MultiSelectComponent],
  imports: [
    CommonModule,
    FormLabelModule,
    MatSelectModule,
    ReactiveFormsModule,
    ScrollingModule,
  ],
})
export class MultiSelectModule {}
