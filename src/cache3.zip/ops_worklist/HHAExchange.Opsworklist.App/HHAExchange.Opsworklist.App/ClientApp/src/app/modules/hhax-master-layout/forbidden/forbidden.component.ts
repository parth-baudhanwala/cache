import { Component } from '@angular/core';

@Component({
  templateUrl: './forbidden.component.html'
})
export class ForbiddenComponent { }
