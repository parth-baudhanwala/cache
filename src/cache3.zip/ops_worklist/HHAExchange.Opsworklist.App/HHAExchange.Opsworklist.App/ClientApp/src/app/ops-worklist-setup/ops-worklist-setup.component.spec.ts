import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpsWorklistSetupComponent } from './ops-worklist-setup.component';

describe('OpsWorklistSetupComponent', () => {
  let component: OpsWorklistSetupComponent;
  let fixture: ComponentFixture<OpsWorklistSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpsWorklistSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OpsWorklistSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
