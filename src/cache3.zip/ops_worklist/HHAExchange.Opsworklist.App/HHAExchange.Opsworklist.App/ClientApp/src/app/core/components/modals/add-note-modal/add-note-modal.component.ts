import { Component, Inject, Input, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from "@angular/material/dialog";
import { HHAUserService } from "@app/core/authentication/user.service";
import { AppConfiguration, Worklist } from "@app/core/models/common.model";
import {
  FileUploadValidate,
  saveAddNote,
  TaskNotes,
  IGetAllNotesByTaskID,
  IGetAllNotesByTaskIDResult,
} from "@app/core/models/notes.model";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { FileService } from "@app/core/services/file.service";
import { NotesService } from "@app/core/services/notes.service";
import { faMinus, faPlus } from "@fortawesome/free-solid-svg-icons";
import * as FileSaver from "file-saver";
import { ToastrAlertService } from "hhax-components";
import find from "lodash/fp/find";

import { OpsWorklistData } from "../../../models/constant.model";
import { ISubjectData, IsubjectResponse } from "../../../models/subject.model";

@Component({
  selector: "add-note",
  templateUrl: "./add-note-modal.component.html",
  styleUrls: ["./add-note-modal.component.scss"],
  styles: [
    `
      :host >>> .tooltip {
        position: absolute;
        max-width: 18rem;
        border-radius: 0.25rem;
        opacity: 9;
      }
      :host >>> .tooltip-inner {
        background-color: #0a0a0a;
        color: #fefefe;
        font-size: 12px;
        font-weight: bold;
        max-width: 18rem;
        text-align: left;
        padding: 0px;
      }
    `,
  ],
})
export class AddNoteComponent implements OnInit {
  @Input() titleText: string;
  @Input() id: string;
  addNote: FormGroup;
  fileUploadError: string;
  fileName: string | ArrayBuffer;
  actualFile: string | ArrayBuffer;
  label: "file Upload";
  name: "Attach File";
  displayFileName: string;
  viewAllData: IGetAllNotesByTaskIDResult[];
  subjectDataList = [];
  subjectOptions: ISubjectData[];
  subjectValue: number;
  reasonType: number;
  fileData: string;
  fileUpload: boolean = false;
  appConfig: AppConfiguration;
  fileGUID: string;
  fileUploadResponse: FormData;
  saveNotesData = new FormData();
  fileUploadData = new FormData();
  fileUploadedValidate: boolean;
  show: boolean;

  isHidden: boolean;
  plus = faPlus;
  minus = faMinus;
  alertMsg: string;
  alertModalMsg: string;
  fileSizeLimit: number = 0;
  isUploading: boolean = false;

  constructor(
    public _addNoteModal: MatDialog,
    public _dialogRef: MatDialogRef<AddNoteComponent>,
    public _notesService: NotesService,
    public _config: ConfigurationService,
    public _userService: HHAUserService,
    public _fb: FormBuilder,
    public _alert: ToastrAlertService,
    public _fileService: FileService,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {}

  ngOnInit() {
    this.alertModalMsg = "Opened Add Note Popup";
    this.appConfig = this._config.appConfiguration;
    if (this.data.worklistPath === Worklist.MEDICAL_COMPLIANCE) {
      this.reasonType = 105;
    } else {
      this.reasonType = 101;
    }
    const requestData = {
      reasonType: this.reasonType,
      UserID: this.appConfig.userId,
      IsActive: 1,
      AppVersion: this.appConfig.appName,
      Version: this.appConfig.version,
      MinorVersion: this.appConfig.minorVersion,
    };
    this.isHidden = false;
    this.addNote = this._fb.group({
      subject: new FormControl(""),
      notes: new FormControl("", Validators.required),
      isInternalNote: new FormControl(true),
      copyNotetoProfile: new FormControl(false),
    });
    if (this.data.record.worklistTaskId) {
      this._notesService
        .GetAllNotesByTaskID(this.data.record.worklistTaskId, this._userService.getUserPrimaryOfficeID()
          , this._config.appConfiguration.entapiurl + "api/")
        .subscribe((res: IGetAllNotesByTaskID) => {
          if (res["result"]) {
            this.viewAllData = res["result"];
          }
        });
    }
    this._notesService
      .getSubjectItems(requestData)
      .subscribe((res: IsubjectResponse) => {
        if (res && res.responseBody) {
          this.subjectOptions = res.responseBody;
          this.subjectOptions.forEach((obj) => {
            this.subjectDataList.push({
              text: obj.reason,
              value: obj.reasonID,
            });
          });
        }
      });
    
    this.fileSizeLimit = this._userService.getFileSizeLimit();
  }

  public toggle() {
    this.isHidden = !this.isHidden;
  }
  closeDialog(action: any): void {
    this._dialogRef.close(action);
  }
  changeListener($event): void {
    if (!this._fileService.isValidFileExtension($event.target)) {
      $event.target.value = null;
      this._alert.error("error", "The selected file has an invalid/unsupported extension.");
    } else if (this._fileService.isValidFile($event.target, this.fileSizeLimit)) {
        this.isUploading = true;
        let formData = new FormData();
        this.fileUpload = true;
        this.displayFileName = $event.target.files[0].name;
        this.fileData = $event.target.files[0];
        formData.append(this.displayFileName, this.fileData);
        formData.append("MethodType", OpsWorklistData.MethodTypeValidate);
        formData.append("AppSecret", this.appConfig.appsecret);
        formData.append("AppName", this.appConfig.appName);
        formData.append("HHAWSURL", this.appConfig.hhawsenturl);
        this._fileService
          .FileUpload(formData)
          .subscribe((res: FileUploadValidate[]) => {
            if (res) {
              this.fileUploadedValidate = res[0].isfileUploadedSucessfully;
              if (this.fileUploadedValidate) {
                this.readThis($event.target);
              } else {
                $event.target.value = null;
                this._alert.error(
                  "error",
                  "Incorrect File size or File type or File name length"
                );
              }
            }
            this.isUploading = false;
          });
    } else {
      this._alert.error(
        "error",
        "Incorrect File size or File type or File name length"
      );
    }
  }

  readThis(inputValue): void {
    const file: File = inputValue.files[0];
    this.data.file = file;
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e) => {
      this.fileName = myReader.result;
      this.data.attachmentfilename = this.fileName;
    };
    myReader.readAsDataURL(inputValue.files[0]);
  }

  async saveNote() {
    this.show = true;
    if (this.fileUpload) {
      this.fileUploadData.append(this.displayFileName, this.fileData);
      this.fileUploadData.append("MethodType", OpsWorklistData.MethodTypeSave);
      this.fileUploadData.append("UserID", this.appConfig.userId.toString());
      this.fileUploadData.append(
        "Module",
        this.data.worklistPath === Worklist.MEDICAL_COMPLIANCE
          ? OpsWorklistData.AideModule
          : OpsWorklistData.PatientModule
      );
      this.fileUploadData.append("ModuleID", OpsWorklistData.ModuleID);
      this.fileUploadData.append("FeatureID", OpsWorklistData.FeatureID);
      this.fileUploadData.append("Agency", OpsWorklistData.Agency);
      this.fileUploadData.append("Feature", OpsWorklistData.FeatureNotes);
      this.fileUploadData.append(
        "AgencyID",
        this.appConfig.agencyID.toString()
      );
      this.fileUploadData.append("AppSecret", this.appConfig.appsecret);
      this.fileUploadData.append("AppName", this.appConfig.appName);
      this.fileUploadData.append("HHAWSURL", this.appConfig.hhawsenturl);
      this.fileUploadData.append("FileGUID", "");
      this._fileService
        .FileUpload(this.fileUploadData)
        .subscribe((res: FileUploadValidate[]) => {
          if (res) {
            this.fileGUID = res[0].fileGUID;
            this.saveNotes();
          }
        });
    } else {
      this.saveNotes();
    }
  }
  saveNotes() {
    const subject = this.addNote.get("subject").value
      ? this.addNote.get("subject").value
      : null;
    const subjectTxt = this.addNote.get("subject").value
      ? find(["value", this.addNote.get("subject").value], this.subjectDataList).text : 0;
    const appConfig = this._config.appConfiguration;
    const taskNote: TaskNotes = new TaskNotes(this._config);
    taskNote.CreatedBy = appConfig.userId.toString();
    taskNote.CreatedByUser = `${this._userService.getUserFullName()} (${this._userService.getUserName()})`;
    taskNote.Subject = subject;
    taskNote.SubjectText = subjectTxt;
    taskNote.Note = this.data.notes;
    taskNote.CopyNoteToProfile = this.addNote.get("copyNotetoProfile").value;
    taskNote.CopyNotesTo = taskNote.CopyNoteToProfile
      ? this.getEntity(this.data.worklistPath)
      : "";
    taskNote.IsInternalNote = this.includeInternalNoteCheckbox()
      ? this.addNote.get("isInternalNote").value
      : null;

    if (this.fileGUID) {
      taskNote.FileAttachmentGUID = this.fileGUID;
      taskNote.AttachmentName = this.displayFileName;
    }
    if (Array.isArray(this.data.record)) {
      // bulk actions
      let obj = {};
      this.data.record.map((record) => {
        obj[record.officeId] = {
          taskIds: [],
          AideIDs: [],
          PatientIDs: [],
        };
      });
      this.data.record.map((record) => {
        obj[record.officeId]["taskIds"].push(record.worklistTaskId);
        this.data.worklistPath === Worklist.MEDICAL_COMPLIANCE
          ? obj[record.officeId]["AideIDs"].push(record.careGiverId)
          : obj[record.officeId]["PatientIDs"].push(record.patientId);
      });
      this.saveBulkNotes(obj, taskNote);
    } else {
      // single record
      taskNote.WorklistTaskIds = this.data.record.worklistTaskId;
      taskNote.OfficeID = this.data.record.officeId;
      taskNote.AideIDs =
        this.data.worklistPath === Worklist.MEDICAL_COMPLIANCE
          ? this.data.record.careGiverId.toString()
          : "";
      taskNote.PatientIDs =
        this.data.worklistPath === Worklist.MEDICAL_COMPLIANCE
          ? ""
          : this.data.record.patientId.toString();
      this._notesService.SaveNotes(taskNote).subscribe((res: saveAddNote) => {
        if (res) {
          this.show = false;
          this.closeDialog(res);
        }
      });
    }
  }

  srUploadAlert(): void {
    this.alertMsg = "Opening Attachment Window";
    setTimeout(() => {
      this.alertMsg = "";
    }, 700);
  }

  async saveBulkNotes(records, taskNote) {
    for (let officeId in records) {
      const officeData = records[officeId];
      taskNote.WorklistTaskIds =
        officeData && officeData.taskIds ? officeData.taskIds.join(",") : "";
      taskNote.AideIDs =
        officeData && officeData.AideIDs ? officeData.AideIDs.join(",") : "";
      taskNote.PatientIDs =
        officeData && officeData.PatientIDs
          ? officeData.PatientIDs.join(",")
          : "";
      taskNote.OfficeID = officeId;

      this._notesService.SaveNotes(taskNote).subscribe((res: saveAddNote) => {
        if (res) {
          this.show = false;
          this.closeDialog(res);
        }
      });
    }
  }

  async downloadFile(record) {
    let payload = {
      AppSecret: this.appConfig.appsecret,
      AppName: this.appConfig.appName,
      HHAWSURL: this.appConfig.hhawsenturl,
      FileGUID: "",
    };
    payload.FileGUID = record.fileGuid;
    this._fileService.downloadFile(payload).subscribe((res) => {
      if (res.ok) {
        const blob = new Blob([res.body], {
          type: res.headers.get("x-file-content-type"),
        });
        const nav = (window.navigator as any);

        if (nav.msSaveOrOpenBlob) {
          // IE 11
          nav.msSaveOrOpenBlob(blob, record.attachmentName);
        } else {
          // Google chrome, Firefox, ....
          FileSaver.saveAs(blob, record.attachmentName);
        }
        this._alert.success("success", "File downloaded successfully");
      }
    });
  }

  getEntity(path) {
    switch (path) {
      case "MedicalCompliance":
        return "caregiver";
      case "ExpiringAuthorization":
        return "patient";
      case "UnstaffedVisits":
        return "patient";
      case "MasterWeek":
        return "patient";
      case "ExpiringCertificationPeriod":
        return "patient";
    }
  }

  isInternalNoteDisabled() {
    if (Array.isArray(this.data.record)) {
      return true;
    } else {
      return this.data.record.isInternalPatient ? true : null;
    }
  }

  includeInternalNoteCheckbox() {
    switch (this.data.worklistPath) {
      case "ExpiringAuthorization":
        return true;
      case "UnstaffedVisits":
        return true;
      default:
        return false;
    }
  }
}
