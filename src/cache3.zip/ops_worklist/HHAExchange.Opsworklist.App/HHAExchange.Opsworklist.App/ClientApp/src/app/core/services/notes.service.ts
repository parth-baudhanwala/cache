import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

import {
  IGetAllNotesByTaskID,
  saveAddNote,
  TaskNotes,
} from "../models/notes.model";
import { IsubjectResponse } from "../models/subject.model";
import { BaseHttpService } from "./base.http.service";
import { ConfigurationService } from "./configuration.service";

@Injectable({
  providedIn: "root",
})
export class NotesService extends BaseHttpService {
  constructor(httpClient: HttpClient, config: ConfigurationService) {
    super(httpClient, config);
    this.apiPrefix = "Notes/";
  }

  SaveNotes(data: TaskNotes): Observable<saveAddNote> {
    return this.post<saveAddNote>("", data);
  }

  GetAllNotesByTaskID(id: number, primaryOfficeID: number, ENTAPIURL: string): Observable<IGetAllNotesByTaskID> {
    return this.get<IGetAllNotesByTaskID>("GetAllNotesByTaskID", {
      WorklistTaskId: id,
      PrimaryOfficeID: primaryOfficeID,
      ENTAPIURL: ENTAPIURL
    });
  }

  getSubjectItems(requestData): Observable<IsubjectResponse> {
    return this.get<IsubjectResponse>("GetSubjectItems", requestData);
  }
}
