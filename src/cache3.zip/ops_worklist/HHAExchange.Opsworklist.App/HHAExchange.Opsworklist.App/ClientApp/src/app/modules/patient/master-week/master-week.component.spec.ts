import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MasterWeekComponent } from "./master-week.component";
import { WorkslistService } from "@app/core/services/workslist.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { SearchFieldsService } from "app/core/services/search-fields.service";
import { HttpClientModule } from "@angular/common/http";
import { FormBuilder } from "@angular/forms";
import { MatDialog, MatDialogModule } from "@angular/material/dialog";
import { of } from "rxjs";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import {
  getContractOptionsResponse,
  getCoordinatorsByIDResponse,
  getDisciplineForOfficeResponse,
  getOfficeDataResponse,
} from "@app/core/services-mock-data/search-field.service.mock";
import { NotesService } from "@app/core/services/notes.service";
import {
  closingConditionResponse,
  GetUsersByWorklistIDResponse,
  UpdateStatusResponse,
} from "@app/core/services-mock-data/common.service.mock";
import { GetAllNotesByTaskIDResponseData } from "@app/core/services-mock-data/notes.service.mock";
import { CommonService } from "@app/core/services/common.service";
import { ComponentColours, ToastrAlertService } from "hhax-components";
import { HHAUserService } from "@app/core/authentication/user.service";
import { saveNotesResponse } from "@app/core/services-mock-data/notes.service.mock";
import { DatePipe } from '@angular/common';

const mockRecord = {
  authorizationNumber: "123456",
  remaining: "20 Hours",
  patientNameOrID: "Simon",
  patientAdmID: "HHA-P001",
  contract: "Jake",
  lastNotes: {
    createdDate: "02/27/2021",
    createdByUser: "Raymond Holt",
    note: "Expiring Auth Notes",
  },
  dateReported: "03/08/2021",
  assignedTo: "Gina Linetti",
  status: "Open",
  expirationDate: "03/31/2021",
  worklistTaskId: 1,
  patientId: 5,
  worklistEntKey: "6632-||-691-||-977506",
};

let inputData = {
  userName: "test",
  worklistId: 1,
  worklistName: "medical",
  worklistPath: "url",
  canManuallyCloseWorklistTask: "NO",
  canAssignWorklistTask: "No",
  isOpsWorklistLandingPage: "any",
  assignedDefaultWorklist: 1,
  taskCount: 6,
};

const mockBulkRecords = [mockRecord, mockRecord];

describe("MasterWeekComponent", () => {
  let component: MasterWeekComponent;
  let fixture: ComponentFixture<MasterWeekComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [MasterWeekComponent],
      imports: [HttpClientModule, MatDialogModule, BrowserAnimationsModule],
      providers: [
        {
          provide: SearchFieldsService,
          useValue: {
            getOffices: () => of(getDisciplineForOfficeResponse),
            getContractOptions: () => of(getContractOptionsResponse),
            getCoordinatorOptions: () => of(getCoordinatorsByIDResponse),
            getOfficeData: () => of(getOfficeDataResponse),
            getDiscipline: () => of(getDisciplineForOfficeResponse),
          },
        },
        {
          provide: WorkslistService,
          useValue: {
            closingCondition: (params) => of(closingConditionResponse),
            getsubject: () => of("test"),
          },
        },
        {
          provide: CommonService,
          useValue: {
            GetUsersByWorklistID: () => of(GetUsersByWorklistIDResponse),
            updateTask: () => of(UpdateStatusResponse),
          },
        },
        {
          provide: NotesService,
          useValue: {
            GetAllNotesByTaskID: () => of(GetAllNotesByTaskIDResponseData),
            SaveNotes: () => of(saveNotesResponse),
          },
        },
        MatDialog,
        FormBuilder,
        { provide: "HOST", useValue: "test" },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userId: 27398,
              userOffices: [{ officeID: "123" }],
              AppVersion: "ENT",
              Version: 21.02,
              MinorVersion: 1,
              VendorID: 691,
              entMainURL: "http://development.hhaexchange.com/HRCG-2111/",
            },
          },
        },
        {
          provide: ToastrAlertService,
          useValue: {
            error: () =>
              of("error", "There was error while fetching Office(s)."),
            success: () => of("success", "Note Saved Successfully"),
          },
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserID: () => of(37485),
            getUserName: () => of("test"),
            getUserFullName: () => of("Test Test"),
          },
        },
        DatePipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterWeekComponent);
    component = fixture.componentInstance;
    component.worklistDetail = inputData; // set input before first detectChanges
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeDefined();
  });

  it("should get change status color", () => {
    let statusColor = component.getStatusColor("Open");
    expect(statusColor).toEqual(ComponentColours.warning);
    statusColor = component.getStatusColor("Closed");
    expect(statusColor).toEqual(ComponentColours.success);
    statusColor = component.getStatusColor("Completed");
    expect(statusColor).toEqual(ComponentColours.success);
    statusColor = component.getStatusColor("In-Progress");
    expect(statusColor).toEqual(ComponentColours.info);
    statusColor = component.getStatusColor("");
    expect(statusColor).toEqual(ComponentColours.none);
    component.onReset();
  });

  it("should call on init method", async () => {
    expect(component.worklistDetail.canAssignWorklistTask).toEqual("No");
    expect(component.worklistDetail.canManuallyCloseWorklistTask).toEqual("NO");
    await component.actionButtons[0].handler(mockBulkRecords);
    await component.actionButtons[1].handler(mockBulkRecords);
    await component.actionButtons[2].handler(mockBulkRecords);
    await component.actionButtons[3].handler(mockBulkRecords);
    await component.actionButtons[4].handler(mockBulkRecords);
    await component.actionButtons[5].handler(mockBulkRecords);

    component.worklistDetail = {
      userName: "test",
      worklistId: 1,
      worklistName: "medical",
      worklistPath: "MedicalCompliance",
      canManuallyCloseWorklistTask: "No",
      canAssignWorklistTask: "No",
      isOpsWorklistLandingPage: "any",
      assignedDefaultWorklist: 1,
      taskCount: 6,
    };
    component.ngOnInit();
  });

  it("should call on submit", async () => {
    component.onSubmit();
    spyOn(component, "onSubmit");
    expect(component.searchWorkLists).toBeDefined();
  });

  it("should call on openNote", async () => {
    component.openNote(mockRecord);
    spyOn(component, "openNote");
    expect(component.openAddNoteDialog).toBeDefined();
  });

  it("should call onAssigneeClick", () => {
    component.onAssigneeClick(mockRecord, {});
    spyOn(component, "onAssigneeClick");
    expect(component.openAssignTaskModal).toBeDefined();
  });

  it("should call openMasterWeekSchedule", () => {
    component.openMasterWeekSchedule(mockRecord);
    spyOn(component, "openMasterWeekSchedule");
    expect(component.openWeekScheduleModal).toBeDefined();
  });

  it("should call getSRSchedule", () => {
    component.getSRSchedule("M:2200 - 2300, Sa:2200 - 2300, Su:2200 - 2300");
    spyOn(component, "onAssigneeClick");
    expect(component.openAssignTaskModal).toBeDefined();
  });

  it("should call openPopUp", () => {
    component.openPopUp(mockRecord);
    spyOn(component, "openWindowPopUp");
    expect(component.openWindowPopUp).toBeDefined();
  });
});
