    export interface ISubjectData {
        reasonID: number;
        reason: string;
        reasonDescription: string;
        reasonType: number;
        reasonLocation: string;
        active: number;
        nonCompliant: number;
        status: string;
        omigEnabled: number;
        sortOrder: number;
    }

    export interface IsubjectResponse {
        responseBody: ISubjectData[];
        httpStatusCode: number;
        httpStatusMessage?: any;
        authenticationToken?: any;
    }
