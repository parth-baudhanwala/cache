import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrAlertService } from 'hhax-components';
import { OpsWorklistSetupBaseComponent } from '../../../core/components/base-component/ops-worklist-setup-base.component';
import { patienStatusOptions } from '../../../core/config/static-options';
import { WorklistName } from '../../../core/models/common.model';
import { CertificationSetup } from '../../../core/models/worklist-setup.model';
import { ConfigurationService } from '../../../core/services/configuration.service';
import { OpsWorklistSetupService } from '../../../core/services/ops-worklist-setup.service';

@Component({
  selector: 'app-certification-period-setup',
  templateUrl: './certification-period-setup.component.html'
})
export class CertificationPeriodSetupComponent extends OpsWorklistSetupBaseComponent implements OnInit {

  expiringCertificationPeriod: FormGroup;
  worklistSetupTabName = WorklistName.CERTIFICATION_PERIOD;
  constructor(private _alert: ToastrAlertService, private _opsWorklistSetupService: OpsWorklistSetupService, private _config: ConfigurationService) {
    super();
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.fetchSaveData();
    this.getMasterWeekSetup();
  }

  fetchSaveData(): void {
    this.expiringCertificationPeriod = new FormGroup({
      taskCreation: new FormControl(30),
      taskCreationbyStatus: new FormControl([3]),
    });
  }

  getMasterWeekSetup(): void {
    this._opsWorklistSetupService.getCertificationSetup(this._config.appConfiguration.agencyID).subscribe({
      next: (res: CertificationSetup) => {
        if (res) {
          this.expiringCertificationPeriod.get("taskCreation").setValue(res.taskCreationDays);
          const patientStatusValues = res.patientStatusIds.split(',').map(element => {
            return Number(element);
          });
          if (patientStatusValues.length == patienStatusOptions.length) {
            patientStatusValues.push(-1);
          }
          this.expiringCertificationPeriod.get("taskCreationbyStatus").setValue(patientStatusValues);
        }
      },
      error: () => this._alert.error("Error", "There was an error while getting information.")
    });
  }

  onSubmit(): void {
    const taskStatusIndex = this.expiringCertificationPeriod.get("taskCreationbyStatus").value.findIndex(el => el == -1);
    if (taskStatusIndex != -1) {
      this.expiringCertificationPeriod.get("taskCreationbyStatus").value.splice(taskStatusIndex, 1);
    }
    if (this.formValidation()) {
      const patientStatusIds: string = this.expiringCertificationPeriod.get("taskCreationbyStatus").value;

      let patientStatusArray: string[] = [];

      for (let index = 0; index < patientStatusIds.length; index++) {
        let patientStatusText = patienStatusOptions.find(x => x.value == patientStatusIds[index]).text;
        patientStatusArray.push(patientStatusText);
      }

      const patientStatus = patientStatusArray.join(",");

      const certificationSetup: CertificationSetup = {
        providerId: this._config.appConfiguration.agencyID,
        taskCreationDays: this.expiringCertificationPeriod.get("taskCreation").value,
        patientStatusIds: patientStatusIds.toString(),
        patientStatus: patientStatus,
        userId: this._config.appConfiguration.userId,
        userName: this._config.appConfiguration.userName
      }

      this._opsWorklistSetupService.saveCertificationSetup(certificationSetup).subscribe(
        {
          complete: () => this._alert.success("Success", "Information has been saved successfully."),
          error: () => this._alert.error("Error", "There was an error while saving information.")
        }
      );
    }
  }

  formValidation(): boolean {
    let isFormValid = true;
    const taskCreationValue = this.expiringCertificationPeriod.get("taskCreation").value;
    const taskCreationByStatusValue = this.expiringCertificationPeriod.get("taskCreationbyStatus").value;
    let messageError;

    if (!taskCreationValue && !taskCreationByStatusValue.length) {
      messageError = "Value required for Task Creation and Task Creation by Status.";
      isFormValid = false;
    }
    else if (taskCreationValue == 0 && !taskCreationByStatusValue.length) {
      messageError = "Task Creation value should not be 0 and value required for Task Creation by Status.";
      isFormValid = false;
    }
    else if (!taskCreationValue) {
      messageError = "Value required for Task Creation.";
      isFormValid = false;
    }
    else if (!taskCreationByStatusValue.length) {
      messageError = "Value required for Task Creation by Status.";
      isFormValid = false;
    }
    else if (taskCreationValue == 0) {
      messageError = "Task Creation value should not be 0.";
      isFormValid = false;
    }
    if (!isFormValid) {
      this._alert.error("Error", messageError);
    }

    return isFormValid;
  }

}
