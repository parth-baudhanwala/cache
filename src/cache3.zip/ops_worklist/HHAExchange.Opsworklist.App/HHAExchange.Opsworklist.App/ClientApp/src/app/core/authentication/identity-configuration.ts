import { IIdentityConfiguration } from './identity-configuration.model';

export const identityConfiguration: IIdentityConfiguration = {
  authority: 'https://localhost:44364/',
  client_id: 'HHAExchange.Opsworklist.Api',
  redirect_uri: 'http://localhost:44366/auth-complete',
  post_logout_redirect_uri: 'https://localhost:44364/account/login',
  response_type: 'id_token token',
  scope: 'openid profile OpsworklistApi opsworklist',
  filterProtocolClaims: true,
  loadUserInfo: false,
  silent_redirect_uri: "https://localhost:44364/silent-refresh",
  silentRequestTimeout: 20000,
  monitorSession: false,//Will raise events for when user has performed a signout at the OP.
  automaticSilentRenew: true,
  accessTokenExpiringNotificationTime: 60, //seconds
  checkSessionInterval: 2000, //Interval, in ms, to check the user's session.
  includeIdTokenInSilentRenew: true
};
