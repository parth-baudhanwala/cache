import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SilentRefreshRoutingModule } from './silent-refresh/silent-refresh-routing.module';
import { TimeoutModalModule } from '../timeout-modal/timeout-modal.module';
import { HHAUserService } from '../user.service';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TimeoutModalModule,
    SilentRefreshRoutingModule
  ],
  providers: [HHAUserService],
})
export class UserModule { }
