import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ConfigurationService } from "../configuration.service";
import { QuickBroadcastResponse } from "@app/core/models/unstaffed-visits.model";

@Injectable({
  providedIn: "root",
})
export class ExternalService {
  constructor(
    public httpClient: HttpClient,
    public config: ConfigurationService
  ) {}

  saveQuickBroadcastInfo(params): Observable<QuickBroadcastResponse> {
    let url = `${this.config.appConfiguration.hhawsenturl}BroadcastInfo.svc/SaveQuickBroadcastInfo`;
    return this.httpClient.post<QuickBroadcastResponse>(url, params);
  }
}
