import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, forkJoin } from "rxjs";
import { mergeMap } from 'rxjs/operators';
import {
  IDisciplineModel,
  IGetCaregiverTeamModel,
  IGetContractDetailsModel,
  IGetCoordinatorsByIDModel,
  IGetLocationForOfficeModel,
  IPatientTeamModel,
  IParams,
  INurseModel,
  OfficesDisciplinesApiResponse,
  OfficesDisciplinesRequestParam,
} from "../models/common.model";
import { IBroadCastModelResponse } from "../models/scripts.model";
import { BaseHttpService } from "./base.http.service";
import { ConfigurationService } from "./configuration.service";
import {
  SessionStorageService
} from "./session-storage.service";

@Injectable({
  providedIn: "root",
})
export class SearchFieldsService extends BaseHttpService {
  private storage: SessionStorageService;

  constructor(
    httpClient: HttpClient,
    config: ConfigurationService,
    storage: SessionStorageService
  ) {
    super(httpClient, config);
    this.apiPrefix = "SearchField/";
    this.storage = storage;
  }
  getDiscipline(params: IParams): Observable<IDisciplineModel> {
    return this.get<IDisciplineModel>("GetCaregiverDisciplinesForOffice", params);
  }

  getOfficesDisciplines(officeIds: number[], providerAdminAPIUrl: string, officeIdBatchSize: number): Observable<OfficesDisciplinesApiResponse> {
    const officeIdBatches = this.getOfficeIdsBatches(officeIds, officeIdBatchSize);

    const observables = officeIdBatches.map(batch => {
      const officesDisciplinesRequestParam = new OfficesDisciplinesRequestParam(batch);
      return this.postRequestWithUrl<OfficesDisciplinesApiResponse>(providerAdminAPIUrl + 'ProviderOffice/Disciplines', officesDisciplinesRequestParam);
    });

    return forkJoin(observables).pipe(
      mergeMap(responseArray => responseArray)
    );
  }

  getOfficeIdsBatches(officeIds: number[], officeIdBatchSize: number) {
    const officeIdBatches = [];

    for (let i = 0; i < officeIds.length; i += officeIdBatchSize) {
      officeIdBatches.push(officeIds.slice(i, i + officeIdBatchSize));
    }

    return officeIdBatches;
  }

  getLanguageData() {
    return this.get<any>("GetLanguages");
  }
  getOfficeData(params: IParams) {
    return this.get<any>("GetAllOffices", params);
  }
  getLocationData(params: IParams): Observable<any> {
    return this.get<any>("GetLocationForOffice", params);
  }
  getBranchData(params: IParams): Observable<IGetLocationForOfficeModel> {
    return this.get<IGetLocationForOfficeModel>("GetBranchForOffice", params);
  }
  getCaregiverTeamData(params: IParams): Observable<IGetCaregiverTeamModel[]> {
    return this.get<IGetCaregiverTeamModel[]>("GetCaregiverTeam", params);
  }
  getPatientTeamData(params: IParams): Observable<IPatientTeamModel[]> {
    return this.get<IPatientTeamModel[]>("GetPatientTeam", params);
  }
  sendMessagetoCaregiver(caregiverData): Observable<IBroadCastModelResponse> {
    return this.post<IBroadCastModelResponse>("sendBroadCastDetails", caregiverData);
  }
  getContractOptions(params: any): Observable<IGetContractDetailsModel> {
    return this.get<IGetContractDetailsModel>("getContractDetail", params);
  }
  getCoordinatorOptions(params: any): Observable<IGetCoordinatorsByIDModel> {
    return this.get<IGetCoordinatorsByIDModel>("getCoordinatorsByID", params);
  }
  getNurseOptions(params: any): Observable<INurseModel[]> {
    return this.get<INurseModel[]>("GetNurseDetails", params);
  }
  getCaregiverComplianceExpItemData(params: IParams): Observable<any> {
    return this.get<any>("GetCaregiverComplianceExpItem", params);
  }
}
