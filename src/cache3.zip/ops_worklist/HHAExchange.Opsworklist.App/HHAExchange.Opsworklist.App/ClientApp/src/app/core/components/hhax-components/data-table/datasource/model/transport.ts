export interface DataTableResponse<T> {
  pageInfo: PageInfo;
  data: T[];
}

export interface DataTableRequest<T> {
  sort: Sort;
  page: PageRequest;
  queryParams: T | any;
}


export interface Sort {
  direction: SortDirection;
  item: string;
}

export interface PageInfo {
  totalRecordCount: number;
}

export interface GetRequest {
  page?: PageRequest;
  sort?: SortRequest;
}

export interface PageRequest {
  pageSize: number;
  pageNumber: number;
}

export interface SortRequest {
  direction: SortDirection;
  item: string;
}

export enum SortDirection {
  Ascending,
  Descending
}
