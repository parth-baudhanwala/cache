export interface TableDataSourceConfig<T = any> {
  // TODO Make models for each type of request
  get: {
    url: string;
    queryParams?: any;
  };
  data?: T[];
  page: PageRequest;
  sort?: Sort;
}

export interface Sort {
  direction: SortDirection;
  item: string;
}

export enum SortDirection {
  Ascending,
  Descending
}

export interface PageRequest {
  pageSize: number;
  pageNumber: number;
}

export interface DataTableRequest<T> {
  sort: Sort;
  page: PageRequest;
  queryParams: T | any;
}

export interface DataTableResponse<T> {
  pageInfo: PageInfo;
  data: T[];
}

export interface PageInfo {
  totalRecordCount: number;
}
