import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from "../../../environments/environment";
import { AppConfiguration, AppSettings } from "../models/common.model";
import { LocalStorageKeyNames, LocalStorageService } from "./local-storage.service";
import { SessionStorageKeyNames, SessionStorageService } from "./session-storage.service";

@Injectable({
  providedIn: "root",
})
export class ConfigurationService {
  public hasAppLoaded = false;

  constructor(
    private _httpClient: HttpClient,
    private _sessionStorage: SessionStorageService,
    private _localStorage: LocalStorageService
  ) { }

  get basePath(): string {
    return document.getElementsByTagName("base")[0].href;
  }

  public get apiUrl(): string {
    return this.basePath.includes("localhost") ? `${environment.apiUrl}/` : `${this.basePath}api/`;
  }

  public get appConfiguration(): AppConfiguration {
    return this._sessionStorage.getItem<AppConfiguration>(
      SessionStorageKeyNames.appConfig
    );
  }

  public geAppConfiguration(UserID: number): Promise<void> {
    if (this.appConfiguration === null) {
      return this._httpClient
        .get<AppConfiguration>(`${this.apiUrl}Common/GetUserProfile`, {
          params: this.serialise({
            UserID,
            CallerInfo: "opsworklist",
          }),
        })
        .toPromise()
        .then((config: AppConfiguration) => {
          config.ApiUrl = this.apiUrl;
          config.userId = UserID;
          this._sessionStorage.setItem(
            SessionStorageKeyNames.appConfig,
            config
          );
        });
    }
    return new Promise<void>((resolve, reject) => resolve());
  }

  public resetAppConfiguration() {
    this._sessionStorage.removeItem(SessionStorageKeyNames.appConfig);
  }

  public getIdentityURL(): string {
    if (this.basePath.includes("localhost")) {
      return "https://localhost:44364";
    }
    const location = `${window.location.protocol}//${window.location.host}/Identity`;
    return location;
  }

  public setAppSettings(): void {
    this._httpClient.get<AppSettings>(this.appSettingsFilePath).subscribe({
      next: (appSettings: AppSettings) => {
        this._localStorage.setItem(LocalStorageKeyNames.changePassword, appSettings.ChangePassword);
        this._localStorage.setItem(LocalStorageKeyNames.contactSupportRedirectUrl, appSettings.ContactSupportRedirectUrl);
        this._localStorage.setItem(LocalStorageKeyNames.liveChat, appSettings.LiveChat);
        this._localStorage.setItem(LocalStorageKeyNames.mfaCookieName, appSettings.MFACookieName);
        this._localStorage.setItem(LocalStorageKeyNames.mfaSettings, appSettings.MFASettings);
        this._localStorage.setItem(LocalStorageKeyNames.remoteSupport, appSettings.RemoteSupport);
        this._localStorage.setItem(LocalStorageKeyNames.supportCenterRedirectUrl, appSettings.SupportCenterRedirectUrl);
        this._localStorage.setItem(LocalStorageKeyNames.tXSupportCenterRedirectUrl, appSettings.TXSupportCenterRedirectUrl);
        this._localStorage.setItem(LocalStorageKeyNames.fileSizeLimit, appSettings.FileSizeLimit);
        this._localStorage.setItem(LocalStorageKeyNames.emailFileSizeLimit, appSettings.EmailFileSizeLimit);
        this._localStorage.setItem(LocalStorageKeyNames.allowedFileTypes, appSettings.AllowedFileTypes);
        this._localStorage.setItem(LocalStorageKeyNames.reskinSupportCenterRedirectUrl, appSettings.ReskinSupportCenterRedirectUrl);
        this._localStorage.setItem(LocalStorageKeyNames.txPaidSupportCenterRedirectUrl, appSettings.TXPaidSupportCenterRedirectUrl);
        this._localStorage.setItem(LocalStorageKeyNames.providerAdminAPIUrl, appSettings.ProviderAdminAPIUrl);
        this._localStorage.setItem(LocalStorageKeyNames.maxProviderDisciplinesOfficeResponseCount, appSettings.MaxProviderDisciplinesOfficeResponseCount);
      },
      error: (err) => console.log(err)
    });
  }

  private get appSettingsFilePath(): string {
    return `${this.basePath}assets/config/appsettings.json`;
  }

  private serialise(model: object): HttpParams {
    let params = new HttpParams();
    const serialise = (obj: object, prefix?: string) => {
      for (const propName in obj) {
        if (obj.hasOwnProperty(propName)) {
          const key = prefix ? `${prefix}.${propName}` : propName;
          const value = obj[propName];

          if (value !== null && typeof value === "object") {
            if (Array.isArray(value)) {
              params = params.set(key, value.join(","));
            } else {
              serialise(value, key);
            }
          } else {
            params = params.set(key, value);
          }
        }
      }
    };

    serialise(model);

    return params;
  }
}
