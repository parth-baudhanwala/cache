import { TestBed } from '@angular/core/testing';

import { OpsWorklistSetupService } from './ops-worklist-setup.service';

describe('OpsWorklistSetupService', () => {
  let service: OpsWorklistSetupService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OpsWorklistSetupService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
