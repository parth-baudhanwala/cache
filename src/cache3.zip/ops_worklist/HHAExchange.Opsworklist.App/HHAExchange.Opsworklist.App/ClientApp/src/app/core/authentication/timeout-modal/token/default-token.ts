import { InjectionToken } from '@angular/core';
import { SessionConfig } from '../model/session.model';
import { configHelper } from '../../../config/static-options';

export const DEFAULT_TIMEOUT_CONFIG: InjectionToken<SessionConfig> = new InjectionToken<
  SessionConfig
>('timeout_session_config', {
  providedIn: 'root',
  factory: () => {
    const sessionTimeoutMinute = localStorage.getItem("SessionTimeoutMinutes");
    const latestSessionTimeoutMinute = sessionTimeoutMinute ? sessionTimeoutMinute : configHelper.defaultSessionTimeoutMinute;

    const sessionTimeoutWarningMinute = localStorage.getItem("SessionTimeoutWarningMinutes");
    const latestSessionTimeoutWarningMinute = sessionTimeoutWarningMinute ? sessionTimeoutWarningMinute : configHelper.defaultSessionTimeoutWarningMinute;

    const sessionTimeoutSecond = parseInt(latestSessionTimeoutMinute) * 60;
    const sessionTimeoutWarningSecond = (parseInt(latestSessionTimeoutMinute) - parseInt(latestSessionTimeoutWarningMinute)) * 60;

    return {
      tokenRefreshInterval: 180,
      idleDuration: 180,
      sessionTimeout: sessionTimeoutSecond,
      timeoutModalDuration: sessionTimeoutWarningSecond,
    } as SessionConfig;
  },
});
