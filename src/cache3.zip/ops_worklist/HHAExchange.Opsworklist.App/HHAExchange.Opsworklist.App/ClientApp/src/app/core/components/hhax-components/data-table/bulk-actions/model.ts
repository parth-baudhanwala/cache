export type BulkActionHandler<T> = (selectedRows: T[]) => void;

export interface BulkActionButton<T> {
  label: string;
  handler: BulkActionHandler<T>;
  isDisable?: string;
}
