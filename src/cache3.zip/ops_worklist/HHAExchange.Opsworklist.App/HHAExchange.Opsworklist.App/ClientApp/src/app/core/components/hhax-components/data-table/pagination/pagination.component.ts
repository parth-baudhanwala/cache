import { Component, OnInit, Input, OnChanges, Output, EventEmitter, } from "@angular/core";
import { PageChangeEvent } from "./model";

@Component({
  selector: "hhax-pagination",
  templateUrl: "./pagination.component.html",
  styleUrls: ["./pagination.component.scss"],
})

export class PaginationComponent implements OnInit, OnChanges {
  @Input() pageSize: number;
  @Input() totalRecords: number;
  @Output() pageChange: EventEmitter<PageChangeEvent> = new EventEmitter();

  currentPage = 1;
  pages: (number | string)[];
  recordRangeEnd: number;
  recordRangeStart: number;
  totalPages: number;
  onPrevious: boolean = false;
  onNext: boolean = false;

  readonly PAGE_SEPARATOR = "...";
  private readonly MAX_PAGES_WITHOUT_SEPARATOR = 9;

  ngOnInit(): void {
    this.recordRangeStart = 1;
    this.reset();
  }

  ngOnChanges(): void {
    // Changes of either of the inputs should be treated as a reset of the pagination component
    this.reset();
  }

  navNext(): void {
    const nextPage = this.currentPage === this.totalPages ? this.currentPage : this.currentPage + 1;
    this.navPage(nextPage);
  }

  navPrevious(): void {
    const previousPage = this.currentPage === 1 ? this.currentPage : this.currentPage - 1;
    this.navPage(previousPage);
  }

  navPage(pageNumber: string | number): void {
    this.currentPage = typeof pageNumber === "string" ? Number(pageNumber) : pageNumber;
    this._generateClickablePageArray();
    this._calculateRecordRange();
    this.pageChange.emit({ pageNumber: this.currentPage });
  }

  reset(): void {
    this.currentPage = 1;
    this.refresh();
  }

  refresh() {
    if (this.pageSize == -1) {
      this.pageSize = this.totalRecords;
    }
    this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
    this._calculateRecordRange();
    this._generateClickablePageArray();
  }

  private _generateClickablePageArray(): void {
    let pageNumberArray: (number | string)[] = [];

    if (this.totalPages <= this.MAX_PAGES_WITHOUT_SEPARATOR) {
      for (let index = 1; index <= this.totalPages; index++) {
        pageNumberArray.push(index);
      }
    } else {
      if (this.currentPage <= 3) {
        pageNumberArray = [1, 2, 3, 4, this.PAGE_SEPARATOR, this.totalPages];
      } else {
        pageNumberArray = [1, this.PAGE_SEPARATOR];

        if (this.currentPage > this.totalPages - 3) {
          pageNumberArray.push(
            this.totalPages - 3,
            this.totalPages - 2,
            this.totalPages - 1,
            this.totalPages
          );
        } else {
          pageNumberArray.push(
            this.currentPage - 1,
            this.currentPage,
            this.currentPage + 1,
            this.PAGE_SEPARATOR,
            this.totalPages
          );
        }
      }
    }
    this.pages = pageNumberArray;
  }

  private _calculateRecordRange(): void {
    const initialRecordRangeStart = (this.currentPage - 1) * this.pageSize;
    this.recordRangeStart = initialRecordRangeStart === 0 ? 1 : (initialRecordRangeStart + 1);
    const initialRecordRangeEnd = initialRecordRangeStart + this.pageSize;
    this.recordRangeEnd = initialRecordRangeEnd > this.totalRecords ? this.totalRecords : initialRecordRangeEnd;
  }
}
