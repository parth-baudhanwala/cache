import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { MasterWeekModal } from "./master-week-schedule.component";
import { ToastrAlertService } from "hhax-components";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { CommonService } from "@app/core/services/common.service";
import {
  MatDialog,
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { of } from "rxjs";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { HHAUserService } from "@app/core/authentication/user.service";

let mockRecord = {
  record: {
    isInternalPatient: true,
    expirationItemType: "Other Compliance",
    expirationItem: "Annual Evauation",
    dueDate: "2021-04-30T00:00:00",
    careGiverCode: "EXQ-2096",
    careGiverId: 977506,
    careGiverTeamId: 0,
    careGiverFirstname: "Ida",
    careGiverLastname: "Aaron",
    careGiverMiddlename: "",
    careGiverFullName: "Ida Aaron",
    worklistTaskId: 42367,
    officeId: 851,
    assignedBy: 27398,
    assignedTo: 27398,
    assignedByUser: "shekhussp",
    assignedToUser: "Shekhar Pandey",
    createdDate: "2021-04-09T07:04:46.259777",
    status: "Open",
    lastNotes: {
      note: "test qa bd sent message",
      subject: "[Push Notification]",
      fileGuid: "53570B89-F174-4890-9119-B5935EEC0CD4",
      fileName: "PP_Rules_Redesign_naren.xls",
      createdBy: 27398,
      createdByUser: "Shekhar Pandey (shekhussp)",
      createdDate: "2021-04-10T13:19:53.2958472+05:30",
      createdDateUtc: "2021-04-10T07:49:53.2958481Z",
    },
    worklistEntKey: "6632-||-691-||-977506",
  },
  title: "View/Add Notes",
  subject: "",
  notes: "",
  attachment: "",
  showViewAllNotes: true,
  worklistPath: "MedicalCompliance",
  taskName: "Annual Evauation",
};
let mwPatientResponse = {
  sunday: "any",
  monday: "any",
  tuesday: "any",
  wednesday: "any",
  thursday: "any",
  friday: "any",
  saturday: "any",
};

describe("MasterWeekModal", () => {
  const mockDialogRef = {
    close: jasmine.createSpy("close"),
  };
  let component: MasterWeekModal;
  let fixture: ComponentFixture<MasterWeekModal>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [MasterWeekModal],
      providers: [
        {
          provide: ToastrAlertService,
          useValue: {
            error: () => of("error", "This action is no longer available."),
            success: () => of("success", "Broadcast is successful."),
          },
        },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              appName: "ENT",
              appsecret: "691",
            },
          },
        },
        { provide: "HOST", useValue: "test" },
        MatDialog,
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockRecord,
        },
        {
          provide: MatDialogRef,
          useValue: mockDialogRef,
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserID: () => of(37485),
            getUserName: () => of("test"),
            getUserFullName: () => of("Test Test"),
          },
        },
        {
          provide: CommonService,
          useValue: {
            GetPatientMasterWeekInfo: () => of(mwPatientResponse),
            GetUPRPatientMasterWeekInfo: () => of(mwPatientResponse),
          },
        },
      ],
      imports: [
        MatDialogModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterWeekModal);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
    component.closeDialog("Closed");
  });

  it("should test getSrTime", () => {
    component.getSrTime("1000-1100");
    expect(component.getSrTime("1000-1100")).toBe(
      "10 Hours 0 Minutes to 11 Hours 0 Minutes"
    );
    component.getSrTime("");
    component.toggle();
  });
  it("should test getColInfo", () => {
    component.getColInfo({});
    expect(component.getColInfo({})).toBe("No data available");
  });
});
