import { EventEmitter, Injectable } from "@angular/core";

@Injectable()
export class KeepAliveMock {
    private onPing = new EventEmitter();

    interval() {
    }

    start() {
    }
}