import { CommonModule, DatePipe } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { AssignTaskComponent } from "@app/core/components/modals/assign-task-modal/assign-task-modal.component";
import { IframeModalComponent } from "@app/core/components/modals/iframe-modal/iframe-modal.component";
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown";
import {
  BadgeLabelModule,
  BadgeLabelSwitchModule,
  BadgeModule,
  CardModule,
  ConfirmationModalModule,
  DatepickerModule,
  DropdownListModule,
  FileUploadModule,
  FormLabelModule,
  HhaxCheckboxModule,
  HhaxPipeModule,
  InputModule,
  LoggerService,
  ModalModule,
  ShowHideModule,
  SpinnerModule,
  TabsModule,
  TextareaModule,
  ToastrAlertService,
} from "hhax-components";
import { RadioButtonModule } from "@app/core/components/hhax-components/radio-button/radio-button.module";
import { TooltipModule } from "ngx-foundation";
import { ToastrService } from "ngx-toastr";
import { BaseComponent } from "./components/base-component/base.component";
import { HhaxTableModule } from "./components/hhax-components/data-table/data-table.module";
import { HhaxTableDataModule } from "./components/hhax-components/data-table/datasource/datasource.module";
import { MultiSelectModule } from "./components/hhax-components/multi-select/multi-select.module";
import { HHAMaterialModule } from "./components/material.module";
import { AddNoteComponent } from "./components/modals/add-note-modal/add-note-modal.component";
import { MasterWeekModal } from "./components/modals/master-week-schedule/master-week-schedule.component";
import { QuickBroadcastComponent } from "./components/modals/quick-broadcast-modal/quick-broadcast-modal.component";
import { SendMessageModalComponent } from "./components/modals/send-message-modal/send-message-modal.component";
import { PipeModule } from "./pipes/pipe.module";
import { BaseHttpService } from "./services/base.http.service";
import { SessionStorageService } from "./services/session-storage.service";

// Services
@NgModule({
  declarations: [
    AddNoteComponent,
    MasterWeekModal,
    AssignTaskComponent,
    IframeModalComponent,
    SendMessageModalComponent,
    BaseComponent,
    QuickBroadcastComponent,
  ],
  imports: [
    CommonModule,
    AngularMultiSelectModule,
    FormsModule,
    TabsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ShowHideModule,
    TooltipModule.forRoot(),
    DropdownListModule,
    MultiSelectModule,
    HhaxTableModule,
    HhaxTableDataModule,
    ModalModule,
    ConfirmationModalModule,
    RadioButtonModule,
    BadgeLabelSwitchModule,
    BadgeLabelModule,
    BadgeModule,
    FileUploadModule,
    FormLabelModule,
    InputModule,
    TextareaModule,
    PipeModule,
    DatepickerModule,
    FontAwesomeModule,
    SpinnerModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    HhaxCheckboxModule,
  ],
  exports: [
    PipeModule,
    HhaxPipeModule,
    ModalModule,
    CardModule,
    HHAMaterialModule,
    DropdownListModule,
    MultiSelectModule,
    ConfirmationModalModule,
    RadioButtonModule,
    BadgeLabelSwitchModule,
    BadgeLabelModule,
    BadgeModule,
    FileUploadModule,
    FormLabelModule,
    InputModule,
    TextareaModule,
    TooltipModule,
    DatepickerModule,
    SpinnerModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
  ],
  providers: [
    ToastrService,
    ToastrAlertService,
    BaseHttpService,
    LoggerService,
    HttpClientModule,
    SessionStorageService,
    DatePipe
  ],
})
export class CoreModule {}
