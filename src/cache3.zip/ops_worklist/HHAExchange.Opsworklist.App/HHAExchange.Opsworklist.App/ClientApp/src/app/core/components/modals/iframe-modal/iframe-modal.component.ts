import {
  Component,
  ElementRef,
  Inject,
  Input,
  OnInit,
  ViewChild,
} from "@angular/core";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from "@angular/material/dialog";
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";
import { Worklist } from "@app/core/models/common.model";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { NotesService } from "@app/core/services/notes.service";
import { WorkslistService } from "@app/core/services/workslist.service";
import { ToastrAlertService } from "hhax-components";

@Component({
  selector: "task-name",
  templateUrl: "./iframe-modal.component.html",
  styleUrls: ["./iframe-modal.component.scss"],
})
export class IframeModalComponent implements OnInit {
  @Input() iframeId: string;
  @Input() height: number = 640;

  @ViewChild("iframe") iframe: ElementRef;

  @Input() iframeUrl: SafeResourceUrl;

  constructor(
    private _sanitizer: DomSanitizer,
    public _taskNameModal: MatDialog,
    public _dialogRef: MatDialogRef<IframeModalComponent>,
    public _worklist: WorkslistService,
    public _alert: ToastrAlertService,
    public notesService: NotesService,
    public config: ConfigurationService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    this.iframeUrl = this.srcUrl(this.data.url);
  }

  srcUrl(url: string): SafeResourceUrl {
    return this._sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  closeDialog(action: string): void {
    if (
      this.data.path === Worklist.UNSTAFFED_VISITS &&
      this.data.isRefresh === false
    ) {
      this._dialogRef.close({ action });
    } else {
      this._worklist
        .closingCondition(this.data.path, this.data.closingConditionParams)
        .subscribe((result) => {
          if (result && result.httpStatusCode === 200) {
            this._dialogRef.close({ action });
          }
        });
    }
  }

  onLoaded() {}
}
