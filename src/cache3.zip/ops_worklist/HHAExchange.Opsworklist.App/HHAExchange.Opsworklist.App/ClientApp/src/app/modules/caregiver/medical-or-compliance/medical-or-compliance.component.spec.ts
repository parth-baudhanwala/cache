import { HttpClientModule } from "@angular/common/http";
import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { FormBuilder } from "@angular/forms";
import { MatDialogModule } from "@angular/material/dialog";
import { MatMenuModule } from "@angular/material/menu";
import { MatToolbarModule } from "@angular/material/toolbar";
import { CookieService, CookieModule } from "ngx-cookie";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HHAUserService } from "@app/core/authentication/user.service";
import {
  closingConditionResponse,
  GetUsersByWorklistIDResponse,
  UpdateStatusResponse,
} from "@app/core/services-mock-data/common.service.mock";
import {
  GetAllNotesByTaskIDResponseData,
  saveNotesResponse,
} from "@app/core/services-mock-data/notes.service.mock";
import {
  getCaregiverTeamDataResponse,
  getDisciplineForOfficeResponse,
  getLocationsData,
  getOfficeDataResponse,
} from "@app/core/services-mock-data/search-field.service.mock";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { NotesService } from "@app/core/services/notes.service";
import { getBranchForOfficeResponse } from "@app/core/services/search-field.service.mock";
import { SearchFieldsService } from "@app/core/services/search-fields.service";
import { WorkslistService } from "@app/core/services/workslist.service";
import {
  ComponentColours,
  LoggerService,
  ToastrAlertService,
} from "hhax-components";
import { of } from "rxjs/internal/observable/of";
import { MedicalOrComplianceComponent } from "./medical-or-compliance.component";
import { Worklist } from "@app/core/models/common.model";
import { DatePipe } from '@angular/common';

let inputData = {
  userName: "test",
  worklistId: 1,
  worklistName: "medical",
  worklistPath: "url",
  canManuallyCloseWorklistTask: "NO",
  canAssignWorklistTask: "No",
  isOpsWorklistLandingPage: "any",
  assignedDefaultWorklist: 1,
  taskCount: 6,
};

let mockRecord = {
  data: {
    expirationItemType: "Other Compliance",
    expirationItem: "Annual Evauation",
    dueDate: "2021-04-30T00:00:00",
    careGiverCode: "EXQ-2096",
    CreatedByUser: "Shekhar Pandey (shekhussp)",
    careGiverId: 977506,
    careGiverTeamId: 0,
    careGiverFirstname: "Ida",
    careGiverLastname: "Aaron",
    careGiverMiddlename: "",
    careGiverFullName: "Ida Aaron",
    worklistTaskId: 42367,
    officeId: 851,
    assignedBy: 27398,
    assignedTo: 27398,
    assignedByUser: "shekhussp",
    assignedToUser: "Shekhar Pandey",
    createdDate: "2021-04-09T07:04:46.259777",
    status: "Open",
    lastNotes: {
      note: "test qa bd sent message",
      subject: "[Push Notification]",
      fileGuid: "53570B89-F174-4890-9119-B5935EEC0CD4",
      fileName: "PP_Rules_Redesign_naren.xls",
      createdBy: 27398,
      createdByUser: "Shekhar Pandey (shekhussp)",
      createdDate: "2021-04-10T13:19:53.2958472+05:30",
      createdDateUtc: "2021-04-10T07:49:53.2958481Z",
    },
    worklistEntKey: "6632-||-691-||-977506",
  },
  title: "View/Add Notes",
  subject: "",
  notes: "",
  attachment: "",
  showViewAllNotes: true,
  worklistPath: "MedicalCompliance",
  taskName: "Annual Evauation",
  worklistTaskId: 1,
};

const saveNotePayloadData = {
  UserID: 27398,
  AppVersion: "ENT",
  Version: 21.05,
  MinorVersion: 1,
  ProviderID: 691,
  CreatedBy: "27398",
  CreatedByUser: "Shekhar Pandey (shekhussp)",
  Subject: null,
  SubjectText: "0",
  Note: "Status changed  to In-Progress",
  WorklistTaskIds: 77755,
  OfficeID: 852,
  AideIDs: "980516",
};
const mockBulkRecords = [mockRecord, mockRecord];

describe("MedicalOrComplianceComponent", () => {
  let component: MedicalOrComplianceComponent;
  let fixture: ComponentFixture<MedicalOrComplianceComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [MedicalOrComplianceComponent],
      imports: [
        HttpClientModule,
        MatDialogModule,
        BrowserAnimationsModule,
        MatMenuModule,
        MatToolbarModule,
        MatMenuModule,
        CookieModule.forRoot(),
      ],
      providers: [
        {
          provide: SearchFieldsService,
          useValue: {
            getDiscipline: () => of(getDisciplineForOfficeResponse),
            getOfficeData: () => of(getOfficeDataResponse),
            getLocationData: () => of(getLocationsData),
            getBranchData: () => of(getBranchForOfficeResponse),
            getCaregiverTeamData: () => of(getCaregiverTeamDataResponse),
          },
        },
        FormBuilder,
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userId: 27398,
              userOffices: [{ officeID: "123" }],
              AppVersion: "ENT",
              Version: 21.02,
              MinorVersion: 1,
              VendorID: 691,
              providerID: 691,
            },
          },
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserID: () => of(37485),
            getUserName: () => of("test"),
            getUserFullName: () => of("Test Test"),
          },
        },
        {
          provide: ToastrAlertService,
          useValue: {
            error: () =>
              of("error", "There was error while fetching Office(s)."),
            success: () => of("success", "Note Saved Successfully"),
          },
        },
        {
          provide: CommonService,
          useValue: {
            GetUsersByWorklistID: () => of(GetUsersByWorklistIDResponse),
            updateTask: () => of(UpdateStatusResponse),
          },
        },
        {
          provide: WorkslistService,
          useValue: {
            closingCondition: () => of(closingConditionResponse),
            getsubject: () => of("test"),
          },
        },
        {
          provide: NotesService,
          useValue: {
            GetAllNotesByTaskID: (id) => of(GetAllNotesByTaskIDResponseData),
            SaveNotes: (saveNotePayloadData) => of(saveNotesResponse),
          },
        },
        {
          provide: "HOST",
          useValue: "test",
        },
        LoggerService,
        CookieService,
        DatePipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalOrComplianceComponent);
    component = fixture.componentInstance;
    component.worklistDetail = inputData;

    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should call on init method", async () => {
    expect(component.worklistDetail.canAssignWorklistTask).toEqual("No");
    expect(component.worklistDetail.canManuallyCloseWorklistTask).toEqual("NO");
    await component.actionButtons[1].handler(mockBulkRecords);
    await component.actionButtons[2].handler(mockBulkRecords);
    await component.actionButtons[3].handler(mockBulkRecords);
    await component.actionButtons[4].handler(mockBulkRecords);
    await component.actionButtons[5].handler(mockBulkRecords);
    await component.actionButtons[6].handler(mockBulkRecords);
    component.worklistDetail = {
      userName: "test",
      worklistId: 1,
      worklistName: "medical",
      worklistPath: "MedicalCompliance",
      canManuallyCloseWorklistTask: "No",
      canAssignWorklistTask: "No",
      isOpsWorklistLandingPage: "any",
      assignedDefaultWorklist: 1,
      taskCount: 6,
    };
    component.ngOnInit();
  });

  it("should get change status color", () => {
    let statusColor = component.getStatusColor("Open");
    expect(statusColor).toEqual(ComponentColours.warning);
    statusColor = component.getStatusColor("Closed");
    expect(statusColor).toEqual(ComponentColours.success);
    statusColor = component.getStatusColor("Completed");
    expect(statusColor).toEqual(ComponentColours.success);
    statusColor = component.getStatusColor("In-Progress");
    expect(statusColor).toEqual(ComponentColours.info);
    statusColor = component.getStatusColor("");
    expect(statusColor).toEqual(ComponentColours.none);
    component.onReset();
  });

  it("should call bulk action button handlers", async () => {
    await component.actionButtons[0].handler(mockBulkRecords);
    await component.actionButtons[1].handler(mockBulkRecords);
    await component.actionButtons[2].handler(mockBulkRecords);
    await component.actionButtons[3].handler(mockBulkRecords);
    if (component.actionButtons.length >= 4) {
      await component.actionButtons[4].handler(mockBulkRecords);
      await component.actionButtons[5].handler(mockBulkRecords);
      await component.actionButtons[6].handler(mockBulkRecords);
    }
    component.officeSelectedChange([123, 555]);
    component.refreshRecords(mockRecord, Worklist.UNSTAFFED_VISITS, Function);
    component.refreshRecords(
      mockBulkRecords,
      Worklist.UNSTAFFED_VISITS,
      Function
    );
    component.openAssignTaskModal(mockRecord, Function, Function);
    component.updateClosedStatus(mockRecord, Function);
    component.onAssigneeClick(mockRecord, {});
    expect(component.openAssignTaskModal).toBeDefined();
  });

  it("should call on submit", async () => {
    component.onSubmit();
    spyOn(component, "onSubmit");
    expect(component.searchWorkLists).toBeDefined();
  });

  it("should call openIframe", async () => {
    component.openiframe(mockRecord);
    const selectedRecord = { data: { worklistEntKey: 1 } };
    const url = "http:google.com";
    component.openIFrame(selectedRecord, url, Function);
    component.openNote(mockRecord);
    expect(component.openAddNoteDialog).toBeDefined();
  });
});
