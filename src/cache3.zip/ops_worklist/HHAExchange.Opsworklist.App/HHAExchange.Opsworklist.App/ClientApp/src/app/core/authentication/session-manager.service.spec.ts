import {
  MatDialog,
  MatDialogModule,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { Idle } from "@ng-idle/core";
import { Keepalive, NgIdleKeepaliveModule } from "@ng-idle/keepalive";
import { HHAUserService } from "./user.service";
import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { getTestBed, TestBed } from "@angular/core/testing";
import { SessionManagerService } from "./session-manager.service";
import { UserData } from "../services-mock-data/user.service.mock";
import { IdleMock } from "../services-mock-data/idle.mock";
import { KeepAliveMock } from "../services-mock-data/keepalive.mock";

describe("SessionManagerService", () => {
  let service: SessionManagerService;
  let userService: HHAUserService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let idle: Idle;
  let keepAlive;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        MatDialogModule,
        NgIdleKeepaliveModule,
      ],
      providers: [
        {
          provide: HHAUserService,
          useValue: {
            startSilentRefresh: () => {},
          },
        },
        {
          // I was expecting this will pass the desired value
          provide: MAT_DIALOG_DATA,
          useValue: MatDialog,
        },
        { provide: Keepalive, useClass: KeepAliveMock },
        { provide: Idle, useClass: IdleMock },
      ],
    });
    injector = getTestBed();
    service = injector.inject(SessionManagerService);
    httpMock = injector.inject(HttpTestingController);
    userService = injector.inject(HHAUserService);
    idle = injector.inject(Idle);
    keepAlive = injector.inject(Keepalive);
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });

  it("SessionManagerService should be created", () => {
    expect(service).toBeDefined();
  });

  it("idleWatcherInit should work when Idle", () => {
    spyOn(idle, "setIdle").and.returnValue(1800);
    service.idleWatcherInit({
      idle: 0,
      sessionTimeOut: 0,
      sessionTimeOutOffset: 0,
      timeOutModalDuration: 0,
    });
    idle.onIdleStart.emit();
    idle.onIdleEnd.emit();
    expect(service.idleWatcherInit).toBeDefined();
  });

  it("keepAliveInit should work When Not Idle", () => {
    // Arrange
    spyOn(idle, "setIdle").and.returnValue(1800);
    spyOn(userService, "startSilentRefresh").and.returnValue(
      new Promise(() => Promise.resolve(UserData))
    );
    // Act
    service.keepAliveInit(1800);
    keepAlive.onPing.emit();
    // Assert
    expect(userService.startSilentRefresh).toHaveBeenCalled();
  });

  it("keepAliveInit should work When Idle", () => {
    service["IsIdle"] = true;
    service.keepAliveInit(1800);
    keepAlive.onPing.emit();
    expect(service.keepAliveInit).toBeDefined();
  });
});
