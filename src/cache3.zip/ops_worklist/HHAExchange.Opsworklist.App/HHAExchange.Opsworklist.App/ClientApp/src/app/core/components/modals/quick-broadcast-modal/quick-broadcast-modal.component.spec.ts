import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { QuickBroadcastComponent } from "./quick-broadcast-modal.component";
import { ToastrAlertService } from "hhax-components";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { ExternalService } from "@app/core/services/external-services/external.service";
import {
  MatDialog,
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { of } from "rxjs";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { NotesService } from "@app/core/services/notes.service";
import { HHAUserService } from "@app/core/authentication/user.service";

let mockRecord = {
  record: {
    expirationItemType: "Other Compliance",
    expirationItem: "Annual Evauation",
    dueDate: "2021-04-30T00:00:00",
    careGiverCode: "EXQ-2096",
    careGiverId: 977506,
    careGiverTeamId: 0,
    careGiverFirstname: "Ida",
    careGiverLastname: "Aaron",
    careGiverMiddlename: "",
    careGiverFullName: "Ida Aaron",
    worklistTaskId: 42367,
    officeId: 851,
    assignedBy: 27398,
    assignedTo: 27398,
    assignedByUser: "shekhussp",
    assignedToUser: "Shekhar Pandey",
    createdDate: "2021-04-09T07:04:46.259777",
    status: "Open",
    lastNotes: {
      note: "test qa bd sent message",
      subject: "[Push Notification]",
      fileGuid: "53570B89-F174-4890-9119-B5935EEC0CD4",
      fileName: "PP_Rules_Redesign_naren.xls",
      createdBy: 27398,
      createdByUser: "Shekhar Pandey (shekhussp)",
      createdDate: "2021-04-10T13:19:53.2958472+05:30",
      createdDateUtc: "2021-04-10T07:49:53.2958481Z",
    },
    worklistEntKey: "6632-||-691-||-977506",
  },
  title: "View/Add Notes",
  subject: "",
  notes: "",
  attachment: "",
  showViewAllNotes: true,
  worklistPath: "MedicalCompliance",
  taskName: "Annual Evauation",
};

describe("QuickBroadcastComponent", () => {
  const mockDialogRef = {
    close: jasmine.createSpy("close"),
  };
  let component: QuickBroadcastComponent;
  let fixture: ComponentFixture<QuickBroadcastComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [QuickBroadcastComponent],
      providers: [
        {
          provide: ToastrAlertService,
          useValue: {
            error: () => of("error", "This action is no longer available."),
            success: () => of("success", "Broadcast is successful."),
          },
        },
        {
          provide: ExternalService,
          useValue: {
            saveQuickBroadcastInfo: () => of({ d: 0 }),
          },
        },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              appName: "ENT",
              appsecret: "691",
            },
          },
        },
        { provide: "HOST", useValue: "test" },
        MatDialog,
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockRecord,
        },
        {
          provide: MatDialogRef,
          useValue: mockDialogRef,
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserID: () => of(37485),
            getUserName: () => of("test"),
            getUserFullName: () => of("Test Test"),
          },
        },
        {
          provide: NotesService,
          useValue: {
            SaveNotes: () => of("saved"),
          },
        },
      ],
      imports: [
        MatDialogModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuickBroadcastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
    component.closeDialog("Closed");
  });

  it("should call ngOninit", () => {
    component.data.record = [mockRecord, mockRecord];
    component.ngOnInit();
  });

  it("should call quickBroadcast", () => {
    component.quickBroadcast();
    spyOn(component, "quickBroadcast");
    expect(component.quickBroadcast).toBeDefined();
  });

  it("should call autoGenerateNote", () => {
    component.autoGenerateNote({ worklistTaskId: 1 }, () => {});
    spyOn(component, "autoGenerateNote");
    expect(component._notesService.SaveNotes).toBeDefined();
  });
});
