import { Component, ElementRef, HostListener, OnInit, ViewChild } from "@angular/core";
import { WindowRefService } from "hhax-components";
import { CookieService } from "ngx-cookie";
import { environment } from "../environments/environment";
import { SessionManagerService } from "./core/authentication/session-manager.service";
import { configHelper } from './core/config/static-options';
import { ConfigurationService } from "./core/services/configuration.service";
import { LocalStorageKeyNames, LocalStorageService } from "./core/services/local-storage.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styles: [
    `
      :host >>> .tooltip {
        position: absolute;
        max-width: 18rem;

        border-radius: 0.25rem;
        opacity: 9;
      }
      :host >>> .tooltip-inner {
        background-color: #0a0a0a;
        color: #fefefe;
        font-size: 12px;
        font-weight: bold;
        max-width: 18rem;
        text-align: left;
        padding: 0px;
      }
    `,
  ],
})
export class AppComponent implements OnInit {
  title: string;
  showHeaderFooter: boolean;

  constructor(
    private _sessionManager: SessionManagerService,
    private _windowRef: WindowRefService,
    private _configurationService: ConfigurationService,
    private _cookieService: CookieService,
    private _localStorageService: LocalStorageService,
  ) {
    if (
      !this._windowRef.nativeWindow.location.href.includes("silent-refresh")
    ) {
      this._sessionManager.keepAliveInit(environment.timeouts.keepAlive);
    }
  }

  ngOnInit(): void {

    const routeName = this._localStorageService.getItem<string>(LocalStorageKeyNames.routePathName);

    if (routeName == "ops-worklist-setup") {
      this.title = "Operation Worklist Setup";
      this.showHeaderFooter = true;
    }
    else if (routeName == "ops-worklist") {
      this.title = "Worklists";
      this.showHeaderFooter = false;
    }
    else {
      this.title = "";
      this.showHeaderFooter = false;
    }

    this.setHhaSessionTime();
  }

  showApp() {
    return this._configurationService.hasAppLoaded;
  }

  @HostListener('click')
  @HostListener('change')
  @HostListener('mousemove')
  setHhaSessionTime() {
    if (location.host.includes(configHelper.domainName)) {
      this._cookieService.put(configHelper.hhaSessionKey, new Date().getTime().toString(), { secure: true, path: '/', domain: configHelper.domainName });
    }
    else {
      this._cookieService.put(configHelper.hhaSessionKey, new Date().getTime().toString(), { secure: true, path: '/' });
    }
  }

  // Skip Links
  @ViewChild("topOfPage", { read: ElementRef, static: false }) topOfPageRef;
  @ViewChild("mainContent", { read: ElementRef, static: false }) mainContentRef;
}
