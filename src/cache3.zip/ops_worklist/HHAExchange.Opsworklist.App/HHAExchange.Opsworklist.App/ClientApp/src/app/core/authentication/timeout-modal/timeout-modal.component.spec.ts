import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { TimeoutModalComponent } from "./timeout-modal.component";

import {
  MatDialogModule,
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";

import { HHAUserService } from "../user.service";
import { of } from "rxjs";

describe("TimeoutModalComponent", () => {
  const mockDialogRef = {
    close: jasmine.createSpy("close"),
  };

  let component: TimeoutModalComponent;
  let fixture: ComponentFixture<TimeoutModalComponent>;
  let inputEl: HTMLElement;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [TimeoutModalComponent],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: { counter: 0 } },
        { provide: MatDialogRef, useValue: {} },
        MatDialog,
        {
          provide: HHAUserService,
          useValue: {
            timeOutUser: () => of({}),
          },
        },
        {
          provide: MatDialogRef,
          useValue: mockDialogRef,
        },
        { provide: "HOST", useValue: "test" },
      ],
      imports: [MatDialogModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeoutModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    inputEl = fixture.nativeElement.querySelector("button");
  });

  it("should create", () => {
    expect(component).toBeTruthy();
    component.continueSession();
  });

  it("should call host listner", () => {
    const event = new KeyboardEvent("keydown", { key: " " });
    inputEl.dispatchEvent(event);
    fixture.detectChanges();
    expect(component.dialog.closeAll).toBeDefined();
  });
});
