export interface MedicalComplianceSetupModel {
  providerId: number;
  employeeTypeId: number;
  employeeType: string;
  taskCreationDays: number;
  caregiverStatusIds: string;
  caregiverStatus: string;
  userId: number;
  userName: string;
}

export interface AuthorizationSetup {
  providerId: number;
  tempAuthorizationFlag: boolean;
  taskCreationDays: number;
  patientStatusIds: string;
  patientStatus: string;
  automaticallyAssignTasks: boolean;
  userId: number;
  userName: string;
}

export interface MasterweekSetup {
  providerId: number;
  taskCreationDays: number;
  patientStatusIds: string;
  patientStatus: string;
  automaticallyAssignTasks: boolean;
  userId: number;
  userName: string;
}

export interface UnscheduledVisitsSetupModel {
  providerId: number;
  taskCreationDays: number;
  patientStatusIds: string;
  patientStatus: string;
  automaticallyAssignTasks: boolean;
  userId: number;
  userName: string;
}

export interface CertificationSetup {
  providerId: number;
  taskCreationDays: number;
  patientStatusIds: string;
  patientStatus: string;
  userId: number;
  userName: string;
}

