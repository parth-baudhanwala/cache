import { Component } from '@angular/core';
import { HHAUserService } from './user.service';

@Component({
    selector: 'hha-silent-callback',
    template: '...'
})
export class SilentRefreshCallBackComponent {
  refreshed: boolean = false;
    constructor(
      private _userService: HHAUserService,
    ) { }
    ngOnInit() {
      this._userService.completeSilentRefresh();
    }
}
