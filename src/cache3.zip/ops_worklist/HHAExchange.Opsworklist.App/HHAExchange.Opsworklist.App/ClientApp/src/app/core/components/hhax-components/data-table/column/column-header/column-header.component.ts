import { EventEmitter } from '@angular/core';
import { Component, HostListener, Input, Output } from '@angular/core';
import { faSortUp, faSortDown, faSort, faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import { Key } from 'ts-key-enum';

import { SortDirection } from '../../datasource/model/transport';

@Component({
  selector: 'th[hhax-column-header]',
  templateUrl: './column-header.component.html',
  styleUrls: ['./column-header.component.scss']
})
export class ColumnHeaderComponent {
  @Input() label: string;
  @Input() sortable: boolean;
  @Input() isSorted: boolean;
  @Input() direction: SortDirection;
  @Input() toolTip: string;
  @Output() click: EventEmitter<void> = new EventEmitter();

  readonly faSortUp = faSortUp;
  readonly faSortDown = faSortDown;
  readonly faSortDefault = faSort;
  readonly infoIcon = faInfoCircle;

  readonly sortDirection = SortDirection;

  @HostListener('keydown', ['$event']) keydown(event) {
    if (event.key === Key.Enter || event.key === ' ') {
      this.click.emit();
    }
  }
}
