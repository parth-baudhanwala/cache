import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SilentRefreshCallBackComponent } from '../../silent-refresh-callback.component';


const routes: Routes = [
  {
    path: 'silent-refresh',
    component: SilentRefreshCallBackComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SilentRefreshRoutingModule { }
