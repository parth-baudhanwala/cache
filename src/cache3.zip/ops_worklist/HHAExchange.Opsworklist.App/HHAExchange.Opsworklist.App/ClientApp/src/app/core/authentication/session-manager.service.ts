import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { HHAUserService } from './user.service';

interface TimeOutConfigModel {
  idle: number,
  sessionTimeOut: number,
  sessionTimeOutOffset: number,
  timeOutModalDuration: number,
}

@Injectable({
  providedIn: 'root'
})
export class SessionManagerService {
  private IsIdle: boolean = false;

  constructor(public timeoutModal: MatDialog,
    private idle: Idle,
    private _userService: HHAUserService,
    private keepalive: Keepalive)
  {
    if (this.timeoutModal) {
      this.timeoutModal.closeAll();
    }
  }

  public idleWatcherInit(timeOutConfig: TimeOutConfigModel) {
    this.idle.setIdle(timeOutConfig.idle);
    this.idle.setTimeout(timeOutConfig.sessionTimeOut - timeOutConfig.sessionTimeOutOffset - timeOutConfig.timeOutModalDuration);
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    
    this.idle.onIdleStart.subscribe(() => this._handleUserIdle());
    this.idle.onIdleEnd.subscribe(() => this._handleUserNoLongerIdle());
    this.idle.watch();
  }

  public keepAliveInit(tokenRefreshInterval: number) {
    this.keepalive.interval(tokenRefreshInterval);
    this.keepalive.onPing.subscribe(() => this._handleKeepAlive());
    this.keepalive.start();
  } 
  
  private _handleKeepAlive() {
    if(!this.IsIdle){
      this._userService.startSilentRefresh();
    }
  }
  
  private _handleUserIdle(): void {
    this.IsIdle = true;
    this._userService.startSilentRefresh();
  }

  private _handleUserNoLongerIdle(): void {
    this.IsIdle = false;
    this._userService.startSilentRefresh();
  }
}
