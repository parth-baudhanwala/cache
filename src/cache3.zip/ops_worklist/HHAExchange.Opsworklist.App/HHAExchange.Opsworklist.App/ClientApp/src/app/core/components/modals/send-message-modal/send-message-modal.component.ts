import { Component, Inject, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from "@angular/material/dialog";
import { AppConfiguration } from "@app/core/models/common.model";
import { OpsWorklistData } from "@app/core/models/constant.model";
import {
  FileUploadValidate,
  scriptDataModel,
  TaskNotes,
} from "@app/core/models/notes.model";
import {
  IBroadCastModelResponse,
  IScriptData,
  ISendMessage,
  ScriptMessages,
} from "@app/core/models/scripts.model";
import { BroadCastService } from "@app/core/services/broadcast.service";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { FileService } from "@app/core/services/file.service";
import { NotesService } from "@app/core/services/notes.service";
import { MultiSelectOption, ToastrAlertService } from "hhax-components";
import moment from "moment";
import {
  ScheduleType,
  DeliveryMethodType,
  TemplateParams,
  PriorityType,
} from "../../../models/send-message-modal.model";
import { HHAUserService } from "@app/core/authentication/user.service";
import { DatePipe } from '@angular/common';
import { TaskDetailsModel } from "../../../models/task-details-model";

@Component({
  selector: "app-send-message-modal",
  templateUrl: "./send-message-modal.component.html",
  styleUrls: ["./send-message-modal.component.scss"],
  styles: [
    `
      :host >>> .tooltip {
        position: absolute;
        max-width: 18rem;
        border-radius: 0.25rem;
        opacity: 9;
      }
      :host >>> .tooltip-inner {
        background-color: #0a0a0a;
        color: #fefefe;
        font-size: 12px;
        font-weight: bold;
        max-width: 18rem;
        text-align: left;
        padding: 0px;
      }
    `,
  ],
})
export class SendMessageModalComponent implements OnInit {
  minDate: string = moment().format().substring(0, 16);
  maxDate: string = "9999-12-31T20:20";
  deliveryTime = false;
  emailDeliveryMethod: string;
  payloadData = {};
  scriptOptions: ScriptMessages[];
  scriptDataList = [];
  displayFileName: string;
  templateId: string;
  fileUploadError: string;
  fileName: string | ArrayBuffer;
  disable: boolean = false;
  fileData: string;
  fileUpload: boolean = false;
  appConfig: AppConfiguration;
  // scriptData: scriptDataModel;
  sendMessageForm: FormGroup;
  broadCastID: number;
  fileUploadedValidate: boolean;
  deliveryMethodOptions: MultiSelectOption[] = [
    { text: "Text", value: DeliveryMethodType.TEXT },
    { text: "Email", value: DeliveryMethodType.EMAIL },
    { text: "Mobile Messaging", value: DeliveryMethodType.MOBILEMESSAGING },
    { text: "Mobile and Text", value: DeliveryMethodType.MOBILEANDTEXT },
  ];
  sendMessageResult: IBroadCastModelResponse;
  fileUploadSizeError: string;
  alertMsg: string;
  alertModalMsg: string;
  recipients: string[] = [];
  PriorityType: PriorityType;
  isSchedule: boolean;
  isBulkTaskDetail: boolean = false;
  public taskdetails: TaskDetailsModel[] = [];
  emailFileSizeLimit: number = 0;
  isUploading: boolean = false;
  messageText: string;
  messageLimit: number = 160;
  messageLimitExceeded : boolean = false;

  constructor(
    public _taskNameModal: MatDialog,
    public _dialogRef: MatDialogRef<SendMessageModalComponent>,
    public _fb: FormBuilder,
    public _service: BroadCastService,
    public _config: ConfigurationService,
    public _commonService: CommonService,
    public _alert: ToastrAlertService,
    public _fileService: FileService,
    public _notesService: NotesService,
    public _userService: HHAUserService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public datepipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.isSchedule = false;
    this.alertModalMsg = "Opened Send Message Popup";
    this.appConfig = this._config.appConfiguration;
    this.getMessageForm(DeliveryMethodType.MOBILEANDTEXT);
    this.fetchScriptOptions();
    this.fetchRecipents();
    this.emailFileSizeLimit = this._userService.getEmailFileSizeLimit();
    this.messageLimit = this._userService.getCaregiverMessageLengthLimit();
    this.messageText = "Limit to " + this.messageLimit + " characters"
  }

  getMessageForm(deliveryMethod) {
    this.sendMessageForm = this._fb.group({
      scheduleType: new FormControl(ScheduleType.NOW),
      deliveryMethod: new FormControl(deliveryMethod),
      script: new FormControl(""),
      subject: new FormControl(""),
      message: new FormControl("", Validators.required),
      priorityType: new FormControl(PriorityType.HIGH, Validators.required),
      email: new FormControl(""),
      attachmentfilename: new FormControl(""),
      scheduleDateTime: new FormControl(
        moment().format().substring(0, 16),
        Validators.required
      ),

      templateID: new FormControl(""),
    });
  }

  onDeliveryMethodChange($event): void {
    this.resetForm($event.target.value);
    this.fetchScriptOptions();
    this.emailDeliveryMethod = $event.target.value;
    let messageTextHelpElement = document.getElementById("messageTextHelp");
    messageTextHelpElement.classList.remove("hhax-form-error-text");
    let broadcastButtonElement = document.getElementById("broadcastButton");
    broadcastButtonElement.setAttribute("disabled", "true");

    if(this.emailDeliveryMethod == "3"){
        this.messageText = "Limit to 1000 characters";
        this.messageLimit = 1000;
    }
    else{
      this.messageLimit = this._userService.getCaregiverMessageLengthLimit();
      this.messageText = "Limit to " + this.messageLimit + " characters"
    }
  }

  resetForm(deliveryMethod) {
    this.deliveryTime = false;
    this.getMessageForm(deliveryMethod);
    if (deliveryMethod === DeliveryMethodType.EMAIL) {
      this.sendMessageForm.get("subject").setValidators(Validators.required);
    } else {
      this.sendMessageForm.get("subject").clearValidators();
      this.sendMessageForm.updateValueAndValidity();
    }
  }

  fetchScriptOptions() {
    let scriptData: scriptDataModel = {
      UserID: this.appConfig.userId,
      ProviderID: this.appConfig.agencyID,
      TemplateType: this.sendMessageForm.get("deliveryMethod").value,
      OfficeIDs:
        this.appConfig.userOffices && this.appConfig.userOffices.length > 0
          ? this.appConfig.userOffices.map((obj) => obj.officeID).join(",")
          : "",
    };
    this.scriptDataList = [];
    this._commonService
      .getScriptData(scriptData)
      .subscribe((res: ISendMessage) => {
        if (res) {
          this.scriptOptions = res.responseBody;
          this.scriptOptions.forEach((obj) => {
            this.scriptDataList.push({
              text: obj.description,
              value: obj.templateId,
            });
          });
        }
      });
  }

  closeDialog(action): void {
    this._dialogRef.close({ action });
  }

  fetchRecipents() {
    if (Array.isArray(this.data.record)) {
      this.data.record.forEach((record) => {
        this.recipients.push(record.careGiverFullName);
        this.recipients = [...new Set(this.recipients)];
      });
    }
  }

  showSchedule(): void {
    this.deliveryTime = true;
    this.sendMessageForm.controls.scheduleType.setValue(ScheduleType.SCHEDULE);
    this.sendMessageForm.get("scheduleDateTime").markAsUntouched();
    this.sendMessageForm
      .get("scheduleDateTime")
      .setValidators([Validators.required]);
    this.sendMessageForm.updateValueAndValidity();
  }

  hideSchedule(): void {
    this.deliveryTime = false;
    this.sendMessageForm.controls.scheduleType.setValue(ScheduleType.NOW);
    this.sendMessageForm.patchValue({
      scheduleDateTime: "",
    });
    this.sendMessageForm.controls.scheduleDateTime.setErrors(null);
    this.sendMessageForm.get("scheduleDateTime").clearValidators();
    this.sendMessageForm.updateValueAndValidity();
  }

  async sendMessage() {
    this.getMessageBroadcastParams();
    this._service
      .sendBroadCastDetails(this.payloadData)
      .subscribe((res: IBroadCastModelResponse) => {
        let broadCastID = res.responseBody.broadCastID;
        if (broadCastID === -10) {
          this._alert.success(
            "success",
            "Your message is being broadcast. To review the details of the broadcast, please navigate to the Communication History page under the Action menu."
          );
        }
        if (broadCastID === 0) {
          this._alert.error(
            "error",
            "Caregiver not configured for sending messages."
          );
        } else if (broadCastID > 0) {
          this.sendMessageResult = res;
          if (this.fileUpload) {
            this.getFileGUID(res.responseBody.broadCastModel);
          } else {
            let updateRecords: any[] = [];
            if (res.responseBody.broadCastModel.length > 0) {
              let allAideIds = [
                ...new Set(this.data.record.map((obj) => obj.careGiverId)),
              ];
              let respAideIds = res.responseBody.broadCastModel.map(
                (obj) => obj.aideID
              );
              let difference = allAideIds.filter(
                (x: number) => !respAideIds.includes(x)
              );
              difference.forEach((rec) => {
                this.data.record.filter((r) => {
                  if (r.careGiverId === rec) {
                    updateRecords.push(r);
                  }
                });
              });
            } else {
              updateRecords = this.data.record;
            }
            this.autoGenerateNote(updateRecords, this.data.refreshTable);
            this._alert.success("success", "Message sent successfully.");
          }
        }
        this.sendMessageForm.reset();
        this.closeDialog(res);
      });
  }

  getMessageBroadcastParams() {
    let form = this.sendMessageForm.value;
    if (form.deliveryMethod) {
      this.payloadData["MessageTypeID"] = Number(form.deliveryMethod);
      this.payloadData["TemplateID"] = Number(form.script)
        ? Number(form.script)
        : 0;
    }
    if (form.subject === "" || form.subject)
      this.payloadData["Subject"] = form.subject ? form.subject : null;
    if (form.email) this.payloadData["BCC"] = form.email;
    if (form.scheduleDateTime)
      this.payloadData["ScheduleDate"] = moment(form.scheduleDateTime).format(
        "MM/DD/YYYY"
      );
    if (form.scheduleDateTime)
      this.payloadData["ScheduledFromTime"] = moment(
        form.scheduleDateTime
      ).format("HH:mm");
    if (form.message) this.payloadData["Message"] = form.message;
    if (form.scheduleType)
      this.payloadData["IsScheduled"] = parseInt(form.scheduleType);
    this.payloadData["UserID"] = this.appConfig.userId;
    this.payloadData["AttachmentFileName"] = this.displayFileName;
    this.payloadData["PriorityType"] = parseInt(form.priorityType);
    this.payloadData["ProviderID"] = this.appConfig.agencyID;
    let careGiverIds = Array.isArray(this.data.record)
      ? [...new Set(this.data.record.map((obj) => obj.careGiverId))]
      : [this.data.record.careGiverId];
    if (this.data.record != null && this.data.record.length > 0) {
      let customObj;
      for (let i = 0; i < this.data.record.length; i++) {
        customObj = new TaskDetailsModel();
        customObj.aideID = this.data.record[i].careGiverId;
        customObj.taskDetail = `Please note that ${this.data.record[i].expirationItem} is due on ${this.datepipe.transform(new Date(this.data.record[i].dueDate), "MM/dd/yyyy")}`;
        customObj.officeID = this.data.record[i].officeId;
        customObj.worklistTaskIds = this.data.record[i].worklistTaskId;
        this.taskdetails.push(customObj);
      }
    }
    this.payloadData["AideID"] = careGiverIds;
    this.payloadData["DeliveryOption"] = 1;
    this.payloadData["BroadCastType"] = 1;
    this.payloadData["Version"] = this.appConfig.version;
    this.payloadData["MinorVersion"] = this.appConfig.minorVersion;
    this.payloadData["Taskdetails"] = this.taskdetails;
    this.payloadData["IsBulkTaskDetail"] = this.isBulkTaskDetail;
    this.payloadData["NotesModel"] = this.getNoteModel();
  }

  onFileUpload($event): void {
    if (!this._fileService.isValidFileExtension($event.target)) {
      $event.target.value = null;
      this._alert.error("error", "The selected file has an invalid/unsupported extension.");
    } else if (this._fileService.isValidFile($event.target, this.emailFileSizeLimit)) {
        this.isUploading = true;
        let formData = new FormData();
        this.fileUpload = true;
        this.displayFileName = $event.target.files[0].name;
        this.fileData = $event.target.files[0];
        formData.append(this.displayFileName, this.fileData);
        formData.append("MethodType", OpsWorklistData.MethodTypeValidate);
        formData.append("AppSecret", this.appConfig.appsecret);
        formData.append("AppName", this.appConfig.appName);
        formData.append("HHAWSURL", this.appConfig.hhawsenturl);
        this._fileService
          .FileUpload(formData)
          .subscribe((res: FileUploadValidate[]) => {
            if (res) {
              this.fileUploadedValidate = res[0].isfileUploadedSucessfully;
              if (this.fileUploadedValidate) {
                this.readThis($event.target);
              } else {
                $event.target.value = null;
                this._alert.error(
                  "error",
                  "Incorrect File size or File type or File name length"
                );
              }
            }
            this.isUploading = false;
          });
    } else {
      this._alert.error(
        "error",
        "Incorrect File size or File type or File name length"
      );
    }
  }

  getFileGUID(broadCastModel) {
    let frmData = new FormData();
    frmData.append(this.displayFileName, this.fileData);
    frmData.append("MethodType", OpsWorklistData.MethodTypeSave);
    frmData.append("UserID", this.appConfig.userId.toString());
    frmData.append("Module", OpsWorklistData.Module);
    frmData.append(
      "ModuleID",
      this.sendMessageResult.responseBody.broadCastID.toString()
    );
    frmData.append(
      "FeatureID",
      this.sendMessageResult.responseBody.broadCastID.toString()
    );
    frmData.append("Agency", OpsWorklistData.Agency);
    frmData.append("Feature", OpsWorklistData.Feature);
    frmData.append("AgencyID", this.appConfig.agencyID.toString());
    frmData.append("AppSecret", this.appConfig.appsecret);
    frmData.append("AppName", this.appConfig.appName);
    frmData.append("HHAWSURL", this.appConfig.hhawsenturl);
    frmData.append("FileGUID", "");

    this._fileService
      .FileUpload(frmData)
      .subscribe((fileUploadResponse: FileUploadValidate[]) => {
        if (fileUploadResponse) {
          let updateRecords: any[] = [];
          if (broadCastModel.length > 0) {
            let allAideIds = [
              ...new Set(this.data.record.map((obj) => obj.careGiverId)),
            ];
            let respAideIds = broadCastModel.map((obj) => obj.aideID);
            let difference = allAideIds.filter(
              (x: number) => !respAideIds.includes(x)
            );
            difference.forEach((rec) => {
              this.data.record.filter((r) => {
                if (r.careGiverId === rec) {
                  updateRecords.push(r);
                }
              });
            });
          } else {
            updateRecords = this.data.record;
          }
          this.autoGenerateNote(updateRecords, this.data.refreshTable);
          this._alert.success("success", "Message sent successfully.");
          this.sendMessageForm.reset();
          this.closeDialog(fileUploadResponse);
        }
      });
  }

  readThis(inputValue): void {
    this.data.file = inputValue.files[0];
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e) => {
      this.fileName = myReader.result;
      this.data.attachmentfilename = this.fileName;
    };
    myReader.readAsDataURL(inputValue.files[0]);
  }

  onScriptChange($event): void {
    let requestBody = new TemplateParams(this._config);
    requestBody.TemplateId =
      $event.target.value === "Select Script Options" ? 0 : $event.target.value;
    requestBody.AgencyId = requestBody.ProviderID;
    this._commonService
      .getMessageByScriptId(requestBody)
      .subscribe((res: IScriptData) => {
        if (res.responseBody) {
          this.sendMessageForm
            .get("message")
            .setValue(res.responseBody[0].message);
            this.limitNotesCharactersWithHint();
        }
      });
  }

  srUploadAlert(): void {
    this.alertMsg = "Opening Attachment Window";
    setTimeout(() => {
      this.alertMsg = "";
    }, 700);
  }

  autoGenerateNote(records, callback) {
    let taskNote = this.getNoteModel();
    if (Array.isArray(records)) {
      //bulk actions, multiple records
      for (let record of records) {
        taskNote.WorklistTaskIds = record.worklistTaskId.toString();
        taskNote.OfficeID = record.officeId;
        this._notesService.SaveNotes(taskNote).subscribe((res) => {
          if (res) callback();
        });
      }
    } else {
      // single record
      taskNote.WorklistTaskIds = records.worklistTaskId.toString();
      taskNote.OfficeID = records.officeId;
      this._notesService.SaveNotes(taskNote).subscribe((res) => {
        if (res) {
          callback();
        }
      });
    }
  }

  getNoteModel(): TaskNotes { 
    let taskNote = new TaskNotes(this._config);
    taskNote.CreatedBy = this._userService.getUserID().toString();
    taskNote.CreatedByUser = `${this._userService.getUserFullName()} (${this._userService.getUserName()})`;
    taskNote.SubjectText = null;
    const deliveryMethod = this.sendMessageForm.get("deliveryMethod").value ?? this.emailDeliveryMethod;
    const capitalize = (s) => {
      if (typeof s !== "string") return "";
      return s.charAt(0).toUpperCase() + s.slice(1);
    };
    let deliveryType = capitalize(
      Object.keys(DeliveryMethodType)
        .find(
          (key) =>
            DeliveryMethodType[key] ===
            deliveryMethod
        )
        .toLowerCase()
    );
    taskNote.Note = `${deliveryType} Message sent.`;
    taskNote.WorklistTaskIds = "";
    taskNote.CopyNotesTo = "";
    return taskNote;
  }

  canShowCopyTaskInfo(): boolean {
    return !(Array.isArray(this.data.record) && this.data.record.length != 1);
  }

  valueChanged(event: Event): void {
    const message = this.sendMessageForm.get("message");
    let record = this.data.record;
    if (this.data.record.length > 1) {
      message.setValue("Medical/Other Compliance details copied to message.");
      this.isBulkTaskDetail = true;
      event.preventDefault();
      event.stopPropagation();
    }
    else {
      this.isBulkTaskDetail = false;
      if (Array.isArray(this.data.record)) {
        record = this.data.record[0];
      }
      const expirationItem = record.expirationItem;
      const dueDate = this.datepipe.transform(new Date(record.dueDate), "MM/dd/yyyy");
      let lastMsg = message.value;
      if (lastMsg == "") {
        lastMsg = `Please note that ${expirationItem} is due on ${dueDate}`;
      } else {
        lastMsg = `${lastMsg} Please note that ${expirationItem} is due on ${dueDate}`;
      }
      message.setValue(lastMsg);
      event.preventDefault();
      event.stopPropagation();
    }
    this.limitNotesCharactersWithHint();
  }

  limitNotesCharactersWithHint(){
    const lengthOfCurrentText = this.sendMessageForm.value.message.length;
    let messageTextHelpElement = document.getElementById("messageTextHelp");
    let broadcastButtonElement = document.getElementById("broadcastButton");
    let textBoxElement = document.getElementById("message");
    if(lengthOfCurrentText > 0){
      let displayText = lengthOfCurrentText + '/' + this.messageLimit + ' characters'
      displayText = lengthOfCurrentText > this.messageLimit ? displayText + ' - Limit exceeded' : displayText;
      this.messageText = displayText;
      if (lengthOfCurrentText > this.messageLimit) {
        this.messageLimitExceeded = true;
        broadcastButtonElement.setAttribute("disabled", "true");
        messageTextHelpElement.classList.add("hhax-form-error-text");
        messageTextHelpElement.setAttribute("aria-label", "Error:"+ this.messageText);
      }
      else {
        broadcastButtonElement.removeAttribute("disabled");
        messageTextHelpElement.classList.remove("hhax-form-error-text");
      }
      textBoxElement.setAttribute('aria-label', this.sendMessageForm.value.message);
      textBoxElement.setAttribute('aria-hidden',"true");
    }
    else{
      this.messageText = "Message is required";
      broadcastButtonElement.setAttribute("disabled", "true");
      textBoxElement.removeAttribute("aria-label");
      textBoxElement.setAttribute('aria-hidden',"false");
      messageTextHelpElement.classList.add("hhax-form-error-text");
      messageTextHelpElement.setAttribute("aria-label", "Error:"+ this.messageText);
    }
  }
}
