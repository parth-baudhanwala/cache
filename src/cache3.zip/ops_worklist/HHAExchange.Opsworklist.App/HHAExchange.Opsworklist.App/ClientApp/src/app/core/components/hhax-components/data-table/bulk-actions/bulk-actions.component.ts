import {
  Component,
  ElementRef,
  HostListener,
  Input,
  QueryList,
  ViewChild,
  ViewChildren,
} from "@angular/core";

import { BulkActionButton, BulkActionHandler } from "./model";
import { HhaxTableComponent } from "../data-table.component";
import { ToastrAlertService } from "hhax-components";
import { Key } from "ts-key-enum";

const uniqueIdTracker = 0;

@Component({
  selector: "hhax-bulk-actions",
  templateUrl: "./bulk-actions.component.html",
  styleUrls: ["./bulk-actions.component.scss"],
})
export class BulkActionsComponent<T> {
  readonly _uid = `bulk-actions-${uniqueIdTracker}`;

  public isDropdownShown: boolean = false;

  private _selectedAction: number = 0;
  private _dropdownJustOpened: boolean = false;

  @Input() buttons: BulkActionButton<T>;
  @Input() disabled: boolean;

  @ViewChild("mainButton", { read: ElementRef })
  private _mainButton: ElementRef;
  @ViewChildren("action", { read: ElementRef })
  private _actions: QueryList<ElementRef>;

  constructor(
    private _tableRef: HhaxTableComponent,
    private _notificationModule: ToastrAlertService,
    public elementRef: ElementRef
  ) {}

  @HostListener("document:click", ["$event.target"])
  public onClick(targetElement: HTMLElement): void {
    if (!targetElement || !this.isDropdownShown) {
      return;
    }

    const clickedInside = this.elementRef.nativeElement.contains(targetElement);
    if (!clickedInside) {
      this.isDropdownShown = false;
    }
  }

  @HostListener("keyup", ["$event"]) keyup(event) {
    // Element doesn't exist on keydown so focusing on keyup
    if (event.key === Key.ArrowDown && this._dropdownJustOpened) {
      this._actions.toArray()[this._selectedAction].nativeElement.focus();
      this._dropdownJustOpened = false;
    }
  }

  handleAction(handler: BulkActionHandler<T>): void {
    this.isDropdownShown = false;
    this._mainButton.nativeElement.focus();
    const selectedRows = this._tableRef.getSelectedRows();
    if (selectedRows.length > 0) {
      handler(selectedRows);
    } else {
      this._notificationModule.error(
        "Error",
        "You must select at least one record"
      );
    }
  }

  toggleDropdownKey(event: KeyboardEvent) {
    if (event.key === Key.ArrowDown && !this.isDropdownShown) {
      this.isDropdownShown = true;
      this._selectedAction = 0;
      this._dropdownJustOpened = true;
    }
    if (event.key === Key.Escape && this.isDropdownShown) {
      this.isDropdownShown = false;
      this._mainButton.nativeElement.focus();
    }
    if (event.key === Key.Enter && !this.isDropdownShown) {
      this.isDropdownShown = true;
      this._selectedAction = 0;
      this._dropdownJustOpened = true;
    }
  }

  toggleDropdown() {
    this.isDropdownShown = !this.isDropdownShown;
  }

  actionNavigation(event: KeyboardEvent) {
    if (event.key === Key.ArrowDown) {
      if (this._selectedAction < this._actions.length - 1) {
        this._actions.toArray()[this._selectedAction].nativeElement.focus();
        this._selectedAction++;
      }
    }
    if (event.key === Key.Tab && event.shiftKey === false) {
      if (this._selectedAction < this._actions.length - 1) {
        this._actions.toArray()[this._selectedAction].nativeElement.focus();
        this._selectedAction++;
      } else if (this._selectedAction === this._actions.length - 1) {
        this.isDropdownShown = false;
        this._selectedAction = 0;
        this._mainButton.nativeElement.focus();
      }
    }

    if (event.key === Key.Tab && event.shiftKey === true) {
      if (this._selectedAction <= this._actions.length - 1) {
        if (this._selectedAction > 0) {
          this._selectedAction--;
          this._actions.toArray()[this._selectedAction].nativeElement.focus();
        } else {
          this._selectedAction = 0;
          this.isDropdownShown = false;
          this._mainButton.nativeElement.autoFocus = true;
        }
      }
    }
    if (event.key === Key.ArrowUp) {
      if (this._selectedAction > 0) {
        this._selectedAction--;
        this._actions.toArray()[this._selectedAction].nativeElement.focus();
      } else {
        this.isDropdownShown = false;
        this._mainButton.nativeElement.focus();
      }
    }
    if (event.key === Key.Escape) {
      this.isDropdownShown = false;
      this._mainButton.nativeElement.focus();
    }

    if (event.key === Key.Enter) {
      this._actions.toArray()[this._selectedAction].nativeElement.click();
    }
  }
}
