import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { LinkComponent, AlignLinkRightDirective, HeaderNavLinkWrapperComponent } from './link/link.component';
import { NavigationComponent } from './navigation.component';
import { NavLeftContainerDirective, NavRightContainerDirective } from './navigation.directive';
import { LinkIconComponent } from './link-icon/link-icon.component';
import { LinkIconRightComponent } from './link-icon-right/link-icon-right.component';

@NgModule({
  declarations: [
    AlignLinkRightDirective,
    HeaderNavLinkWrapperComponent,
    LinkComponent,
    LinkIconComponent,
    NavigationComponent,
    NavLeftContainerDirective,
    NavRightContainerDirective,
    LinkIconRightComponent,
  ],
  exports: [
    AlignLinkRightDirective,
    HeaderNavLinkWrapperComponent,
    LinkComponent,
    LinkIconComponent,
    NavigationComponent,
    NavLeftContainerDirective,
    NavRightContainerDirective,
  ],
  imports: [
    CommonModule,
    FontAwesomeModule,
    RouterModule,
  ],
})
export class HhaxHeaderModule { }
