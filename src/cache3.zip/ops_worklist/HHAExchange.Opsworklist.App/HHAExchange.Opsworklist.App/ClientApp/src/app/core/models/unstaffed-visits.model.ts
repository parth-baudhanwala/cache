import { Defaultparam } from "@app/core/models/defaultparam.model";

export class QuickBroadcastParams extends Defaultparam {
  broadcastID: number;
  broadcastNote: string;
  broadcastNoteText: string;
  visitID: number;
  OfficeID: number;
  BroadcastStatus: string;
  PatientID: number;
  ProcessStatus: string;
  VisitDate: string;
  AdmissionID: string;
  AppName: string;
  AppSecret: string;
  CallerInfo: string;
}

export interface QuickBroadcastResponse {
  d: number;
}
