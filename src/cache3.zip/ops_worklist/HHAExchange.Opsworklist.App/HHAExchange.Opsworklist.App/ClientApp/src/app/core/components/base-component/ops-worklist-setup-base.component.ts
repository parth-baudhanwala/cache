import { Component, OnInit } from '@angular/core';
import { patienStatusOptions } from "../../../../app/core/config/static-options";

@Component({
  selector: 'app-ops-worklist-setup-base',
  template: ` <p>ops worklist setup base component</p> `
})
export class OpsWorklistSetupBaseComponent implements OnInit {

  patientTaskCreationStatus = patienStatusOptions;
  constructor() { }

  ngOnInit(): void { }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  onPasteAllowNumbersOnly(event): void {
    const isMatched = event.clipboardData.getData('text/plain').match(/^(?!0+$)[0-9]{1,10}$/);
    if (!isMatched) {
      event.preventDefault();
    }
  }

  handleKeydown(event: any, callback: Function = undefined) {
    if (event && event.key === "Enter") {
      if (event.target) {
        event.preventDefault();
      }

      if (callback) callback(event);
    }
  }

  handleKeyboardAccessibility(event: any) {
    if (event && event.target) {
      event.target.click();
    }
  }
}
