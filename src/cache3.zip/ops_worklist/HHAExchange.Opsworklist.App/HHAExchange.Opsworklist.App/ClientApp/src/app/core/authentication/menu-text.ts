export enum MenuText {
  qve = 'Quick Visit Entry',
  caregiveravailability = 'CaregiverCommunicationsAvailability',
  communicationhistory  = 'Caregiver Communications History' 
}
