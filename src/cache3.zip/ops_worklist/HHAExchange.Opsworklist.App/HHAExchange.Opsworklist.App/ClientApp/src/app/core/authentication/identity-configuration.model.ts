export interface IIdentityConfiguration {
  authority: any;
  client_id: string;
  redirect_uri: string;
  post_logout_redirect_uri: string;
  response_type: string;
  silent_redirect_uri: string;
  silentRequestTimeout: number;
  scope: string;
  filterProtocolClaims: boolean;
  loadUserInfo: boolean;
  monitorSession: boolean;
  automaticSilentRenew: boolean;
  accessTokenExpiringNotificationTime: number;
  checkSessionInterval: number;
  includeIdTokenInSilentRenew: boolean;
}
