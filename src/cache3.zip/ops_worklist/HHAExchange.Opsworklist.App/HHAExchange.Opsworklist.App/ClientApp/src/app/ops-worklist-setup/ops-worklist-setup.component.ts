import { AfterViewInit, Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { find, head, isEmpty } from 'lodash/fp';
import { HHAUserService } from '../core/authentication/user.service';
import { IAuthenticationParams, Worklist, WorklistDetail, WorklistName } from '../core/models/common.model';
import { CommonService } from '../core/services/common.service';
import { ConfigurationService } from '../core/services/configuration.service';
import { LocalStorageKeyNames, LocalStorageService } from '../core/services/local-storage.service';
import { LazyLoadService } from '../lazy-tabs/lazy-load-service';
import { ReplaceKeywordPipe } from '@app/core/pipes/replace-keyword.pipe';

@Component({
  selector: 'app-ops-worklist-setup',
  templateUrl: './ops-worklist-setup.component.html'
})
export class OpsWorklistSetupComponent implements OnInit, AfterViewInit {

  worklistSetupDetails: WorklistDetail[] = [];

  constructor(
    private _config: ConfigurationService,
    private _loader: LazyLoadService,
    private _commonService: CommonService,
    private _userService: HHAUserService,
    private _localStorage: LocalStorageService,
    private _replaceKeyword: ReplaceKeywordPipe
  ) { }

  @ViewChild("tab", { read: ViewContainerRef, static: false })
  tab: ViewContainerRef;

  ngOnInit(): void {
    this.checkAuthentication();
    this.setWorkistTabs();
  }

  ngAfterViewInit(): void {
    const tabData = head(this.worklistSetupDetails);
    this.loadDynamicTab(tabData);
  }

  setWorkistTabs(): void {
    this.worklistSetupDetails = [
      {
        worklistId: 1,
        worklistName: WorklistName.MEDICAL_COMPLIANCE,
        worklistPath: Worklist.MEDICAL_COMPLIANCE_SETUP,
        userName: this._config.appConfiguration.userName,
        canManuallyCloseWorklistTask: false,
        canAssignWorklistTask: false,
        isOpsWorklistLandingPage: false,
        assignedDefaultWorklist: 0
      },
      {
        worklistId: 2,
        worklistName: WorklistName.EXPIRING_AUTHORIZATION,
        worklistPath: Worklist.EXPIRING_AUTHORIZATION_SETUP,
        userName: this._config.appConfiguration.userName,
        canManuallyCloseWorklistTask: false,
        canAssignWorklistTask: false,
        isOpsWorklistLandingPage: false,
        assignedDefaultWorklist: 0
      },
      {
       worklistId: 3,
       worklistName: WorklistName.UNSTAFFED_VISITS,
       worklistPath: Worklist.UNSTAFFED_VISITS_SETUP,
       userName: this._config.appConfiguration.userName,
       canManuallyCloseWorklistTask: false,
       canAssignWorklistTask: false,
       isOpsWorklistLandingPage: false,
       assignedDefaultWorklist: 0
      },
      {
       worklistId: 4,
       worklistName: WorklistName.MASTER_WEEK,
       worklistPath: Worklist.MASTER_WEEK_SETUP,
       userName: this._config.appConfiguration.userName,
       canManuallyCloseWorklistTask: false,
       canAssignWorklistTask: false,
       isOpsWorklistLandingPage: false,
       assignedDefaultWorklist: 0
      },
      {
       worklistId: 5,
       worklistName: WorklistName.CERTIFICATION_PERIOD,
       worklistPath: Worklist.CERTIFICATION_PERIOD_SETUP,
       userName: this._config.appConfiguration.userName,
       canManuallyCloseWorklistTask: false,
       canAssignWorklistTask: false,
       isOpsWorklistLandingPage: false,
       assignedDefaultWorklist: 0
      }
    ];
  }

  selectTab(name: string): void {
    const worklistTabData = find(
      (tab: WorklistDetail) =>
        name.includes(this._replaceKeyword.transform(tab.worklistName)),
      this.worklistSetupDetails
    );
    this.loadDynamicTab(worklistTabData);
  }

  loadDynamicTab(tabData: WorklistDetail): void {
    if (tabData && !isEmpty(tabData.worklistPath)) {
      this.tab.clear();
      this._loader.load(tabData, this.tab);
    }
  }

  checkAuthentication(): void {
    const sessionId = this._localStorage.getItem<string>(LocalStorageKeyNames.sessionID);

    if (!sessionId) {
      this._userService.logoutUser();
    }

    const authParams: IAuthenticationParams = {
      UserID: this._config.appConfiguration.userId,
      SessionID: sessionId,
      AppVersion: this._config.appConfiguration.appName,
      Version: this._config.appConfiguration.version,
      MinorVersion: this._config.appConfiguration.minorVersion
    };

    this._commonService.getUserAuthentication(authParams).subscribe({
      next: (result) => {
        if (!result || !result.isUserLoggedIn) {
          this._userService.logoutUser();
        }
      },
      error: () => this._userService.logoutUser()
    });
  }
}
