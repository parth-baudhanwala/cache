export interface AutocompleteRsModel {
    id: string | number;
    name: string;
}