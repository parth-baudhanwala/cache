export class ComplianceExpItem {
  static generateHierarchy(complianceList: ComplianceExpItem[]) {
    try {
      const newList = complianceList;
      for (var i = 0; i < newList.length; i++) {
        const currCmp = newList[i];
        currCmp.children = [];
        currCmp.children = newList.filter(
          (cmp) => cmp.parentID === currCmp.complianceExpItemID
        );
      }
      return newList.filter((cmp) => cmp.parentID === -1)[0].children;
    } catch (err) {
      return [];
    }
  }
  selected: boolean;
  expirationItem: string;
  complianceExpItemID: number;
  parentID: number;
  isLeaf: boolean;
  level: number;
  hirarchyLevel: number;
  type: string;
  parent: string;
  isEnable: boolean;
  children: ComplianceExpItem[];
}

