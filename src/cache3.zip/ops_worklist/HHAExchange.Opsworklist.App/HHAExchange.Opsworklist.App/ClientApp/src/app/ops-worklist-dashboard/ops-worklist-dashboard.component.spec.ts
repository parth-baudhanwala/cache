import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { GetWlTaskStatusCount } from "@app/core/services-mock-data/common.service.mock";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { of } from "rxjs";

import { LazyLoadService } from "../lazy-tabs/lazy-load-service";
import { OpsWorklistDashboardComponent } from "./ops-worklist-dashboard.component";

describe("OpsWorklistDashboardComponent", () => {
  let component: OpsWorklistDashboardComponent;
  let fixture: ComponentFixture<OpsWorklistDashboardComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [OpsWorklistDashboardComponent],
      providers: [
        {
          provide: CommonService,
          useValue: {
            getWorkListsTaskCount: () => of(GetWlTaskStatusCount),
          },
        },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userID: 27398,
              providerID: 691,
              workLists: [
                {
                  userName: "shekhussp",
                  worklistId: 1,
                  worklistName: "Expiring Caregiver Medical/Other Compliance",
                  canManuallyCloseWorklistTask: "No",
                  canAssignWorklistTask: "Yes",
                  isOpsWorklistLandingPage: "Yes",
                  assignedDefaultWorklist: 2,
                },
                {
                  userName: "shekhussp",
                  worklistId: 2,
                  worklistName: "Expiring Authorizations",
                  canManuallyCloseWorklistTask: "No",
                  canAssignWorklistTask: "Yes",
                  isOpsWorklistLandingPage: "Yes",
                  assignedDefaultWorklist: 2,
                },
              ],
              agencyID: "691",
            },
          },
        },
        {
          provide: LazyLoadService,
          useValue: {
            load: () => of("path", 1),
          },
        },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpsWorklistDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeDefined();
  });

  it("should check assign list data", () => {
    const worklistTab = [
      {
        title: "ops workslist",
        id: 1,
        path: "url",
        taskCount: 5,
        worklistId: 1,
        detail: {
          userName: "srinivas",
          worklistId: 2,
          worklistName: "ops works list",
          worklistPath: "url",
          canManuallyCloseWorklistTask: true,
          canAssignWorklistTask: true,
          isOpsWorklistLandingPage: "any;",
          assignedDefaultWorklist: 5,
          taskCount: 5,
        },
      },
    ];
    const worklistCounts = [
      {
        worklistID: 1,
        taskCount: 3,
      },
    ];
    component.updateWorklistOpenCounts(worklistTab, worklistCounts);
    expect(worklistTab[0].taskCount).toBe(3);
  });

  it("should call selectTab", () => {
    component.selectTab("Worklist Title");
    expect(component.loadDynamicTab).toBeDefined();
  });

  it("load", () => {
    let worklist = {
      detail: {
        assignedDefaultWorklist: 1,
        canAssignWorklistTask: "Yes",
        canManuallyCloseWorklistTask: "Yes",
        isOpsWorklistLandingPage: "Yes",
        userName: "shekhussp",
        worklistId: 5,
        worklistName: "Expiring Certification Period",
        worklistPath: "ExpiringCertificationPeriod",
      },
      id: 5,
      path: "ExpiringCertificationPeriod",
      taskCount: 51,
      title: "Expiring Certification Period",
      worklistId: 5,
    };
    component.loadDynamicTab(worklist);
    expect(component.tab.clear).toBeDefined();
  });
});
