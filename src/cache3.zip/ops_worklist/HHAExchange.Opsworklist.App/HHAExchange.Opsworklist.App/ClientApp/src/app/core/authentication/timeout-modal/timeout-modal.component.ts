import { Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HhaxSuccessButtonDirective } from '@app/core/components/hhax-components/button/button.directive';
import { Guid } from 'guid-typescript';
import { ModalComponent } from 'hhax-components';
import { configHelper } from '../../config/static-options';
import { HHAUserService } from '../user.service';
import { SessionConfig } from './model/session.model';
import { TimeoutService } from './service/timeout.service';
import { DEFAULT_TIMEOUT_CONFIG } from './token/default-token';

@Component({
  selector: 'app-timeout-modal',
  templateUrl: './timeout-modal.component.html',
  styleUrls: ['./timeout-modal.component.scss']
})
export class TimeoutModalComponent implements OnInit, OnDestroy {
  @ViewChild(HhaxSuccessButtonDirective, { static: true, read: ElementRef })
  confirmationButton: ElementRef<HTMLButtonElement>;

  secondsTimer: NodeJS.Timeout;
  updateSrTimer: NodeJS.Timeout;

  secondsRemaining: number;
  timeoutDuration: number;

  showSrTimeRemaining: boolean;
  showSessionExpireMsg: boolean = true;
  sessionTime: any;
  resetSessionCount: number;

  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<ModalComponent>,
    public _userService: HHAUserService,
    @Inject(DEFAULT_TIMEOUT_CONFIG) public sessionConfig: SessionConfig,
    private _timeModalService: TimeoutService
  ) {
    this.secondsRemaining = this.timeoutDuration = sessionConfig.timeoutModalDuration;
  }

  ngOnInit(): void {
    this.sessionTime = this._timeModalService.setSessionTime();
    const sessionTimeoutMinute = localStorage.getItem("SessionTimeoutMinutes");
    const latestSessionTimeoutMinute = sessionTimeoutMinute ? sessionTimeoutMinute : configHelper.defaultSessionTimeoutMinute;
    this.resetSessionCount = parseInt(latestSessionTimeoutMinute) * 60;
    this.secondsTimer = setInterval(() => {
      this.secondsRemaining--;
      if (this.secondsRemaining === 0) {
        this.clearTimers();
      }
    }, 1_000);

    const tenSecondsRemaining =
      toMilliseconds(this.timeoutDuration) - toMilliseconds(10);

    this.updateSrTimer = setTimeout(() => {
      this.showSrTimeRemaining = true;
    }, tenSecondsRemaining);
  }



  ngOnDestroy(): void {
    this.clearTimers();
  }

  logoutUser() {
    this._userService.logoutUser();
  }

  continueSession(): void {
    var endDate = new Date();
    var seconds = (endDate.getTime() - this.sessionTime.getTime()) / 1000;
    if (this.secondsRemaining <= 0 || this.resetSessionCount <= seconds) {
      this.showSessionExpireMsg = false;
    } else {
      this._timeModalService.updateSessionTime(new Date());
      this.showSessionExpireMsg = true;
      this.dialogRef.close();
    }
  }

  logoutSession() {
    this.dialogRef.close();
    this.logoutUser();
  }

  private clearTimers() {
    clearInterval(this.secondsTimer);
    clearTimeout(this.updateSrTimer);
  }
}

export function toMilliseconds(seconds: number): number {
  return seconds * 1_000;
}

export function generateComponentId() {
  return Guid.create().toString();
}
