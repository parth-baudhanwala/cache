import { Component, Input } from '@angular/core';
import { RadioButtonGroupComponent } from './radio-button-group/radio-button-group.component';
import { coerceBooleanProperty } from '@angular/cdk/coercion';

let uniqueRadioButtonId = 0;

@Component({
  selector    : 'hhax-radio-button',
  templateUrl : './radio-button.component.html',
  styleUrls   : ['./radio-button.component.scss']
})
export class RadioButtonComponent {

  @Input() value: any;
  @Input() name?: string;

  @Input('disabled')
  get isDisabled(): boolean { return this._isDisabled; }
  set isDisabled(v: boolean) { this._isDisabled = coerceBooleanProperty(v); }
  private _isDisabled: boolean;

  readonly _uid = `radio-button-${uniqueRadioButtonId++}`;

  constructor(public parentRadioGroup: RadioButtonGroupComponent) { }
}
