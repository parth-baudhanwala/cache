import { AfterViewInit, Component, OnInit, ViewChild, ViewContainerRef } from "@angular/core";
import { workListCount, WorklistDetail, worklistTab } from "@app/core/models/common.model";
import { Events } from "@app/core/models/constant.model";
import { CommonService } from "@app/core/services/common.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { concat, find, head, isEmpty, size, sortBy } from "lodash/fp";
import { LazyLoadService } from "../lazy-tabs/lazy-load-service";
import { ReplaceKeywordPipe } from "@app/core/pipes/replace-keyword.pipe";

@Component({
  selector: "ops-worklist-dashboard",
  templateUrl: "./ops-worklist-dashboard.component.html",
})
export class OpsWorklistDashboardComponent implements OnInit, AfterViewInit {
  userWorkLists: worklistTab[] = [];

  constructor(
    private _workLists: CommonService,
    private _config: ConfigurationService,
    private _loader: LazyLoadService,
    private _replaceKeyword: ReplaceKeywordPipe
  ) { }

  @ViewChild("tab", { read: ViewContainerRef, static: false })
  tab: ViewContainerRef;

  ngOnInit(): void {
    this.userWorkLists = sortBy(["id"], this.getWorkistTabs());
    this.refreshWorklistCount();
  }

  ngAfterViewInit(): void {
    const tabData = head(this.userWorkLists);
    this.loadDynamicTab(tabData);
  }

  refreshWorklistCount(): void {
    let payload = {
      userID: this._config.appConfiguration.userId,
      providerID: Number(this._config.appConfiguration.agencyID),
    };

    this._workLists.getWorkListsTaskCount(payload).subscribe((worklistCount: workListCount[]) => {
      this.updateWorklistOpenCounts(this.userWorkLists, worklistCount);
    });
  }

  getWorkistTabs(): worklistTab[] {
    const defaultWorkLists = this._config.appConfiguration.workLists
      .filter((obj: WorklistDetail) => obj.assignedDefaultWorklist === obj.worklistId)
      .map((obj: WorklistDetail, index: number) => ({
        title: obj.worklistName,
        id: index + 1,
        worklistId: obj.worklistId,
        path: obj.worklistPath,
        detail: obj,
      }));

    const otherWorkLists = this._config.appConfiguration.workLists
      .filter((obj: WorklistDetail) => obj.assignedDefaultWorklist !== obj.worklistId)
      .map((obj: WorklistDetail, index: number) => ({
        title: obj.worklistName,
        id: index + 1 + size(defaultWorkLists),
        worklistId: obj.worklistId,
        path: obj.worklistPath,
        detail: obj,
      }));

    return concat(defaultWorkLists, otherWorkLists);
  }

  updateWorklistOpenCounts(workListTabs: worklistTab[], worklistCounts: workListCount[]): void {
    workListTabs.forEach((obj) => {
      obj.taskCount = (find(["worklistID", obj.worklistId], worklistCounts) || {}).taskCount || 0;
    });
  }

  selectTab(name: string): void {
    const worklistTabData = find(
      (obj: worklistTab) =>
        name.includes(this._replaceKeyword.transform(obj.title)),
      this.userWorkLists
    );
    this.loadDynamicTab(worklistTabData);
  }

  loadDynamicTab(tabData: worklistTab): void {
    if (tabData && !isEmpty(tabData.path)) {
      this.tab.clear();
      this._loader.load(tabData.detail, this.tab, (event: Events) => {
        if (event === Events.REFRESH_WORKLIST_COUNT) {
          this.refreshWorklistCount();
        }
      });
    }
  }
}
