import {
  Component,
  OnInit,
  Input,
  forwardRef,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
} from "@angular/core";
import { Observable, iif, of } from "rxjs";
import { debounceTime, tap, switchMap, finalize } from "rxjs/operators";
import { FormControl, NG_VALUE_ACCESSOR } from "@angular/forms";
import { LoggerService } from "hhax-components";
import { BaseHttpService } from "../../../services/base.http.service";
import { AutocompleteRsModel } from "./autocomplete.model";

let uniqueIdTracker = 0;

@Component({
  selector: "hhax-autocomplete",
  templateUrl: "./autocomplete.component.html",
  styleUrls: ["./autocomplete.component.scss"],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => AutocompleteComponent),
    },
  ],
})
export class AutocompleteComponent implements OnInit, OnChanges {
  readonly _uidHint = `hhax-autocomplete-hint-${uniqueIdTracker++}`;

  @Input() placeholder: string = "";
  @Input() id: string;
  @Input() label: string;
  @Input() getUrl: string;
  @Input() getParams: Observable<object>;
  @Output() selectedOption = new EventEmitter<AutocompleteRsModel>();

  onChange: (value: string) => void;
  onBlur: (event: Event) => void;

  value: string | number;
  autocompleteOptions: AutocompleteRsModel[] = [];
  filteredOptions: Observable<string[]>;
  control = new FormControl();
  isLoading = false;
  apiQueryParams: object;
  autocompleteOptionsReset$ = of([]);

  constructor(
    private _logger: LoggerService,
    private _httpClient: BaseHttpService
  ) {}

  ngOnInit() {
    this.control.valueChanges
      .pipe(
        debounceTime(500),
        tap(() => {
          this.isLoading = true;
        }),
        switchMap((v) =>
          iif(
            () => v !== "",
            this._httpClient.get<[]>(this.getUrl, this.getParams),
            this.autocompleteOptionsReset$
          ).pipe(finalize(() => (this.isLoading = false)))
        )
      )
      .subscribe((responseData) => {
        this.autocompleteOptions = responseData;
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      changes.getParams.currentValue &&
      changes.getParams.currentValue.substring === ""
    ) {
      this.control.setValue("");
    }
    debounceTime(500);
    if (changes.getParams.firstChange !== true) {
      this.getParams = changes.getParams.currentValue;
    }
  }

  writeValue(value: string | number | null): void {
    if (
      typeof value === "string" ||
      typeof value === "number" ||
      value === null
    ) {
      this.value = value;
    } else {
      // TODO Maybe make a logger service specifically for form controls so this can be templated?
      this._logger.logError(
        `Form control expected value of type 'string' or 'number', but instead received value of type: ${typeof value}`
      );
    }
  }
  registerOnChange(fn: any): void {
    this.onChange = (value: string) => {
      this.value = value;
      this.control.setValue(this.value);
      fn(value);
    };
  }

  registerOnTouched(fn: any): void {
    this.onBlur = fn;
  }

  sendOption(event, option): void {
    if (event.isUserInput) {
      this.selectedOption.emit(option);
    }
  }

  displayFn(providerValue): string | undefined {
    return this.autocompleteOptions.find((x) => x.id == providerValue).name;
  }
}
