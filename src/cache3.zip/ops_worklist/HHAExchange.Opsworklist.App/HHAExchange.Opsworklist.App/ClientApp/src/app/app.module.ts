import { OverlayContainer } from "@angular/cdk/overlay";
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { APP_INITIALIZER, Inject, NgModule } from "@angular/core";
import { BrowserModule, Title } from "@angular/platform-browser";
import { BrowserAnimationsModule, NoopAnimationsModule } from "@angular/platform-browser/animations";
import { Router, RouterModule } from "@angular/router";
import { isBlank } from "@app/lib/utils";
import { ApplicationInsights } from "@microsoft/applicationinsights-web";
import { NgIdleModule } from "@ng-idle/core";
import { NgIdleKeepaliveModule } from "@ng-idle/keepalive";
import { BaseService, SpinnerModule, ToastrAlertComponent, WindowRefService } from "hhax-components";
import { CookieModule, CookieService } from "ngx-cookie";
import { ToastrModule } from "ngx-toastr";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { AuthInterceptor } from "./core/authentication/auth.interceptor";
import { HHAAuthGuard } from "./core/authentication/hha-auth-guard.service";
import { HttpErrorInterceptor } from "./core/authentication/http-error.interceptor";
import { SecurityModule } from "./core/authentication/security.module";
import { TimeoutService } from "./core/authentication/timeout-modal/service/timeout.service";
import { HHAUserService } from "./core/authentication/user.service";
import { HHAMaterialOverlayContainer } from "./core/components/contianers/material-overlay-container";
import { CoreModule } from "./core/core.module";
import { ConfigurationService } from "./core/services/configuration.service";
import { LocalStorageKeyNames, LocalStorageService } from './core/services/local-storage.service';
import { HhaxMasterLayoutModule } from "./modules/hhax-master-layout/hhax-master-layout.module";

// Core
// hhax-components
const TOASTR_CONFIG = {
  closeButton: true,
  progressBar: false,
  timeOut: 5000,
  toastComponent: ToastrAlertComponent,
};

@NgModule({
  declarations: [AppComponent],
  bootstrap: [AppComponent],
  imports: [
    AppRoutingModule,
    BrowserAnimationsModule,
    BrowserModule,
    CoreModule,
    HttpClientModule,
    NgIdleModule.forRoot(),
    NgIdleKeepaliveModule.forRoot(),
    NoopAnimationsModule,
    RouterModule,
    SecurityModule,
    ToastrModule.forRoot(TOASTR_CONFIG),
    SpinnerModule,
    CookieModule.forRoot(),
    HhaxMasterLayoutModule
  ],
  providers: [
    HHAAuthGuard,
    ConfigurationService,
    Title,
    {
      provide: APP_INITIALIZER,
      useFactory: (userService: HHAUserService) => () =>
        userService.setUserManager(),
      deps: [HHAUserService],
      multi: true,
    },
    {
      provide: "HOST",
      useValue: window.location.host,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true,
    },
    {
      provide: OverlayContainer,
      useClass: HHAMaterialOverlayContainer
    },
    WindowRefService,
    BaseService
  ],
})
export class AppModule {

  constructor(
    public httpClient: HttpClient,
    public userService: HHAUserService,
    public router: Router,
    private _configurationService: ConfigurationService,
    public cookieService: CookieService,
    private _localStorageService: LocalStorageService,
    public sessionManager: TimeoutService,
    @Inject('HOST') host: string,
  ) {
    if (!window.location.href.includes('silent-refresh')) {
      this.sessionManager.initalizeIdleWatcher();
      this.sessionManager.initializeKeepAliveWatcher();
    }

    const user = userService.getUser();
    const urlIndex = host.indexOf('localhost') === 0 ? 1 : 2;
    const routeName = window.location.pathname.split('/')[urlIndex];

    if (routeName && routeName != "auth-complete" && routeName != "silent-refresh" && routeName != "Opsworklist#{Octopus.Environment.Name}") {
      this._localStorageService.setItem(LocalStorageKeyNames.routePathName, routeName);
    }

    if (isBlank(user) || !userService.isLoggedIn()) {
      if (window.location.href.indexOf("auth-complete") !== -1) {
        userService.completeAuthentication().then(() => {

          const sessionID = this.cookieService.get("HHAX_Session");
          if (!(sessionID == null || sessionID == "")) {
            this._localStorageService.setItem(LocalStorageKeyNames.sessionID, sessionID);
          }

          this._configurationService.geAppConfiguration(userService.getUserID()).then(() => {
            _configurationService.hasAppLoaded = true;
            this.appInsightsInit();
          });

          let route = _localStorageService.getItem(LocalStorageKeyNames.routePathName);
          this.router.navigate([route]);
        });
      }
      else if (window.location.href.indexOf("silent-refresh") === -1) {
        userService.startAuthentication();
      }
    }
    else {
      this._configurationService.geAppConfiguration(userService.getUserID()).then(() => {
        _configurationService.hasAppLoaded = true;
        this.appInsightsInit();
      });
    }
    router.initialNavigation();

    this._configurationService.setAppSettings();
  }

  appInsightsInit() {
    if (
      !isBlank(this._configurationService.appConfiguration.instrumentationKey)
    ) {
      const appInsights = new ApplicationInsights({
        config: {
          instrumentationKey:
            this._configurationService.appConfiguration.instrumentationKey,
        },
      });
      appInsights.loadAppInsights();
      appInsights.trackPageView();
    }
  }
}
