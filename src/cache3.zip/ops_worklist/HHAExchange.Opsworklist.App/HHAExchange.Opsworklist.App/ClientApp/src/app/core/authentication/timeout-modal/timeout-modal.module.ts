import { A11yModule } from '@angular/cdk/a11y';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { HhaxAccessibilityModule } from '@app/core/components/hhax-components/accessibility/accessibility.module';
import { HhaxButtonModule } from '@app/core/components/hhax-components/button/button.module';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { HhaxLayoutsModule, ModalModule } from 'hhax-components';
import { TimeoutService } from './service/timeout.service';
import { TimeoutModalComponent } from './timeout-modal.component';

@NgModule({
    declarations: [TimeoutModalComponent],
    exports: [TimeoutModalComponent],
    imports: [CommonModule, 
        ModalModule,
        HhaxAccessibilityModule,
        HhaxButtonModule,
        HhaxLayoutsModule,
        MatDialogModule,
        A11yModule,
        NgIdleKeepaliveModule.forRoot()
    ],
    providers: [TimeoutService],
})
export class TimeoutModalModule { }