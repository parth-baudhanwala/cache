import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MedicalComplianceSetupComponent } from './medical-compliance-setup.component';
import { CoreModule } from "@app/core/core.module";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";

@NgModule({
  declarations: [
    MedicalComplianceSetupComponent
  ],
  imports: [
    CommonModule,
    CoreModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class MedicalComplianceSetupModule {
  static entry = MedicalComplianceSetupComponent;
}
