import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { getTestBed, TestBed } from '@angular/core/testing';

import { sendBroadCastSendMessageDataResponse } from '../services-mock-data/search-field.service.mock';
import { BroadCastService } from './broadcast.service';
import { SessionStorageService } from './session-storage.service';

describe("BroadCastService", () => {

  let sendBroadCastSendMessageData =  {
      MessageTypeID: "1",
      TemplateID: 3823,
      Subject: "send broadcast message",
      Message: "AN Test Voice Script",
      IsScheduled: 1,
      UserID: 27398,
      PriorityType: 1,
      ProviderID: 691,
      AideID: [
        978989
      ],
      DeliveryOption: 1
  }
  let service: BroadCastService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        SessionStorageService,
        { provide: "HOST", useValue: "test" },

      ],
    });
    injector = getTestBed();
    service = injector.inject(BroadCastService);
    httpMock = injector.inject(HttpTestingController);
  });
  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });
  it("BroadCastService should be created", () => {
    expect(service).toBeTruthy();
  });
  it("BroadCastService should call sendBroadCastDetails", () => {
    service.sendBroadCastDetails(sendBroadCastSendMessageData).subscribe((res) => {
      expect(res).toEqual(sendBroadCastSendMessageDataResponse);
    });
    const request = httpMock.expectOne( 'Common/sendBroadCastDetails');
    expect(request.request.method).toBe('POST');
    request.flush(sendBroadCastSendMessageDataResponse);
  })
});
