import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnstaffedVisitsSetupComponent } from './unstaffed-visits-setup.component';

describe('UnstaffedVisitsSetupComponent', () => {
  let component: UnstaffedVisitsSetupComponent;
  let fixture: ComponentFixture<UnstaffedVisitsSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnstaffedVisitsSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnstaffedVisitsSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
