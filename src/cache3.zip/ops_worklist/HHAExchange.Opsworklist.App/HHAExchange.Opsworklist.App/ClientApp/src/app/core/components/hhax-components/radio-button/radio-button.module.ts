import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { MatRadioModule } from "@angular/material/radio";
import { ReactiveFormsModule } from "@angular/forms";
import { RadioButtonComponent } from "./radio-button.component";
import { RadioButtonGroupComponent } from "./radio-button-group/radio-button-group.component";
import { FormLabelModule } from "hhax-components";

@NgModule({
  declarations: [RadioButtonComponent, RadioButtonGroupComponent],
  exports: [RadioButtonComponent, RadioButtonGroupComponent],
  imports: [CommonModule, FormLabelModule, MatRadioModule, ReactiveFormsModule],
})
export class RadioButtonModule {}
