import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { HhaxLayoutsModule } from 'hhax-components';
import { HhaxHeaderModule } from '../../core/components/hhax-components/navigation/header.module';
import { CoreModule } from '../../core/core.module';
import { HhaxFooterComponent } from './footer/footer.component';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { HhaxNavigationBarComponent } from './header/hhax-navigation-bar.component';
import { LayoutComponent } from './layout/layout.component';


@NgModule({
  declarations: [
    HhaxNavigationBarComponent,
    HhaxFooterComponent,
    LayoutComponent,
    ForbiddenComponent
  ],
  imports: [
    CommonModule,
    HhaxHeaderModule,
    FontAwesomeModule,
    RouterModule,
    CoreModule,
    HhaxLayoutsModule
  ],
  exports: [
    LayoutComponent,
    ForbiddenComponent
  ]
})
export class HhaxMasterLayoutModule { }
