import { ComponentFixture, TestBed, waitForAsync } from "@angular/core/testing";
import { WorkslistService } from "@app/core/services/workslist.service";
import { ConfigurationService } from "@app/core/services/configuration.service";
import { SearchFieldsService } from "app/core/services/search-fields.service";
import { HttpClientModule } from "@angular/common/http";
import { FormBuilder } from "@angular/forms";
import { MatDialog, MatDialogModule } from "@angular/material/dialog";
import { of } from "rxjs";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { CertificationPeriodComponent } from "./certification-period.component";
import {
  getContractOptionsResponse,
  getCoordinatorsByIDResponse,
  getDisciplineForOfficeResponse,
  getOfficeDataResponse,
  getNurseOptionsResponse,
} from "@app/core/services-mock-data/search-field.service.mock";
import { NotesService } from "@app/core/services/notes.service";
import {
  closingConditionResponse,
  GetUsersByWorklistIDResponse,
  UpdateStatusResponse,
} from "@app/core/services-mock-data/common.service.mock";
import { GetAllNotesByTaskIDResponseData } from "@app/core/services-mock-data/notes.service.mock";
import { CommonService } from "@app/core/services/common.service";
import { ToastrAlertService } from "hhax-components";
import { HHAUserService } from "@app/core/authentication/user.service";
import { saveNotesResponse } from "@app/core/services-mock-data/notes.service.mock";
import { Worklist } from "@app/core/models/common.model";
import { DatePipe } from '@angular/common';

const mockRecord = {
  authorizationNumber: "123456",
  remaining: "20 Hours",
  patientNameOrID: "Simon",
  patientAdmID: "HHA-P001",
  contract: "Jake",
  lastNotes: {
    createdDate: "02/27/2021",
    createdByUser: "Raymond Holt",
    note: "Expiring Auth Notes",
  },
  dateReported: "03/08/2021",
  assignedTo: "Gina Linetti",
  status: "Open",
  expirationDate: "03/31/2021",
  worklistTaskId: 1,
  patientId: 5,
  worklistEntKey: "6632-||-691-||-977506",
};

let inputData = {
  userName: "test",
  worklistId: 1,
  worklistName: "medical",
  worklistPath: "url",
  canManuallyCloseWorklistTask: "No",
  canAssignWorklistTask: "No",
  isOpsWorklistLandingPage: "any",
  assignedDefaultWorklist: 1,
  taskCount: 6,
};

const mockBulkRecords = [mockRecord, mockRecord];

describe("CertificationPeriodComponent", () => {
  let component: CertificationPeriodComponent;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [CertificationPeriodComponent],
      imports: [HttpClientModule, MatDialogModule, BrowserAnimationsModule],
      providers: [
        {
          provide: SearchFieldsService,
          useValue: {
            getOffices: () => of(getDisciplineForOfficeResponse),
            getContractOptions: () => of(getContractOptionsResponse),
            getCoordinatorOptions: () => of(getCoordinatorsByIDResponse),
            getOfficeData: () => of(getOfficeDataResponse),
            getDiscipline: () => of(getDisciplineForOfficeResponse),
            getNurseOptions: () => of(getNurseOptionsResponse),
          },
        },
        {
          provide: WorkslistService,
          useValue: {
            closingCondition: (params) => of(closingConditionResponse),
            getsubject: () => of("test"),
          },
        },
        {
          provide: CommonService,
          useValue: {
            GetUsersByWorklistID: () => of(GetUsersByWorklistIDResponse),
            updateTask: () => of(UpdateStatusResponse),
          },
        },
        {
          provide: NotesService,
          useValue: {
            GetAllNotesByTaskID: () => of(GetAllNotesByTaskIDResponseData),
            SaveNotes: () => of(saveNotesResponse),
          },
        },
        MatDialog,
        FormBuilder,
        { provide: "HOST", useValue: "test" },
        {
          provide: ConfigurationService,
          useValue: {
            appConfiguration: {
              userId: 27398,
              userOffices: [{ officeID: "123" }, { officeID: "2" }],
              AppVersion: "ENT",
              Version: 21.02,
              MinorVersion: 1,
              VendorID: 691,
              providerID: 691,
              providerAppURL:
                "https://uat.hhaexchange.com/PROVIDER2104010000/caregiver-availability",
              entMainURL: "http://development.hhaexchange.com/HRCG-2111/",
            },
          },
        },
        {
          provide: ToastrAlertService,
          useValue: {
            error: () =>
              of("error", "There was error while fetching Office(s)."),
            success: () => of("success", "Note Saved Successfully"),
          },
        },
        {
          provide: HHAUserService,
          useValue: {
            getUserID: () => of(37485),
            getUserName: () => of("test"),
            getUserFullName: () => of("Test Test"),
          },
        },
        DatePipe,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    let fixture: ComponentFixture<CertificationPeriodComponent>;
    fixture = TestBed.createComponent(CertificationPeriodComponent);
    component = fixture.componentInstance;
    component.worklistDetail = inputData; // set input before first detectChanges
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should call on submit", async () => {
    component.onSubmit();
    spyOn(component, "onSubmit");
    expect(component.searchWorkLists).toBeDefined();
  });

  it("should call reset", () => {
    component.nurseOptions = [{ text: "option", value: 1 }];
    component.physicianOptions = [{ text: "option", value: 1 }];
    component.onReset();
    expect(component.searchWorkLists).toBeDefined();
    component.onAssigneeClick(mockRecord, {});
  });

  it("should call openPopUp", () => {
    spyOn(component, "openWindowPopUp");
    component.openPopUp({ data: { isInternalPatient: true } });
    expect(component.openWindowPopUp).toBeDefined();
  });

  it("should call on openNote", async () => {
    component.openNote(mockRecord);
    spyOn(component, "openNote");
    expect(component.openAddNoteDialog).toBeDefined();
  });

  it("should test action button", async () => {
    expect(component.worklistDetail.canAssignWorklistTask).toEqual("No");
    expect(component.worklistDetail.canManuallyCloseWorklistTask).toEqual("No");
    await component.actionButtons[0].handler(mockBulkRecords);
    await component.actionButtons[1].handler(mockBulkRecords);
    await component.actionButtons[2].handler(mockBulkRecords);
    await component.actionButtons[3].handler(mockBulkRecords);
    await component.actionButtons[4].handler(mockBulkRecords);
  });

  it("should call getNurseOptions", async () => {
    component.getNurseOptions({});
    expect(component._searchservice.getNurseOptions).toBeDefined();
  });

  it("should call onPopUpClose", async () => {
    component.onPopUpClose(
      { data: mockRecord },
      Worklist.CERTIFICATION_PERIOD,
      Function
    );
    expect(component._worklist.closingCondition).toBeDefined();
  });
});
