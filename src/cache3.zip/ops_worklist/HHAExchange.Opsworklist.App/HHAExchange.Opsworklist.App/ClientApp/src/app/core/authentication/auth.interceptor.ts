import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HHAUserService } from '../authentication/user.service';


@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private _userService: HHAUserService) { }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    let requestToForward = req;

    const user = this._userService.getUser();
   
    if (user !== null && user !== undefined && this._userService.isLoggedIn()) {
      
      requestToForward = req.clone({
        setHeaders: {
          Authorization: `Bearer ${user.access_token}`,
          'Cache-Control': 'no-cache',
          Pragma: 'no-cache',
          Expires: 'Sat, 01 Jan 2000 00:00:00 GMT',
          'If-Modified-Since': '0'
        }
      });
    }

    return next.handle(requestToForward);
  }
}
