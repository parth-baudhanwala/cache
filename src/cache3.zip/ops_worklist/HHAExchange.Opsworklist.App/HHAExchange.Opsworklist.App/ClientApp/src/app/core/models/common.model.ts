import { Defaultparam } from "./defaultparam.model";

export interface UserOffice {
  officeID: number;
  officeName: string;
  isPrimary: boolean;
}

export interface AppConfiguration {
  appName: string;
  version: number;
  minorVersion: number;
  vendorName: string;
  userName: string;
  agencyID: number;
  entMainURL: string;
  entpurl?: any;
  workLists: WorklistDetail[];
  userOffices: UserOffice[];
  instrumentationKey: string;
  appsecret: string;
  hhawsenturl?: any;
  opsworklistAPIURL?: any;
  providerAppURL?: any;
  ApiUrl: string;
  userId: number;
  sessionID: string;
  entapiurl: string;
  mobileChatUrl: string;
  mobileChatAccess: boolean;
}

export interface AppSettings {
  ChangePassword: string;
  ContactSupportRedirectUrl: string;
  LiveChat: string;
  MFACookieName: string;
  MFASettings: string;
  RemoteSupport: string;
  SupportCenterRedirectUrl: string;
  TXSupportCenterRedirectUrl: string;
  FileSizeLimit: number;
  EmailFileSizeLimit: number;
  AllowedFileTypes: string;
  ReskinSupportCenterRedirectUrl: string;
  TXPaidSupportCenterRedirectUrl: string;
  ProviderAdminAPIUrl: string;
  MaxProviderDisciplinesOfficeResponseCount: number;
}

export interface UpdateTaskRequest {
  WlTaskId: string;
  AssignedBy?: number;
  AssignedTo?: number;
  AssignedByUser?: string;
  AssignedToUser?: string;
  Status?: string;
  UpdatedBy: number;
  UpdatedByUser: string;
}

export interface IPutResponse {
  responseBody: string;
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface MultiSelect {
  text: string;
  value: number | string;
}

export enum Worklist {
  MEDICAL_COMPLIANCE = "MedicalCompliance",
  EXPIRING_AUTHORIZATION = "ExpiringAuthorization",
  UNSTAFFED_VISITS = "UnstaffedVisits",
  MASTER_WEEK = "MasterWeek",
  CERTIFICATION_PERIOD = "ExpiringCertificationPeriod",
  MEDICAL_COMPLIANCE_SETUP = "MedicalComplianceSetup",
  EXPIRING_AUTHORIZATION_SETUP = "ExpiringAuthorizationSetup",
  UNSTAFFED_VISITS_SETUP = "UnstaffedVisitsSetup",
  MASTER_WEEK_SETUP = "MasterWeekSetup",
  CERTIFICATION_PERIOD_SETUP = "ExpiringCertificationPeriodSetup"
}

export enum WorklistName {
  MEDICAL_COMPLIANCE = "Expiring Caregiver Medical/Other Compliance",
  EXPIRING_AUTHORIZATION = "Expiring Authorization",
  UNSTAFFED_VISITS = "Unstaffed Visits",
  MASTER_WEEK = "Expiring Master Week",
  CERTIFICATION_PERIOD = "Expiring Certification Period"
}

export interface PageInfo {
  totalRecordCount: number;
}

export interface PaginationResult<T> {
  pageInfo: PageInfo;
  data: T[];
}

export interface DefaultSearchFields {
  worklistTaskId: number;
  worklistId: number;
  worklistEntKey: string;
  assignedBy: number;
  assignedTo: number;
  assignedByUser: string;
  assignedToUser: string;
  createdDate: Date;
  status: string;
  lastNotes: any;
}

export interface MedicalComplianceModel extends DefaultSearchFields {
  expirationItemType: string;
  expirationItem: string;
  dueDate: Date;
  careGiverId: string;
  careGiverTeamId: number;
  careGiverFullName: string;
  careGiverFirstname: string;
  careGiverLastname: string;
  careGiverMiddlename: string;
}

export interface ExpiringAuthorizationTaskModel extends DefaultSearchFields {
  expirationItemType: string;
  expirationItem: string;
  dueDate: Date;
  PatientId: number;
  careGiverTeamId: number;
  PatientName: string;
  ContractName: string;
  CoordinatorName: string;
  AdmissionId: string;
  PatientFirstname: string;
  PatientLastname: string;
  PatientMiddlename: string;
  AuthorizationNumber: string;
}

export interface DisciplineResponseBody {
  disciplineID: number;
  discipline: string;
}

export interface IDisciplineModel {
  responseBody: DisciplineResponseBody[];
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface OfficesDisciplinesApiResponse {
  message: string;
  payload: DisciplinesOfficeResponse;
  success: string;
  error: object;
}

export interface DisciplinesOfficeResponse {
  office: DisciplinesResponse[] | null;
  isMaxAllowedResponseCountExceeded: boolean;
  maxAllowedResponseCount: number;
}

export interface DisciplinesResponse {
  officeId: number;
  officeDisciplines: OfficesDisciplines[] | null;
}

export interface OfficesDisciplines {
  disciplineId: number;
  discipline: string;
  disciplineType: number;
  description: string;
  selected: boolean;
}

export interface LanguageResponseBody {
  languageID: number;
  language: string;
}

export interface ILanguageModel {
  responseBody: LanguageResponseBody[];
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export class OfficesDisciplinesRequestParam {
  id: number[] | null;

  constructor(id: number[] | null) {
    this.id = id;
  }
}

export interface IParams {
  UserID: number;
  LocationID: number;
  Active: number;
  PatientID: number;
  AideID: number;
  OfficeXml: any;
  AppVersion: string;
  Version: number;
  MinorVersion: number;
  VendorID: number;
  OfficeId: string;
}

export interface IAuthenticationParams {
  UserID: number;
  SessionID: string,
  AppVersion: string;
  Version: number;
  MinorVersion: number;
}

export interface GetContractResponseBody {
  sourceID: number;
  sourceName: string;
}

export interface IGetContractDetailsModel {
  responseBody: GetContractResponseBody[];
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface IGetCoordinatorsByIDModel {
  responseBody: any[];
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

// export interface IGetLocationForOfficeResponseBody {
//   officeName: string;
//   office: number;
//   officeID: number;
//   parentID: number;
//   isLeaf: number;
//   level: number;
//   hirarchyLevel: number;
//   type: number;
//   parent?: any;
//   sortOrder: number;
// }

export interface IGetLocationForOfficeResponseBody {
  branchID: number;
  branchName: string;
}

export interface IGetLocationForOfficeModel {
  responseBody: IGetLocationForOfficeResponseBody[];
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface IGetCaregiverTeamModel {
  caregiverTeamID: number;
  caregiverTeam: string;
}

export interface IUserDetailsModel {
  isUserLoggedIn: boolean;
  officeID: any;
}

export interface IPatientTeamModel {
  patientTeamID: number;
  patientTeam: string;
}

export interface IGetLocationResponseBody {
  locationID: number;
  location: string;
}

export interface IGetLocationModel {
  responseBody: IGetLocationResponseBody[];
  httpStatusCode: number;
  httpStatusMessage?: any;
  authenticationToken?: any;
}

export interface IAssignUser {
  WorklistID: number;
  OfficeIDs: string;
}
export interface workListCount {
  worklistID: number;
  taskCount: number;
}

export interface WorklistDetail {
  userName: string;
  worklistId: number;
  worklistName: string;
  worklistPath: string;
  canManuallyCloseWorklistTask: string | boolean;
  canAssignWorklistTask: string | boolean;
  isOpsWorklistLandingPage: any;
  assignedDefaultWorklist: number;
  taskCount?: number;
}

export interface worklistTab {
  title: string;
  id: number;
  path: string;
  taskCount?: number;
  worklistId: number;
  detail: WorklistDetail;
}

export enum TypeAheadCriteria {
  Contains = 0,
  StartsWith = 1,
}

export interface caregiverAutocomplete {
  caregiverId?: number;
  caregiver: string;
  providerId: number;
  officeId: string;
  criteria: TypeAheadCriteria;
  count: number;
}

export interface patientAutocomplete {
  worklistPath: string;
  patientId?: number;
  patient: string;
  providerId: number;
  officeId: string;
  criteria: TypeAheadCriteria;
  count: number;
}

export interface TaskCount {
  userID: number;
  providerID: number;
}

export class closingConditionParams extends Defaultparam {
  entKeys: string[];
  worklistId: number;
  UpdatedByUser: string;
  isFromOpsWorklist = true;
}

export interface downloadFileResponse {
  contentType: string;
  downloadMessage: null;
  fileData: string;
  fileName: string;
  fileStatus: boolean;
}

export interface INurseModel {
  nurseID: number;
  nurseName: string;
}

export interface IPhysicianModel {
  physicianID: number;
  physicianName: string;
}

export class MasterWeekInfoParams extends Defaultparam {
  masterWeekHeaderID: number;
  PatientID: number;
}

export class MasterWeekInfoResponse {
  sunday: any;
  monday: any;
  tuesday: any;
  wednesday: any;
  thursday: any;
  friday: any;
  saturday: any;
}

export interface physicianAutocomplete {
  worklistPath: string;
  physicianId?: number;
  physician: string;
  criteria: TypeAheadCriteria;
  count: number;
}
