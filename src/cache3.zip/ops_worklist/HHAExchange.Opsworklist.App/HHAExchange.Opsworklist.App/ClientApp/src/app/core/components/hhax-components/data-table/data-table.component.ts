import {
  AfterViewInit,
  Component,
  ComponentFactory,
  ComponentFactoryResolver,
  ComponentRef,
  ContentChild,
  ContentChildren,
  Directive,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  QueryList,
  SimpleChanges,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
} from "@angular/core";

import { ActionButton, DataRow, TableColumn } from "./model";

import { DataTableRowDefinition } from "./rows";
import { CellCheckboxComponent, CellActionComponent } from "./cells";
import { SortDirection, Sort } from "./datasource/model/transport";
import { ToolbarComponent } from "./toolbar/toolbar.component";
import { coerceBooleanProperty } from "@angular/cdk/coercion";
import { Guid } from "guid-typescript";
import { SpinnerComponent } from "hhax-components";

declare var $: any;

@Directive({
  selector: "[hhaxCell]",
})
export class CellDefinition {
  constructor(public template: TemplateRef<any>) {}
}

@Directive({
  selector: "[hhaxColumnRef]",
})
export class ColumnReference {
  @Input("hhaxColumnRef") name: string;

  @ContentChild(CellDefinition, { static: true }) cell: CellDefinition;

  constructor(public _viewContainer: ViewContainerRef) {}
}

@Directive({ selector: "[hhaxCellOutlet]" })
export class CellOutlet implements OnDestroy {
  static currentCellOutletInstance: CellOutlet = null;

  context: any;

  column: any;

  constructor(public _viewContainer: ViewContainerRef) {
    CellOutlet.currentCellOutletInstance = this;
  }

  ngOnDestroy(): void {
    CellOutlet.currentCellOutletInstance = null;
  }
}

@Component({
  selector: "hhax-table",
  templateUrl: "./data-table.component.html",
  styleUrls: ["./data-table.component.scss"],
})
export class HhaxTableComponent<T = any> implements AfterViewInit, OnChanges {
  @Input("selectable")
  get getSelectable(): boolean {
    return this._selectable;
  }
  set getSelectable(v: boolean) {
    this._selectable = coerceBooleanProperty(v);
  }
  _selectable: boolean;

  @Input() actions: ActionButton<any>[];
  @Input() columns: TableColumn<any>[];
  @Input() data: T[];
  @Input() tableTitle: string;
  @Input() filterSrText: string;

  @Output() sortChange: EventEmitter<Sort> = new EventEmitter();

  @ViewChild("spinnerOutlet", { read: ViewContainerRef, static: true })
  spinnerOutlet: ViewContainerRef;
  @ViewChild("table", { static: true, read: ViewContainerRef })
  _containerRef: ViewContainerRef;
  @ViewChild("toolbar", { read: ViewContainerRef, static: true })
  private _toolbar: ViewContainerRef;
  @ViewChild("rowOutlet", { read: ViewContainerRef, static: true })
  private _rowOutlet: ViewContainerRef;
  @ViewChild(CellDefinition, { static: true })
  private _cellTemplate: CellDefinition;
  @ViewChild(CellCheckboxComponent, { static: true })
  private _cellCheckboxTemplate: CellCheckboxComponent;
  @ViewChild(CellActionComponent, { static: true })
  private _cellActionTemplate: CellActionComponent;
  @ViewChild(DataTableRowDefinition, { static: true })
  private _row: DataTableRowDefinition;

  @ContentChildren(ColumnReference, { descendants: true })
  private _columnReferences: QueryList<ColumnReference>;
  @ContentChild(ToolbarComponent, { static: true })
  private _toolbarTemplate: ToolbarComponent;
  @ContentChild(CellCheckboxComponent, { static: true })
  private _contentCellCheckboxTemplate: CellCheckboxComponent;

  rows: DataRow<T>[] = [];
  sort: Sort = { direction: SortDirection.Ascending, item: "CreatedDate" };
  totalRecordCount = 0;
  totalColumns = 0;
  srText: string;

  private readonly _spinnerFactory: ComponentFactory<SpinnerComponent>;
  private _spinnerInstance: ComponentRef<SpinnerComponent>;

  constructor(private _componentFactory: ComponentFactoryResolver) {
    this._spinnerFactory =
      this._componentFactory.resolveComponentFactory(SpinnerComponent);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.data && changes.data.currentValue != undefined) {
      this.setTableRowData();
      this.renderRows();
    }
    if (
      (changes.columns && changes.columns.currentValue != undefined) ||
      (changes.actions && changes.actions.currentValue != undefined) ||
      (changes.selectable && changes.selectable.currentValue != undefined)
    ) {
      this.totalColumns = this.columns.length;
      if (this._selectable) this.totalColumns++;
      if (this.actions) this.totalColumns++;
    }
  }

  ngAfterViewInit(): void {
    if (this._toolbarTemplate) {
      this._renderToolbar();
    }

    if (this.data) {
      this.setTableRowData();
      this.renderRows();
    }
  }

  setTableRowData() {
    this.rows = this.data.map<DataRow<T>>((record) => ({ data: record }));
  }

  showLoadingIcon(): void {
    if (!this._spinnerInstance) {
      const spinnerComponentRef = this.spinnerOutlet.createComponent(
        this._spinnerFactory
      );
      spinnerComponentRef.instance.fillContainer = true;
      spinnerComponentRef.instance.show = true;

      this._spinnerInstance = spinnerComponentRef;
    }
  }

  hideLoadingIcon(): void {
    if (this._spinnerInstance) {
      this._spinnerInstance.destroy();
      this._spinnerInstance = null;
    }
  }

  renderRows(): void {
    this.clearRows();
    this.rows.forEach((dataRow, index) => {
      this._rowOutlet.createEmbeddedView(this._row._templateRef);

      if (this._selectable) {
        this._renderCheckbox(dataRow, index);
      }

      this.columns.forEach((column) => {
        const customCellTemplate = this._columnReferences?.find(
          (columnRef) => columnRef.name === column.key
        );
        CellOutlet.currentCellOutletInstance._viewContainer.createEmbeddedView(
          customCellTemplate
            ? customCellTemplate.cell.template
            : this._cellTemplate.template,
          { $implicit: dataRow, column }
        );
      });

      CellOutlet.currentCellOutletInstance._viewContainer.createEmbeddedView(
        this._cellActionTemplate._template,
        { $implicit: this.actions, dataRow, rowIndex: index }
      );

      this.setSrText();
    });
    // Foundation scripting is awful when trying to integrate with an Angular app. Because the scripts here usually get
    // run before anything is actually written to the DOM, the call to hook up foundation functionality to the action
    // column is getting run before any items are actually rendered. This timeout should give the app enough time to
    // finish rendering. Not thrilled about this solution, but it is temporary. The action column is a type of button that will
    // be added very soon.
    setTimeout(() => {
      if (typeof $ !== "undefined") {
        $(".dropdown-pane").foundation();
      }
    }, 1000);
  }

  clearRows(): void {
    this._rowOutlet.clear();
    this.setSrText();
  }

  areAllRowsChecked() {
    return this.rows.length && !this.rows.some((r) => !r.selected);
  }

  checkAllRows(checked: boolean): void {
    this.rows.forEach((row) => (row.selected = checked));
  }

  getSelectedRows(): any[] {
    return this.rows.filter((row) => row.selected).map((row) => row.data);
  }

  sortColumn(key: string): void {
    if (this.totalRecordCount == 0) {
      return;
    }

    if (this.sort.item !== key) {
      this.sort.item = key;
      this.sort.direction = SortDirection.Ascending;
    } else {
      this.sort.direction =
        this.sort.direction === SortDirection.Ascending
          ? SortDirection.Descending
          : SortDirection.Ascending;
    }

    this.sortChange.emit(this.sort);
  }

  private _renderToolbar(): void {
    this._toolbar.createEmbeddedView(this._toolbarTemplate._templateRef);
  }

  private _renderCheckbox(dataRow: DataRow<any>, index: number) {
    const preferredTemplate = this._contentCellCheckboxTemplate
      ? this._contentCellCheckboxTemplate._template
      : this._cellCheckboxTemplate._template;

    dataRow.guid = Guid.create();

    CellOutlet.currentCellOutletInstance._viewContainer.createEmbeddedView(
      preferredTemplate,
      {
        $implicit: dataRow,
        rowIndex: index,
      }
    );
  }
  private setSrText(): void {
    this.srText = `Showing ${this.data ? this.data.length : 0} records in ${
      this.filterSrText
    }. Navigate manually to access the table results.`;
    setTimeout(() => {
      this.srText = "";
    }, 700);
  }
}
