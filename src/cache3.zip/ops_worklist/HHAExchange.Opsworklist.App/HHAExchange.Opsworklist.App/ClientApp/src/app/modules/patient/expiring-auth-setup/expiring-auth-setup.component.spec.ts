import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpiringAuthSetupComponent } from './expiring-auth-setup.component';

describe('ExpiringAuthSetupComponent', () => {
  let component: ExpiringAuthSetupComponent;
  let fixture: ComponentFixture<ExpiringAuthSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExpiringAuthSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpiringAuthSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
