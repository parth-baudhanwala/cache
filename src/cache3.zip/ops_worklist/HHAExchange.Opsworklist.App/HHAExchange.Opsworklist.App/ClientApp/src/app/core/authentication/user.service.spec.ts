import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { getTestBed, TestBed } from "@angular/core/testing";
import { HHAUserService } from "./user.service";
import { ConfigurationService } from "../services/configuration.service";

describe("HHAUserService", () => {
  let service: HHAUserService;
  let sessionServiceData: ConfigurationService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ConfigurationService, { provide: "HOST", useValue: "test" }],
    });
    injector = getTestBed();
    service = injector.inject(HHAUserService);
    httpMock = injector.inject(HttpTestingController);
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpMock.verify();
  });

  it("HHAUserService should be created", () => {
    expect(service).toBeDefined();
  });
  it("getDefaultRoute should be created", () => {
    const value = "";
    expect(value).toEqual("");
    service.getDefaultRoute();
  });

  it("getUserFullName should be created", () => {
    service.getUserFullName();
    expect(service.isLoggedIn).toBeDefined();
  });

  it("setUserManager should be created", () => {
    spyOn(service, "setUserManager");
    service.setUserManager();
    service.startAuthentication();
    service.completeAuthentication();
    service.completeSilentRefresh();
    service.startSilentRefresh();
    service.revokeAccessToken();
    service.getAuthorizationHeaderValue();
    expect(service.setUserManager).toHaveBeenCalled();
  });

  it("getClaims should be created", () => {
    service.getClaims();
    service.timeOutUser();
    expect(service.getClaims()).toBeFalsy();
  });

  it("isLoggedIn should be created", () => {
    service.getUserName();
    service.getUserID();
    service.getVendorID();
    service.getUserFullName();
    service.getAuthorizationHeaderValue();
    service.getAccessToken();
    expect(service.isLoggedIn).toBeDefined();
  });
  it("getUser should be created", () => {
    service.getUser();
    expect(service.getUser).toBeDefined();
  });

  it("logoutUser(); should be created", () => {
    service.logoutUser();
    expect(service.logoutUser).toBeDefined();
  });
});
