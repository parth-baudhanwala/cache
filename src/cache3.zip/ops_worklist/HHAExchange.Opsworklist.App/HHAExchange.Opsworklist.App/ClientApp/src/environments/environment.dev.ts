export const environment = {
  production: false,
  name: 'dev',
  apiUrl: 'http://localhost:5000',
  ssoEnabled: true,
  timeouts: {
    idle: 120,
    sessionTimeOut: 1200,
    sessionTimeOutOffset: 20,
    timeOutModalDuration: 60,
    keepAlive : 1800
  }
};
