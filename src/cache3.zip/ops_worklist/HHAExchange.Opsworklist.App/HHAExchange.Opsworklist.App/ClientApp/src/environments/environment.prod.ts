export const environment = {
  production: true,
  name: 'prod',
  apiUrl: 'http://localhost:5000',
  ssoEnabled: true,
  timeouts: {
    idle: 120,
    sessionTimeOutOffset: 20,
    timeOutModalDuration: 60,
    keepAlive : 1800
  }
};
